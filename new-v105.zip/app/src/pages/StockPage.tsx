import { useState, useRef, useEffect, useMemo } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import type { StockItem } from "@/services/stockService";
import {
  loadStockData, saveStockData, loadStockMeta, saveStockMeta,
  parseFinalFile, parseLoglabFile, parseDealerFile,
  mergeStockData, searchStock, exportStockToExcel,
  getAllWarehouses, getWarehouseTotals,
} from "@/services/stockService";
import {
  Package, Upload, Download, Search, X, Warehouse,
  TrendingUp, Filter, BarChart3,
} from "lucide-react";

export default function StockPage() {
  const [items, setItems] = useState<StockItem[]>(loadStockData);
  const [searchQuery, setSearchQuery] = useState("");
  const [meta, setMeta] = useState<Record<string, string>>(loadStockMeta);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterBrand, setFilterBrand] = useState("all");
  const [showOnlyInStock, setShowOnlyInStock] = useState(true);

  const finalRef = useRef<HTMLInputElement>(null);
  const loglabRef = useRef<HTMLInputElement>(null);
  const dealerRef = useRef<HTMLInputElement>(null);

  // All unique warehouses with stock
  const warehouses = useMemo(() => getAllWarehouses(items), [items]);
  const warehouseTotals = useMemo(() => getWarehouseTotals(items), [items]);

  // Split warehouses by source
  const rcWarehouses = useMemo(() => warehouses.filter((w) => w.startsWith("РЦ ")), [warehouses]);
  const dealerWarehouses = useMemo(() => warehouses.filter((w) => !w.startsWith("РЦ ")), [warehouses]);

  const filtered = useMemo(() => {
    let result = searchQuery.trim() ? searchStock(items, searchQuery) : [...items];
    if (filterCategory !== "all") result = result.filter((it) => it.category === filterCategory);
    if (filterBrand !== "all") result = result.filter((it) => it.brand === filterBrand);
    if (showOnlyInStock) result = result.filter((it) => Object.values(it.stockByWarehouse).some((q) => q > 0));
    return result;
  }, [items, searchQuery, filterCategory, filterBrand, showOnlyInStock]);

  const categories = useMemo(() => [...new Set(items.map((it) => it.category).filter(Boolean))].sort(), [items]);
  const brands = useMemo(() => [...new Set(items.map((it) => it.brand).filter(Boolean))].sort(), [items]);

  const stats = useMemo(() => {
    const withStock = items.filter((it) => Object.values(it.stockByWarehouse).some((q) => q > 0)).length;
    const totalQty = Object.values(warehouseTotals).reduce((s, v) => s + v, 0);
    return { total: items.length, withStock, totalQty };
  }, [items, warehouseTotals]);

  const handleUpload = async (type: "final" | "loglab" | "dealer", file: File) => {
    setIsLoading(true);
    setError("");
    try {
      let currentItems = [...items]; // Use current React state, not localStorage!
      let loglabMap = new Map<string, Record<string, number>>();
      let dealerMap = new Map<string, Record<string, number>>();

      if (type === "final") {
        currentItems = await parseFinalFile(file);
        setMeta({ lastfinalUpload: new Date().toISOString() });
      } else if (type === "loglab") {
        if (currentItems.length === 0) { setError("Сначала загрузите «Финал для B2B»"); setIsLoading(false); return; }
        loglabMap = await parseLoglabFile(file);
        setMeta((m) => ({ ...m, lastloglabUpload: new Date().toISOString() }));
      } else if (type === "dealer") {
        if (currentItems.length === 0) { setError("Сначала загрузите «Финал для B2B»"); setIsLoading(false); return; }
        dealerMap = await parseDealerFile(file);
        console.log("[Stock] Dealer map size:", dealerMap.size);
        console.log("[Stock] Dealer map keys (first 5):", Array.from(dealerMap.keys()).slice(0, 5));
        console.log("[Stock] Base items (first 3 KSSS):", currentItems.slice(0, 3).map((it) => it.ksss));
        setMeta((m) => ({ ...m, lastdealerUpload: new Date().toISOString() }));
      }

      currentItems = mergeStockData(currentItems, loglabMap, dealerMap);
      setItems(currentItems);
      saveStockData(currentItems);
    } catch (err) {
      setError("Ошибка: " + String(err));
    }
    setIsLoading(false);
  };

  const handleExport = () => {
    if (items.length === 0) return;
    const data = exportStockToExcel(items, warehouses);
    const blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Остатки_склады_${new Date().toISOString().split("T")[0]}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Cell color by qty
  const qtyColor = (qty: number) => {
    if (qty <= 0) return "text-gray-200";
    if (qty < 1) return "text-amber-600";
    return "text-green-700";
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)] bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Warehouse className="h-6 w-6 text-[#0d9488]" />
                Остатки на складах
              </h1>
              <p className="text-sm text-gray-500 mt-0.5">
                {stats.total} позиций &middot; {stats.withStock} с остатками &middot;
                {warehouses.length} складов &middot; Итого: {Math.round(stats.totalQty * 1000) / 1000} т/шт
              </p>
            </div>
            {items.length > 0 && (
              <Button variant="outline" size="sm" onClick={handleExport} className="gap-1.5">
                <Download className="h-4 w-4" /> Экспорт
              </Button>
            )}
          </div>
        </div>

        <div className="px-6 py-4 space-y-4">
          {/* Upload zone */}
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h2 className="text-sm font-semibold text-gray-700 mb-3">Загрузка файлов</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                { ref: finalRef, type: "final" as const, label: "Финал для B2B", desc: "Базовый каталог", metaKey: "lastfinalUpload" },
                { ref: loglabRef, type: "loglab" as const, label: "Запасы ЛогЛаб", desc: "Остатки по РЦ", metaKey: "lastloglabUpload" },
                { ref: dealerRef, type: "dealer" as const, label: "Остатки дилеров", desc: "Склады дистрибьюторов", metaKey: "lastdealerUpload" },
              ].map((u) => (
                <div
                  key={u.type}
                  onClick={() => u.ref.current?.click()}
                  className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${meta[u.metaKey] ? "border-green-300 bg-green-50" : "border-gray-300 hover:border-[#0d9488]"}`}
                >
                  <Upload className="h-5 w-5 mx-auto mb-1 text-gray-400" />
                  <div className="text-sm font-medium text-gray-700">{u.label}</div>
                  <div className="text-xs text-gray-400">{u.desc}</div>
                  {meta[u.metaKey] && <div className="text-xs text-green-600 mt-1">Загружен</div>}
                  <input ref={u.ref} type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload(u.type, f); e.target.value = ""; }} />
                </div>
              ))}
            </div>
            {error && <div className="mt-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</div>}
          </div>

          {/* Search & Filters */}
          {items.length > 0 && (
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <div className="flex flex-wrap gap-2 items-center">
                <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2 flex-1 min-w-[200px]">
                  <Search className="h-4 w-4 text-gray-400" />
                  <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Поиск по КССС, названию, бренду..." className="bg-transparent text-sm outline-none flex-1" />
                  {searchQuery && <button onClick={() => setSearchQuery("")}><X className="h-4 w-4 text-gray-400" /></button>}
                </div>
                <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-1.5 text-sm px-3 py-2 rounded-lg border ${showFilters ? "bg-[#f0fdfa] border-[#0d9488] text-[#0d9488]" : "border-gray-200 text-gray-600"}`}>
                  <Filter className="h-4 w-4" /> Фильтры
                </button>
              </div>

              {showFilters && (
                <div className="mt-3 flex flex-wrap gap-3 items-end">
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">Категория</label>
                    <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="text-sm border rounded px-2 py-1">
                      <option value="all">Все</option>
                      {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">Бренд</label>
                    <select value={filterBrand} onChange={(e) => setFilterBrand(e.target.value)} className="text-sm border rounded px-2 py-1">
                      <option value="all">Все</option>
                      {brands.map((b) => <option key={b} value={b}>{b}</option>)}
                    </select>
                  </div>
                  <label className="flex items-center gap-1.5 text-sm cursor-pointer">
                    <input type="checkbox" checked={showOnlyInStock} onChange={(e) => setShowOnlyInStock(e.target.checked)} className="accent-[#0d9488]" />
                    Только с остатками
                  </label>
                  {(filterCategory !== "all" || filterBrand !== "all") && (
                    <button onClick={() => { setFilterCategory("all"); setFilterBrand("all"); }} className="text-xs text-gray-400">Сбросить</button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Table with per-warehouse columns */}
          {filtered.length > 0 && (
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto" style={{ maxHeight: "650px" }}>
                <table className="w-full text-xs">
                  <thead className="bg-gray-50 sticky top-0 z-10">
                    <tr>
                      <th className="px-2 py-2 text-left font-medium text-gray-500 border-b min-w-[70px] sticky left-0 bg-gray-50 z-20">КССС</th>
                      <th className="px-2 py-2 text-left font-medium text-gray-500 border-b min-w-[200px]">Наименование</th>
                      <th className="px-2 py-2 text-left font-medium text-gray-500 border-b">Вид</th>
                      <th className="px-2 py-2 text-left font-medium text-gray-500 border-b">Вязкость</th>
                      {/* RC columns */}
                      {rcWarehouses.map((wh) => (
                        <th key={wh} className="px-2 py-2 text-right font-medium text-amber-700 border-b min-w-[70px] bg-amber-50">
                          {wh.replace("РЦ ", "")}
                          <div className="text-[10px] text-amber-500">{Math.round((warehouseTotals[wh] || 0) * 1000) / 1000}</div>
                        </th>
                      ))}
                      {/* Dealer columns */}
                      {dealerWarehouses.map((wh) => (
                        <th key={wh} className="px-2 py-2 text-right font-medium text-purple-700 border-b min-w-[100px] bg-purple-50">
                          {wh.length > 20 ? wh.slice(0, 18) + ".." : wh}
                          <div className="text-[10px] text-purple-500">{Math.round((warehouseTotals[wh] || 0) * 100) / 100}</div>
                        </th>
                      ))}
                      <th className="px-2 py-2 text-right font-medium text-green-700 border-b min-w-[70px] bg-green-50">ИТОГО</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((it) => {
                      const total = Object.values(it.stockByWarehouse).reduce((s, v) => s + v, 0);
                      return (
                        <tr key={it.ksss} className="border-b border-gray-50 hover:bg-gray-50">
                          <td className="px-2 py-1.5 font-mono text-[11px] sticky left-0 bg-white hover:bg-gray-50 z-10">{it.ksss}</td>
                          <td className="px-2 py-1.5 max-w-[250px] truncate" title={it.name}>{it.name}</td>
                          <td className="px-2 py-1.5 text-gray-500">{it.type}</td>
                          <td className="px-2 py-1.5 text-gray-500">{it.viscosity}</td>
                          {rcWarehouses.map((wh) => {
                            const qty = it.stockByWarehouse[wh] || 0;
                            return (
                              <td key={wh} className={`px-2 py-1.5 text-right font-mono ${qtyColor(qty)}`}>
                                {qty > 0 ? (qty < 1 ? qty.toFixed(3) : qty.toFixed(2)) : "—"}
                              </td>
                            );
                          })}
                          {dealerWarehouses.map((wh) => {
                            const qty = it.stockByWarehouse[wh] || 0;
                            return (
                              <td key={wh} className={`px-2 py-1.5 text-right font-mono ${qtyColor(qty)}`}>
                                {qty > 0 ? qty.toFixed(0) : "—"}
                              </td>
                            );
                          })}
                          <td className={`px-2 py-1.5 text-right font-mono font-semibold ${total > 0 ? "text-green-700" : "text-gray-300"}`}>
                            {total > 0 ? total.toFixed(2) : "—"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-2 border-t border-gray-100 text-xs text-gray-400 flex justify-between">
                <span>Показано {filtered.length} из {items.length}</span>
                <span>{warehouses.length} складов</span>
              </div>
            </div>
          )}

          {items.length === 0 && !isLoading && (
            <div className="text-center py-16 text-gray-400">
              <Warehouse className="h-16 w-16 mx-auto mb-3 opacity-20" />
              <p className="text-lg font-medium">Нет данных</p>
              <p className="text-sm mt-1">Загрузите: Финал + ЛогЛаб + Дилеры</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
