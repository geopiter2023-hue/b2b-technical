import { useState, useRef, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Send, ImageIcon, X, Trash2 } from "lucide-react";

interface TaskChatProps {
  taskId: number;
}

export default function TaskChat({ taskId }: TaskChatProps) {
  const [message, setMessage] = useState("");
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const utils = trpc.useUtils();

  const { data: comments, isLoading } = trpc.comment.list.useQuery(
    { taskId },
    { enabled: taskId > 0, staleTime: 0 }
  );

  const createComment = trpc.comment.create.useMutation({
    onSuccess: () => {
      utils.comment.list.invalidate({ taskId });
      setMessage("");
      setImageBase64(null);
      setImageName(null);
    },
  });

  const deleteComment = trpc.comment.delete.useMutation({
    onSuccess: () => {
      utils.comment.list.invalidate({ taskId });
    },
  });

  // Auto-scroll to bottom on new comments
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [comments]);

  const handleSend = () => {
    if (!message.trim() && !imageBase64) return;
    createComment.mutate({
      taskId,
      message: message.trim() || " ",
      imageUrl: imageBase64 || undefined,
    });
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Файл слишком большой (макс 5MB)");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setImageBase64(result);
        setImageName(file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "";
    const d = new Date(date);
    return d.toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <Card className="mt-6 border-red-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <span className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-red-700 text-xs font-bold">
            {comments?.length || 0}
          </span>
          Обсуждение
        </CardTitle>
      </CardHeader>
      <Separator />
      <CardContent className="p-0">
        {/* Messages */}
        <ScrollArea className="h-[350px]" ref={scrollRef as any}>
          <div className="p-4 space-y-4">
            {isLoading ? (
              <p className="text-sm text-gray-400 text-center py-8">Загрузка сообщений...</p>
            ) : comments?.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">
                Нет сообщений. Напишите первый комментарий.
              </p>
            ) : (
              [...(comments || [])].reverse().map((comment) => (
                <div key={comment.id} className="flex gap-3 group">
                  <Avatar className="w-8 h-8 flex-shrink-0 bg-red-100 text-red-700">
                    <AvatarFallback className="bg-red-100 text-red-700 text-xs font-bold">
                      {(comment.userName || "B").charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-800">
                        {comment.userName || "B2B"}
                      </span>
                      <span className="text-xs text-gray-400">
                        {formatDate(comment.createdAt)}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity text-gray-400 hover:text-red-600"
                        onClick={() => deleteComment.mutate({ id: comment.id })}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                    {comment.message?.trim() && comment.message !== " " && (
                      <p className="text-sm text-gray-700 mt-1 break-words">{comment.message}</p>
                    )}
                    {comment.imageUrl && (
                      <div className="mt-2">
                        <img
                          src={comment.imageUrl}
                          alt="Attachment"
                          className="max-w-[200px] max-h-[200px] rounded-lg border border-gray-200 cursor-pointer hover:opacity-90 transition-opacity object-cover"
                          onClick={() => window.open(comment.imageUrl!, "_blank")}
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        <Separator />

        {/* Input area */}
        <div className="p-3 space-y-2">
          {/* Image preview */}
          {imageBase64 && (
            <div className="flex items-center gap-2 bg-red-50 rounded-lg p-2">
              <img src={imageBase64} alt="Preview" className="h-12 w-12 rounded object-cover" />
              <span className="text-xs text-gray-600 truncate flex-1">{imageName}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-gray-500 hover:text-red-600"
                onClick={() => {
                  setImageBase64(null);
                  setImageName(null);
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          <div className="flex gap-2">
            <Input
              placeholder="Напишите комментарий..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1"
            />
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={handleImageSelect}
              className="hidden"
            />
            <Button
              variant="outline"
              size="icon"
              className="border-red-300 text-red-700 hover:bg-red-50 flex-shrink-0"
              onClick={() => fileInputRef.current?.click()}
              title="Прикрепить фото"
            >
              <ImageIcon className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              className="bg-red-700 hover:bg-red-800 text-white flex-shrink-0"
              onClick={handleSend}
              disabled={createComment.isPending || (!message.trim() && !imageBase64)}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
