import { useState, useRef, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ZoomIn,
  ZoomOut,
  Download,
  ArrowLeft,
} from "lucide-react";
import { Link } from "react-router";
import jsPDF from "jspdf";

const statusColors: Record<string, string> = {
  not_started: "#9CA3AF",
  planning: "#FCD34D",
  in_progress: "#DC2626",
  review: "#A855F7",
  completed: "#10B981",
  cancelled: "#EF4444",
};

const statusMap: Record<string, string> = {
  not_started: "Не начата",
  planning: "В планировании",
  in_progress: "В работе",
  review: "На проверке",
  completed: "Завершена",
  cancelled: "Отменена",
};

export default function GanttPage() {
  const { data: tasksData } = trpc.task.list.useQuery({
    limit: 200,
    sortBy: "startDate",
    sortOrder: "asc",
  });

  const [scale, setScale] = useState<"week" | "month">("week");
  const [zoom, setZoom] = useState(1);
  const ganttRef = useRef<HTMLDivElement>(null);

  const tasks = tasksData?.list || [];

  const { minDate, maxDate, timeline } = useMemo(() => {
    const allDates = tasks
      .filter((t) => t.startDate && t.endDate)
      .flatMap((t) => [new Date(t.startDate!), new Date(t.endDate!)]);

    if (allDates.length === 0) {
      const now = new Date();
      return {
        minDate: now,
        maxDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000),
        timeline: [],
      };
    }

    const min = new Date(Math.min(...allDates.map((d) => d.getTime())));
    const max = new Date(Math.max(...allDates.map((d) => d.getTime())));
    min.setDate(min.getDate() - 7);
    max.setDate(max.getDate() + 14);

    const items: { label: string; date: Date }[] = [];
    const curr = new Date(min);

    if (scale === "week") {
      while (curr <= max) {
        const weekStart = new Date(curr);
        const weekEnd = new Date(curr);
        weekEnd.setDate(weekEnd.getDate() + 6);
        items.push({
          label: `${weekStart.getDate()}.${weekStart.getMonth() + 1}-${weekEnd.getDate()}.${weekEnd.getMonth() + 1}`,
          date: new Date(curr),
        });
        curr.setDate(curr.getDate() + 7);
      }
    } else {
      while (curr <= max) {
        items.push({
          label: `${curr.toLocaleString("ru-RU", { month: "short" })} ${curr.getFullYear()}`,
          date: new Date(curr),
        });
        curr.setMonth(curr.getMonth() + 1);
      }
    }

    return { minDate: min, maxDate: max, timeline: items };
  }, [tasks, scale]);

  const totalDays = Math.max(1, (maxDate.getTime() - minDate.getTime()) / (1000 * 60 * 60 * 24));

  const getTaskPosition = (start: Date | string, end: Date | string) => {
    const s = typeof start === "string" ? new Date(start) : start;
    const e = typeof end === "string" ? new Date(end) : end;
    const left = ((s.getTime() - minDate.getTime()) / (1000 * 60 * 60 * 24)) / totalDays;
    const width = Math.max(0.02, (e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24)) / totalDays;
    return { left: Math.max(0, left * 100), width: Math.min(100, width * 100) };
  };

  const handleExportPdf = async () => {
    if (!ganttRef.current) return;
    try {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        alert("Ошибка создания canvas");
        return;
      }

      const width = Math.min(ganttRef.current.scrollWidth, 3000);
      const height = Math.min(ganttRef.current.scrollHeight, 5000);
      canvas.width = width;
      canvas.height = height;

      // Draw white background
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);

      // Draw timeline header
      const colWidth = timeline.length > 0 ? (width - 200) / timeline.length : 100;
      ctx.font = "12px sans-serif";
      ctx.fillStyle = "#374151";
      ctx.textAlign = "center";

      timeline.forEach((item, i) => {
        const x = 200 + i * colWidth + colWidth / 2;
        ctx.fillText(item.label, x, 20);
        ctx.strokeStyle = "#E5E7EB";
        ctx.beginPath();
        ctx.moveTo(200 + i * colWidth, 30);
        ctx.lineTo(200 + i * colWidth, height);
        ctx.stroke();
      });

      // Draw tasks
      const rowHeight = 40;
      tasks.forEach((task, i) => {
        const y = 50 + i * rowHeight;

        // Task name
        ctx.fillStyle = "#7F1D1D";
        ctx.textAlign = "left";
        ctx.font = "12px sans-serif";
        const name = task.name.length > 28 ? task.name.substring(0, 28) + "..." : task.name;
        ctx.fillText(name, 10, y + 18);

        if (task.startDate && task.endDate) {
          const { left, width: barWidth } = getTaskPosition(task.startDate, task.endDate);
          const barX = 200 + (left / 100) * (width - 200);
          const barW = Math.max(2, (barWidth / 100) * (width - 200));

          // Bar (use fillRect instead of roundRect for compatibility)
          ctx.fillStyle = statusColors[task.status] || "#DC2626";
          ctx.fillRect(barX, y + 8, barW, 20);

          // Progress overlay
          ctx.fillStyle = "rgba(255,255,255,0.3)";
          ctx.fillRect(barX, y + 8, barW * ((task.progress || 0) / 100), 20);
        }
      });

      // Grid line after header
      ctx.strokeStyle = "#E5E7EB";
      ctx.beginPath();
      ctx.moveTo(0, 30);
      ctx.lineTo(width, 30);
      ctx.stroke();

      const pdf = new jsPDF("l", "mm", "a4");
      const imgData = canvas.toDataURL("image/png");
      const pageWidth = 297;
      const pageHeight = 210;
      const imgWidth = pageWidth;
      const imgHeight = (height / width) * pageWidth;

      if (imgHeight <= pageHeight) {
        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      } else {
        let position = 0;
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        let heightLeft = imgHeight - pageHeight;
        while (heightLeft > 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }
      }
      pdf.save("gantt_chart.pdf");
    } catch (err) {
      console.error("PDF export error:", err);
      alert("Ошибка при создании PDF. Попробуйте уменьшить масштаб диаграммы.");
    }
  };

  return (
    <Layout>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Link to="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Диаграмма Ганта</h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Select value={scale} onValueChange={(v: "week" | "month") => setScale(v)}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">По неделям</SelectItem>
                <SelectItem value="month">По месяцам</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={() => setZoom((z) => Math.min(3, z + 0.2))}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              className="border-red-700 text-red-700 hover:bg-red-50"
              onClick={handleExportPdf}
            >
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
          </div>
        </div>

        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div
              ref={ganttRef}
              className="overflow-x-auto"
              style={{ minHeight: "500px" }}
            >
              <div style={{ minWidth: `${Math.max(800, 200 + timeline.length * 100 * zoom)}px` }}>
                {/* Header */}
                <div className="flex border-b bg-gray-50 sticky top-0">
                  <div className="w-[200px] flex-shrink-0 p-3 font-semibold text-sm text-gray-700 border-r">
                    Задача
                  </div>
                  <div className="flex flex-1">
                    {timeline.map((item, i) => (
                      <div
                        key={i}
                        className="flex-shrink-0 p-3 text-center text-xs text-gray-500 border-r border-gray-200"
                        style={{ width: `${100 * zoom}px` }}
                      >
                        {item.label}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Task rows */}
                {tasks.map((task) => {
                  const pos =
                    task.startDate && task.endDate
                      ? getTaskPosition(task.startDate, task.endDate)
                      : null;

                  return (
                    <div key={task.id} className="flex border-b hover:bg-gray-50">
                      <div className="w-[200px] flex-shrink-0 p-3 border-r text-sm text-gray-800 truncate flex items-center gap-2">
                        <Badge
                          className="w-2 h-2 p-0 rounded-full flex-shrink-0"
                          style={{
                            backgroundColor: statusColors[task.status] || "#9CA3AF",
                          }}
                        />
                        <span className="truncate">{task.name}</span>
                      </div>
                      <div className="flex flex-1 relative" style={{ minHeight: "40px" }}>
                        {pos && (
                          <div
                            className="absolute top-2 h-6 rounded-md text-xs text-white flex items-center px-2 overflow-hidden whitespace-nowrap cursor-pointer hover:brightness-110 transition-all"
                            style={{
                              left: `${pos.left}%`,
                              width: `${Math.max(2, pos.width)}%`,
                              backgroundColor: statusColors[task.status] || "#DC2626",
                            }}
                            title={`${task.name} (${statusMap[task.status]})`}
                          >
                            <div
                              className="absolute inset-0 bg-white/20"
                              style={{ width: `${task.progress || 0}%` }}
                            />
                            <span className="relative z-10">
                              {task.progress || 0}%
                            </span>
                          </div>
                        )}
                        {/* Grid lines */}
                        {timeline.map((_, i) => (
                          <div
                            key={i}
                            className="flex-shrink-0 border-r border-gray-100"
                            style={{ width: `${100 * zoom}px` }}
                          />
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <div className="flex flex-wrap gap-3">
          {Object.entries(statusMap).map(([key, label]) => (
            <div key={key} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-sm"
                style={{ backgroundColor: statusColors[key] }}
              />
              <span className="text-sm text-gray-600">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
