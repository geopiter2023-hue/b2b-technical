import { useState, useRef, useEffect, useCallback } from "react";
import Layout from "@/components/Layout";
import type { Product, CardConfig, TemplateOption, CardFields } from "@/types/productCards";
import {
  TEMPLATES, TEMPLATE_CATEGORIES, SEASON_BACKGROUNDS, FONTS,
  FIELD_LABELS, getDefaultConfig,
} from "@/types/productCards";
import {
  loadProducts, saveProducts, loadConfig, saveConfig,
  parseExcelFile, exportCanvasToPng, getDemoProducts, clearProducts,
} from "@/services/productCardService";
import QRCode from "qrcode";

/* ─── Accordion Section ─── */
function Section({ title, icon, children, defaultOpen = false }: {
  title: string; icon: string; children: React.ReactNode; defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-gray-200 rounded-xl mb-2 overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-3 text-left hover:bg-gray-50"
      >
        <span className="flex items-center gap-2 text-sm font-semibold text-gray-800">
          <span className="text-gray-500">{icon}</span>
          {title}
        </span>
        <svg
          className={`w-4 h-4 text-gray-400 transition-transform ${open ? "rotate-180" : ""}`}
          fill="none" stroke="currentColor" viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {open && <div className="px-3 pb-3 border-t border-gray-100">{children}</div>}
    </div>
  );
}

/* ─── Toggle Switch ─── */
function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center justify-between py-1.5 cursor-pointer">
      <span className="text-sm text-gray-700">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-11 h-6 rounded-full transition-colors ${value ? "bg-[#0d9488]" : "bg-gray-300"}`}
      >
        <span className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform shadow ${value ? "translate-x-5" : ""}`} />
      </button>
    </label>
  );
}

/* ─── Text Size Control ─── */
function TextSizeControl({
  label, config, onChange,
}: {
  label: string; config: { size: number; font: string }; onChange: (c: { size: number; font: string }) => void;
}) {
  return (
    <div className="py-2 border-b border-gray-100 last:border-0">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-sm text-gray-700">{label}</span>
        <div className="flex items-center gap-1">
          <button onClick={() => onChange({ ...config, size: Math.max(8, config.size - 1) })} className="w-7 h-7 rounded border border-gray-300 flex items-center justify-center text-gray-600 hover:bg-gray-100">−</button>
          <span className="w-8 text-center text-sm font-medium">{config.size}</span>
          <button onClick={() => onChange({ ...config, size: config.size + 1 })} className="w-7 h-7 rounded border border-gray-300 flex items-center justify-center text-gray-600 hover:bg-gray-100">+</button>
          <span className="text-xs text-gray-500 ml-1">px</span>
        </div>
      </div>
      <select
        value={config.font}
        onChange={(e) => onChange({ ...config, font: e.target.value })}
        className="w-full px-2 py-1.5 text-sm border border-gray-200 rounded-md bg-white"
      >
        {FONTS.map(f => <option key={f} value={f}>{f}</option>)}
      </select>
    </div>
  );
}

/* ─── Position Control ─── */
function PositionControl({
  label, pos, onChange,
}: {
  label: string; pos: { x: number; y: number }; onChange: (p: { x: number; y: number }) => void;
}) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <span className="text-sm text-gray-700 w-24 truncate">{label}</span>
      <div className="flex items-center gap-1">
        <button onClick={() => onChange({ ...pos, y: pos.y - 1 })} className="w-7 h-7 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-100 text-gray-500">↑</button>
        <button onClick={() => onChange({ ...pos, x: pos.x - 1 })} className="w-7 h-7 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-100 text-gray-500">←</button>
        <span className="text-xs text-gray-500 w-16 text-center font-mono">X:{pos.x} Y:{pos.y}</span>
        <button onClick={() => onChange({ ...pos, x: pos.x + 1 })} className="w-7 h-7 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-100 text-gray-500">→</button>
        <button onClick={() => onChange({ ...pos, y: pos.y + 1 })} className="w-7 h-7 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-100 text-gray-500">↓</button>
      </div>
    </div>
  );
}

/* ─── Main Page ─── */
export default function ProductCardsPage() {
  const [products, setProducts] = useState<Product[]>(loadProducts);
  const [config, setConfig] = useState<CardConfig>(loadConfig() || getDefaultConfig());
  const [currentIndex, setCurrentIndex] = useState(0);
  const [photos, setPhotos] = useState<Record<number, string>>({});
  const [uploadedPhotos, setUploadedPhotos] = useState<Record<number, string[]>>({});
  const [draggedOver, setDraggedOver] = useState(false);
  const [exporting, setExporting] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const excelInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const [pendingPhotoProductId, setPendingPhotoProductId] = useState<number | null>(null);

  const currentProduct = products[currentIndex] || null;

  /* Persist */
  useEffect(() => { saveProducts(products); }, [products]);
  useEffect(() => { saveConfig(config); }, [config]);

  /* ─── Canvas Rendering ─── */
  const drawCard = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas || !currentProduct) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = config.width;
    const H = config.height;
    canvas.width = W;
    canvas.height = H;

    /* Background */
    const tmpl = TEMPLATES.find(t => t.key === config.template);
    const r = config.borderRadius;

    ctx.clearRect(0, 0, W, H);

    /* Rounded rect path */
    ctx.beginPath();
    ctx.moveTo(r, 0);
    ctx.lineTo(W - r, 0);
    ctx.quadraticCurveTo(W, 0, W, r);
    ctx.lineTo(W, H - r);
    ctx.quadraticCurveTo(W, H, W - r, H);
    ctx.lineTo(r, H);
    ctx.quadraticCurveTo(0, H, 0, H - r);
    ctx.lineTo(0, r);
    ctx.quadraticCurveTo(0, 0, r, 0);
    ctx.closePath();
    ctx.save();
    ctx.clip();

    /* Background fill */
    if (config.backgroundImage) {
      const img = await loadImage(config.backgroundImage);
      ctx.drawImage(img, 0, 0, W, H);
    } else if (tmpl?.bg) {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, tmpl.bg[0]);
      if (tmpl.bg[1]) grad.addColorStop(1, tmpl.bg[1]);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
    } else {
      ctx.fillStyle = config.colors.primary;
      ctx.fillRect(0, 0, W, H);
    }

    /* Season background overlay */
    if (config.seasonBg) {
      ctx.fillStyle = getSeasonOverlay(config.seasonBg);
      ctx.fillRect(0, 0, W, H);
    }

    /* Template effects */
    if (config.template === "geometry") {
      drawGeometryPattern(ctx, W, H, config.colors.primary);
    } else if (config.template === "gloss") {
      drawGlossEffect(ctx, W, H);
    } else if (config.template === "holographic") {
      drawHoloEffect(ctx, W, H);
    } else if (config.template === "neon") {
      drawNeonEffect(ctx, W, H, config.colors.primary);
    }

    const textColor = tmpl?.textColor || config.colors.text;
    ctx.fillStyle = textColor;
    ctx.textAlign = "left";

    /* ── Logo ── */
    if (config.fields.logo) {
      const ts = config.textSizes.logo;
      ctx.font = `bold ${ts.size}px ${ts.font}`;
      const lp = config.positions.logo;
      ctx.fillText((currentProduct.brand || "LUKOIL").toUpperCase(), (lp.x / 100) * W, (lp.y / 100) * H + ts.size);
    }

    /* ── Dealer badge ── */
    if (config.fields.dealer && config.dealerText) {
      const ts = config.textSizes.dealerBadge;
      ctx.font = `${ts.size}px ${ts.font}`;
      const dp = config.positions.dealer;
      ctx.textAlign = "right";
      ctx.fillText(config.dealerText, (dp.x / 100) * W, (dp.y / 100) * H + ts.size);
      ctx.textAlign = "left";
    }

    /* ── QR Code ── */
    if (config.fields.qrCode) {
      try {
        const qrDataUrl = await QRCode.toDataURL(currentProduct.kccc || "123", { width: 60, margin: 1 });
        const qrImg = await loadImage(qrDataUrl);
        const qp = config.positions.qrcode;
        ctx.drawImage(qrImg, (qp.x / 100) * W, (qp.y / 100) * H, 50, 50);
      } catch { /* ignore QR errors */ }
    }

    /* ── SAE Badge ── */
    if (config.fields.saeBadge && currentProduct.viscosity) {
      const sp = config.positions.saeBadge;
      drawBadge(ctx, currentProduct.viscosity, (sp.x / 100) * W, (sp.y / 100) * H, textColor, "rgba(255,255,255,0.2)");
    }

    /* ── API Badge ── */
    if (config.fields.apiAceaBadge && currentProduct.api) {
      const ap = config.positions.apiAcea;
      const text = [currentProduct.api, currentProduct.acea].filter(Boolean).join(" / ");
      drawBadge(ctx, text, (ap.x / 100) * W, (ap.y / 100) * H, textColor, "rgba(255,255,255,0.15)");
    }

    /* ── ILSAC Logo ── */
    if (config.fields.ilsacLogo && currentProduct.ilsac) {
      const ip = config.positions.ilsac;
      drawBadge(ctx, currentProduct.ilsac, (ip.x / 100) * W, (ip.y / 100) * H, textColor, "rgba(255,255,255,0.15)");
    }

    /* ── Product photo ── */
    const productPhotos = uploadedPhotos[currentProduct.id];
    const photoSrc = photos[currentProduct.id] || (productPhotos?.[0]);
    if (photoSrc) {
      try {
        const img = await loadImage(photoSrc);
        const imgW = W * 0.6;
        const imgH = H * 0.35;
        const imgX = (W - imgW) / 2;
        const imgY = H * 0.22;
        ctx.save();
        roundRect(ctx, imgX, imgY, imgW, imgH, 8);
        ctx.clip();
        ctx.drawImage(img, imgX, imgY, imgW, imgH);
        ctx.restore();
      } catch { /* ignore image errors */ }
    } else {
      /* Placeholder */
      const imgW = W * 0.5;
      const imgH = H * 0.3;
      const imgX = (W - imgX) / 2;
      const imgY = H * 0.25;
      ctx.fillStyle = "rgba(255,255,255,0.1)";
      roundRect(ctx, imgX - imgW/2, imgY, imgW, imgH, 8);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.font = "14px Arial";
      ctx.textAlign = "center";
      ctx.fillText("Фото товара", W / 2, imgY + imgH / 2);
      ctx.textAlign = "left";
    }

    /* ── Product name ── */
    if (config.fields.name && currentProduct.name) {
      const ts = config.textSizes.name;
      ctx.font = `bold ${ts.size}px ${ts.font}`;
      ctx.textAlign = "center";
      const np = config.positions.name;
      const nameY = (np.y / 100) * H;
      wrapText(ctx, currentProduct.name, W / 2, nameY, W * 0.9, ts.size * 1.2);
      ctx.textAlign = "left";
    }

    /* ── Article ── */
    if (config.fields.article && currentProduct.article) {
      const ts = config.textSizes.article;
      ctx.font = `${ts.size}px ${ts.font}`;
      const ap = config.positions.article;
      ctx.fillText(`Арт: ${currentProduct.article}`, (ap.x / 100) * W, (ap.y / 100) * H);
    }

    /* ── Characteristics / STO ── */
    if (config.fields.characteristics) {
      const ts = config.textSizes.characteristics;
      ctx.font = `${ts.size}px ${ts.font}`;
      const cp = config.positions.characteristics;
      const sto = config.stoNumber || `СТО 79345251-185-2019`;
      ctx.globalAlpha = 0.85;
      ctx.fillText(sto, (cp.x / 100) * W, (cp.y / 100) * H);
      ctx.globalAlpha = 1;
    }

    /* ── Volume (big) ── */
    if (config.fields.volume && currentProduct.volume) {
      const ts = config.textSizes.volume;
      ctx.font = `bold ${ts.size}px ${ts.font}`;
      ctx.fillStyle = config.colors.volume;
      ctx.textAlign = "center";
      const vp = config.positions.volume;
      const volY = vp.y === 0 ? H - ts.size * 0.3 : (vp.y / 100) * H;
      ctx.fillText(currentProduct.volume, W / 2, volY);
      ctx.textAlign = "left";
      ctx.fillStyle = textColor;
    }

    /* ── KCCC Code ── */
    if (config.fields.kcccCode && currentProduct.kccc) {
      ctx.font = `12px Arial`;
      ctx.globalAlpha = 0.6;
      ctx.textAlign = "center";
      ctx.fillText(`КССС: ${currentProduct.kccc}`, W / 2, H - 20);
      ctx.globalAlpha = 1;
      ctx.textAlign = "left";
    }

    /* ── Advantages ── */
    if (config.fields.advantages && config.advantages.length > 0) {
      const ts = config.textSizes.advantages;
      ctx.font = `${ts.size}px ${ts.font}`;
      const ap = config.positions.advantages;
      let ay = (ap.y / 100) * H;
      const maxAdv = Math.min(config.advantages.length, 4);
      for (let i = 0; i < maxAdv; i++) {
        ctx.fillText("✓ " + config.advantages[i], (ap.x / 100) * W, ay);
        ay += ts.size * 1.3;
      }
    }

    /* ── Barcode (simple representation) ── */
    if (config.fields.barcode && currentProduct.barcode) {
      ctx.font = "12px Arial";
      ctx.globalAlpha = 0.5;
      ctx.textAlign = "center";
      ctx.fillText("|||||||| " + currentProduct.barcode + " ||||||||", W / 2, H - 35);
      ctx.globalAlpha = 1;
      ctx.textAlign = "left";
    }

    ctx.restore();

    /* ── Border ── */
    ctx.strokeStyle = "rgba(0,0,0,0.1)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(r, 0);
    ctx.lineTo(W - r, 0);
    ctx.quadraticCurveTo(W, 0, W, r);
    ctx.lineTo(W, H - r);
    ctx.quadraticCurveTo(W, H, W - r, H);
    ctx.lineTo(r, H);
    ctx.quadraticCurveTo(0, H, 0, H - r);
    ctx.lineTo(0, r);
    ctx.quadraticCurveTo(0, 0, r, 0);
    ctx.closePath();
    ctx.stroke();

    /* ── EAN-13 ── */
    if (config.fields.ean13) {
      const ep = config.positions.ean13;
      ctx.font = "14px Arial";
      ctx.globalAlpha = 0.7;
      ctx.fillText("EAN-13", (ep.x / 100) * W, (ep.y / 100) * H);
      ctx.globalAlpha = 1;
    }
  }, [config, currentProduct, photos, uploadedPhotos]);

  /* Redraw on change */
  useEffect(() => {
    drawCard();
  }, [drawCard]);

  /* ─── Handlers ─── */
  const handleExcelUpload = async (file: File) => {
    try {
      const parsed = await parseExcelFile(file);
      const newProducts: Product[] = parsed.map((p, i) => ({
        ...getDemoProducts()[0],
        ...p,
        id: Date.now() + i,
      }));
      if (newProducts.length > 0) {
        setProducts(newProducts);
        setCurrentIndex(0);
      }
    } catch (err) {
      console.error("Excel parse error:", err);
    }
  };

  const handlePhotoUpload = (productId: number, file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setPhotos(prev => ({ ...prev, [productId]: dataUrl }));
      setUploadedPhotos(prev => ({
        ...prev,
        [productId]: [...(prev[productId] || []), dataUrl],
      }));
    };
    reader.readAsDataURL(file);
  };

  const handleBgImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setConfig(prev => ({ ...prev, backgroundImage: e.target?.result as string }));
    };
    reader.readAsDataURL(file);
  };

  const updateField = (key: keyof CardFields, value: boolean) => {
    setConfig(prev => ({ ...prev, fields: { ...prev.fields, [key]: value } }));
  };

  const updateTemplate = (tmpl: TemplateOption) => {
    setConfig(prev => ({
      ...prev,
      template: tmpl.key,
      category: tmpl.category,
      colors: { ...prev.colors, primary: tmpl.bg[0], text: tmpl.textColor },
    }));
  };

  const addAdvantage = (text: string) => {
    if (!text.trim()) return;
    setConfig(prev => ({ ...prev, advantages: [...prev.advantages, text.trim()] }));
  };

  const removeAdvantage = (index: number) => {
    setConfig(prev => ({ ...prev, advantages: prev.advantages.filter((_, i) => i !== index) }));
  };

  const exportCurrent = () => {
    const canvas = canvasRef.current;
    if (!canvas || !currentProduct) return;
    const safeName = (currentProduct.name || "card").replace(/[^a-zA-Z0-9]/g, "_").substring(0, 30);
    exportCanvasToPng(canvas, `card_${currentProduct.kccc || "0"}_${safeName}.png`);
  };

  const [allPhotoQueue, setAllPhotoQueue] = useState<{ file: File; id: number }[]>([]);

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)]">
        {/* Header */}
        <div className="p-4 md:p-6 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Карточки товаров</h1>
              <p className="text-sm text-gray-500 mt-1">Генерация карточек товаров для печати и маркетплейсов</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => excelInputRef.current?.click()}
                className="px-4 py-2 bg-[#0d9488] text-white rounded-lg text-sm font-medium hover:bg-[#0f766e] transition-colors flex items-center gap-2"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                Загрузить Excel
              </button>
              <input ref={excelInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleExcelUpload(f); e.target.value = ""; }} />
              <button
                onClick={exportCurrent}
                disabled={!currentProduct}
                className="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors disabled:opacity-40 flex items-center gap-2"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Скачать PNG
              </button>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex flex-col lg:flex-row">
          {/* LEFT: Settings */}
          <div className="flex-1 p-4 md:p-6 border-r border-gray-200 overflow-y-auto" style={{ maxHeight: "calc(100vh - 140px)" }}>

            {/* Product base */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider">База товаров</h3>
                {products.length > 0 && (
                  <span className="text-xs text-gray-500">{products.length} товаров</span>
                )}
              </div>
              {products.length > 0 && (
                <div className="border border-gray-200 rounded-lg overflow-hidden mb-3">
                  <div className="overflow-x-auto" style={{ maxHeight: "200px" }}>
                    <table className="w-full text-xs">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="px-2 py-1.5 text-left font-medium text-gray-600">#</th>
                          <th className="px-2 py-1.5 text-left font-medium text-gray-600">КССС</th>
                          <th className="px-2 py-1.5 text-left font-medium text-gray-600">Название</th>
                          <th className="px-2 py-1.5 text-left font-medium text-gray-600">Фото</th>
                        </tr>
                      </thead>
                      <tbody>
                        {products.map((p, i) => (
                          <tr
                            key={p.id}
                            className={`cursor-pointer hover:bg-gray-50 ${i === currentIndex ? "bg-blue-50" : ""}`}
                            onClick={() => setCurrentIndex(i)}
                          >
                            <td className="px-2 py-1.5 text-gray-500">{i + 1}</td>
                            <td className="px-2 py-1.5 font-mono text-gray-700">{p.kccc}</td>
                            <td className="px-2 py-1.5 text-gray-800 truncate max-w-[200px]">{p.name}</td>
                            <td className="px-2 py-1.5">
                              {photos[p.id] || uploadedPhotos[p.id]?.[0] ? (
                                <span className="text-green-600 text-xs">✓</span>
                              ) : (
                                <button
                                  onClick={(e) => { e.stopPropagation(); setPendingPhotoProductId(p.id); photoInputRef.current?.click(); }}
                                  className="text-xs text-[#0d9488] hover:underline"
                                >
                                  Загрузить
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
              <input
                ref={photoInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f && pendingPhotoProductId !== null) {
                    handlePhotoUpload(pendingPhotoProductId, f);
                    setPendingPhotoProductId(null);
                  }
                  e.target.value = "";
                }}
              />
            </div>

            {/* Card settings */}
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider">Карточка товара</h3>
              <button
                onClick={() => { setConfig(getDefaultConfig()); setPhotos({}); setUploadedPhotos({}); }}
                className="text-xs text-gray-500 hover:text-gray-700 flex items-center gap-1"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
                Сбросить
              </button>
            </div>

            {/* Template */}
            <Section title="Шаблон" icon="⊞" defaultOpen>
              <div className="flex flex-wrap gap-1 mb-3">
                {TEMPLATE_CATEGORIES.map(cat => (
                  <button
                    key={cat.key}
                    onClick={() => setConfig(prev => ({ ...prev, category: cat.key }))}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                      config.category === cat.key
                        ? "bg-[#0d9488] text-white"
                        : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-2">
                {TEMPLATES.filter(t => t.category === config.category).map(tmpl => (
                  <button
                    key={tmpl.key}
                    onClick={() => updateTemplate(tmpl)}
                    className={`p-2 rounded-lg border-2 text-left transition-all ${
                      config.template === tmpl.key ? "border-[#0d9488]" : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="h-10 rounded mb-1" style={{
                      background: tmpl.bg.length > 1
                        ? `linear-gradient(135deg, ${tmpl.bg[0]}, ${tmpl.bg[1]})`
                        : tmpl.bg[0]
                    }} />
                    <span className="text-xs text-gray-700">{tmpl.name}</span>
                  </button>
                ))}
              </div>
            </Section>

            {/* Size */}
            <Section title="Размер и форма" icon="⌗" defaultOpen>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs text-gray-500 block mb-1">Ширина px</label>
                  <input
                    type="number"
                    value={config.width}
                    onChange={e => setConfig(prev => ({ ...prev, width: Number(e.target.value) || 400 }))}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 block mb-1">Высота px</label>
                  <input
                    type="number"
                    value={config.height}
                    onChange={e => setConfig(prev => ({ ...prev, height: Number(e.target.value) || 500 }))}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                  />
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-gray-500">Скругление углов</label>
                  <span className="text-xs font-medium">{config.borderRadius}px</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={50}
                  value={config.borderRadius}
                  onChange={e => setConfig(prev => ({ ...prev, borderRadius: Number(e.target.value) }))}
                  className="w-full accent-[#0d9488]"
                />
              </div>
            </Section>

            {/* Fields */}
            <Section title="Поля карточки" icon="☰">
              <div className="mb-3">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Базовые</div>
                <div className="grid grid-cols-2 gap-x-4">
                  <Toggle label="Характеристики" value={config.fields.characteristics} onChange={v => updateField("characteristics", v)} />
                  <Toggle label="Объём" value={config.fields.volume} onChange={v => updateField("volume", v)} />
                  <Toggle label="Название" value={config.fields.name} onChange={v => updateField("name", v)} />
                  <Toggle label="Артикул" value={config.fields.article} onChange={v => updateField("article", v)} />
                  <Toggle label="Логотип" value={config.fields.logo} onChange={v => updateField("logo", v)} />
                  <Toggle label="Дилер" value={config.fields.dealer} onChange={v => updateField("dealer", v)} />
                  <Toggle label="Штрихкод" value={config.fields.barcode} onChange={v => updateField("barcode", v)} />
                  <Toggle label="Преимущества" value={config.fields.advantages} onChange={v => updateField("advantages", v)} />
                </div>
              </div>
              <div className="mb-3">
                <label className="text-xs text-gray-500 block mb-1">Текст дилера</label>
                <input
                  type="text"
                  value={config.dealerText}
                  onChange={e => setConfig(prev => ({ ...prev, dealerText: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                />
              </div>
              <div className="mb-3">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Поля товара</div>
                <div className="grid grid-cols-2 gap-x-4">
                  <Toggle label="Продукт" value={config.fields.product} onChange={v => updateField("product", v)} />
                  <Toggle label="Направление" value={config.fields.direction} onChange={v => updateField("direction", v)} />
                  <Toggle label="Бренд" value={config.fields.brand} onChange={v => updateField("brand", v)} />
                  <Toggle label="Линейка" value={config.fields.line} onChange={v => updateField("line", v)} />
                  <Toggle label="Под-линейка" value={config.fields.subLine} onChange={v => updateField("subLine", v)} />
                  <Toggle label="Вид" value={config.fields.type} onChange={v => updateField("type", v)} />
                  <Toggle label="Вязкость" value={config.fields.viscosity} onChange={v => updateField("viscosity", v)} />
                  <Toggle label="API" value={config.fields.api} onChange={v => updateField("api", v)} />
                  <Toggle label="ACEA" value={config.fields.acea} onChange={v => updateField("acea", v)} />
                  <Toggle label="ILSAC" value={config.fields.ilsac} onChange={v => updateField("ilsac", v)} />
                </div>
              </div>
              <div>
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Доп. элементы</div>
                <div className="grid grid-cols-2 gap-x-4">
                  <Toggle label="QR-код" value={config.fields.qrCode} onChange={v => updateField("qrCode", v)} />
                  <Toggle label="SAE бейдж" value={config.fields.saeBadge} onChange={v => updateField("saeBadge", v)} />
                  <Toggle label="API/ACEA бейдж" value={config.fields.apiAceaBadge} onChange={v => updateField("apiAceaBadge", v)} />
                  <Toggle label="ILSAC логотип" value={config.fields.ilsacLogo} onChange={v => updateField("ilsacLogo", v)} />
                  <Toggle label="КССС код" value={config.fields.kcccCode} onChange={v => updateField("kcccCode", v)} />
                  <Toggle label="Объём" value={config.fields.volumeBadge} onChange={v => updateField("volumeBadge", v)} />
                  <Toggle label="Бейдж дилера" value={config.fields.dealerBadge} onChange={v => updateField("dealerBadge", v)} />
                  <Toggle label="OEM допуск" value={config.fields.oemApproval} onChange={v => updateField("oemApproval", v)} />
                  <Toggle label="Страна" value={config.fields.country} onChange={v => updateField("country", v)} />
                  <Toggle label="EAN-13" value={config.fields.ean13} onChange={v => updateField("ean13", v)} />
                </div>
              </div>
            </Section>

            {/* Colors */}
            <Section title="Цвета оформления" icon="◎">
              <div className="mb-3">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Сезонный фон</div>
                <div className="flex flex-wrap gap-1">
                  {SEASON_BACKGROUNDS.map(s => (
                    <button
                      key={s.key}
                      onClick={() => setConfig(prev => ({ ...prev, seasonBg: s.key }))}
                      className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                        config.seasonBg === s.key
                          ? "border-[#0d9488] bg-[#0d9488] text-white"
                          : "border-gray-200 text-gray-600 hover:bg-gray-100"
                      }`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <ColorInput label="Основной" value={config.colors.primary} onChange={v => setConfig(prev => ({ ...prev, colors: { ...prev.colors, primary: v } }))} />
                <ColorInput label="Текст" value={config.colors.text} onChange={v => setConfig(prev => ({ ...prev, colors: { ...prev.colors, text: v } }))} />
                <ColorInput label="Объём" value={config.colors.volume} onChange={v => setConfig(prev => ({ ...prev, colors: { ...prev.colors, volume: v } }))} />
              </div>
              <div className="mt-3">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">Фоновое изображение</div>
                <div
                  onDragOver={e => { e.preventDefault(); setDraggedOver(true); }}
                  onDragLeave={() => setDraggedOver(false)}
                  onDrop={e => { e.preventDefault(); setDraggedOver(false); const f = e.dataTransfer.files[0]; if (f) handleBgImageUpload(f); }}
                  onClick={() => bgInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${draggedOver ? "border-[#0d9488] bg-[#f0fdfa]" : "border-gray-300 hover:border-gray-400"}`}
                >
                  {config.backgroundImage ? (
                    <div className="flex items-center gap-2 justify-center">
                      <img src={config.backgroundImage} alt="" className="h-10 rounded object-cover" />
                      <span className="text-xs text-gray-600">Нажмите чтобы заменить</span>
                    </div>
                  ) : (
                    <>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="1.5" className="mx-auto mb-1"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      <span className="text-xs text-gray-500">Загрузить фон (JPG/PNG)</span>
                    </>
                  )}
                </div>
                <input ref={bgInputRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleBgImageUpload(f); e.target.value = ""; }} />
              </div>
            </Section>

            {/* Characteristics */}
            <Section title="Характеристики" icon="↳">
              <div>
                <label className="text-xs text-gray-500 block mb-1">СТО номер</label>
                <input
                  type="text"
                  value={config.stoNumber}
                  onChange={e => setConfig(prev => ({ ...prev, stoNumber: e.target.value }))}
                  placeholder="СТО 79345251-185-2019"
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                />
                <p className="text-xs text-gray-400 mt-1">Пусто = авто из товара</p>
              </div>
            </Section>

            {/* Advantages */}
            <Section title="Преимущества" icon="✓">
              <div className="space-y-1 mb-3">
                {config.advantages.map((adv, i) => (
                  <div key={i} className="flex items-center justify-between py-1">
                    <span className="flex items-center gap-2 text-sm text-gray-700">
                      <span className="text-[#0d9488]">✓</span>
                      {adv}
                    </span>
                    <button onClick={() => removeAdvantage(i)} className="text-gray-400 hover:text-red-500 text-sm">✕</button>
                  </div>
                ))}
              </div>
              <AdvantageInput onAdd={addAdvantage} />
            </Section>

            {/* Photo */}
            <Section title="Настройки фото" icon="📷">
              <div
                onDragOver={e => { e.preventDefault(); }}
                onDrop={e => {
                  e.preventDefault();
                  const f = e.dataTransfer.files[0];
                  if (f && currentProduct) handlePhotoUpload(currentProduct.id, f);
                }}
                onClick={() => { if (currentProduct) { setPendingPhotoProductId(currentProduct.id); photoInputRef.current?.click(); }}}
                className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:border-gray-400 transition-colors"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="1.5" className="mx-auto mb-1"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                <span className="text-xs text-gray-500">
                  {currentProduct ? "Загрузить фото товара" : "Выберите товар"}
                </span>
              </div>
              {currentProduct && uploadedPhotos[currentProduct.id]?.length > 0 && (
                <div className="mt-2">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-gray-500">Фото:</span>
                    {uploadedPhotos[currentProduct.id].map((ph, i) => (
                      <img key={i} src={ph} alt="" className="w-10 h-10 rounded object-cover border" />
                    ))}
                    <button
                      onClick={() => {
                        setPhotos(prev => { const n = { ...prev }; delete n[currentProduct.id]; return n; });
                        setUploadedPhotos(prev => { const n = { ...prev }; delete n[currentProduct.id]; return n; });
                      }}
                      className="text-xs text-red-500 hover:text-red-700 ml-2"
                    >
                      Удалить
                    </button>
                  </div>
                </div>
              )}
            </Section>

            {/* Text sizes */}
            <Section title="Размеры текста" icon="T">
              <TextSizeControl label="Логотип" config={config.textSizes.logo} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, logo: c } }))} />
              <TextSizeControl label="Бейдж дилера" config={config.textSizes.dealerBadge} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, dealerBadge: c } }))} />
              <TextSizeControl label="Характеристики" config={config.textSizes.characteristics} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, characteristics: c } }))} />
              <TextSizeControl label="Объём" config={config.textSizes.volume} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, volume: c } }))} />
              <TextSizeControl label="Название" config={config.textSizes.name} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, name: c } }))} />
              <TextSizeControl label="Артикул" config={config.textSizes.article} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, article: c } }))} />
              <TextSizeControl label="Преимущества" config={config.textSizes.advantages} onChange={c => setConfig(prev => ({ ...prev, textSizes: { ...prev.textSizes, advantages: c } }))} />
            </Section>

            {/* Positions */}
            <Section title="Позиции элементов" icon="↔">
              <PositionControl label="Логотип" pos={config.positions.logo} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, logo: p } }))} />
              <PositionControl label="Дилер" pos={config.positions.dealer} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, dealer: p } }))} />
              <PositionControl label="Название" pos={config.positions.name} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, name: p } }))} />
              <PositionControl label="Артикул" pos={config.positions.article} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, article: p } }))} />
              <PositionControl label="Характеристики" pos={config.positions.characteristics} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, characteristics: p } }))} />
              <PositionControl label="Объём" pos={config.positions.volume} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, volume: p } }))} />
              <PositionControl label="Преимущества" pos={config.positions.advantages} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, advantages: p } }))} />
              <PositionControl label="EAN-13" pos={config.positions.ean13} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, ean13: p } }))} />
              <PositionControl label="Продукт" pos={config.positions.product} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, product: p } }))} />
              <PositionControl label="QR-код" pos={config.positions.qrcode} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, qrcode: p } }))} />
              <PositionControl label="SAE бейдж" pos={config.positions.saeBadge} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, saeBadge: p } }))} />
              <PositionControl label="API/ACEA" pos={config.positions.apiAcea} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, apiAcea: p } }))} />
              <PositionControl label="ILSAC" pos={config.positions.ilsac} onChange={p => setConfig(prev => ({ ...prev, positions: { ...prev.positions, ilsac: p } }))} />
            </Section>
          </div>

          {/* RIGHT: Preview */}
          <div className="lg:w-[420px] p-4 md:p-6 bg-gray-50 flex flex-col">
            <div className="flex items-center gap-2 mb-3">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              <span className="text-sm font-semibold text-gray-700">Предпросмотр</span>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between mb-3">
              <button
                onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
                disabled={currentIndex === 0}
                className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-white disabled:opacity-30"
              >
                ←
              </button>
              <span className="text-sm font-medium text-gray-600">
                {currentIndex + 1} / {products.length}
              </span>
              <div className="flex gap-1">
                <button
                  onClick={() => setCurrentIndex(Math.min(products.length - 1, currentIndex + 1))}
                  disabled={currentIndex >= products.length - 1}
                  className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-white disabled:opacity-30"
                >
                  →
                </button>
                <button
                  onClick={() => drawCard()}
                  className="w-8 h-8 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-white"
                  title="Обновить"
                >
                  ↻
                </button>
              </div>
            </div>

            {/* Photo management for current product */}
            {currentProduct && (
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs text-gray-500">Фото:</span>
                {(uploadedPhotos[currentProduct.id] || []).length > 0 ? (
                  <>
                    {uploadedPhotos[currentProduct.id].map((ph, i) => (
                      <img key={i} src={ph} alt="" className="w-10 h-10 rounded object-cover border" />
                    ))}
                    <button
                      onClick={() => {
                        setPhotos(prev => { const n = { ...prev }; delete n[currentProduct.id]; return n; });
                        setUploadedPhotos(prev => { const n = { ...prev }; delete n[currentProduct.id]; return n; });
                      }}
                      className="text-xs text-red-500 hover:text-red-700"
                    >
                      ✕ Удалить
                    </button>
                    <button
                      onClick={() => { setPendingPhotoProductId(currentProduct.id); photoInputRef.current?.click(); }}
                      className="text-xs text-[#0d9488] hover:underline ml-2"
                    >
                      ↥ Заменить
                    </button>
                  </>
                ) : (
                  <span className="text-xs text-gray-400">Нет фото</span>
                )}
              </div>
            )}

            {/* Canvas */}
            <div className="flex-1 flex items-center justify-center bg-gray-200 rounded-xl p-4">
              <canvas
                ref={canvasRef}
                style={{
                  maxWidth: "100%",
                  maxHeight: "calc(100vh - 380px)",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.15)",
                  borderRadius: config.borderRadius,
                }}
              />
            </div>

            {/* Product info */}
            {currentProduct && (
              <div className="mt-4 p-3 bg-white rounded-xl border border-gray-200">
                <div className="font-semibold text-sm text-gray-800">{currentProduct.name}</div>
                <div className="text-xs text-gray-500 mt-1">
                  КССС: {currentProduct.kccc} | {currentIndex + 1}/{products.length}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

/* ─── Sub-components ─── */

function ColorInput({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-xs text-gray-500 block mb-1">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={e => onChange(e.target.value)}
          className="w-10 h-8 rounded cursor-pointer border p-0.5"
        />
        <span className="text-xs font-mono text-gray-600 uppercase">{value}</span>
      </div>
    </div>
  );
}

function AdvantageInput({ onAdd }: { onAdd: (text: string) => void }) {
  const [text, setText] = useState("");
  return (
    <div className="flex gap-2">
      <input
        type="text"
        value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={e => { if (e.key === "Enter") { onAdd(text); setText(""); } }}
        placeholder="Новое преимущество..."
        className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm"
      />
      <button
        onClick={() => { onAdd(text); setText(""); }}
        className="w-10 h-10 bg-[#0d9488] text-white rounded-lg flex items-center justify-center hover:bg-[#0f766e]"
      >
        +
      </button>
    </div>
  );
}

/* ─── Canvas Helpers ─── */

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawBadge(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, textColor: string, bgColor: string) {
  ctx.save();
  ctx.font = "bold 12px Arial";
  const metrics = ctx.measureText(text);
  const pad = 8;
  const w = metrics.width + pad * 2;
  const h = 22;
  ctx.fillStyle = bgColor;
  roundRect(ctx, x, y, w, h, 4);
  ctx.fill();
  ctx.fillStyle = textColor;
  ctx.textAlign = "left";
  ctx.fillText(text, x + pad, y + 16);
  ctx.restore();
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
  const words = text.split(" ");
  let line = "";
  let cy = y;
  for (let i = 0; i < words.length; i++) {
    const test = line + words[i] + " ";
    if (ctx.measureText(test).width > maxWidth && i > 0) {
      ctx.fillText(line.trim(), x, cy);
      line = words[i] + " ";
      cy += lineHeight;
    } else {
      line = test;
    }
  }
  ctx.fillText(line.trim(), x, cy);
}

function getSeasonOverlay(season: string): string {
  switch (season) {
    case "spring": return "rgba(144, 238, 144, 0.15)";
    case "summer": return "rgba(255, 215, 0, 0.15)";
    case "autumn": return "rgba(210, 105, 30, 0.15)";
    case "winter": return "rgba(173, 216, 230, 0.2)";
    default: return "transparent";
  }
}

function drawGeometryPattern(ctx: CanvasRenderingContext2D, W: number, H: number, _color: string) {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(W * 0.2 * i, 0);
    ctx.lineTo(W * 0.2 * i + 50, H);
    ctx.stroke();
  }
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.arc(W * 0.3 * (i + 1), H * 0.5, 30 + i * 15, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function drawGlossEffect(ctx: CanvasRenderingContext2D, W: number, H: number) {
  ctx.save();
  const grad = ctx.createRadialGradient(W * 0.7, H * 0.2, 0, W * 0.7, H * 0.2, W * 0.4);
  grad.addColorStop(0, "rgba(255,255,255,0.3)");
  grad.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

function drawHoloEffect(ctx: CanvasRenderingContext2D, W: number, H: number) {
  ctx.save();
  const grad = ctx.createLinearGradient(0, 0, W, H);
  grad.addColorStop(0, "rgba(255,0,255,0.1)");
  grad.addColorStop(0.5, "rgba(0,255,255,0.1)");
  grad.addColorStop(1, "rgba(255,255,0,0.1)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}

function drawNeonEffect(ctx: CanvasRenderingContext2D, W: number, H: number, _color: string) {
  ctx.save();
  ctx.shadowColor = "#39FF14";
  ctx.shadowBlur = 20;
  ctx.strokeStyle = "rgba(57,255,20,0.3)";
  ctx.lineWidth = 2;
  ctx.strokeRect(5, 5, W - 10, H - 10);
  ctx.restore();
}
