import { useState, useEffect, useCallback, useMemo } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import type { YandexMetricaConfig, MetricQuery, MetricResponse, MetricPreset, MetricOption, DimensionOption } from "@/types/metrics";
import { METRICS_VISITS, METRICS_HITS, DIMENSIONS_VISITS, DIMENSIONS_HITS, PRESETS, ALL_METRICS, ALL_DIMENSIONS } from "@/types/metrics";
import { fetchMetricData, loadMetricConfig, saveMetricConfig, formatMetricValue, getMetricLabel, getDimensionLabel } from "@/services/metricsService";
import { Line, Bar, Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend);

const today = () => {
  const d = new Date();
  return d.toISOString().split("T")[0];
};
const weekAgo = () => {
  const d = new Date();
  d.setDate(d.getDate() - 7);
  return d.toISOString().split("T")[0];
};
const monthAgo = () => {
  const d = new Date();
  d.setDate(d.getDate() - 30);
  return d.toISOString().split("T")[0];
};

export default function MetricsPage() {
  /* ── Config ── */
  const [config, setConfig] = useState<YandexMetricaConfig>(() => loadMetricConfig() || { oauthToken: "", counterId: "" });
  const [showSettings, setShowSettings] = useState(false);

  /* ── Query builder ── */
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(["ym:s:visits", "ym:s:users", "ym:s:pageviews"]);
  const [selectedDimensions, setSelectedDimensions] = useState<string[]>(["ym:s:date"]);
  const [date1, setDate1] = useState(weekAgo());
  const [date2, setDate2] = useState(today());
  const [filters, setFilters] = useState("");
  const [limit, setLimit] = useState(100);

  /* ── Data ── */
  const [response, setResponse] = useState<MetricResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /* ── View ── */
  const [chartType, setChartType] = useState<"line" | "bar" | "doughnut">("line");
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);

  /* ── Tabs ── */
  const [metricTab, setMetricTab] = useState<"visits" | "hits">("visits");
  const [dimTab, setDimTab] = useState<"visits" | "hits">("visits");

  useEffect(() => { saveMetricConfig(config); }, [config]);

  /* ── Categorize ── */
  const metricsByCategory = useMemo(() => {
    const src = metricTab === "visits" ? METRICS_VISITS : METRICS_HITS;
    const cats: Record<string, MetricOption[]> = {};
    src.forEach(m => { (cats[m.category] ||= []).push(m); });
    return cats;
  }, [metricTab]);

  const dimsByCategory = useMemo(() => {
    const src = dimTab === "visits" ? DIMENSIONS_VISITS : DIMENSIONS_HITS;
    const cats: Record<string, DimensionOption[]> = {};
    src.forEach(d => { (cats[d.category] ||= []).push(d); });
    return cats;
  }, [dimTab]);

  /* ── Toggle ── */
  const toggleMetric = (key: string) => {
    setSelectedMetrics(prev => {
      const has = prev.includes(key);
      if (has) return prev.filter(k => k !== key);
      /* Check prefix compatibility */
      const prefix = key.startsWith("ym:s:") ? "ym:s:" : "ym:pv:";
      const filtered = prev.filter(k => k.startsWith(prefix));
      return [...filtered, key];
    });
  };

  const toggleDimension = (key: string) => {
    setSelectedDimensions(prev => {
      const has = prev.includes(key);
      if (has) return prev.filter(k => k !== key);
      /* Check prefix compatibility */
      const prefix = key.startsWith("ym:s:") ? "ym:s:" : "ym:pv:";
      const filtered = prev.filter(k => k.startsWith(prefix));
      return [...filtered, key];
    });
  };

  /* ── Apply preset ── */
  const applyPreset = (preset: MetricPreset) => {
    setSelectedMetrics([...preset.metrics]);
    setSelectedDimensions([...preset.dimensions]);
    setSelectedPreset(preset.name);
    // Auto-set tab based on prefix
    if (preset.metrics[0]?.startsWith("ym:pv:")) {
      setMetricTab("hits");
      setDimTab("hits");
    } else {
      setMetricTab("visits");
      setDimTab("visits");
    }
  };

  /* ── Quick dates ── */
  const setQuickDate = (type: "today" | "week" | "month") => {
    const d2 = today();
    let d1: string;
    switch (type) {
      case "today": d1 = d2; break;
      case "week": d1 = weekAgo(); break;
      case "month": d1 = monthAgo(); break;
    }
    setDate1(d1);
    setDate2(d2);
  };

  /* ── Fetch ── */
  const fetchData = useCallback(async () => {
    if (!config.oauthToken || !config.counterId) {
      setShowSettings(true);
      setError("Укажите OAuth токен и ID счётчика в настройках");
      return;
    }
    if (selectedMetrics.length === 0) {
      setError("Выберите хотя бы одну метрику");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const query: MetricQuery = {
        id: config.counterId,
        counterId: config.counterId,
        metrics: selectedMetrics,
        dimensions: selectedDimensions,
        date1,
        date2,
        ...(filters ? { filters } : {}),
        ...(limit ? { limit } : {}),
      };
      const data = await fetchMetricData(query, config);
      if (data.errors && data.errors.length > 0) {
        setError(data.errors.map(e => e.message).join("; "));
      } else {
        setResponse(data);
      }
    } catch (err: any) {
      setError(err.message || "Ошибка запроса к API");
    }
    setLoading(false);
  }, [config, selectedMetrics, selectedDimensions, date1, date2, filters, limit]);

  /* ── Chart data ── */
  const chartData = useMemo(() => {
    if (!response?.data || response.data.length === 0) return null;
    const labels = response.data.map(row => row.dimensions.map(d => d.name).join(" / "));
    const datasets = response.query.metrics.map((metricKey, i) => ({
      label: getMetricLabel(metricKey),
      data: response.data.map(row => row.metrics[i]),
      borderColor: CHART_COLORS[i % CHART_COLORS.length],
      backgroundColor: CHART_BG[i % CHART_BG.length],
      tension: 0.3,
    }));
    return { labels, datasets };
  }, [response]);

  const doughnutData = useMemo(() => {
    if (!response?.data || response.data.length === 0 || selectedMetrics.length === 0) return null;
    const labels = response.data.map(row => row.dimensions.map(d => d.name).join(" / "));
    const values = response.data.map(row => row.metrics[0]);
    return {
      labels,
      datasets: [{
        data: values,
        backgroundColor: labels.map((_, i) => CHART_BG[i % CHART_BG.length]),
        borderColor: labels.map((_, i) => CHART_COLORS[i % CHART_COLORS.length]),
        borderWidth: 1,
      }],
    };
  }, [response, selectedMetrics]);

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)]">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Метрики</h1>
              <p className="text-sm text-gray-500 mt-0.5">Аналитика Яндекс.Метрика — отчёты и визуализация</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
                ⚙ Настройки
              </Button>
              <Button onClick={fetchData} disabled={loading} size="sm" className="gap-2">
                {loading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : "▶"}
                {loading ? "Загрузка..." : "Получить данные"}
              </Button>
            </div>
          </div>
        </div>

        {/* Settings panel */}
        {showSettings && (
          <div className="bg-blue-50 border-b border-blue-200 px-6 py-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-1">OAuth токен</label>
                <input
                  type="password"
                  value={config.oauthToken}
                  onChange={e => setConfig(p => ({ ...p, oauthToken: e.target.value }))}
                  placeholder="y0_AgAAAAA..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:border-blue-500 focus:outline-none"
                />
                <p className="text-xs text-gray-500 mt-1">
                  <a href="https://oauth.yandex.ru/authorize?response_type=token&client_id=1" target="_blank" rel="noopener" className="text-blue-600 hover:underline">Получить токен</a>
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-1">ID счётчика</label>
                <input
                  type="text"
                  value={config.counterId}
                  onChange={e => setConfig(p => ({ ...p, counterId: e.target.value }))}
                  placeholder="44147844"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>
              <div className="flex items-end">
                <Button onClick={() => { saveMetricConfig(config); setShowSettings(false); }} size="sm" className="w-full">
                  💾 Сохранить
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Main content */}
        <div className="px-6 py-4">
          <div className="grid grid-cols-1 xl:grid-cols-[300px_1fr] gap-4">
            {/* LEFT: Query Builder */}
            <div className="space-y-4">
              {/* Presets */}
              <div className="bg-white rounded-xl border border-gray-200 p-4">
                <h3 className="text-sm font-bold text-gray-800 mb-3">📋 Пресеты отчётов</h3>
                <div className="space-y-1.5">
                  {PRESETS.map(preset => (
                    <button
                      key={preset.name}
                      onClick={() => applyPreset(preset)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                        selectedPreset === preset.name
                          ? "bg-blue-100 text-blue-800 border border-blue-300"
                          : "hover:bg-gray-100 border border-transparent"
                      }`}
                    >
                      <div className="font-medium">{preset.name}</div>
                      <div className="text-xs text-gray-500">{preset.description}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Dates */}
              <div className="bg-white rounded-xl border border-gray-200 p-4">
                <h3 className="text-sm font-bold text-gray-800 mb-3">📅 Период</h3>
                <div className="flex gap-1 mb-3">
                  {(["today", "week", "month"] as const).map(t => (
                    <button
                      key={t}
                      onClick={() => setQuickDate(t)}
                      className="flex-1 px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-xs font-medium text-gray-700 transition-colors"
                    >
                      {t === "today" ? "Сегодня" : t === "week" ? "Неделя" : "Месяц"}
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">С</label>
                    <input type="date" value={date1} onChange={e => setDate1(e.target.value)} className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:border-blue-500 focus:outline-none" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">По</label>
                    <input type="date" value={date2} onChange={e => setDate2(e.target.value)} className="w-full px-2 py-1.5 text-sm border border-gray-300 rounded focus:border-blue-500 focus:outline-none" />
                  </div>
                </div>
                <div className="mt-2">
                  <label className="text-xs text-gray-500 block mb-1">Фильтры (опционально)</label>
                  <textarea
                    value={filters}
                    onChange={e => setFilters(e.target.value)}
                    placeholder="ym:s:trafficSourceName=='Поисковые системы'"
                    rows={2}
                    className="w-full px-2 py-1.5 text-xs border border-gray-300 rounded focus:border-blue-500 focus:outline-none resize-none"
                  />
                </div>
                <div className="mt-2">
                  <label className="text-xs text-gray-500 block mb-1">Лимит: {limit}</label>
                  <input type="range" min={10} max={1000} step={10} value={limit} onChange={e => setLimit(Number(e.target.value))} className="w-full accent-blue-600" />
                </div>
              </div>

              {/* Metrics */}
              <div className="bg-white rounded-xl border border-gray-200 p-4">
                <div className="flex gap-2 mb-3">
                  <button onClick={() => setMetricTab("visits")} className={`px-3 py-1 rounded-full text-xs font-medium ${metricTab === "visits" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600"}`}>Визиты</button>
                  <button onClick={() => setMetricTab("hits")} className={`px-3 py-1 rounded-full text-xs font-medium ${metricTab === "hits" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600"}`}>Хиты</button>
                </div>
                <h3 className="text-sm font-bold text-gray-800 mb-2">📊 Метрики</h3>
                <div className="space-y-2 max-h-[300px] overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
                  {Object.entries(metricsByCategory).map(([cat, items]) => (
                    <div key={cat}>
                      <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">{cat}</div>
                      {items.map(m => (
                        <label key={m.key} className="flex items-center gap-2 py-1 cursor-pointer hover:bg-gray-50 rounded px-1">
                          <input type="checkbox" checked={selectedMetrics.includes(m.key)} onChange={() => toggleMetric(m.key)} className="rounded accent-blue-600" />
                          <span className="text-xs text-gray-700">{m.label}</span>
                        </label>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              {/* Dimensions */}
              <div className="bg-white rounded-xl border border-gray-200 p-4">
                <div className="flex gap-2 mb-3">
                  <button onClick={() => setDimTab("visits")} className={`px-3 py-1 rounded-full text-xs font-medium ${dimTab === "visits" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600"}`}>Визиты</button>
                  <button onClick={() => setDimTab("hits")} className={`px-3 py-1 rounded-full text-xs font-medium ${dimTab === "hits" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600"}`}>Хиты</button>
                </div>
                <h3 className="text-sm font-bold text-gray-800 mb-2">🔀 Группировки</h3>
                <div className="space-y-2 max-h-[300px] overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
                  {Object.entries(dimsByCategory).map(([cat, items]) => (
                    <div key={cat}>
                      <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">{cat}</div>
                      {items.map(d => (
                        <label key={d.key} className="flex items-center gap-2 py-1 cursor-pointer hover:bg-gray-50 rounded px-1">
                          <input type="checkbox" checked={selectedDimensions.includes(d.key)} onChange={() => toggleDimension(d.key)} className="rounded accent-blue-600" />
                          <span className="text-xs text-gray-700">{d.label}</span>
                        </label>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* RIGHT: Results */}
            <div className="space-y-4">
              {/* Error */}
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-800">
                  <div className="flex items-center gap-2 font-semibold mb-1">❌ Ошибка</div>
                  <div className="text-sm">{error}</div>
                </div>
              )}

              {/* Summary cards */}
              {response?.totals && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {response.query.metrics.map((m, i) => (
                    <div key={m} className="bg-white rounded-xl border border-gray-200 p-4">
                      <div className="text-xs text-gray-500 uppercase tracking-wider">{getMetricLabel(m)}</div>
                      <div className="text-2xl font-bold text-gray-900 mt-1">{formatMetricValue(response.totals![i], m)}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Chart */}
              {response?.data && response.data.length > 0 && (
                <div className="bg-white rounded-xl border border-gray-200 p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-bold text-gray-800">📈 График</h3>
                    <div className="flex gap-1">
                      {(["line", "bar", "doughnut"] as const).map(t => (
                        <button
                          key={t}
                          onClick={() => setChartType(t)}
                          className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                            chartType === t ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                          }`}
                        >
                          {t === "line" ? "Линия" : t === "bar" ? "Столбцы" : "Круг"}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div style={{ height: "320px" }}>
                    {chartType === "doughnut" && doughnutData ? (
                      <Doughnut data={doughnutData} options={{ maintainAspectRatio: false, plugins: { legend: { position: "right" } } }} />
                    ) : chartType === "bar" && chartData ? (
                      <Bar data={chartData} options={{ maintainAspectRatio: false, responsive: true }} />
                    ) : chartData ? (
                      <Line data={chartData} options={{ maintainAspectRatio: false, responsive: true }} />
                    ) : null}
                  </div>
                  {response.contains_sensitive_data && (
                    <p className="text-xs text-amber-600 mt-2">⚠️ Данные предоставлены с ограничениями (менее 10 посетителей в выборке)</p>
                  )}
                </div>
              )}

              {/* Table */}
              {response?.data && response.data.length > 0 && (
                <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                  <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                    <h3 className="text-sm font-bold text-gray-800">📋 Детализация</h3>
                    <span className="text-xs text-gray-500">{response.data.length} строк</span>
                  </div>
                  <div className="overflow-x-auto" style={{ maxHeight: "500px" }}>
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          {response.query.dimensions.map((d, i) => (
                            <th key={i} className="px-3 py-2 text-left text-xs font-semibold text-gray-600 border-b">{getDimensionLabel(d)}</th>
                          ))}
                          {response.query.metrics.map((m, i) => (
                            <th key={i} className="px-3 py-2 text-right text-xs font-semibold text-gray-600 border-b">{getMetricLabel(m)}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {response.data.map((row, i) => (
                          <tr key={i} className="border-b border-gray-50 hover:bg-gray-50">
                            {row.dimensions.map((d, j) => (
                              <td key={j} className="px-3 py-2 text-gray-800 font-medium">{d.name}</td>
                            ))}
                            {row.metrics.map((v, j) => (
                              <td key={j} className="px-3 py-2 text-right text-gray-700 font-mono">{formatMetricValue(v, response.query.metrics[j])}</td>
                            ))}
                          </tr>
                        ))}
                        {response.totals && (
                          <tr className="bg-blue-50 font-semibold">
                            {response.query.dimensions.map((_, j) => (
                              <td key={j} className="px-3 py-2 text-blue-800">{j === 0 ? "ИТОГО" : ""}</td>
                            ))}
                            {response.totals.map((v, j) => (
                              <td key={j} className="px-3 py-2 text-right text-blue-800 font-mono">{formatMetricValue(v, response.query.metrics[j])}</td>
                            ))}
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Empty state */}
              {!response && !loading && !error && (
                <div className="flex flex-col items-center justify-center py-20 text-gray-400">
                  <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mb-4"><path d="M18 20V10M12 20V4M6 20v-6"/><path d="M3 20h18"/></svg>
                  <p className="text-lg font-medium">Настройте запрос и нажмите «Получить данные»</p>
                  <p className="text-sm mt-1">Выберите метрики, группировки и период</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

const CHART_COLORS = ["#2563EB", "#059669", "#DC2626", "#D97706", "#7C3AED", "#DB2777", "#0891B2", "#65A30D"];
const CHART_BG = ["rgba(37,99,235,0.2)", "rgba(5,150,105,0.2)", "rgba(220,38,38,0.2)", "rgba(217,119,6,0.2)", "rgba(124,58,237,0.2)", "rgba(219,39,119,0.2)", "rgba(8,145,178,0.2)", "rgba(101,163,13,0.2)"];
