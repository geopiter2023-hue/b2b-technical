import type { BitrixProduct, Mapping } from "@/types/bitrixImport";
import { BITRIX_TEMPLATE_COLUMNS } from "@/types/bitrixImport";

export async function parseExcelFile(file: File): Promise<{
  headers: string[];
  rows: Record<string, string | number>[];
}> {
  return new Promise((resolve, reject) => {
    import("xlsx").then((XLSX) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rawRows: unknown[][] = XLSX.utils.sheet_to_json(sheet, {
            header: 1,
            defval: "",
          });
          if (rawRows.length < 2) {
            resolve({ headers: [], rows: [] });
            return;
          }
          const headers = (rawRows[0] as string[]).map((h) =>
            String(h).trim()
          );
          const rows: Record<string, string | number>[] = [];
          for (let i = 1; i < rawRows.length; i++) {
            const rowArr = rawRows[i] as unknown[];
            if (!rowArr[0]) continue;
            const row: Record<string, string | number> = {};
            headers.forEach((h, idx) => {
              row[h] =
                rowArr[idx] !== undefined ? String(rowArr[idx]).trim() : "";
            });
            rows.push(row);
          }
          resolve({ headers, rows });
        } catch (err) {
          reject(err);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  });
}

export function generateBitrixExcel(
  products: BitrixProduct[],
  filename = "bitrix-import.xlsx"
) {
  const cols = BITRIX_TEMPLATE_COLUMNS.map((c) => c.label);
  const rows = products.map((p) =>
    BITRIX_TEMPLATE_COLUMNS.map((c) => (p[c.key] !== undefined ? String(p[c.key]) : ""))
  );
  const data = [cols, ...rows];
  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Товары");
  XLSX.writeFile(wb, filename);
}

export function applyMapping(
  sourceRows: Record<string, string | number>[],
  mapping: Mapping[]
): BitrixProduct[] {
  return sourceRows.map((src) => {
    const product: BitrixProduct = {};
    mapping.forEach((m) => {
      if (m.sourceCol && src[m.sourceCol] !== undefined) {
        product[m.templateCol] = src[m.sourceCol];
      }
    });
    return product;
  });
}

export function generateMappingPreview(
  sourceRows: Record<string, string | number>[],
  mapping: Mapping[]
): Record<string, string>[] {
  return sourceRows.slice(0, 5).map((src) => {
    const preview: Record<string, string> = {};
    mapping.forEach((m) => {
      if (m.sourceCol) {
        preview[m.templateCol] = String(src[m.sourceCol] || "");
      }
    });
    return preview;
  });
}
