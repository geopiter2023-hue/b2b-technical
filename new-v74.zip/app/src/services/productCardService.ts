import type { Product, CardConfig } from "@/types/productCards";

const STORAGE_KEY = "product_cards_data";
const STORAGE_CONFIG = "product_cards_config";

export function saveProducts(products: Product[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
}

export function loadProducts(): Product[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : getDemoProducts();
  } catch {
    return getDemoProducts();
  }
}

export function saveConfig(config: CardConfig) {
  localStorage.setItem(STORAGE_CONFIG, JSON.stringify(config));
}

export function loadConfig(): CardConfig | null {
  try {
    const data = localStorage.getItem(STORAGE_CONFIG);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function clearProducts() {
  localStorage.removeItem(STORAGE_KEY);
}

export function getDemoProducts(): Product[] {
  return [
    { id: 1, kccc: "3150660", name: "ЛУКОЙЛ GENESIS ARMORTECH 0W-40", brand: "LUKOIL", viscosity: "0W-40", api: "SN/CF", acea: "C3", volume: "1л", barcode: "4601234567890", article: "3150660" },
    { id: 2, kccc: "3150665", name: "ЛУКОЙЛ GENESIS ARMORTECH 0W-30", brand: "LUKOIL", viscosity: "0W-30", api: "SN/CF", acea: "C2", volume: "4л", barcode: "", article: "3150665" },
    { id: 3, kccc: "2255947", name: "ЛУКОЙЛ GENESIS ARMORTECH 5W-40", brand: "LUKOIL", viscosity: "5W-40", api: "SN", acea: "C3", volume: "4л", barcode: "", article: "2255947" },
    { id: 4, kccc: "2255948", name: "ЛУКОЙЛ GENESIS ARMORTECH 5W-30", brand: "LUKOIL", viscosity: "5W-30", api: "SN Plus", acea: "C2", volume: "1л", barcode: "", article: "2255948" },
    { id: 5, kccc: "2270940", name: "ЛУКОЙЛ GENESIS ARMORTECH 5W-40", brand: "LUKOIL", viscosity: "5W-40", api: "SN/CF", acea: "C3", volume: "5л", barcode: "", article: "2270940" },
    { id: 6, kccc: "2270939", name: "ЛУКОЙЛ GENESIS ARMORTECH 5W-30", brand: "LUKOIL", viscosity: "5W-30", api: "SN Plus", acea: "C2", volume: "5л", barcode: "", article: "2270939" },
    { id: 7, kccc: "2405224", name: "ЛУКОЙЛ GENESIS ARMORTECH 0W-20", brand: "LUKOIL", viscosity: "0W-20", api: "SN Plus", acea: "C5", volume: "4л", barcode: "", article: "2405224" },
    { id: 8, kccc: "2405226", name: "ЛУКОЙЛ GENESIS ARMORTECH 0W-16", brand: "LUKOIL", viscosity: "0W-16", api: "SN Plus", acea: "C5", volume: "4л", barcode: "", article: "2405226" },
    { id: 9, kccc: "3409225", name: "ЛУКОЙЛ GENESIS ARMORTECH 10W-40", brand: "LUKOIL", viscosity: "10W-40", api: "SN", acea: "A3/B4", volume: "4л", barcode: "", article: "3409225" },
    { id: 10, kccc: "3184789", name: "ЛУКОЙЛ GENESIS CLARITECH 5W-30", brand: "LUKOIL", viscosity: "5W-30", api: "SN Plus", acea: "C2", volume: "4л", barcode: "", article: "3184789" },
  ];
}

export function parseExcelFile(file: File): Promise<Partial<Product>[]> {
  return new Promise((resolve, reject) => {
    import("xlsx").then(XLSX => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
          if (rows.length < 2) { resolve([]); return; }

          const headers = (rows[0] as string[]).map(h => String(h).toLowerCase().trim());
          const products: Partial<Product>[] = [];

          const colMap: Record<string, string> = {};
          headers.forEach((h, i) => {
            if (h.includes("кссс") || h.includes("kccc")) colMap.kccc = String(i);
            else if (h.includes("название") || h.includes("наименование") || h.includes("name")) colMap.name = String(i);
            else if (h.includes("бренд") || h.includes("brand")) colMap.brand = String(i);
            else if (h.includes("вязкост") || h.includes("sae") || h.includes("viscosity")) colMap.viscosity = String(i);
            else if (h.includes("api")) colMap.api = String(i);
            else if (h.includes("acea")) colMap.acea = String(i);
            else if (h.includes("объем") || h.includes("объём") || h.includes("volume")) colMap.volume = String(i);
            else if (h.includes("штрих") || h.includes("ean") || h.includes("barcode")) colMap.barcode = String(i);
            else if (h.includes("артикул") || h.includes("article")) colMap.article = String(i);
            else if (h.includes("под-лин") || h.includes("подлин") || h.includes("sub")) colMap.subLine = String(i);
            else if (h.includes("направлен") || h.includes("direction")) colMap.direction = String(i);
            else if (h.includes("линейка") || h.includes("line")) colMap.line = String(i);
            else if (h.includes("вид") || h.includes("type")) colMap.type = String(i);
            else if (h.includes("ilsac")) colMap.ilsac = String(i);
            else if (h.includes("страна") || h.includes("country")) colMap.country = String(i);
            else if (h.includes("oem") || h.includes("допуск")) colMap.oem = String(i);
          });

          for (let i = 1; i < rows.length; i++) {
            const row = rows[i] as string[];
            if (!row[0]) continue;
            const p: Partial<Product> = { id: i };
            if (colMap.kccc !== undefined) p.kccc = String(row[Number(colMap.kccc)] || "");
            if (colMap.name !== undefined) p.name = String(row[Number(colMap.name)] || "");
            if (colMap.brand !== undefined) p.brand = String(row[Number(colMap.brand)] || "");
            else if (p.name?.toUpperCase().includes("LUKOIL")) p.brand = "LUKOIL";
            if (colMap.viscosity !== undefined) p.viscosity = String(row[Number(colMap.viscosity)] || "");
            if (colMap.api !== undefined) p.api = String(row[Number(colMap.api)] || "");
            if (colMap.acea !== undefined) p.acea = String(row[Number(colMap.acea)] || "");
            if (colMap.volume !== undefined) p.volume = String(row[Number(colMap.volume)] || "");
            if (colMap.barcode !== undefined) p.barcode = String(row[Number(colMap.barcode)] || "");
            if (colMap.article !== undefined) p.article = String(row[Number(colMap.article)] || "");
            if (colMap.subLine !== undefined) p.subLine = String(row[Number(colMap.subLine)] || "");
            if (colMap.direction !== undefined) p.direction = String(row[Number(colMap.direction)] || "");
            if (colMap.line !== undefined) p.line = String(row[Number(colMap.line)] || "");
            if (colMap.type !== undefined) p.type = String(row[Number(colMap.type)] || "");
            if (colMap.ilsac !== undefined) p.ilsac = String(row[Number(colMap.ilsac)] || "");
            if (colMap.country !== undefined) p.country = String(row[Number(colMap.country)] || "");
            if (colMap.oem !== undefined) p.oem = String(row[Number(colMap.oem)] || "");
            if (p.name) products.push(p);
          }
          resolve(products);
        } catch (err) {
          reject(err);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  });
}

export function exportCanvasToPng(canvas: HTMLCanvasElement, filename: string) {
  canvas.toBlob((blob) => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, "image/png");
}

export async function exportAllToZip(
  canvases: { canvas: HTMLCanvasElement; filename: string }[]
): Promise<void> {
  const JSZip = (await import("jszip")).default;
  const zip = new JSZip();
  const folder = zip.folder("cards");
  if (!folder) return;

  for (const { canvas, filename } of canvases) {
    const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, "image/png"));
    if (blob) folder.file(filename, blob);
  }

  const zipBlob = await zip.generateAsync({ type: "blob" });
  const url = URL.createObjectURL(zipBlob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "product_cards.zip";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
