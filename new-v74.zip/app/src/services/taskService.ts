import { supabase, isSupabaseConfigured } from "@/lib/supabase";

export interface Task {
  id: number; name: string; description: string | null;
  status: string; priority: string; assignee: string | null; executor: string | null;
  start_date: string | null; end_date: string | null;
  complexity: number | null; budget: string | null; progress: number | null;
  notes: string | null; category: string | null; source_id: string | null;
  created_at: string; updated_at: string;
}

export type TaskFilters = { status?: string; priority?: string; assignee?: string; search?: string; category?: string };

const LS_KEY = "b2b_tasks";
function loadLocal(): Task[] { try { const r = localStorage.getItem(LS_KEY); return r ? JSON.parse(r) : []; } catch { return []; } }
function saveLocal(t: Task[]) { try { localStorage.setItem(LS_KEY, JSON.stringify(t)); } catch {} }
function nextId(t: Task[]): number { return t.length === 0 ? 1 : Math.max(...t.map((x) => x.id)) + 1; }

// Try Supabase first, fallback to localStorage
export async function listTasks(filters: TaskFilters = {}, sortBy = "created_at", sortOrder: "asc" | "desc" = "desc", page = 1, limit = 200) {
  if (isSupabaseConfigured) {
    try {
      let q = supabase.from("tasks").select("*", { count: "exact" });
      if (filters.status && filters.status !== "all") q = q.eq("status", filters.status);
      if (filters.priority && filters.priority !== "all") q = q.eq("priority", filters.priority);
      if (filters.assignee && filters.assignee !== "all") q = q.eq("assignee", filters.assignee);
      if (filters.category && filters.category !== "all") q = q.eq("category", filters.category);
      if (filters.search) q = q.or(`name.ilike.%${filters.search}%,assignee.ilike.%${filters.search}%`);
      q = q.order(sortBy, { ascending: sortOrder === "asc" }).range((page - 1) * limit, page * limit - 1);
      const { data, error, count } = await q;
      if (error) throw error;
      const list = (data || []) as Task[];
      saveLocal(list);
      return { list, total: count || 0, page, limit };
    } catch (err) { console.warn("[Tasks] Supabase failed, using localStorage:", err); }
  }
  let tasks = loadLocal();
  if (filters.status && filters.status !== "all") tasks = tasks.filter((t) => t.status === filters.status);
  if (filters.priority && filters.priority !== "all") tasks = tasks.filter((t) => t.priority === filters.priority);
  if (filters.assignee && filters.assignee !== "all") tasks = tasks.filter((t) => t.assignee === filters.assignee);
  if (filters.category && filters.category !== "all") tasks = tasks.filter((t) => t.category === filters.category);
  if (filters.search) { const s = filters.search.toLowerCase(); tasks = tasks.filter((t) => t.name.toLowerCase().includes(s) || (t.assignee && t.assignee.toLowerCase().includes(s))); }
  tasks.sort((a, b) => { const av = (a as any)[sortBy] || ""; const bv = (b as any)[sortBy] || ""; return sortOrder === "asc" ? (av < bv ? -1 : 1) : (av > bv ? -1 : 1); });
  return { list: tasks.slice((page - 1) * limit, page * limit), total: tasks.length, page, limit };
}

export async function getTask(id: number): Promise<Task | null> {
  if (isSupabaseConfigured) { try { const { data, error } = await supabase.from("tasks").select("*").eq("id", id).single(); if (!error) return data as Task; } catch {} }
  return loadLocal().find((t) => t.id === id) || null;
}

export async function createTask(taskData: any) {
  const now = new Date().toISOString();
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("tasks").insert({
        name: taskData.name, description: taskData.description || null,
        status: taskData.status || "not_started", priority: taskData.priority || "medium",
        assignee: taskData.assignee || null, executor: taskData.executor || null,
        start_date: taskData.start_date || taskData.startDate || null,
        end_date: taskData.end_date || taskData.endDate || null,
        complexity: taskData.complexity ?? 2, budget: taskData.budget || null,
        progress: taskData.progress ?? 0, notes: taskData.notes || null,
        category: taskData.category || null, source_id: taskData.sourceId || null,
      }).select("id").single();
      if (error) throw error;
      const all = await listTasks(); saveLocal(all.list);
      return data;
    } catch (err) { console.warn("[Tasks] Supabase create failed:", err); }
  }
  const tasks = loadLocal();
  const newTask: Task = { id: nextId(tasks), name: taskData.name, description: taskData.description || null, status: taskData.status || "not_started", priority: taskData.priority || "medium", assignee: taskData.assignee || null, executor: taskData.executor || null, start_date: taskData.start_date || taskData.startDate || null, end_date: taskData.end_date || taskData.endDate || null, complexity: taskData.complexity ?? 2, budget: taskData.budget || null, progress: taskData.progress ?? 0, notes: taskData.notes || null, category: taskData.category || null, source_id: taskData.sourceId || null, created_at: now, updated_at: now };
  tasks.push(newTask); saveLocal(tasks);
  return { id: newTask.id };
}

export async function updateTask(id: number, taskData: any) {
  const up: any = {};
  if (taskData.name !== undefined) up.name = taskData.name;
  if (taskData.description !== undefined) up.description = taskData.description || null;
  if (taskData.status !== undefined) up.status = taskData.status;
  if (taskData.priority !== undefined) up.priority = taskData.priority;
  if (taskData.assignee !== undefined) up.assignee = taskData.assignee || null;
  if (taskData.executor !== undefined) up.executor = taskData.executor || null;
  if (taskData.start_date !== undefined || taskData.startDate !== undefined) up.start_date = taskData.start_date || taskData.startDate || null;
  if (taskData.end_date !== undefined || taskData.endDate !== undefined) up.end_date = taskData.end_date || taskData.endDate || null;
  if (taskData.complexity !== undefined) up.complexity = taskData.complexity;
  if (taskData.budget !== undefined) up.budget = taskData.budget || null;
  if (taskData.progress !== undefined) up.progress = taskData.progress;
  if (taskData.notes !== undefined) up.notes = taskData.notes || null;
  if (taskData.category !== undefined) up.category = taskData.category || null;
  if (isSupabaseConfigured) {
    try { const { error } = await supabase.from("tasks").update(up).eq("id", id); if (error) throw error; const all = await listTasks(); saveLocal(all.list); return; } catch (err) { console.warn("[Tasks] Supabase update failed:", err); }
  }
  const tasks = loadLocal(); const idx = tasks.findIndex((t) => t.id === id);
  if (idx !== -1) { tasks[idx] = { ...tasks[idx], ...up, updated_at: new Date().toISOString() }; saveLocal(tasks); }
}

export async function deleteTask(id: number) {
  if (isSupabaseConfigured) {
    try { const { error } = await supabase.from("tasks").delete().eq("id", id); if (error) throw error; const all = await listTasks(); saveLocal(all.list); return; } catch (err) { console.warn("[Tasks] Supabase delete failed:", err); }
  }
  saveLocal(loadLocal().filter((t) => t.id !== id));
}

export async function getTaskStats() {
  if (isSupabaseConfigured) {
    try { const { data, error } = await supabase.from("tasks").select("*"); if (error) throw error; const tasks = data as Task[]; return { total: tasks.length, inProgress: tasks.filter((t) => t.status === "in_progress").length, done: tasks.filter((t) => t.status === "completed").length, overdue: tasks.filter((t) => t.end_date && new Date(t.end_date) < new Date() && t.status !== "completed" && t.status !== "cancelled").length }; } catch (err) { console.warn("[Tasks] Supabase stats failed:", err); }
  }
  const tasks = loadLocal();
  return { total: tasks.length, inProgress: tasks.filter((t) => t.status === "in_progress").length, done: tasks.filter((t) => t.status === "completed").length, overdue: tasks.filter((t) => t.end_date && new Date(t.end_date) < new Date() && t.status !== "completed" && t.status !== "cancelled").length };
}

export async function getAssignees() {
  if (isSupabaseConfigured) { try { const { data, error } = await supabase.from("tasks").select("assignee").not("assignee", "is", null); if (!error) return Array.from(new Set(data.map((a: any) => a.assignee))); } catch {} }
  return Array.from(new Set(loadLocal().map((t) => t.assignee).filter(Boolean)));
}

export function exportLocalTasks(): Task[] { return loadLocal(); }
export function importLocalTasks(tasks: Task[]) { saveLocal(tasks); }
export function clearLocalTasks() { localStorage.removeItem(LS_KEY); }
