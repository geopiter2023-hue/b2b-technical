import { useEffect, useMemo, useRef, useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Upload, Download, Trash2, TrendingUp, TrendingDown,
  BarChart3, Search, RotateCcw, AlertTriangle,
} from "lucide-react";
import { Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement,
  PointElement, LineElement, Title, Tooltip, Legend,
} from "chart.js";
import ChartDataLabels from "chartjs-plugin-datalabels";
import PasswordDialog from "@/components/PasswordDialog";
import {
  parsePriceControlExcel, savePriceControlData, loadPriceControlData,
  clearPriceControlData, addPriceControlUpload, getPriceControlUploads,
  getPriceControlSummary, getCategoryStats, getDeviationGroups,
  formatPrice, formatNumber, formatMarkup,
  type PriceControlRecord, type PriceControlUpload, type PriceControlSummary,
} from "@/services/priceControlService";
import jsPDF from "jspdf";
import html2canvas from "html2canvas-pro";

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, PointElement, LineElement, Title, Tooltip, Legend, ChartDataLabels);

const CHART_COLORS = ["#DC2626", "#2563EB", "#D97706", "#16A34A", "#7C3AED", "#0891B2", "#BE185D", "#4338CA", "#059669", "#CA8A04"];

export default function PriceControlPage() {
  const [records, setRecords] = useState<PriceControlRecord[]>([]);
  const [summary, setSummary] = useState<PriceControlSummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [exportingPdf, setExportingPdf] = useState(false);

  // Filters
  const [categoryFilter, setCategoryFilter] = useState<string[]>([]);
  const [deviationFilter, setDeviationFilter] = useState<string[]>([]);

  // Password
  const [pwdDialogOpen, setPwdDialogOpen] = useState(false);
  const [pwdAction, setPwdAction] = useState<{ type: "upload" | "clear"; label: string }>({ type: "upload", label: "Загрузка файла" });
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  const [uploadHistory, setUploadHistory] = useState<PriceControlUpload[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const pdfRef = useRef<HTMLDivElement>(null);

  // Load saved data
  useEffect(() => {
    setTimeout(() => {
      try {
        const saved = loadPriceControlData();
        if (saved.length > 0) { setRecords(saved); setSummary(getPriceControlSummary(saved)); }
      } catch {}
      setUploadHistory(getPriceControlUploads());
      setIsDataLoaded(true);
    }, 100);
  }, []);

  // Filtered
  const filtered = useMemo(() => {
    return records.filter((r) => {
      if (categoryFilter.length > 0 && !categoryFilter.includes(r.category || "Без категории")) return false;
      if (deviationFilter.length > 0 && !deviationFilter.includes(r.deviation)) return false;
      if (search) {
        const s = search.toLowerCase();
        return r.name.toLowerCase().includes(s) || r.ksss.toLowerCase().includes(s) || r.category.toLowerCase().includes(s);
      }
      return true;
    });
  }, [records, categoryFilter, deviationFilter, search]);

  // Unique values
  const categories = useMemo(() => Array.from(new Set(records.map((r) => r.category || "Без категории"))).sort(), [records]);

  // Analytics
  const filteredSummary = useMemo(() => getPriceControlSummary(filtered), [filtered]);
  const catStats = useMemo(() => getCategoryStats(filtered), [filtered]);
  const devGroups = useMemo(() => getDeviationGroups(filtered), [filtered]);

  // Charts
  const markupChart = useMemo(() => ({
    labels: devGroups.map((g) => g.label),
    datasets: [{
      data: devGroups.map((g) => g.count),
      backgroundColor: devGroups.map((g) => g.color + "80"),
      borderColor: devGroups.map((g) => g.color),
      borderWidth: 2,
    }],
  }), [devGroups]);

  const categoryChart = useMemo(() => {
    const top = catStats.slice(0, 10);
    return {
      labels: top.map((c) => c.category.length > 20 ? c.category.slice(0, 20) + "..." : c.category),
      datasets: [{
        label: "Наценка %",
        data: top.map((c) => c.avgMarkup),
        backgroundColor: CHART_COLORS.slice(0, top.length).map((c) => c + "80"),
        borderColor: CHART_COLORS.slice(0, top.length),
        borderWidth: 2,
      }],
    };
  }, [catStats]);

  const pieOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { position: "bottom" as const, labels: { boxWidth: 12, font: { size: 10 } } }, datalabels: { display: true, color: "#fff", font: { weight: "bold" as const, size: 11 }, formatter: (_v: number, ctx: any) => { const sum = ctx.dataset.data.reduce((a: number, b: number) => a + b, 0); return sum > 0 ? ((ctx.dataset.data[ctx.dataIndex] / sum) * 100).toFixed(1) + "%" : ""; } } },
  };
  const barOptions = {
    responsive: true, maintainAspectRatio: false, indexAxis: "y" as const,
    plugins: { legend: { display: false }, datalabels: { display: true, color: "#374151", font: { weight: "bold" as const, size: 10 }, anchor: "end" as const, align: "right" as const, formatter: (v: number) => v.toFixed(2) + "%" } },
    scales: { x: { beginAtZero: true } },
  };

  // Extra column names
  const extraColNames = useMemo(() => {
    const names = new Set<string>();
    for (const r of records) { if (r.extra) for (const k of Object.keys(r.extra)) names.add(k); }
    return Array.from(names);
  }, [records]);

  // Handlers
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setPendingFile(file);
    setPwdAction({ type: "upload", label: "Загрузка прайс-листа" });
    setPwdDialogOpen(true);
    if (fileRef.current) fileRef.current.value = "";
  };

  const processFile = async (file: File) => {
    setIsLoading(true); setLoadError("");
    try {
      const buffer = await file.arrayBuffer();
      const { records: data, errors } = parsePriceControlExcel(buffer);
      if (errors.length > 0 && data.length === 0) { setLoadError(errors.join("\n")); setIsLoading(false); return; }
      setRecords(data);
      const sm = getPriceControlSummary(data);
      setSummary(sm);
      savePriceControlData(data);
      addPriceControlUpload(file.name, data.length);
      setUploadHistory(getPriceControlUploads());
      setCategoryFilter([]); setDeviationFilter([]); setSearch("");
      if (errors.length > 0) setLoadError("Предупреждения: " + errors.join("; "));
    } catch (err: any) { setLoadError("Ошибка: " + err.message); }
    finally { setIsLoading(false); }
  };

  const handleClear = () => { clearPriceControlData(); setRecords([]); setSummary(null); setCategoryFilter([]); setDeviationFilter([]); setSearch(""); };

  const handleExportPdf = async () => {
    if (!filtered.length) return;
    setExportingPdf(true);
    await new Promise((r) => setTimeout(r, 800));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (!pdfRef.current) { setExportingPdf(false); return; }
    try {
      const canvas = await html2canvas(pdfRef.current, { scale: 1.5, useCORS: true, logging: false, backgroundColor: "#ffffff", windowWidth: 1200 });
      const pdf = new jsPDF("l", "mm", "a4");
      const pw = 297, m = 10, cw = pw - m * 2;
      const imgH = (canvas.height * cw) / canvas.width;
      let pos = 0, rem = imgH;
      while (rem > 0) {
        const sliceH = Math.min(210 - m * 2, rem);
        const sc = document.createElement("canvas"); sc.width = canvas.width; sc.height = (sliceH / imgH) * canvas.height;
        const ctx = sc.getContext("2d")!; ctx.drawImage(canvas, 0, (pos / imgH) * canvas.height, canvas.width, (sliceH / imgH) * canvas.height, 0, 0, sc.width, sc.height);
        if (pos > 0) pdf.addPage();
        pdf.addImage(sc.toDataURL("image/png"), "PNG", m, m, cw, sliceH); pos += sliceH; rem -= sliceH;
      }
      pdf.save(`price_control_${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch {}
    setExportingPdf(false);
  };

  if (!isDataLoaded) {
    return <Layout><div className="flex items-center justify-center h-96"><div className="animate-spin h-10 w-10 border-4 border-red-200 border-t-red-700 rounded-full" /></div></Layout>;
  }

  // Empty state
  if (records.length === 0) {
    return (
      <Layout>
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><BarChart3 className="h-7 w-7 text-red-700" />Контроль цен</h1>
          </div>
          <Card className="py-8 sm:py-16">
            <CardContent className="text-center px-4">
              <Upload className="h-12 w-12 sm:h-16 sm:w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-base sm:text-lg font-semibold text-gray-600 mb-2">Загрузите прайс-лист</h3>
              <p className="text-xs sm:text-sm text-gray-400 mb-4">Поддерживается прайс-лист ЛУКОЙЛ (.xlsx, .xls)</p>
              <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} onChange={handleFileChange} className="hidden" />
              <Button className="bg-red-700 hover:bg-red-800" size="sm" onClick={() => fileRef.current?.click()} disabled={isLoading}>
                <Upload className="h-4 w-4 mr-2" />{isLoading ? "Загрузка..." : "Выбрать файл"}
              </Button>
              {loadError && <p className="text-red-600 text-sm mt-3">{loadError}</p>}
            </CardContent>
          </Card>
          {uploadHistory.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">История загрузок ({uploadHistory.length})</CardTitle></CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {uploadHistory.map((item) => (
                    <div key={item.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-50">
                      <div className="flex items-center gap-3"><BarChart3 className="h-5 w-5 text-red-600" />
                        <div><p className="text-sm font-medium">{item.fileName}</p><p className="text-xs text-gray-500">{new Date(item.uploadedAt).toLocaleDateString("ru-RU")} · {formatNumber(item.recordCount)} товаров</p></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
          <PasswordDialog open={pwdDialogOpen} onOpenChange={setPwdDialogOpen} action={pwdAction.label} onSuccess={() => { if (pwdAction.type === "upload" && pendingFile) { processFile(pendingFile); setPendingFile(null); } else if (pwdAction.type === "clear") handleClear(); }} />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><BarChart3 className="h-7 w-7 text-red-700" />Контроль цен</h1>
            {summary && <p className="text-xs text-gray-500">{formatNumber(summary.totalProducts)} товаров · {formatNumber(summary.totalStock)} единиц</p>}
          </div>
          <div className="flex gap-2 flex-wrap">
            <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} onChange={handleFileChange} className="hidden" />
            <Button variant="outline" size="sm" className="border-red-700 text-red-700 hover:bg-red-50" onClick={() => fileRef.current?.click()} disabled={isLoading}>
              <Upload className="h-4 w-4 mr-2" />{isLoading ? "..." : "Новый файл"}
            </Button>
            <Button variant="outline" size="sm" className="border-gray-300 text-gray-700" onClick={handleExportPdf} disabled={exportingPdf}>
              <Download className="h-4 w-4 mr-2" />{exportingPdf ? "..." : "PDF"}
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-red-600" onClick={() => { setPwdAction({ type: "clear", label: "Удаление данных" }); setPwdDialogOpen(true); }}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Card><CardContent className="p-4">
            <p className="text-xs text-gray-500">Товаров</p>
            <p className="text-2xl font-bold text-gray-900">{formatNumber(filteredSummary.totalProducts)}</p>
            <p className="text-xs text-gray-400">{formatNumber(filteredSummary.totalStock)} ед. на складе</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-gray-500">Средняя наценка</p>
            <p className="text-2xl font-bold text-red-700">{filteredSummary.avgMarkup.toFixed(2)}%</p>
            <p className="text-xs text-gray-400">{filteredSummary.minMarkup.toFixed(1)}% — {filteredSummary.maxMarkup.toFixed(1)}%</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-gray-500">Закуп / Розница</p>
            <p className="text-lg font-bold text-gray-900">{formatPrice(filteredSummary.avgPurchasePrice)} / {formatPrice(filteredSummary.avgRetailPrice)}</p>
            <p className="text-xs text-gray-400">средние цены</p>
          </CardContent></Card>
          <Card><CardContent className="p-4">
            <p className="text-xs text-gray-500">Товарная масса</p>
            <p className="text-lg font-bold text-gray-900">{formatPrice(filteredSummary.totalRetailValue)} ₽</p>
            <p className="text-xs text-gray-400">розничная стоимость</p>
          </CardContent></Card>
        </div>

        {/* Onacenka ranges */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Низкая <10%", count: filteredSummary.markupRanges.low, color: "bg-red-100 text-red-700 border-red-200" },
            { label: "Норма 10-30%", count: filteredSummary.markupRanges.normal, color: "bg-green-100 text-green-700 border-green-200" },
            { label: "Высокая 30-50%", count: filteredSummary.markupRanges.high, color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
            { label: ">50%", count: filteredSummary.markupRanges.veryHigh, color: "bg-red-200 text-red-800 border-red-300" },
          ].map((r) => (
            <Card key={r.label} className={`${r.color} cursor-pointer hover:shadow-md transition-shadow ${deviationFilter.includes(r.label) ? "ring-2 ring-red-500" : ""}`}
              onClick={() => setDeviationFilter((prev) => prev.includes(r.label) ? prev.filter((d) => d !== r.label) : [...prev, r.label])}>
              <CardContent className="p-3 text-center"><p className="text-2xl font-bold">{r.count}</p><p className="text-xs">{r.label}</p></CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          <div className="relative flex-1 min-w-0 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input placeholder="Поиск по КССС, названию, категории..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 h-8 text-sm" />
          </div>
          <div className="flex flex-wrap gap-1">
            {categories.map((cat) => (
              <Badge key={cat} variant={categoryFilter.includes(cat) ? "default" : "outline"}
                className={`cursor-pointer text-xs ${categoryFilter.includes(cat) ? "bg-red-700 hover:bg-red-800" : "hover:bg-gray-100"}`}
                onClick={() => setCategoryFilter((prev) => prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat])}>
                {cat}
              </Badge>
            ))}
          </div>
          <Button variant="ghost" size="sm" className="h-8 text-gray-500" onClick={() => { setCategoryFilter([]); setDeviationFilter([]); setSearch(""); }}>
            <RotateCcw className="h-3 w-3 mr-1" />Сбросить
          </Button>
        </div>

        <Tabs defaultValue="overview">
          <TabsList className="flex-wrap h-auto">
            <TabsTrigger value="overview">Обзор</TabsTrigger>
            <TabsTrigger value="categories">Категории</TabsTrigger>
            <TabsTrigger value="deviations">Отклонения</TabsTrigger>
            <TabsTrigger value="products">Товары ({filtered.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card><CardHeader><CardTitle className="text-base">Распределение по наценке</CardTitle></CardHeader><CardContent><div style={{ height: "350px" }}><Doughnut data={markupChart as any} options={pieOptions} /></div></CardContent></Card>
              <Card><CardHeader><CardTitle className="text-base">Наценка по категориям (топ-10)</CardTitle></CardHeader><CardContent><div style={{ height: "350px" }}><Bar data={categoryChart as any} options={barOptions} /></div></CardContent></Card>
            </div>
          </TabsContent>

          <TabsContent value="categories">
            <Card><CardHeader><CardTitle className="text-base">Категории ({catStats.length})</CardTitle></CardHeader>
              <CardContent className="p-0 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0 z-10"><tr><th className="px-4 py-2 text-left">Категория</th><th className="px-4 py-2 text-right">Товаров</th><th className="px-4 py-2 text-right">Ср. закуп</th><th className="px-4 py-2 text-right">Ср. розница</th><th className="px-4 py-2 text-right">Наценка</th><th className="px-4 py-2 text-right">Остаток</th></tr></thead>
                  <tbody className="divide-y">
                    {catStats.map((c) => (
                      <tr key={c.category} className="hover:bg-gray-50">
                        <td className="px-4 py-2 font-medium">{c.category}</td>
                        <td className="px-4 py-2 text-right">{c.count}</td>
                        <td className="px-4 py-2 text-right">{formatPrice(c.avgPurchase)}</td>
                        <td className="px-4 py-2 text-right font-bold">{formatPrice(c.avgRetail)}</td>
                        <td className="px-4 py-2 text-right text-red-700 font-bold">{c.avgMarkup.toFixed(2)}%</td>
                        <td className="px-4 py-2 text-right">{formatNumber(c.totalStock)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deviations">
            <div className="grid grid-cols-1 gap-4">
              {devGroups.filter((g) => g.count > 0).map((g) => (
                <Card key={g.label}>
                  <CardHeader><CardTitle className="text-base flex items-center gap-2"><span className="w-3 h-3 rounded-full" style={{ background: g.color }} />{g.label} ({g.count})</CardTitle></CardHeader>
                  <CardContent className="p-0 overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50"><tr><th className="px-3 py-2 text-left">КССС</th><th className="px-3 py-2 text-left">Товар</th><th className="px-3 py-2 text-left">Категория</th><th className="px-3 py-2 text-right">Закуп</th><th className="px-3 py-2 text-right">Розница</th><th className="px-3 py-2 text-right">Наценка</th><th className="px-3 py-2 text-right">Остаток</th></tr></thead>
                      <tbody className="divide-y">
                        {g.products.slice(0, 20).map((p) => (
                          <tr key={p.id} className="hover:bg-gray-50">
                            <td className="px-3 py-2 text-xs font-mono text-gray-600">{p.ksss || "—"}</td>
                            <td className="px-3 py-2 font-medium">{p.name}</td>
                            <td className="px-3 py-2 text-gray-500">{p.category}</td>
                            <td className="px-3 py-2 text-right">{formatPrice(p.purchasePrice)}</td>
                            <td className="px-3 py-2 text-right font-bold">{formatPrice(p.retailPrice)}</td>
                            <td className="px-3 py-2 text-right font-bold" style={{ color: p.markup > 50 ? "#DC2626" : p.markup < 10 ? "#EF4444" : "#16A34A" }}>{formatMarkup(p.markup)}</td>
                            <td className="px-3 py-2 text-right">{formatNumber(p.stock)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="products">
            <Card>
              <CardHeader><CardTitle className="text-base">Товары ({filtered.length})</CardTitle></CardHeader>
              <CardContent className="p-0 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0 z-10"><tr><th className="px-3 py-2 text-left">КССС</th><th className="px-3 py-2 text-left">Товар</th><th className="px-3 py-2 text-left">Категория</th><th className="px-3 py-2 text-right">Закуп</th><th className="px-3 py-2 text-right">Розница</th><th className="px-3 py-2 text-right">Спец</th><th className="px-3 py-2 text-right">Наценка</th><th className="px-3 py-2 text-right">Остаток</th>{extraColNames.map((cn) => <th key={cn} className="px-3 py-2 text-left text-gray-600">{cn}</th>)}</tr></thead>
                  <tbody className="divide-y">
                    {filtered.slice(0, 200).map((p) => (
                      <tr key={p.id} className="hover:bg-gray-50">
                        <td className="px-3 py-2 text-xs font-mono text-gray-600">{p.ksss || "—"}</td>
                        <td className="px-3 py-2 font-medium">{p.name}</td>
                        <td className="px-3 py-2 text-gray-500">{p.category}</td>
                        <td className="px-3 py-2 text-right">{formatPrice(p.purchasePrice)}</td>
                        <td className="px-3 py-2 text-right font-bold">{formatPrice(p.retailPrice)}</td>
                        <td className="px-3 py-2 text-right">{p.specialPrice ? formatPrice(p.specialPrice) : "—"}</td>
                        <td className="px-3 py-2 text-right font-bold" style={{ color: p.markup > 50 ? "#DC2626" : p.markup < 10 ? "#EF4444" : "#16A34A" }}>{formatMarkup(p.markup)}</td>
                        <td className="px-3 py-2 text-right">{formatNumber(p.stock)}</td>
                        {extraColNames.map((cn) => <td key={cn} className="px-3 py-2 text-gray-600">{p.extra?.[cn] || ""}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Password Dialog */}
        <PasswordDialog open={pwdDialogOpen} onOpenChange={setPwdDialogOpen} action={pwdAction.label} onSuccess={() => { if (pwdAction.type === "upload" && pendingFile) { processFile(pendingFile); setPendingFile(null); } else if (pwdAction.type === "clear") handleClear(); }} />

        {/* PDF div */}
        {exportingPdf && (
          <div ref={pdfRef} style={{ position: "absolute", left: "-9999px", top: 0, width: "1200px", background: "#fff", padding: "30px", fontFamily: "Arial, sans-serif" }}>
            <div style={{ borderBottom: "3px solid #DC2626", marginBottom: "20px", paddingBottom: "10px" }}>
              <h1 style={{ fontSize: "22px", color: "#DC2626", margin: 0 }}>Контроль цен — B2B Task Manager</h1>
              <p style={{ fontSize: "11px", color: "#666" }}>{formatNumber(filteredSummary.totalProducts)} товаров · Средняя наценка {filteredSummary.avgMarkup.toFixed(2)}%</p>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "9px" }}>
              <thead><tr style={{ background: "#DC2626", color: "#fff" }}>
                <th style={{ padding: "4px", border: "1px solid #ddd" }}>КССС</th><th style={{ padding: "4px", border: "1px solid #ddd" }}>Товар</th><th style={{ padding: "4px", border: "1px solid #ddd" }}>Категория</th>
                <th style={{ padding: "4px", border: "1px solid #ddd", textAlign: "right" }}>Закуп</th><th style={{ padding: "4px", border: "1px solid #ddd", textAlign: "right" }}>Розница</th><th style={{ padding: "4px", border: "1px solid #ddd", textAlign: "right" }}>Наценка</th><th style={{ padding: "4px", border: "1px solid #ddd", textAlign: "right" }}>Остаток</th>
              </tr></thead>
              <tbody>{filtered.slice(0, 300).map((p, i) => (
                <tr key={p.id} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                  <td style={{ padding: "3px", border: "1px solid #ddd", fontFamily: "monospace" }}>{p.ksss || "—"}</td>
                  <td style={{ padding: "3px", border: "1px solid #ddd", fontWeight: "bold" }}>{p.name}</td>
                  <td style={{ padding: "3px", border: "1px solid #ddd" }}>{p.category}</td>
                  <td style={{ padding: "3px", border: "1px solid #ddd", textAlign: "right" }}>{formatPrice(p.purchasePrice)}</td>
                  <td style={{ padding: "3px", border: "1px solid #ddd", textAlign: "right" }}>{formatPrice(p.retailPrice)}</td>
                  <td style={{ padding: "3px", border: "1px solid #ddd", textAlign: "right" }}>{formatMarkup(p.markup)}</td>
                  <td style={{ padding: "3px", border: "1px solid #ddd", textAlign: "right" }}>{formatNumber(p.stock)}</td>
                </tr>
              ))}</tbody>
            </table>
            <p style={{ fontSize: "9px", color: "#999", marginTop: "20px", textAlign: "center" }}>Сформировано: {new Date().toLocaleString("ru-RU")} | B2B Task Manager — ЛУКОЙЛ</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
