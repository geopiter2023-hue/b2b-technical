export interface Product {
  id: number;
  kccc: string;
  name: string;
  brand: string;
  viscosity?: string;
  api?: string;
  acea?: string;
  volume?: string;
  barcode?: string;
  article?: string;
  subLine?: string;
  direction?: string;
  line?: string;
  type?: string;
  ilsac?: string;
  country?: string;
  oem?: string;
  photo?: string;
}

export interface CardConfig {
  template: string;
  category: string;
  width: number;
  height: number;
  borderRadius: number;
  colors: {
    primary: string;
    text: string;
    volume: string;
    accent?: string;
    frame?: string;
  };
  backgroundImage?: string;
  seasonBg?: string;
  fields: CardFields;
  dealerText: string;
  stoNumber: string;
  advantages: string[];
  textSizes: Record<string, TextSizeConfig>;
  positions: Record<string, PositionConfig>;
  photoScale: number;
  photoX: number;
  photoY: number;
  logoImage?: string;
  bannerImage?: string;
  bannerY: number;
}

export interface CardFields {
  characteristics: boolean;
  name: boolean;
  logo: boolean;
  barcode: boolean;
  volume: boolean;
  article: boolean;
  dealer: boolean;
  advantages: boolean;
  product: boolean;
  brand: boolean;
  subLine: boolean;
  viscosity: boolean;
  api: boolean;
  acea: boolean;
  ilsac: boolean;
  direction: boolean;
  line: boolean;
  type: boolean;
  qrCode: boolean;
  saeBadge: boolean;
  apiAceaBadge: boolean;
  ilsacLogo: boolean;
  kcccCode: boolean;
  volumeBadge: boolean;
  dealerBadge: boolean;
  oemApproval: boolean;
  country: boolean;
  ean13: boolean;
}

export interface TextSizeConfig {
  size: number;
  font: string;
}

export interface PositionConfig {
  x: number;
  y: number;
}

export interface TemplateOption {
  key: string;
  name: string;
  category: string;
  bg: string[];
  textColor: string;
  useCustomColor?: boolean;
  isFrame?: boolean;
  isDouble?: boolean;
}

export const DEFAULT_ADVANTAGES = [
  "Оригинальный продукт",
  "Соответствует спецификациям",
  "Гарантия качества",
  "Быстрая доставка",
];

export const TEMPLATES: TemplateOption[] = [
  // Металлики
  { key: "kanistra", name: "Канистра", category: "metallics", bg: ["#DC143C", "#B01030"], textColor: "#FFFFFF" },
  { key: "silver", name: "Серебряный", category: "metallics", bg: ["#C0C0C0", "#808080"], textColor: "#FFFFFF" },
  { key: "gold", name: "Золотой", category: "metallics", bg: ["#DAA520", "#B8860B"], textColor: "#FFFFFF" },
  { key: "geometry", name: "Геометрия", category: "metallics", bg: ["#1E3A5F", "#2E5A8F"], textColor: "#FFFFFF" },
  { key: "gradient", name: "Градиент", category: "metallics", bg: ["#8B0000", "#DC143C"], textColor: "#FFFFFF" },
  // Полные цвета — используют colors.primary
  { key: "full_red", name: "Красный", category: "fullcolor", bg: ["#DC143C"], textColor: "#FFFFFF", useCustomColor: true },
  { key: "full_blue", name: "Синий", category: "fullcolor", bg: ["#2563EB"], textColor: "#FFFFFF", useCustomColor: true },
  { key: "full_green", name: "Зелёный", category: "fullcolor", bg: ["#059669"], textColor: "#FFFFFF", useCustomColor: true },
  { key: "full_black", name: "Чёрный", category: "fullcolor", bg: ["#111827"], textColor: "#FFFFFF", useCustomColor: true },
  { key: "full_white", name: "Белый", category: "fullcolor", bg: ["#FFFFFF"], textColor: "#111827", useCustomColor: true },
  { key: "full_orange", name: "Оранжевый", category: "fullcolor", bg: ["#EA580C"], textColor: "#FFFFFF", useCustomColor: true },
  // Рамки — белый фон + цветная рамка
  { key: "frame_red", name: "Рамка красная", category: "frames", bg: ["#FFFFFF"], textColor: "#DC143C", isFrame: true, useCustomColor: true },
  { key: "frame_blue", name: "Рамка синяя", category: "frames", bg: ["#FFFFFF"], textColor: "#2563EB", isFrame: true, useCustomColor: true },
  { key: "frame_black", name: "Рамка чёрная", category: "frames", bg: ["#FFFFFF"], textColor: "#111827", isFrame: true, useCustomColor: true },
  { key: "frame_green", name: "Рамка зелёная", category: "frames", bg: ["#FFFFFF"], textColor: "#059669", isFrame: true, useCustomColor: true },
  { key: "frame_gold", name: "Рамка золотая", category: "frames", bg: ["#FFFFFF"], textColor: "#DAA520", isFrame: true, useCustomColor: true },
  // Двойные — верх/низ
  { key: "double_redblack", name: "Красный + Чёрный", category: "double", bg: ["#DC143C", "#111827"], textColor: "#FFFFFF", isDouble: true },
  { key: "double_bluewhite", name: "Синий + Белый", category: "double", bg: ["#2563EB", "#FFFFFF"], textColor: "#FFFFFF", isDouble: true },
  { key: "double_blackgold", name: "Чёрный + Золото", category: "double", bg: ["#111827", "#DAA520"], textColor: "#FFFFFF", isDouble: true },
  { key: "double_greenblack", name: "Зелёный + Чёрный", category: "double", bg: ["#059669", "#111827"], textColor: "#FFFFFF", isDouble: true },
  // Волшебные
  { key: "gloss", name: "Блеск", category: "magic", bg: ["#FF6B6B", "#FF8E8E"], textColor: "#FFFFFF" },
  { key: "holographic", name: "Голографик", category: "magic", bg: ["#FF00FF", "#DA70D6"], textColor: "#FFFFFF" },
  { key: "neon", name: "Неон", category: "magic", bg: ["#39FF14", "#00CC00"], textColor: "#000000" },
];

export const TEMPLATE_CATEGORIES = [
  { key: "metallics", name: "Металлики" },
  { key: "fullcolor", name: "Полные цвета" },
  { key: "frames", name: "Рамки" },
  { key: "double", name: "Двойные" },
  { key: "magic", name: "Волшебные" },
];

export const SEASON_BACKGROUNDS = [
  { key: "", name: "Без фона" },
  { key: "spring", name: "Весна" },
  { key: "summer", name: "Лето" },
  { key: "autumn", name: "Осень" },
  { key: "winter", name: "Зима" },
];

export const FONTS = [
  "Arial", "Inter", "Georgia", "Impact", "Roboto", "Open Sans", "Montserrat", "Lato",
  "Poppins", "Oswald", "Raleway", "Nunito", "Merriweather", "Playfair Display", "Bebas Neue",
  "Fira Sans", "Source Sans Pro", "Ubuntu", "PT Sans", "Noto Sans", "Rubik", "Work Sans",
  "Barlow", "Heebo", "Manrope", "Cabin", "Josefin Sans", "DM Sans", "Space Grotesk",
  "Sora", "Outfit", "Lexend", "Plus Jakarta Sans", "Figtree", "Instrument Sans",
  "Geist", "Schibsted Grotesk", "Public Sans", "Red Hat Display", "Quicksand", "Mulish",
  "Libre Franklin", "Karla", "IBM Plex Sans", "Inconsolata", "JetBrains Mono", "Fira Code",
  "Source Code Pro", "Space Mono", "Oxygen", "Exo 2", "Cairo", "Tajawal", "Almarai",
  "Tinos", "Literata", "Spectral", "STIX Two Text", "Cormorant Garamond", "EB Garamond",
  "Vollkorn", "Cardo", "Libre Baskerville", "Baskervville",
];

export function getDefaultConfig(): CardConfig {
  return {
    template: "kanistra",
    category: "metallics",
    width: 400,
    height: 500,
    borderRadius: 20,
    colors: {
      primary: "#DC143C",
      text: "#FFFFFF",
      volume: "#FFFFFF",
      accent: "#FFD700",
      frame: "#DC143C",
    },
    seasonBg: "",
    fields: {
      characteristics: true,
      name: true,
      logo: true,
      barcode: false,
      volume: true,
      article: true,
      dealer: true,
      advantages: true,
      product: true,
      brand: true,
      subLine: false,
      viscosity: true,
      api: true,
      acea: true,
      ilsac: false,
      direction: true,
      line: true,
      type: false,
      qrCode: false,
      saeBadge: false,
      apiAceaBadge: false,
      ilsacLogo: false,
      kcccCode: false,
      volumeBadge: false,
      dealerBadge: false,
      oemApproval: false,
      country: false,
      ean13: false,
    },
    dealerText: "ОФИЦИАЛЬНЫЙ ДИЛЕР",
    stoNumber: "",
    advantages: [...DEFAULT_ADVANTAGES],
    textSizes: {
      logo: { size: 35, font: "Arial" },
      dealerBadge: { size: 17, font: "Arial" },
      characteristics: { size: 22, font: "Arial" },
      volume: { size: 120, font: "Arial" },
      name: { size: 22, font: "Arial" },
      article: { size: 15, font: "Arial" },
      advantages: { size: 18, font: "Arial" },
    },
    positions: {
      logo: { x: 5, y: 5 },
      dealer: { x: 92, y: 3 },
      name: { x: 5, y: 55 },
      article: { x: 5, y: 62 },
      characteristics: { x: 5, y: 70 },
      volume: { x: 0, y: 0 },
      advantages: { x: 5, y: 78 },
      ean13: { x: 10, y: 92 },
      product: { x: 50, y: 35 },
      qrcode: { x: 80, y: 75 },
      saeBadge: { x: 5, y: 25 },
      apiAcea: { x: 5, y: 32 },
      ilsac: { x: 85, y: 60 },
    },
    photoScale: 60,
    photoX: 50,
    photoY: 35,
    bannerY: 88,
  };
}

export const FIELD_LABELS: Record<string, string> = {
  characteristics: "Характеристики",
  name: "Название",
  logo: "Логотип",
  barcode: "Штрихкод",
  volume: "Объём",
  article: "Артикул",
  dealer: "Дилер",
  advantages: "Преимущества",
  product: "Продукт",
  brand: "Бренд",
  subLine: "Под-линейка",
  viscosity: "Вязкость",
  api: "API",
  acea: "ACEA",
  ilsac: "ILSAC",
  direction: "Направление",
  line: "Линейка",
  type: "Вид",
  qrCode: "QR-код",
  saeBadge: "SAE бейдж",
  apiAceaBadge: "API/ACEA бейдж",
  ilsacLogo: "ILSAC логотип",
  kcccCode: "КССС код",
  volumeBadge: "Объём",
  dealerBadge: "Бейдж дилера",
  oemApproval: "OEM допуск",
  country: "Страна",
  ean13: "EAN-13 штрихкод",
};
