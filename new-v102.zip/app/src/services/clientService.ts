import type { Client, ClientOrder, DadataResponse, ClientHistoryEntry } from "@/types/clients";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";

const STORAGE_KEY = "b2b_clients_db";
const STORAGE_SETTINGS_KEY = "b2b_api_settings";
const DADATA_API_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party";
const DADATA_BATCH_SIZE = 10; // Dadata supports batch queries
const DADATA_MAX_RETRIES = 3;
const DADATA_RETRY_DELAY = 500; // ms

// ═══ localStorage helpers (fallback + cache) ═══
function loadLocal(): Client[] {
  try { const r = localStorage.getItem(STORAGE_KEY); return r ? JSON.parse(r) : []; }
  catch { return []; }
}
function saveLocal(t: Client[]) { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(t)); } catch {} }
function loadLocalSettings(): Record<string, string> {
  try { const r = localStorage.getItem(STORAGE_SETTINGS_KEY); return r ? JSON.parse(r) : {}; }
  catch { return {}; }
}
function saveLocalSettings(s: Record<string, string>) { try { localStorage.setItem(STORAGE_SETTINGS_KEY, JSON.stringify(s)); } catch {} }

// ═══ Supabase: Clients ═══

export async function loadClients(): Promise<Client[]> {
  if (!isSupabaseConfigured) return loadLocal();
  try {
    const { data, error } = await supabase.from("clients").select("*, client_orders(*), client_history(*)");
    if (error) throw error;
    const clients: Client[] = (data || []).map((row: any) => ({
      id: row.id,
      inn: row.inn,
      kpp: row.kpp || "",
      ogrn: row.ogrn || "",
      name: row.name || "",
      fullName: row.full_name || "",
      type: row.type || "",
      status: row.status || "",
      address: row.address || "",
      management: row.management || "",
      managementPost: row.management_post || "",
      okved: row.okved || "",
      phone: row.phone || "",
      email: row.email || "",
      note: row.note || "",
      tags: row.tags || [],
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      orders: (row.client_orders || []).map((o: any) => ({
        id: o.id,
        number: o.number,
        date: o.date,
        amount: Number(o.amount) || 0,
        status: o.status,
        products: o.products,
        notes: o.notes || "",
        createdAt: o.created_at,
      })),
      history: (row.client_history || []).map((h: any) => ({
        id: h.id,
        type: h.type,
        description: h.description,
        date: h.date,
        author: h.author,
      })),
    }));
    saveLocal(clients);
    return clients;
  } catch {
    return loadLocal();
  }
}

export async function saveClients(clients: Client[]) {
  saveLocal(clients);
  if (!isSupabaseConfigured) return;
  // Upsert all clients
  for (const c of clients) {
    await upsertClient(c);
  }
}

async function upsertClient(client: Client) {
  if (!isSupabaseConfigured) return;
  try {
    const { error } = await supabase.from("clients").upsert({
      inn: client.inn,
      kpp: client.kpp || null,
      ogrn: client.ogrn || null,
      name: client.name || "",
      full_name: client.fullName || "",
      type: client.type || null,
      status: client.status || null,
      address: client.address || null,
      management: client.management || null,
      management_post: client.managementPost || null,
      okved: client.okved || null,
      phone: client.phone || null,
      email: client.email || null,
      note: client.note || null,
      tags: client.tags || [],
    }, { onConflict: "inn" });
    if (error) console.error("[Supabase] upsert client error:", error);
    // Upsert orders
    if (client.orders) {
      for (const o of client.orders) {
        await supabase.from("client_orders").upsert({
          id: o.id.length > 30 ? undefined : o.id, // Let DB generate UUID if not valid
          client_inn: client.inn,
          number: o.number,
          date: o.date,
          amount: o.amount,
          status: o.status,
          products: o.products,
          notes: o.notes || null,
        }, { onConflict: "id" });
      }
    }
    // Upsert history
    if (client.history) {
      for (const h of client.history) {
        await supabase.from("client_history").upsert({
          id: h.id.length > 30 ? undefined : h.id,
          client_inn: client.inn,
          type: h.type,
          description: h.description,
          date: h.date,
          author: h.author || null,
        }, { onConflict: "id" });
      }
    }
  } catch (err) {
    console.error("[Supabase] upsert client failed:", err);
  }
}

// ═══ CRUD ═══

export async function addClient(client: Client): Promise<Client[]> {
  const clients = await loadClients();
  const existing = clients.find((c) => c.inn === client.inn);
  let updated: Client[];
  if (existing) {
    updated = clients.map((c) => c.inn === client.inn ? { ...client, updatedAt: new Date().toISOString() } : c);
  } else {
    updated = [...clients, client];
  }
  saveLocal(updated);
  if (isSupabaseConfigured) await upsertClient(client);
  return updated;
}

export async function updateClient(inn: string, updates: Partial<Client>): Promise<Client[]> {
  const clients = await loadClients();
  const updated = clients.map((c) => {
    if (c.inn === inn) {
      const newC = { ...c, ...updates, updatedAt: new Date().toISOString() };
      if (updates.note || updates.phone || updates.email || updates.tags) {
        newC.history = [...c.history, { id: Date.now().toString(), type: "edit", description: `Обновлено: ${Object.keys(updates).join(", ")}`, date: new Date().toISOString() }];
      }
      return newC;
    }
    return c;
  });
  saveLocal(updated);
  if (isSupabaseConfigured) {
    const client = updated.find((c) => c.inn === inn);
    if (client) await upsertClient(client);
  }
  return updated;
}

export async function deleteClient(inn: string): Promise<Client[]> {
  const clients = (await loadClients()).filter((c) => c.inn !== inn);
  saveLocal(clients);
  if (isSupabaseConfigured) {
    await supabase.from("clients").delete().eq("inn", inn);
  }
  return clients;
}

export async function addHistoryEntry(inn: string, entry: ClientHistoryEntry): Promise<Client[]> {
  const clients = await loadClients();
  const updated = clients.map((c) => c.inn === inn ? { ...c, history: [...c.history, entry], updatedAt: new Date().toISOString() } : c);
  saveLocal(updated);
  if (isSupabaseConfigured) {
    await supabase.from("client_history").insert({
      client_inn: inn,
      type: entry.type,
      description: entry.description,
      date: entry.date,
      author: entry.author || null,
    });
  }
  return updated;
}

// ═══ Orders CRUD ═══

export async function addClientOrder(inn: string, order: ClientOrder): Promise<Client[]> {
  const clients = await loadClients();
  const updated = clients.map((c) => c.inn === inn ? { ...c, orders: [...(c.orders || []), order], updatedAt: new Date().toISOString() } : c);
  saveLocal(updated);
  if (isSupabaseConfigured) {
    await supabase.from("client_orders").insert({
      client_inn: inn,
      number: order.number,
      date: order.date,
      amount: order.amount,
      status: order.status,
      products: order.products,
      notes: order.notes || null,
    });
  }
  return updated;
}

export async function updateClientOrder(inn: string, orderId: string, updates: Partial<ClientOrder>): Promise<Client[]> {
  const clients = await loadClients();
  const updated = clients.map((c) => c.inn === inn ? { ...c, orders: (c.orders || []).map((o) => o.id === orderId ? { ...o, ...updates } : o), updatedAt: new Date().toISOString() } : c);
  saveLocal(updated);
  if (isSupabaseConfigured) {
    await supabase.from("client_orders").update({
      number: updates.number,
      date: updates.date,
      amount: updates.amount,
      status: updates.status,
      products: updates.products,
      notes: updates.notes,
    }).eq("id", orderId);
  }
  return updated;
}

export async function deleteClientOrder(inn: string, orderId: string): Promise<Client[]> {
  const clients = await loadClients();
  const updated = clients.map((c) => c.inn === inn ? { ...c, orders: (c.orders || []).filter((o) => o.id !== orderId), updatedAt: new Date().toISOString() } : c);
  saveLocal(updated);
  if (isSupabaseConfigured) {
    await supabase.from("client_orders").delete().eq("id", orderId);
  }
  return updated;
}

// ═══ Filters & Search ═══

export interface ClientFilters {
  status?: string;
  type?: string;
  hasOrders?: boolean;
}

export async function filterClients(filters: ClientFilters): Promise<Client[]> {
  let clients = await loadClients();
  if (filters.status && filters.status !== "all") clients = clients.filter((c) => c.status === filters.status);
  if (filters.type && filters.type !== "all") clients = clients.filter((c) => c.type === filters.type);
  if (filters.hasOrders !== undefined) {
    clients = clients.filter((c) => filters.hasOrders ? (c.orders?.length || 0) > 0 : (c.orders?.length || 0) === 0);
  }
  return clients;
}

export async function searchClients(query: string): Promise<Client[]> {
  const clients = await loadClients();
  if (!query.trim()) return clients;
  const q = query.toLowerCase();
  return clients.filter((c) =>
    c.inn.includes(q) || c.name.toLowerCase().includes(q) || c.fullName.toLowerCase().includes(q) ||
    c.kpp?.includes(q) || c.ogrn?.includes(q) || c.address?.toLowerCase().includes(q) ||
    c.tags?.some((t) => t.toLowerCase().includes(q))
  );
}

// ═══ API Settings (Supabase) ═══

export interface ApiSettings {
  dadataApiKey: string;
  yandexMetricsToken: string;
  yandexMetricsCounterId: string;
  yandexMetricsClientId: string;
}

export async function loadApiSettings(): Promise<ApiSettings> {
  // Try Supabase first
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.from("api_settings").select("*").eq("user_id", "default").single();
      if (!error && data) {
        const settings: ApiSettings = {
          dadataApiKey: data.dadata_api_key || "",
          yandexMetricsToken: data.yandex_metrics_token || "",
          yandexMetricsCounterId: data.yandex_metrics_counter_id || "",
          yandexMetricsClientId: data.yandex_metrics_client_id || "",
        };
        // Sync to localStorage
        saveLocalSettings({
          dadataApiKey: settings.dadataApiKey,
          yandexMetricsToken: settings.yandexMetricsToken,
          yandexMetricsCounterId: settings.yandexMetricsCounterId,
          yandexMetricsClientId: settings.yandexMetricsClientId,
        });
        return settings;
      }
    } catch { /* fallback */ }
  }
  // Fallback: localStorage
  const ls = loadLocalSettings();
  return {
    dadataApiKey: ls.dadataApiKey || localStorage.getItem("dadata_api_key") || "",
    yandexMetricsToken: ls.yandexMetricsToken || "",
    yandexMetricsCounterId: ls.yandexMetricsCounterId || "",
    yandexMetricsClientId: ls.yandexMetricsClientId || "",
  };
}

export async function saveApiSettings(settings: Partial<ApiSettings>) {
  // Save to localStorage
  const existing = loadLocalSettings();
  const merged = { ...existing, ...settings };
  saveLocalSettings(merged);
  if (settings.dadataApiKey !== undefined) localStorage.setItem("dadata_api_key", settings.dadataApiKey);
  // Save to Supabase
  if (isSupabaseConfigured) {
    try {
      await supabase.from("api_settings").upsert({
        user_id: "default",
        dadata_api_key: merged.dadataApiKey || null,
        yandex_metrics_token: merged.yandexMetricsToken || null,
        yandex_metrics_counter_id: merged.yandexMetricsCounterId || null,
        yandex_metrics_client_id: merged.yandexMetricsClientId || null,
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id" });
    } catch (err) {
      console.error("[Supabase] save settings failed:", err);
    }
  }
}

// ═══ Dadata API with retry ═══

async function fetchDadataWithRetry(body: object, apiKey: string, retries = DADATA_MAX_RETRIES): Promise<DadataResponse | null> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(DADATA_API_URL, {
        method: "POST",
        headers: { Authorization: `Token ${apiKey}`, "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(body),
      });
      if (res.status === 429) {
        // Rate limited — wait and retry
        const delay = DADATA_RETRY_DELAY * Math.pow(2, attempt);
        console.warn(`[Dadata] Rate limited, retrying in ${delay}ms (attempt ${attempt + 1})`);
        await new Promise((r) => setTimeout(r, delay));
        continue;
      }
      if (!res.ok) { console.error("[Dadata] HTTP error:", res.status); return null; }
      return (await res.json()) as DadataResponse;
    } catch (err) {
      if (attempt < retries) {
        const delay = DADATA_RETRY_DELAY * Math.pow(2, attempt);
        await new Promise((r) => setTimeout(r, delay));
        continue;
      }
      console.error("[Dadata] Fetch error:", err);
      return null;
    }
  }
  return null;
}

export async function fetchDadataByInn(inn: string, apiKey: string): Promise<DadataResponse | null> {
  if (!apiKey) return null;
  const cleanInn = inn.replace(/\D/g, "");
  if (cleanInn.length < 10) return null;
  return fetchDadataWithRetry({ query: cleanInn }, apiKey);
}

/** Batch lookup — queries Dadata with multiple INNs at once */
export async function fetchDadataBatch(inns: string[], apiKey: string, onChunk?: (done: number, total: number) => void): Promise<Map<string, DadataResponse["suggestions"][0]>> {
  const result = new Map<string, DadataResponse["suggestions"][0]>();
  if (!apiKey || inns.length === 0) return result;

  // Clean and dedupe
  const cleanInns = [...new Set(inns.map((i) => i.replace(/\D/g, "")).filter((i) => i.length >= 10))];

  for (let i = 0; i < cleanInns.length; i += DADATA_BATCH_SIZE) {
    const chunk = cleanInns.slice(i, i + DADATA_BATCH_SIZE);
    const res = await fetchDadataWithRetry({ query: chunk }, apiKey);
    if (res?.suggestions) {
      for (const s of res.suggestions) {
        if (s.data?.inn) result.set(s.data.inn, s);
      }
    }
    if (onChunk) onChunk(Math.min(i + DADATA_BATCH_SIZE, cleanInns.length), cleanInns.length);
    // Small delay between chunks to avoid rate limiting
    if (i + DADATA_BATCH_SIZE < cleanInns.length) {
      await new Promise((r) => setTimeout(r, 200));
    }
  }
  return result;
}

// ═══ Convert Dadata → Client ═══

export function suggestionToClient(s: DadataResponse["suggestions"][0]): Client {
  const d = s.data;
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
    inn: d.inn || "",
    kpp: d.kpp || "",
    ogrn: d.ogrn || "",
    name: d.name?.short_with_opf || s.value || "",
    fullName: d.name?.full_with_opf || s.value || "",
    type: (d.type === "LEGAL" || d.type === "INDIVIDUAL" ? d.type : "") as Client["type"],
    status: (d.state?.status || "") as Client["status"],
    address: d.address?.value || "",
    management: d.management?.name || "",
    managementPost: d.management?.post || "",
    okved: d.okved || "",
    phone: "", email: "", note: "", tags: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    orders: [],
    history: [{ id: Date.now().toString(), type: "create" as const, description: `Клиент добавлен через Dadata (ИНН: ${d.inn})`, date: new Date().toISOString() }],
  };
}

export function createMinimalClient(inn: string, name?: string): Client {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
    inn: inn.replace(/\D/g, ""), kpp: "", ogrn: "",
    name: name || `Клиент ИНН ${inn}`,
    fullName: name || `Клиент ИНН ${inn}`,
    type: "" as Client["type"], status: "" as Client["status"],
    address: "", management: "", managementPost: "", okved: "",
    phone: "", email: "", note: "", tags: [],
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    orders: [],
    history: [{ id: Date.now().toString(), type: "create" as const, description: `Клиент добавлен из файла (ИНН: ${inn})`, date: new Date().toISOString() }],
  };
}

// ═══ Migration: localStorage → Supabase ═══

export async function migrateLocalToSupabase(): Promise<boolean> {
  if (!isSupabaseConfigured) return false;
  const alreadyMigrated = localStorage.getItem("b2b_clients_migrated");
  if (alreadyMigrated) return true;
  const localClients = loadLocal();
  if (localClients.length === 0) { localStorage.setItem("b2b_clients_migrated", "true"); return true; }
  console.log(`[Migration] Migrating ${localClients.length} clients to Supabase...`);
  for (const client of localClients) {
    await upsertClient(client);
    await new Promise((r) => setTimeout(r, 50));
  }
  // Migrate settings
  const dadataKey = localStorage.getItem("dadata_api_key") || "";
  if (dadataKey) {
    await saveApiSettings({ dadataApiKey: dadataKey });
  }
  localStorage.setItem("b2b_clients_migrated", "true");
  console.log("[Migration] Done!");
  return true;
}

// ═══ Import from Excel/TXT ═══

export interface ImportResult {
  rows: Array<{ inn: string; name?: string; phone?: string; email?: string; note?: string }>;
  innColumnFound: boolean;
  totalRows: number;
  detectedHeaders: string[];
}

function isInnColumn(h: string): boolean {
  const hl = h.toLowerCase();
  return hl === "инн" || hl === "inn" || hl.includes("инн");
}
function normalizeInn(v: unknown): string {
  if (v == null) return "";
  if (typeof v === "number") { const s = v.toString(); return s.length === 9 ? "0" + s : s; }
  return String(v).trim();
}

export async function parseClientsFromExcel(file: File): Promise<ImportResult> {
  return new Promise((resolve, reject) => {
    if (file.name.toLowerCase().endsWith(".txt")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const lines = String(e.target?.result || "").split(/\r?\n/);
        const rows: Array<{ inn: string }> = [];
        for (const line of lines) { const d = line.trim().replace(/\D/g, ""); if (d.length >= 10 && d.length <= 12) rows.push({ inn: d }); }
        resolve({ rows, innColumnFound: rows.length > 0, totalRows: lines.length, detectedHeaders: ["TXT"] });
      };
      reader.readAsText(file);
      return;
    }
    import("xlsx").then((XLSX) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const wb = XLSX.read(new Uint8Array(e.target?.result as ArrayBuffer), { type: "array" });
          const sheet = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: "" }) as string[][];
          if (sheet.length < 1) { resolve({ rows: [], innColumnFound: false, totalRows: 0, detectedHeaders: [] }); return; }
          const headers = sheet[0].map((h) => String(h).toLowerCase().trim());
          let innCol = headers.findIndex(isInnColumn);
          if (innCol === -1) innCol = 0;
          const colMap: Record<string, number> = {};
          headers.forEach((h, i) => { if (isInnColumn(h)) colMap.inn = i; if (h.includes("название") || h.includes("наименование") || h.includes("name")) colMap.name = i; if (h.includes("телефон") || h.includes("phone")) colMap.phone = i; if (h.includes("email") || h.includes("почта")) colMap.email = i; if (h.includes("примечание") || h.includes("note")) colMap.note = i; });
          const results: ImportResult["rows"] = [];
          for (let i = 1; i < sheet.length; i++) {
            const row = sheet[i];
            if (!row.some((v) => String(v).trim())) continue;
            const inn = normalizeInn(innCol >= 0 ? row[innCol] : "").replace(/\D/g, "");
            if (inn.length < 10 || inn.length > 12) continue;
            results.push({ inn, name: colMap.name !== undefined ? String(row[colMap.name] || "").trim() || undefined : undefined, phone: colMap.phone !== undefined ? String(row[colMap.phone] || "").trim() || undefined : undefined, email: colMap.email !== undefined ? String(row[colMap.email] || "").trim() || undefined : undefined, note: colMap.note !== undefined ? String(row[colMap.note] || "").trim() || undefined : undefined });
          }
          resolve({ rows: results, innColumnFound: innCol >= 0, totalRows: sheet.length - 1, detectedHeaders: headers });
        } catch (err) { reject(err); }
      };
      reader.readAsArrayBuffer(file);
    });
  });
}

export interface BulkImportResult {
  added: number; existing: number; failed: number; dadataMiss: number; log: string[];
}

export async function bulkImportClients(file: File, dadataKey: string, onProgress: (pct: number) => void): Promise<BulkImportResult> {
  const result: BulkImportResult = { added: 0, existing: 0, failed: 0, dadataMiss: 0, log: [] };
  let parsed: ImportResult;
  try { parsed = await parseClientsFromExcel(file); } catch (err) { result.log.push(`Ошибка парсинга: ${String(err)}`); return result; }
  if (!parsed.innColumnFound) { result.log.push(`Колонка ИНН не найдена. Заголовки: ${parsed.detectedHeaders.join(", ")}`); return result; }
  if (parsed.rows.length === 0) { result.log.push("Не найдено валидных ИНН"); return result; }

  const existingClients = await loadClients();
  const newRows = parsed.rows.filter((r) => !existingClients.find((c) => c.inn === r.inn));
  result.existing = parsed.rows.length - newRows.length;
  if (newRows.length === 0) { result.log.push(`Все ${result.existing} клиентов уже в базе`); return result; }

  result.log.push(`Всего: ${parsed.rows.length}, новых: ${newRows.length}, уже в базе: ${result.existing}`);
  if (dadataKey) result.log.push(`Запрашиваем Dadata (batch по ${DADATA_BATCH_SIZE})...`);

  // Batch Dadata lookup for new INNs only
  let dadataMap = new Map<string, DadataResponse["suggestions"][0]>();
  if (dadataKey) {
    dadataMap = await fetchDadataBatch(
      newRows.map((r) => r.inn),
      dadataKey,
      (done, total) => onProgress(Math.round((done / total) * 50)) // First 50% for Dadata
    );
    result.log.push(`Dadata нашёл: ${dadataMap.size} / ${newRows.length}`);
  }

  // Process results
  for (let i = 0; i < newRows.length; i++) {
    onProgress(50 + Math.round(((i + 1) / newRows.length) * 50)); // Second 50% for processing
    const row = newRows[i];
    const dadataResult = dadataMap.get(row.inn);
    let client: Client;
    if (dadataResult) {
      client = suggestionToClient(dadataResult);
      if (row.phone) client.phone = row.phone;
      if (row.email) client.email = row.email;
      if (row.note) client.note = row.note;
      result.log.push(`✓ ${row.inn} — ${client.name}`);
    } else {
      client = createMinimalClient(row.inn, row.name);
      if (row.phone) client.phone = row.phone;
      if (row.email) client.email = row.email;
      if (row.note) client.note = row.note;
      result.dadataMiss++;
      result.log.push(`⚠ ${row.inn} — ${client.name}`);
    }
    existingClients.push(client);
    result.added++;
    await upsertClient(client);
  }

  saveLocal(existingClients);
  result.log.push(`---`);
  result.log.push(`Итого: ${result.added} добавлено, ${result.existing} уже было, ${result.dadataMiss} без Dadata`);
  return result;
}
