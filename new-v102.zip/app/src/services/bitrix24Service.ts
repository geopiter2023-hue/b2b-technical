// ═══════════════════════════════════════════
// Bitrix24 REST API Integration
// ═══════════════════════════════════════════

import type { OrderRecord } from "./salesService";

const API_VERSION = "v1";

export interface Bitrix24Config {
  webhookUrl: string; // https://domain.bitrix24.ru/rest/USER_ID/WEBHOOK_TOKEN/
  enabled: boolean;
  lastSync: string;
}

export interface Bitrix24Order {
  id: number;
  accountNumber: string;
  dateInsert: string;
  statusId: string;
  statusName: string;
  payed: string; // "Y" or "N"
  price: string;
  currency: string;
  userId: number;
  clientName: string;
  clientPhone: string;
  clientEmail: string;
  deliveryName: string;
  deliveryAddress: string;
  products: Bitrix24Product[];
  comments: string;
  updatedAt: string;
}

export interface Bitrix24Product {
  id: number;
  name: string;
  quantity: number;
  price: number;
  productId: number;
}

export interface Bitrix24Contact {
  id: number;
  name: string;
  lastName: string;
  secondName: string;
  phone: string;
  email: string;
  companyName: string;
  inn: string;
  kpp: string;
  address: string;
  web: string;
  typeId: string; // CLIENT, SUPPLIER, etc.
  sourceId: string;
  assignedById: number;
  createdTime: string;
}

export interface Bitrix24Company {
  id: number;
  title: string;
  inn: string;
  kpp: string;
  ogrn: string;
  phone: string;
  email: string;
  address: string;
  web: string;
  companyType: string;
  industry: string;
  employees: string;
  revenue: string;
  assignedById: number;
  createdTime: string;
}

// ═══ Config storage ═══

const CONFIG_KEY = "bitrix24_config";

export function loadConfig(): Bitrix24Config {
  try {
    const saved = localStorage.getItem(CONFIG_KEY);
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  return { webhookUrl: "", enabled: false, lastSync: "" };
}

export function saveConfig(config: Bitrix24Config) {
  localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
}

// ═══ Helper: make API call ═══

async function apiCall<T>(webhookUrl: string, method: string, params: Record<string, any> = {}): Promise<T | null> {
  // Ensure trailing slash
  const base = webhookUrl.endsWith("/") ? webhookUrl : webhookUrl + "/";
  const url = `${base}${method}.json`;

  try {
    const body = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null) {
        if (Array.isArray(value)) {
          value.forEach((v, i) => body.append(`${key}[${i}]`, String(v)));
        } else {
          body.append(key, String(value));
        }
      }
    }

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });

    if (!res.ok) {
      console.error(`[Bitrix24] HTTP ${res.status}: ${method}`);
      return null;
    }

    const json = await res.json();
    if (json.error) {
      console.error(`[Bitrix24] Error ${json.error}: ${json.error_description}`);
      return null;
    }
    return json.result as T;
  } catch (err) {
    console.error(`[Bitrix24] Fetch error: ${method}`, err);
    return null;
  }
}

// ═══ Orders ═══

export async function getOrders(webhookUrl: string, filter: { dateFrom?: string; dateTo?: string; statusId?: string } = {}): Promise<Bitrix24Order[]> {
  // Get order list
  const listResult = await apiCall<any>(webhookUrl, "sale.order.list", {
    "filter[>DATE_INSERT]": filter.dateFrom || undefined,
    "filter[<DATE_INSERT]": filter.dateTo || undefined,
    "filter[STATUS_ID]": filter.statusId || undefined,
    order: { DATE_INSERT: "DESC" },
    select: ["ID", "ACCOUNT_NUMBER", "DATE_INSERT", "STATUS_ID", "PRICE", "CURRENCY", "USER_ID", "COMMENTS", "DATE_UPDATE"],
  });

  if (!listResult || !Array.isArray(listResult.orders)) return [];

  // Get status names
  const statusesResult = await apiCall<any>(webhookUrl, "sale.status.list");
  const statusMap: Record<string, string> = {};
  if (statusesResult && Array.isArray(statusesResult)) {
    for (const s of statusesResult) {
      statusMap[s.id] = s.name;
    }
  }

  const orders: Bitrix24Order[] = [];

  for (const o of listResult.orders) {
    // Get basket items for each order
    const basketResult = await apiCall<any>(webhookUrl, "sale.basketitem.list", {
      "filter[ORDER_ID]": o.id,
      select: ["ID", "NAME", "QUANTITY", "PRICE", "PRODUCT_ID"],
    });

    // Get user info
    const userResult = await apiCall<any>(webhookUrl, "user.get", { ID: o.userId });
    const user = userResult && Array.isArray(userResult) && userResult.length > 0 ? userResult[0] : null;

    const products: Bitrix24Product[] = (basketResult?.basketItems || []).map((b: any) => ({
      id: Number(b.id),
      name: String(b.name || ""),
      quantity: Number(b.quantity || 0),
      price: Number(b.price || 0),
      productId: Number(b.productId || 0),
    }));

    orders.push({
      id: Number(o.id),
      accountNumber: String(o.accountNumber || o.id),
      dateInsert: String(o.dateInsert || ""),
      statusId: String(o.statusId || ""),
      statusName: statusMap[o.statusId] || o.statusId,
      payed: String(o.payed || "N"),
      price: String(o.price || "0"),
      currency: String(o.currency || "RUB"),
      userId: Number(o.userId || 0),
      clientName: user ? `${user.NAME || ""} ${user.LAST_NAME || ""}`.trim() : `User #${o.userId}`,
      clientPhone: user?.PERSONAL_MOBILE || user?.WORK_PHONE || "",
      clientEmail: user?.EMAIL || "",
      deliveryName: "",
      deliveryAddress: "",
      products,
      comments: String(o.comments || ""),
      updatedAt: String(o.dateUpdate || ""),
    });
  }

  return orders;
}

// ═══ Contacts (Clients) ═══

export async function getContacts(webhookUrl: string): Promise<Bitrix24Contact[]> {
  const result = await apiCall<any>(webhookUrl, "crm.contact.list", {
    select: ["ID", "NAME", "LAST_NAME", "SECOND_NAME", "PHONE", "EMAIL", "COMPANY_TITLE", "ADDRESS", "WEB", "TYPE_ID", "SOURCE_ID", "ASSIGNED_BY_ID", "DATE_CREATE"],
  });

  if (!result || !Array.isArray(result)) return [];

  return result.map((c: any) => ({
    id: Number(c.ID || 0),
    name: String(c.NAME || ""),
    lastName: String(c.LAST_NAME || ""),
    secondName: String(c.SECOND_NAME || ""),
    phone: extractPhone(c.PHONE),
    email: extractEmail(c.EMAIL),
    companyName: String(c.COMPANY_TITLE || ""),
    inn: "", // Will be filled from requisites
    kpp: "",
    address: String(c.ADDRESS || ""),
    web: String(c.WEB || ""),
    typeId: String(c.TYPE_ID || ""),
    sourceId: String(c.SOURCE_ID || ""),
    assignedById: Number(c.ASSIGNED_BY_ID || 0),
    createdTime: String(c.DATE_CREATE || ""),
  }));
}

// ═══ Companies (with INN/KPP) ═══

export async function getCompanies(webhookUrl: string): Promise<Bitrix24Company[]> {
  const result = await apiCall<any>(webhookUrl, "crm.company.list", {
    select: ["ID", "TITLE", "PHONE", "EMAIL", "ADDRESS", "WEB", "COMPANY_TYPE", "INDUSTRY", "EMPLOYEES", "REVENUE", "ASSIGNED_BY_ID", "DATE_CREATE"],
  });

  if (!result || !Array.isArray(result)) return [];

  const companies: Bitrix24Company[] = [];

  for (const c of result) {
    // Get requisites for INN/KPP
    const requisites = await apiCall<any>(webhookUrl, "crm.requisite.list", {
      "filter[ENTITY_TYPE_ID]": 4, // COMPANY
      "filter[ENTITY_ID]": c.ID,
    });

    let inn = "", kpp = "", ogrn = "";
    if (requisites && Array.isArray(requisites) && requisites.length > 0) {
      const req = requisites[0];
      inn = String(req.RQ_INN || "");
      kpp = String(req.RQ_KPP || "");
      ogrn = String(req.RQ_OGRN || "");
    }

    companies.push({
      id: Number(c.ID || 0),
      title: String(c.TITLE || ""),
      inn,
      kpp,
      ogrn,
      phone: extractPhone(c.PHONE),
      email: extractEmail(c.EMAIL),
      address: String(c.ADDRESS || ""),
      web: String(c.WEB || ""),
      companyType: String(c.COMPANY_TYPE || ""),
      industry: String(c.INDUSTRY || ""),
      employees: String(c.EMPLOYEES || ""),
      revenue: String(c.REVENUE || ""),
      assignedById: Number(c.ASSIGNED_BY_ID || 0),
      createdTime: String(c.DATE_CREATE || ""),
    });
  }

  return companies;
}

// ═══ Test connection ═══

export async function testConnection(webhookUrl: string): Promise<{ success: boolean; userName?: string; error?: string }> {
  if (!webhookUrl.includes(".bitrix24") || !webhookUrl.includes("/rest/")) {
    return { success: false, error: "Неверный формат webhook URL" };
  }

  const result = await apiCall<any>(webhookUrl, "profile");
  if (!result) {
    return { success: false, error: "Не удалось подключиться. Проверьте webhook URL." };
  }

  return {
    success: true,
    userName: `${result.NAME || ""} ${result.LAST_NAME || ""}`.trim(),
  };
}

// ═══ Convert Bitrix24 orders → OrderRecord for SalesDashboard ═══

export async function getOrdersAsRecords(webhookUrl: string, filter: { dateFrom?: string; dateTo?: string } = {}): Promise<OrderRecord[]> {
  const bxOrders = await getOrders(webhookUrl, filter);
  const records: OrderRecord[] = [];

  for (const o of bxOrders) {
    // Each product in order becomes a separate OrderRecord
    for (const p of o.products) {
      records.push({
        id: `${o.id}-${p.id}`,
        date: o.dateInsert?.split("T")[0] || "",
        updDate: null,
        orderNumber: o.accountNumber,
        region: "",
        dealer: "",
        delivery: o.deliveryName || "",
        ksss: null,
        product: p.name,
        productCode: p.productId || null,
        externalCatalogCode: null,
        externalProductCode: null,
        viscosity: null,
        application: null,
        productWeight: null,
        grossWeight: null,
        netWeightKg: null,
        quantity: p.quantity,
        unit: null,
        productPrice: p.price,
        productAmount: p.price * p.quantity,
        totalAmount: Number(o.price),
        deliveryCost: null,
        discount: null,
        discountPercent: null,
        discountLevel: null,
        nds: null,
        priceType: null,
        status: o.statusName || "N",
        paid: o.payed === "Y",
        shipped: false,
        cancelled: (o.statusName || "").toLowerCase().includes("отмен"),
        deliveryAllowed: false,
        hasProblem: false,
        buyer: o.clientName || `Клиент #${o.userId}`,
        buyerEmail: o.clientEmail || null,
        buyerInn: null,
        buyerLegalName: null,
        payerType: null,
        paymentSystem: null,
        paymentStatus: null,
        paidAmount: o.payed === "Y" ? Number(o.price) : null,
        psAmount: null,
        updGenerated: false,
        updNumber: null,
        updDocNumber: null,
        updDocDate: null,
        updDocSerial: null,
        asfGenerated: false,
        asfDocNumber: null,
        asfDocDate: null,
        trackingNumber: null,
        shippingIdentifier: null,
        deliveryDateApproved: null,
        shippingDocNumber: null,
        shippingDocDate: null,
        deliveryTimeMin: null,
        deliveryTimeMax: null,
        deliveryPeriodMin: null,
        deliveryPeriodMax: null,
        pvzCode: null,
        pvzIndexCity: null,
        paymentOrderNumber: null,
        paymentOrderDate: null,
        paymentOrderViewStatus: null,
        source: "bitrix24",
        externalOrderCode: o.accountNumber,
        site: null,
        responsible: null,
        office: null,
        affiliate: null,
        bitrixSync: "synced",
        comment: o.comments || null,
        buyerComment: null,
        cancelReason: null,
        cancelComment: null,
        problemDescription: null,
        hydrolift: false,
        dealerPaymentEmailSent: false,
        buyerPaymentEmailSent: false,
        preOrder: false,
        edoParticipation: null,
        changeDate: null,
        fundsReceiptDate: null,
        yandexProUser: null,
        discountsAndRules: null,
        coupons: null,
        deliveryMethodInfo: null,
        deliveryType: null,
        deliveryTypeId: null,
        tariffType: null,
        tariffId: null,
        deliveryApp: null,
        tariffName: null,
        totalLogisticsCost: null,
        bankAccount: null,
        bankName: null,
        bankBik: null,
        dealerId: null,
        addressString: o.deliveryAddress || null,
        house: null,
        street: null,
        city: null,
        zip: null,
        location: null,
        fiasRegion: null,
        contactFio: o.clientName || null,
        contactEmail: o.clientEmail || null,
        contactPhone: o.clientPhone || null,
        accumulatedWeightAtOrder: null,
        accumulatedWeightAtRecalc: null,
        actualAccumulatedWeight: null,
        totalOrdersSinceRegistration: null,
        opticoreOrderId: null,
        courierCity: null,
        courierStreet: null,
        aouuid: null,
        dealerSaved: false,
        dealerConfirmed: false,
        deliveryInvoice: null,
        managerCalculationNeeded: false,
        postponeLoglabSend: false,
        accountingDocsEmailSent: false,
        riskIndicatorResponseId: null,
        asfFile: null,
        updFile: null,
        orderProblem: null,
      });
    }
    // If order has no products, still add it as one record
    if (o.products.length === 0) {
      records.push({
        id: String(o.id),
        date: o.dateInsert?.split("T")[0] || "",
        updDate: null,
        orderNumber: o.accountNumber,
        region: "",
        dealer: "",
        delivery: o.deliveryName || "",
        ksss: null,
        product: "Заказ без товаров",
        productCode: null,
        externalCatalogCode: null,
        externalProductCode: null,
        viscosity: null,
        application: null,
        productWeight: null,
        grossWeight: null,
        netWeightKg: null,
        quantity: 1,
        unit: null,
        productPrice: Number(o.price),
        productAmount: Number(o.price),
        totalAmount: Number(o.price),
        deliveryCost: null,
        discount: null,
        discountPercent: null,
        discountLevel: null,
        nds: null,
        priceType: null,
        status: o.statusName || "N",
        paid: o.payed === "Y",
        shipped: false,
        cancelled: (o.statusName || "").toLowerCase().includes("отмен"),
        deliveryAllowed: false,
        hasProblem: false,
        buyer: o.clientName || `Клиент #${o.userId}`,
        buyerEmail: o.clientEmail || null,
        buyerInn: null,
        buyerLegalName: null,
        payerType: null,
        paymentSystem: null,
        paymentStatus: null,
        paidAmount: o.payed === "Y" ? Number(o.price) : null,
        psAmount: null,
        updGenerated: false,
        updNumber: null,
        updDocNumber: null,
        updDocDate: null,
        updDocSerial: null,
        asfGenerated: false,
        asfDocNumber: null,
        asfDocDate: null,
        trackingNumber: null,
        shippingIdentifier: null,
        deliveryDateApproved: null,
        shippingDocNumber: null,
        shippingDocDate: null,
        deliveryTimeMin: null,
        deliveryTimeMax: null,
        deliveryPeriodMin: null,
        deliveryPeriodMax: null,
        pvzCode: null,
        pvzIndexCity: null,
        paymentOrderNumber: null,
        paymentOrderDate: null,
        paymentOrderViewStatus: null,
        source: "bitrix24",
        externalOrderCode: o.accountNumber,
        site: null,
        responsible: null,
        office: null,
        affiliate: null,
        bitrixSync: "synced",
        comment: o.comments || null,
        buyerComment: null,
        cancelReason: null,
        cancelComment: null,
        problemDescription: null,
        hydrolift: false,
        dealerPaymentEmailSent: false,
        buyerPaymentEmailSent: false,
        preOrder: false,
        edoParticipation: null,
        changeDate: null,
        fundsReceiptDate: null,
        yandexProUser: null,
        discountsAndRules: null,
        coupons: null,
        deliveryMethodInfo: null,
        deliveryType: null,
        deliveryTypeId: null,
        tariffType: null,
        tariffId: null,
        deliveryApp: null,
        tariffName: null,
        totalLogisticsCost: null,
        bankAccount: null,
        bankName: null,
        bankBik: null,
        dealerId: null,
        addressString: o.deliveryAddress || null,
        house: null,
        street: null,
        city: null,
        zip: null,
        location: null,
        fiasRegion: null,
        contactFio: o.clientName || null,
        contactEmail: o.clientEmail || null,
        contactPhone: o.clientPhone || null,
        accumulatedWeightAtOrder: null,
        accumulatedWeightAtRecalc: null,
        actualAccumulatedWeight: null,
        totalOrdersSinceRegistration: null,
        opticoreOrderId: null,
        courierCity: null,
        courierStreet: null,
        aouuid: null,
        dealerSaved: false,
        dealerConfirmed: false,
        deliveryInvoice: null,
        managerCalculationNeeded: false,
        postponeLoglabSend: false,
        accountingDocsEmailSent: false,
        riskIndicatorResponseId: null,
        asfFile: null,
        updFile: null,
        orderProblem: null,
      });
    }
  }

  return records;
}

// ═══ Helpers ═══

function extractPhone(phoneField: any): string {
  if (!phoneField) return "";
  if (Array.isArray(phoneField)) {
    const first = phoneField.find((p: any) => p.VALUE);
    return first?.VALUE || "";
  }
  return String(phoneField);
}

function extractEmail(emailField: any): string {
  if (!emailField) return "";
  if (Array.isArray(emailField)) {
    const first = emailField.find((e: any) => e.VALUE);
    return first?.VALUE || "";
  }
  return String(emailField);
}
