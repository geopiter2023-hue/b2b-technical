import { useState, useEffect } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import {
  loadConfig,
  saveConfig,
  testConnection,
  getOrders,
  getContacts,
  getCompanies,
  type Bitrix24Config,
  type Bitrix24Order,
  type Bitrix24Contact,
  type Bitrix24Company,
} from "@/services/bitrix24Service";
import {
  Link2, CheckCircle2, AlertCircle, RefreshCw, Package,
  Users, Building2, Search, ChevronDown, ChevronUp,
  Phone, Mail, MapPin, Calendar, DollarSign,
} from "lucide-react";

export default function Bitrix24Page() {
  const [config, setConfig] = useState<Bitrix24Config>(loadConfig);
  const [webhookInput, setWebhookInput] = useState(config.webhookUrl);
  const [testResult, setTestResult] = useState<{ success: boolean; userName?: string; error?: string } | null>(null);
  const [activeTab, setActiveTab] = useState<"orders" | "contacts" | "companies">("orders");
  const [orders, setOrders] = useState<Bitrix24Order[]>([]);
  const [contacts, setContacts] = useState<Bitrix24Contact[]>([]);
  const [companies, setCompanies] = useState<Bitrix24Company[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  useEffect(() => { setWebhookInput(config.webhookUrl); }, [config.webhookUrl]);

  const handleTest = async () => {
    setTestResult(null);
    setError("");
    const result = await testConnection(webhookInput);
    setTestResult(result);
    if (result.success) {
      const newConfig = { ...config, webhookUrl: webhookInput, enabled: true };
      setConfig(newConfig);
      saveConfig(newConfig);
    }
  };

  const handleSync = async () => {
    if (!config.enabled || !config.webhookUrl) { setError("Сначала настройте подключение"); return; }
    setIsLoading(true);
    setError("");
    try {
      if (activeTab === "orders") {
        const data = await getOrders(config.webhookUrl, {
          dateFrom: dateFrom || undefined,
          dateTo: dateTo || undefined,
        });
        setOrders(data);
      } else if (activeTab === "contacts") {
        const data = await getContacts(config.webhookUrl);
        setContacts(data);
      } else {
        const data = await getCompanies(config.webhookUrl);
        setCompanies(data);
      }
      const newConfig = { ...config, lastSync: new Date().toISOString() };
      setConfig(newConfig);
      saveConfig(newConfig);
    } catch (err) {
      setError("Ошибка синхронизации: " + String(err));
    }
    setIsLoading(false);
  };

  const filteredOrders = orders.filter((o) =>
    !searchQuery ||
    o.accountNumber.includes(searchQuery) ||
    o.clientName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredContacts = contacts.filter((c) =>
    !searchQuery ||
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.phone.includes(searchQuery) ||
    c.inn?.includes(searchQuery)
  );

  const filteredCompanies = companies.filter((c) =>
    !searchQuery ||
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.inn?.includes(searchQuery) ||
    c.phone?.includes(searchQuery)
  );

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)] bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Link2 className="h-6 w-6 text-[#0d9488]" />
            Интеграция с Битрикс24
          </h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Прямое подключение к магазину Битрикс24 через webhook API
          </p>
        </div>

        <div className="px-6 py-4 space-y-4">
          {/* Connection Settings */}
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h2 className="text-sm font-semibold text-gray-700 mb-3">Подключение</h2>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={webhookInput}
                onChange={(e) => setWebhookInput(e.target.value)}
                placeholder="Вставьте webhook URL: https://ваш-домен.bitrix24.ru/rest/1/abcdef..."
                className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:border-[#0d9488]"
              />
              <Button onClick={handleTest} variant="outline" className="gap-1.5">
                <Link2 className="h-4 w-4" />
                Проверить
              </Button>
            </div>

            {testResult && (
              <div className={`mt-2 flex items-center gap-2 text-sm px-3 py-2 rounded-lg ${testResult.success ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>
                {testResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                {testResult.success ? `Подключено! Пользователь: ${testResult.userName}` : testResult.error}
              </div>
            )}

            <div className="mt-2 text-xs text-gray-400">
              Как получить webhook: Битрикс24 → Приложения → Вебхуки → Скопировать inbound webhook URL
            </div>

            {config.enabled && (
              <div className="mt-2 text-xs text-[#0d9488]">
                ✓ Подключено{config.lastSync ? ` · Последняя синхронизация: ${new Date(config.lastSync).toLocaleString("ru-RU")}` : ""}
              </div>
            )}
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">
              <AlertCircle className="h-4 w-4" />{error}
            </div>
          )}

          {/* Data Tabs */}
          {config.enabled && (
            <>
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="flex border-b border-gray-100">
                  {[
                    { key: "orders" as const, label: `Заказы (${orders.length})`, icon: Package },
                    { key: "contacts" as const, label: `Контакты (${contacts.length})`, icon: Users },
                    { key: "companies" as const, label: `Компании (${companies.length})`, icon: Building2 },
                  ].map((t) => (
                    <button
                      key={t.key}
                      onClick={() => setActiveTab(t.key)}
                      className={`flex-1 py-2.5 text-sm font-medium flex items-center justify-center gap-1.5 ${activeTab === t.key ? "text-[#0d9488] border-b-2 border-[#0d9488]" : "text-gray-500 hover:text-gray-700"}`}
                    >
                      <t.icon className="h-4 w-4" />{t.label}
                    </button>
                  ))}
                </div>

                <div className="p-4">
                  {/* Filters */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-1.5 flex-1 min-w-[200px]">
                      <Search className="h-4 w-4 text-gray-400" />
                      <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Поиск..." className="bg-transparent text-sm outline-none flex-1" />
                    </div>
                    {activeTab === "orders" && (
                      <>
                        <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="text-sm border rounded-lg px-2 py-1.5" />
                        <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="text-sm border rounded-lg px-2 py-1.5" />
                      </>
                    )}
                    <Button size="sm" onClick={handleSync} disabled={isLoading} className="bg-[#0d9488] hover:bg-[#0f766e] gap-1.5">
                      <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                      {isLoading ? "Загрузка..." : "Синхронизировать"}
                    </Button>
                  </div>

                  {/* Content */}
                  {activeTab === "orders" && (
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {filteredOrders.length === 0 ? (
                        <div className="text-center py-8 text-gray-400">
                          <Package className="h-10 w-10 mx-auto mb-2 opacity-30" />
                          <p className="text-sm">Нет заказов. Нажмите «Синхронизировать»</p>
                        </div>
                      ) : (
                        filteredOrders.map((order) => (
                          <div key={order.id} className="border border-gray-100 rounded-lg overflow-hidden">
                            <div
                              className="flex items-center justify-between px-3 py-2 cursor-pointer hover:bg-gray-50"
                              onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                            >
                              <div className="flex items-center gap-2 flex-1 min-w-0">
                                <span className="text-xs font-mono text-gray-400">#{order.accountNumber}</span>
                                <span className="text-sm font-medium text-gray-800 truncate">{order.clientName || "—"}</span>
                                <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${order.payed === "Y" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>
                                  {order.payed === "Y" ? "Оплачен" : order.statusName}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium text-gray-800">{Number(order.price).toLocaleString("ru-RU")} ₽</span>
                                {expandedOrder === order.id ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />}
                              </div>
                            </div>
                            {expandedOrder === order.id && (
                              <div className="px-3 py-2 bg-gray-50 border-t border-gray-100 space-y-1.5">
                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                  <Calendar className="h-3 w-3" />{new Date(order.dateInsert).toLocaleString("ru-RU")}
                                </div>
                                {order.clientPhone && <div className="flex items-center gap-2 text-xs text-gray-500"><Phone className="h-3 w-3" />{order.clientPhone}</div>}
                                {order.clientEmail && <div className="flex items-center gap-2 text-xs text-gray-500"><Mail className="h-3 w-3" />{order.clientEmail}</div>}
                                {order.comments && <div className="text-xs text-gray-500">{order.comments}</div>}
                                <div className="mt-2">
                                  <div className="text-[10px] font-medium text-gray-500 uppercase mb-1">Товары ({order.products.length})</div>
                                  {order.products.map((p) => (
                                    <div key={p.id} className="flex items-center justify-between text-xs py-0.5">
                                      <span className="text-gray-700 truncate flex-1">{p.name}</span>
                                      <span className="text-gray-500 ml-2">{p.quantity} шт × {p.price.toLocaleString("ru-RU")} ₽</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {activeTab === "contacts" && (
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {filteredContacts.length === 0 ? (
                        <div className="text-center py-8 text-gray-400">
                          <Users className="h-10 w-10 mx-auto mb-2 opacity-30" />
                          <p className="text-sm">Нет контактов. Нажмите «Синхронизировать»</p>
                        </div>
                      ) : (
                        filteredContacts.map((c) => (
                          <div key={c.id} className="flex items-start justify-between px-3 py-2 border border-gray-100 rounded-lg hover:bg-gray-50">
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium text-gray-800">{c.name} {c.lastName}</div>
                              {c.companyName && <div className="text-xs text-gray-500">{c.companyName}</div>}
                              <div className="flex items-center gap-3 mt-1">
                                {c.phone && <span className="flex items-center gap-1 text-xs text-gray-500"><Phone className="h-3 w-3" />{c.phone}</span>}
                                {c.email && <span className="flex items-center gap-1 text-xs text-gray-500"><Mail className="h-3 w-3" />{c.email}</span>}
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {activeTab === "companies" && (
                    <div className="space-y-2 max-h-[500px] overflow-y-auto">
                      {filteredCompanies.length === 0 ? (
                        <div className="text-center py-8 text-gray-400">
                          <Building2 className="h-10 w-10 mx-auto mb-2 opacity-30" />
                          <p className="text-sm">Нет компаний. Нажмите «Синхронизировать»</p>
                        </div>
                      ) : (
                        filteredCompanies.map((c) => (
                          <div key={c.id} className="flex items-start justify-between px-3 py-2 border border-gray-100 rounded-lg hover:bg-gray-50">
                            <div className="flex-1 min-w-0">
                              <div className="text-sm font-medium text-gray-800">{c.title}</div>
                              <div className="flex items-center gap-3 mt-1 flex-wrap">
                                {c.inn && <span className="text-xs font-mono text-gray-500">ИНН: {c.inn}</span>}
                                {c.kpp && <span className="text-xs font-mono text-gray-500">КПП: {c.kpp}</span>}
                                {c.phone && <span className="flex items-center gap-1 text-xs text-gray-500"><Phone className="h-3 w-3" />{c.phone}</span>}
                                {c.email && <span className="flex items-center gap-1 text-xs text-gray-500"><Mail className="h-3 w-3" />{c.email}</span>}
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </Layout>
  );
}
