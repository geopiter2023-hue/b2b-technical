import { useState, useRef, useCallback, useMemo, useEffect } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Upload, BarChart3, TrendingUp, Package, Users, Receipt,
  Download, RotateCcw, Truck, CheckCircle, XCircle,
  AlertTriangle, CircleDollarSign, FileSpreadsheet, FileDown,
  Settings2, EyeOff, Trash2, ChevronDown, ChevronRight,
  MapPin, History, X, Link2
} from "lucide-react";
import {
  parseLukoilExcel,
  getSummary,
  aggregateByPeriod,
  aggregateByDimension,
  getStatusDistribution,
  getDeliveryDistribution,
  getTopProducts,
  getTopBuyers,
  filterRecords,
  getFilterOptions,
  ALL_COLUMNS,
  getRecordValue,
  saveOrdersToStorage,
  loadOrdersFromStorage,
  type OrderRecord as OrderRecordType,
  saveVisibleColumns,
  loadVisibleColumns,
} from "@/services/salesService";
import {
  loadConfig as loadBitrixConfig,
  getOrdersAsRecords,
  type Bitrix24Config,
} from "@/services/bitrix24Service";
import {
  clearSalesStorage,
  addUploadHistory,
  getUploadHistory,
  deleteUploadHistoryItem,
  clearUploadHistory,
  saveFileData,
  loadFileData,
  deleteFileData,
  listSavedFiles,
  type OrderRecord,
  type SalesSummary,
  type ChartData,
  type ColumnDef,
  type UploadHistoryItem,
  type SavedFileData,
} from "@/services/salesService";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
} from "chart.js";
import { Bar, Pie, Doughnut, Line } from "react-chartjs-2";
import PasswordDialog from "@/components/PasswordDialog";
import html2canvas from "html2canvas-pro";
import jsPDF from "jspdf";
import ChartDataLabels from "chartjs-plugin-datalabels";

ChartJS.register(
  CategoryScale, LinearScale, BarElement, Title,
  Tooltip, Legend, ArcElement, PointElement, LineElement,
  ChartDataLabels
);

const CHART_OPTIONS = {
  responsive: true,
  plugins: {
    legend: { display: false },
    datalabels: {
      display: true,
      color: "#374151",
      font: { weight: "bold" as const, size: 10 },
      anchor: "end" as const,
      align: "top" as const,
      formatter: (v: number) => v >= 1000000 ? (v / 1000000).toFixed(1) + "M" : v >= 1000 ? (v / 1000).toFixed(0) + "k" : v,
    },
  },
  scales: { y: { beginAtZero: true } },
};

const PIE_OPTIONS = {
  responsive: true,
  plugins: {
    legend: { position: "bottom" as const, labels: { boxWidth: 12, font: { size: 10 } } },
    datalabels: {
      display: true,
      color: "#fff",
      font: { weight: "bold" as const, size: 11 },
      formatter: (_v: number, ctx: any) => {
        const sum = ctx.dataset.data.reduce((a: number, b: number) => a + b, 0);
        const pct = sum > 0 ? ((ctx.dataset.data[ctx.dataIndex] / sum) * 100).toFixed(1) + "%" : "";
        return pct;
      },
    },
  },
};

const HBAR_OPTIONS = {
  responsive: true,
  indexAxis: "y" as const,
  plugins: {
    legend: { display: false },
    datalabels: {
      display: true,
      color: "#374151",
      font: { weight: "bold" as const, size: 10 },
      anchor: "end" as const,
      align: "right" as const,
      formatter: (v: number) => v >= 1000000 ? (v / 1000000).toFixed(1) + "M" : v >= 1000 ? (v / 1000).toFixed(0) + "k" : v,
    },
  },
  scales: { x: { beginAtZero: true } },
};

function formatCurrency(v: number): string {
  return new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(v);
}

function formatNumber(v: number): string {
  return new Intl.NumberFormat("ru-RU").format(v);
}

// ============================================================
// PDF helpers
// ============================================================
function aggregateForPdf(records: OrderRecord[]) {
  const statusMap = new Map<string, { count: number; revenue: number }>();
  const regionMap = new Map<string, { count: number; revenue: number }>();
  const deliveryMap = new Map<string, { count: number; revenue: number }>();
  const dealerMap = new Map<string, { count: number; revenue: number }>();
  const viscosityMap = new Map<string, { count: number; revenue: number }>();
  const appMap = new Map<string, { count: number; revenue: number }>();

  records.forEach((r) => {
    const s = r.status || "—";
    const se = statusMap.get(s) || { count: 0, revenue: 0 };
    se.count += 1; se.revenue += r.productAmount; statusMap.set(s, se);

    const re = regionMap.get(r.region) || { count: 0, revenue: 0 };
    re.count += 1; re.revenue += r.productAmount; regionMap.set(r.region, re);

    const de = deliveryMap.get(r.delivery) || { count: 0, revenue: 0 };
    de.count += 1; de.revenue += r.productAmount; deliveryMap.set(r.delivery, de);

    const dle = dealerMap.get(r.dealer) || { count: 0, revenue: 0 };
    dle.count += 1; dle.revenue += r.productAmount; dealerMap.set(r.dealer, dle);

    const v = r.viscosity || "Не установлено";
    const ve = viscosityMap.get(v) || { count: 0, revenue: 0 };
    ve.count += 1; ve.revenue += r.productAmount; viscosityMap.set(v, ve);

    const a = r.application || "Не установлено";
    const ae = appMap.get(a) || { count: 0, revenue: 0 };
    ae.count += 1; ae.revenue += r.productAmount; appMap.set(a, ae);
  });

  return {
    statusTable: Array.from(statusMap.entries()).map(([status, v]) => ({ status, ...v })).sort((a, b) => b.revenue - a.revenue),
    regionTable: Array.from(regionMap.entries()).map(([region, v]) => ({ region, ...v })).sort((a, b) => b.revenue - a.revenue),
    deliveryTable: Array.from(deliveryMap.entries()).map(([delivery, v]) => ({ delivery, ...v })).sort((a, b) => b.revenue - a.revenue),
    dealerTable: Array.from(dealerMap.entries()).map(([dealer, v]) => ({ dealer, ...v })).sort((a, b) => b.revenue - a.revenue),
    viscosityTable: Array.from(viscosityMap.entries()).map(([viscosity, v]) => ({ viscosity, ...v })).sort((a, b) => b.revenue - a.revenue),
    applicationTable: Array.from(appMap.entries()).map(([app, v]) => ({ app, ...v })).sort((a, b) => b.revenue - a.revenue),
  };
}

const PdfBar = ({ value, max, color }: { value: number; max: number; color: string }) => {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div style={{ width: "100%", height: "12px", background: "#f0f0f0", borderRadius: "3px", overflow: "hidden" }}>
      <div style={{ width: `${pct}%`, height: "100%", background: color, borderRadius: "3px" }} />
    </div>
  );
};

const colors = ["#DC2626", "#EF4444", "#F97316", "#EAB308", "#22C55E", "#3B82F6", "#8B5CF6", "#EC4899", "#14B8A6", "#6366F1"];

const StatCard = ({ title, value, sub, icon: Icon, color, onClick }: any) => (
  <Card className={onClick ? "cursor-pointer hover:shadow-md transition-shadow" : ""} onClick={onClick}>
    <CardContent className="p-4 flex items-center gap-4">
      <div className={`p-3 rounded-lg ${color}`}><Icon className="h-6 w-6" /></div>
      <div className="min-w-0">
        <p className="text-sm text-gray-500 truncate">{title}</p>
        <p className="text-xl font-bold text-gray-900">{value}</p>
        {sub && <p className="text-xs text-gray-400">{sub}</p>}
      </div>
    </CardContent>
  </Card>
);

export default function SalesDashboard() {
  // Defer localStorage loading to avoid blocking main thread
  const [records, setRecords] = useState<OrderRecord[]>([]);
  const [filtered, setFiltered] = useState<OrderRecord[]>([]);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [summary, setSummary] = useState<SalesSummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const pdfRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [columnDialogOpen, setColumnDialogOpen] = useState(false);
  const [uploadHistory, setUploadHistory] = useState<UploadHistoryItem[]>([]);
  const [bitrixConfig, setBitrixConfig] = useState<Bitrix24Config>(loadBitrixConfig);
  const [bitrixSyncing, setBitrixSyncing] = useState(false);

  // Load saved data off-main-thread on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const saved = loadOrdersFromStorage();
        if (saved && saved.length > 0) {
          setRecords(saved);
          setFiltered(saved);
          setSummary(getSummary(saved));
        }
      } catch (e) { console.error("[Sales] Failed to load saved orders:", e); }
      // Load upload history
      setUploadHistory(getUploadHistory());
      setIsDataLoaded(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  // Visible columns - load from localStorage or use defaults
  const [visibleColumns, setVisibleColumns] = useState<string[]>(() => {
    const saved = loadVisibleColumns();
    if (saved && saved.length > 0) return saved;
    return ALL_COLUMNS.filter((c) => c.defaultVisible).map((c) => c.key);
  });

  // Expand/collapse categories in dialog
  const [expandedCats, setExpandedCats] = useState<Record<string, boolean>>({});

  // Filters
  const [filters, setFilters] = useState({
    dateFrom: "", dateTo: "", status: "all", region: "all",
    dealer: "all", delivery: "all", buyer: "all", product: "all",
    paid: "all", cancelled: "all",
  });

  const [period, setPeriod] = useState<"day" | "week" | "month">("day");

  // Summary computed only via applyFilters — no duplicate useEffect

  const filterOptions = useMemo(() =>
    records.length > 0 ? getFilterOptions(records) : null,
    [records]
  );

  const applyFilters = useCallback((recs: OrderRecord[], flts: typeof filters) => {
    const f = filterRecords(recs, flts);
    setFiltered(f);
    setSummary(getSummary(f));
  }, []);

  const [loadError, setLoadError] = useState<string | null>(null);

  const handleBitrixSync = async () => {
    if (!bitrixConfig.enabled || !bitrixConfig.webhookUrl) {
      setLoadError("Сначала настройте Битрикс24 в разделе «Битрикс24 API»");
      return;
    }
    setBitrixSyncing(true);
    setLoadError("");
    try {
      const data = await getOrdersAsRecords(bitrixConfig.webhookUrl);
      if (data.length === 0) {
        setLoadError("Нет заказов в Битрикс24");
        setBitrixSyncing(false);
        return;
      }
      setRecords(data);
      setFiltered(data);
      setSummary(getSummary(data));
      saveOrdersToStorage(data);
      setUploadHistory([{ id: `bx-${Date.now()}`, fileName: `Битрикс24 (${data.length} позиций)`, recordCount: data.length, date: new Date().toISOString() }, ...uploadHistory]);
    } catch (err: any) {
      setLoadError("Ошибка синхронизации: " + (err.message || String(err)));
    }
    setBitrixSyncing(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Show password dialog first
    setPendingFile(file);
    setPwdAction({ type: "upload", label: "Загрузка файла" });
    setPwdDialogOpen(true);
    // Reset file input
    if (fileRef.current) fileRef.current.value = "";
  };

  const processFile = async (file: File) => {
    setIsLoading(true);
    setLoadError(null);
    try {
      console.log("[Sales] Parsing file:", file.name, "size:", (file.size / 1024).toFixed(1), "KB");
      const data = await parseLukoilExcel(file);
      console.log("[Sales] Parsed records:", data.length);
      setRecords(data);
      setFiltered(data);
      const sm = getSummary(data);
      setSummary(sm);
      // Save to localStorage with error handling
      try { saveOrdersToStorage(data); } catch (e: any) { console.warn("[Sales] Failed to save to localStorage:", e.message); }
      // Save upload history + file data
      try {
        const uploadId = addUploadHistory(file.name, data.length, sm.totalRevenue);
        if (uploadId) saveFileData(uploadId, file.name, data);
      } catch (e) { /* ignore */ }
      // Reset filters
      const emptyFilters = { dateFrom: "", dateTo: "", status: "all", region: "all", dealer: "all", delivery: "all", buyer: "all", product: "all", paid: "all", cancelled: "all" };
      setFilters(emptyFilters);
      setActiveTab("overview");
    } catch (err: any) {
      console.error("[Sales] Upload error:", err);
      setLoadError(err.message || "Ошибка загрузки файла");
    } finally {
      setIsLoading(false);
    }
  };

  const updateFilter = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    applyFilters(records, newFilters);
  };

  const resetFilters = () => {
    const empty = { dateFrom: "", dateTo: "", status: "all", region: "all", dealer: "all", delivery: "all", buyer: "all", product: "all", paid: "all", cancelled: "all" };
    setFilters(empty);
    applyFilters(records, empty);
  };

  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [pwdDialogOpen, setPwdDialogOpen] = useState(false);
  const [pwdAction, setPwdAction] = useState<{ type: "upload" | "clear"; label: string }>({ type: "upload", label: "Загрузка файла" });
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  const handleClearData = () => {
    clearSalesStorage();
    clearUploadHistory();
    setRecords([]);
    setFiltered([]);
    setSummary(null);
    setUploadHistory([]);
    setShowClearConfirm(false);
  };

  // Column management
  const toggleColumn = (key: string) => {
    setVisibleColumns((prev) => {
      const next = prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key];
      saveVisibleColumns(next);
      return next;
    });
  };

  const toggleCategory = (category: string) => {
    setExpandedCats((prev) => ({ ...prev, [category]: !prev[category] }));
  };

  const selectAllInCategory = (category: string) => {
    const catCols = ALL_COLUMNS.filter((c) => c.category === category).map((c) => c.key);
    setVisibleColumns((prev) => {
      const next = Array.from(new Set([...prev, ...catCols]));
      saveVisibleColumns(next);
      return next;
    });
  };

  const deselectAllInCategory = (category: string) => {
    const catCols = ALL_COLUMNS.filter((c) => c.category === category).map((c) => c.key);
    setVisibleColumns((prev) => {
      const next = prev.filter((k) => !catCols.includes(k));
      saveVisibleColumns(next);
      return next;
    });
  };

  const resetColumns = () => {
    const defaults = ALL_COLUMNS.filter((c) => c.defaultVisible).map((c) => c.key);
    setVisibleColumns(defaults);
    saveVisibleColumns(defaults);
  };

  // CSV export
  const handleExport = () => {
    if (!filtered.length) return;
    // Headers: only visible columns
    const visibleDefs = ALL_COLUMNS.filter((c) => visibleColumns.includes(c.key));
    let csv = visibleDefs.map((c) => c.label).join(";") + "\n";
    for (const r of filtered) {
      csv += visibleDefs.map((c) => {
        const v = getRecordValue(r, c.key);
        const s = String(v).replace(/"/g, '""');
        return s.includes(";") ? `"${s}"` : s;
      }).join(";") + "\n";
    }
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "lukoil_orders_export.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  // PDF export
  const handleExportPdf = async () => {
    if (!filtered.length) return;
    setExportingPdf(true);
    // Wait for React to render the hidden PDF div
    await new Promise((r) => setTimeout(r, 500));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (!pdfRef.current) {
      setExportingPdf(false);
      alert("PDF элемент не найден");
      return;
    }
    try {
      const canvas = await html2canvas(pdfRef.current, {
        scale: 1.5, useCORS: true, logging: false,
        backgroundColor: "#ffffff", windowWidth: 1200,
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pw = 210, ph = 297, m = 10, cw = pw - m * 2;
      const imgH = (canvas.height * cw) / canvas.width;
      let pos = 0, rem = imgH;
      while (rem > 0) {
        const sliceH = Math.min(ph - m * 2, rem);
        const sc = document.createElement("canvas");
        sc.width = canvas.width;
        sc.height = (sliceH / imgH) * canvas.height;
        const ctx = sc.getContext("2d")!;
        ctx.drawImage(canvas, 0, (pos / imgH) * canvas.height, canvas.width, (sliceH / imgH) * canvas.height, 0, 0, sc.width, sc.height);
        if (pos > 0) pdf.addPage();
        pdf.addImage(sc.toDataURL("image/png"), "PNG", m, m, cw, sliceH);
        pos += sliceH; rem -= sliceH;
      }
      pdf.save(`lukoil_report_${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch (err: any) { alert("Ошибка PDF: " + err.message); }
    finally { setExportingPdf(false); }
  };

  // Charts
  const periodChart = useMemo(() => filtered.length ? aggregateByPeriod(filtered, period) : null, [filtered, period]);
  const statusChart = useMemo(() => filtered.length ? getStatusDistribution(filtered) : null, [filtered]);
  const deliveryChart = useMemo(() => filtered.length ? getDeliveryDistribution(filtered) : null, [filtered]);
  const regionChart = useMemo(() => filtered.length ? aggregateByDimension(filtered, "region") : null, [filtered]);
  const dealerChart = useMemo(() => filtered.length ? aggregateByDimension(filtered, "dealer") : null, [filtered]);
  const viscosityChart = useMemo(() => filtered.length ? aggregateByDimension(filtered, "viscosity") : null, [filtered]);
  const applicationChart = useMemo(() => filtered.length ? aggregateByDimension(filtered, "application") : null, [filtered]);
  const topProducts = useMemo(() => filtered.length ? getTopProducts(filtered, 15) : [], [filtered]);
  const topBuyers = useMemo(() => filtered.length ? getTopBuyers(filtered, 15) : [], [filtered]);

  // PDF data
  const pdfData = useMemo(() => aggregateForPdf(filtered), [filtered]);
  const maxRegionRev = pdfData.regionTable[0]?.revenue || 1;
  const maxDealerRev = pdfData.dealerTable[0]?.revenue || 1;
  const maxProdRev = topProducts[0]?.revenue || 1;
  const maxBuyerRev = topBuyers[0]?.revenue || 1;
  const maxViscRev = pdfData.viscosityTable[0]?.revenue || 1;

  // Visible column definitions
  const visibleColDefs = useMemo(() =>
    ALL_COLUMNS.filter((c) => visibleColumns.includes(c.key)),
    [visibleColumns]
  );

  // Grouped columns for dialog
  const groupedColumns = useMemo(() => {
    const cats = new Map<string, ColumnDef[]>();
    ALL_COLUMNS.forEach((c) => {
      const arr = cats.get(c.category) || [];
      arr.push(c);
      cats.set(c.category, arr);
    });
    return Array.from(cats.entries());
  }, []);

  // Loading saved data from localStorage
  if (!isDataLoaded) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <div className="text-center">
            <div className="animate-spin h-10 w-10 border-4 border-red-200 border-t-red-700 rounded-full mx-auto mb-4" />
            <p className="text-gray-500">Загрузка сохранённых данных...</p>
          </div>
        </div>
      </Layout>
    );
  }

  // Empty state — no data
  if (records.length === 0) {
    return (
      <Layout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <FileSpreadsheet className="h-7 w-7 text-red-700" />
              Дашборд заказов ЛУКОЙЛ
            </h1>
          </div>
          <Card className="py-8 sm:py-16">
            <CardContent className="text-center px-4 sm:px-6">
              <Upload className="h-12 w-12 sm:h-16 sm:w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-base sm:text-lg font-semibold text-gray-600 mb-2">Загрузите отчёт по заказам</h3>
              <p className="text-xs sm:text-sm text-gray-400 mb-4 max-w-lg mx-auto">
                Загрузите Excel-файл или синхронизируйте с Битрикс24 напрямую. Данные сохранятся автоматически.
              </p>
              <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} onChange={handleFileUpload} className="hidden" />
              <div className="flex flex-wrap gap-2 justify-center">
                <Button className="bg-red-700 hover:bg-red-800" size="sm" onClick={() => fileRef.current?.click()} disabled={isLoading}>
                  <Upload className="h-4 w-4 mr-2" />{isLoading ? "Загрузка..." : "Выбрать файл"}
                </Button>
                <Button variant="outline" size="sm" onClick={handleBitrixSync} disabled={bitrixSyncing} className="gap-1.5 border-[#0d9488] text-[#0d9488] hover:bg-[#f0fdfa]">
                  <Link2 className="h-4 w-4" />{bitrixSyncing ? "Синхронизация..." : "Из Битрикс24"}
                </Button>
              </div>
              {loadError && <p className="text-red-600 text-sm mt-3">{loadError}</p>}
            </CardContent>
          </Card>

          {/* Upload history */}
          {uploadHistory.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <History className="h-5 w-5 text-gray-500" />
                  История загрузок ({uploadHistory.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {uploadHistory.map((item) => {
                    const hasData = !!loadFileData(item.id);
                    return (
                    <div key={item.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-50">
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <FileSpreadsheet className="h-5 w-5 text-red-600 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-gray-800 truncate">{item.fileName}</p>
                          <p className="text-xs text-gray-500">
                            {new Date(item.uploadedAt).toLocaleDateString("ru-RU")} в {new Date(item.uploadedAt).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}
                            {" · "}{formatNumber(item.recordCount)} записей
                            {item.totalRevenue > 0 && ` · ${formatNumber(item.totalRevenue)} ₽`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {hasData && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-700 border-red-200 hover:bg-red-50 h-7 text-xs"
                            onClick={() => {
                              const saved = loadFileData(item.id);
                              if (saved) {
                                setRecords(saved.orders);
                                setFiltered(saved.orders);
                                setSummary(getSummary(saved.orders));
                                setActiveTab("overview");
                              }
                            }}
                          >
                            <Upload className="h-3 w-3 mr-1" />Загрузить
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-red-600 h-7 w-7 p-0"
                          onClick={() => {
                            deleteUploadHistoryItem(item.id);
                            deleteFileData(item.id);
                            setUploadHistory(getUploadHistory());
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
          {/* Password Dialog */}
          <PasswordDialog
            open={pwdDialogOpen}
            onOpenChange={setPwdDialogOpen}
            action={pwdAction.label}
            onSuccess={() => {
              if (pwdAction.type === "upload" && pendingFile) {
                processFile(pendingFile);
                setPendingFile(null);
              } else if (pwdAction.type === "clear") {
                handleClearData();
              }
            }}
          />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Error display */}
        {loadError && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="h-5 w-5" />
              <span className="text-sm font-medium">{loadError}</span>
            </div>
            <Button variant="ghost" size="sm" className="text-red-600" onClick={() => setLoadError(null)}>✕</Button>
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <FileSpreadsheet className="h-7 w-7 text-red-700" />
              Дашборд заказов ЛУКОЙЛ
            </h1>
            {uploadHistory.length > 0 && (
              <p className="text-xs text-gray-500 ml-9">
                Последняя загрузка: {uploadHistory[0].fileName} ({formatNumber(uploadHistory[0].recordCount)} записей)
              </p>
            )}
          </div>
          <div className="flex gap-2 flex-wrap">
            <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} onChange={handleFileUpload} className="hidden" />
            <Button variant="outline" size="sm" className="border-red-700 text-red-700 hover:bg-red-50" onClick={() => fileRef.current?.click()} disabled={isLoading}>
              <Upload className="h-4 w-4 sm:mr-2" /><span className="hidden sm:inline">{isLoading ? "..." : "Новый файл"}</span><span className="sm:hidden">Файл</span>
            </Button>

            {/* Column selector dialog */}
            <Dialog open={columnDialogOpen} onOpenChange={setColumnDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="border-gray-300 text-gray-700 hover:bg-gray-50">
                  <Settings2 className="h-4 w-4 sm:mr-2" /><span className="hidden sm:inline">Колонки ({visibleColumns.length})</span><span className="sm:hidden">Кол.</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg sm:max-w-2xl max-h-[85vh] sm:max-h-[80vh] p-0 mx-2 sm:mx-auto">
                <DialogHeader className="p-4 pb-2">
                  <DialogTitle className="flex items-center justify-between text-base">
                    <span>Настройка колонок</span>
                    <Button variant="ghost" size="sm" className="text-gray-500 h-8" onClick={resetColumns}>
                      <RotateCcw className="h-3 w-3 mr-1" />По умолч.
                    </Button>
                  </DialogTitle>
                </DialogHeader>
                <ScrollArea className="px-4 pb-4" style={{ maxHeight: "60vh" }}>
                  <div className="space-y-3">
                    {groupedColumns.map(([category, cols]) => (
                      <div key={category} className="border border-gray-100 rounded-lg overflow-hidden">
                        <button
                          onClick={() => toggleCategory(category)}
                          className="w-full flex items-center justify-between px-3 py-2 bg-gray-50 hover:bg-gray-100 transition-colors"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            {expandedCats[category] ? <ChevronDown className="h-4 w-4 text-gray-500 flex-shrink-0" /> : <ChevronRight className="h-4 w-4 text-gray-500 flex-shrink-0" />}
                            <span className="font-semibold text-sm text-gray-700 truncate">{category}</span>
                            <Badge className="bg-gray-100 text-gray-600 text-xs flex-shrink-0">
                              {cols.filter((c) => visibleColumns.includes(c.key)).length}/{cols.length}
                            </Badge>
                          </div>
                          <div className="flex gap-1 flex-shrink-0">
                            <Button variant="ghost" size="sm" className="h-6 text-xs text-red-600 hover:text-red-800 px-2" onClick={(e) => { e.stopPropagation(); selectAllInCategory(category); }}>
                              Все
                            </Button>
                            <Button variant="ghost" size="sm" className="h-6 text-xs text-gray-500 px-2" onClick={(e) => { e.stopPropagation(); deselectAllInCategory(category); }}>
                              Снять
                            </Button>
                          </div>
                        </button>
                        {expandedCats[category] && (
                          <div className="p-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {cols.map((col) => (
                              <label key={col.key} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                                <Checkbox
                                  checked={visibleColumns.includes(col.key)}
                                  onCheckedChange={() => toggleColumn(col.key)}
                                />
                                <span className="text-sm text-gray-700">{col.label}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </DialogContent>
            </Dialog>

            <Button variant="outline" size="sm" className="border-gray-300 text-gray-700 hover:bg-gray-50" onClick={handleExport}>
              <Download className="h-4 w-4 sm:mr-2" /><span className="hidden sm:inline">CSV</span>
            </Button>
            <Button variant="outline" size="sm" className="border-gray-300 text-gray-700 hover:bg-gray-50" onClick={handleExportPdf} disabled={exportingPdf}>
              <FileDown className="h-4 w-4 sm:mr-2" />{exportingPdf ? "..." : <><span className="hidden sm:inline">PDF</span><span className="sm:hidden">PDF</span></>}
            </Button>
            {/* Clear data with confirmation */}
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-red-600 px-2" onClick={() => { setPwdAction({ type: "clear", label: "Удаление данных" }); setPwdDialogOpen(true); }} title="Удалить данные">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Summary Cards */}
        {summary && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <StatCard title="Выручка" value={formatCurrency(summary.totalRevenue)} icon={Receipt} color="bg-red-50 text-red-700" />
              <StatCard title="Заказов" value={formatNumber(summary.totalOrders)} sub={`${formatNumber(summary.totalProducts)} позиций`} icon={Package} color="bg-amber-50 text-amber-700" />
              <StatCard title="Средний чек" value={formatCurrency(summary.avgOrderValue)} icon={TrendingUp} color="bg-emerald-50 text-emerald-700" />
              <StatCard title="Доставка" value={formatCurrency(summary.totalDeliveryCost)} icon={Truck} color="bg-blue-50 text-blue-700" />
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <StatCard title="Оплачено" value={formatCurrency(summary.paidAmount)} icon={CheckCircle} color="bg-emerald-50 text-emerald-700" onClick={() => updateFilter("paid", "yes")} />
              <StatCard title="Не оплачено" value={formatCurrency(summary.unpaidAmount)} icon={XCircle} color="bg-orange-50 text-orange-700" onClick={() => { updateFilter("paid", "no"); updateFilter("cancelled", "no"); }} />
              <StatCard title="Отменено" value={formatCurrency(summary.cancelledAmount)} icon={AlertTriangle} color="bg-red-50 text-red-700" onClick={() => updateFilter("cancelled", "yes")} />
              <StatCard title="Скидки" value={formatCurrency(summary.totalDiscount)} icon={CircleDollarSign} color="bg-purple-50 text-purple-700" />
            </div>
          </>
        )}

        {/* Filters */}
        <Card>
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-red-700" />Фильтры
              </h3>
              <Button variant="ghost" size="sm" className="text-gray-500 hover:text-red-700" onClick={resetFilters}>
                <RotateCcw className="h-3 w-3 mr-1" />Сбросить
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-2">
              <div><Label className="text-xs text-gray-500">Дата с</Label><Input type="date" value={filters.dateFrom} onChange={(e) => updateFilter("dateFrom", e.target.value)} /></div>
              <div><Label className="text-xs text-gray-500">Дата по</Label><Input type="date" value={filters.dateTo} onChange={(e) => updateFilter("dateTo", e.target.value)} /></div>
              {filterOptions && (
                <>
                  <div><Label className="text-xs text-gray-500">Статус</Label>
                    <Select value={filters.status} onValueChange={(v) => updateFilter("status", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="all">Все</SelectItem>{filterOptions.statuses.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs text-gray-500">Регион</Label>
                    <Select value={filters.region} onValueChange={(v) => updateFilter("region", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="all">Все</SelectItem>{filterOptions.regions.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs text-gray-500">Дилер</Label>
                    <Select value={filters.dealer} onValueChange={(v) => updateFilter("dealer", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="all">Все</SelectItem>{filterOptions.dealers.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs text-gray-500">Доставка</Label>
                    <Select value={filters.delivery} onValueChange={(v) => updateFilter("delivery", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="all">Все</SelectItem>{filterOptions.deliveries.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs text-gray-500">Оплата</Label>
                    <Select value={filters.paid} onValueChange={(v) => updateFilter("paid", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="all">Все</SelectItem><SelectItem value="yes">Оплачено</SelectItem><SelectItem value="no">Не оплачено</SelectItem></SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs text-gray-500">Отмена</Label>
                    <Select value={filters.cancelled} onValueChange={(v) => updateFilter("cancelled", v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="all">Все</SelectItem><SelectItem value="yes">Отменено</SelectItem><SelectItem value="no">Активно</SelectItem></SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>
            <p className="text-xs text-gray-500">Найдено: <strong>{formatNumber(filtered.length)}</strong> из {formatNumber(records.length)} | Колонок: <strong>{visibleColumns.length}</strong></p>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="overview">Обзор</TabsTrigger>
            <TabsTrigger value="statuses">Статусы</TabsTrigger>
            <TabsTrigger value="regions">Регионы</TabsTrigger>
            <TabsTrigger value="products">Товары</TabsTrigger>
            <TabsTrigger value="buyers">Покупатели</TabsTrigger>
            <TabsTrigger value="table">
              Таблица {visibleColumns.length > 0 && <Badge className="ml-1 bg-red-50 text-red-700 text-xs">{visibleColumns.length}</Badge>}
            </TabsTrigger>
          </TabsList>

          {/* OVERVIEW */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-red-700" />Динамика выручки</CardTitle>
                    <div className="flex gap-1">
                      {(["day", "week", "month"] as const).map((p) => (
                        <Button key={p} variant={period === p ? "default" : "ghost"} size="sm" className={period === p ? "bg-red-700 hover:bg-red-800" : "text-gray-500"} onClick={() => setPeriod(p)}>
                          {p === "day" ? "День" : p === "week" ? "Неделя" : "Месяц"}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>{periodChart && <Line data={periodChart as any} options={{ ...CHART_OPTIONS, elements: { line: { tension: 0.3 } } }} />}</CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="h-4 w-4 text-red-700" />По статусам</CardTitle>
                </CardHeader>
                <CardContent>{statusChart && <Doughnut data={statusChart as any} options={PIE_OPTIONS} />}</CardContent>
              </Card>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><MapPin className="h-4 w-4 text-red-700" />По регионам</CardTitle></CardHeader>
                <CardContent>{regionChart && <Bar data={regionChart as any} options={HBAR_OPTIONS} />}</CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-base flex items-center gap-2"><Truck className="h-4 w-4 text-red-700" />По доставке</CardTitle></CardHeader>
                <CardContent>{deliveryChart && <Pie data={deliveryChart as any} options={PIE_OPTIONS} />}</CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* STATUSES */}
          <TabsContent value="statuses" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card><CardHeader><CardTitle className="text-base">Распределение по статусам</CardTitle></CardHeader>
                <CardContent className="flex justify-center">{statusChart && <Doughnut data={statusChart as any} options={{ ...PIE_OPTIONS, cutout: "50%" }} />}</CardContent>
              </Card>
              <Card><CardHeader><CardTitle className="text-base">По дилерам</CardTitle></CardHeader>
                <CardContent>{dealerChart && <Bar data={dealerChart as any} options={HBAR_OPTIONS} />}</CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* REGIONS */}
          <TabsContent value="regions" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card><CardHeader><CardTitle className="text-base">Выручка по регионам</CardTitle></CardHeader>
                <CardContent>{regionChart && <Bar data={regionChart as any} options={CHART_OPTIONS} />}</CardContent>
              </Card>
              <Card><CardHeader><CardTitle className="text-base">По способу доставки</CardTitle></CardHeader>
                <CardContent className="flex justify-center">{deliveryChart && <Pie data={deliveryChart as any} options={PIE_OPTIONS} />}</CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* PRODUCTS */}
          <TabsContent value="products" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card><CardHeader><CardTitle className="text-base flex items-center gap-2"><Package className="h-4 w-4 text-red-700" />По вязкости</CardTitle></CardHeader>
                <CardContent>{viscosityChart && <Bar data={viscosityChart as any} options={HBAR_OPTIONS} />}</CardContent>
              </Card>
              <Card><CardHeader><CardTitle className="text-base">По области применения</CardTitle></CardHeader>
                <CardContent className="flex justify-center">{applicationChart && <Doughnut data={applicationChart as any} options={PIE_OPTIONS} />}</CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader><CardTitle className="text-base">ТОП-15 товаров</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader><TableRow className="bg-gray-50">
                    <TableHead className="w-[40px]">#</TableHead><TableHead>Товар</TableHead>
                    <TableHead className="text-right">Кол-во</TableHead><TableHead className="text-right">Выручка</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>{topProducts.map((p, i) => (
                    <TableRow key={i} className="hover:bg-gray-50">
                      <TableCell className="text-gray-400">{i + 1}</TableCell>
                      <TableCell className="whitespace-normal break-words" style={{ maxWidth: "400px" }}><span className="text-sm">{p.product}</span></TableCell>
                      <TableCell className="text-right font-medium">{formatNumber(p.quantity)}</TableCell>
                      <TableCell className="text-right font-semibold text-red-700">{formatCurrency(p.revenue)}</TableCell>
                    </TableRow>
                  ))}</TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* BUYERS */}
          <TabsContent value="buyers" className="space-y-4">
            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><Users className="h-4 w-4 text-red-700" />ТОП-15 покупателей</CardTitle></CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader><TableRow className="bg-gray-50">
                    <TableHead className="w-[40px]">#</TableHead><TableHead>Покупатель</TableHead>
                    <TableHead className="text-right">Заказов</TableHead><TableHead className="text-right">Выручка</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>{topBuyers.map((b, i) => (
                    <TableRow key={i} className="hover:bg-gray-50">
                      <TableCell className="text-gray-400">{i + 1}</TableCell>
                      <TableCell className="whitespace-normal break-words" style={{ maxWidth: "300px" }}><span className="text-sm font-medium">{b.buyer}</span></TableCell>
                      <TableCell className="text-right"><Badge className="bg-blue-50 text-blue-700">{b.orders}</Badge></TableCell>
                      <TableCell className="text-right font-semibold text-red-700">{formatCurrency(b.revenue)}</TableCell>
                    </TableRow>
                  ))}</TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* TABLE - with configurable columns */}
          <TabsContent value="table">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <CardTitle className="text-base">Данные ({formatNumber(filtered.length)} записей, {visibleColumns.length} колонок)</CardTitle>
                  <Button variant="outline" size="sm" className="text-red-700 border-red-200 self-start sm:self-auto" onClick={() => setColumnDialogOpen(true)}>
                    <Settings2 className="h-4 w-4 mr-1" /><span className="hidden sm:inline">Настроить колонки</span><span className="sm:hidden">Колонки</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0 overflow-x-auto">
                {visibleColDefs.length === 0 ? (
                  <div className="text-center py-12">
                    <EyeOff className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 mb-2">Нет выбранных колонок</p>
                    <Button variant="outline" className="text-red-700 border-red-200" onClick={() => setColumnDialogOpen(true)}>
                      <Settings2 className="h-4 w-4 mr-2" />Выбрать колонки
                    </Button>
                  </div>
                ) : (
                  <>
                    <div style={{ minWidth: `${Math.max(800, visibleColDefs.length * 120)}px` }}>
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-50">
                            {visibleColDefs.map((col) => (
                              <TableHead key={col.key} className="text-xs whitespace-nowrap">{col.label}</TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filtered.slice(0, 20).map((r, i) => (
                            <TableRow key={i} className="hover:bg-gray-50">
                              {visibleColDefs.map((col) => {
                                const val = getRecordValue(r, col.key);
                                const isNum = typeof val === "number" && col.key !== "orderNumber";
                                const isCurrency = ["productAmount", "totalAmount", "productPrice", "deliveryCost", "discount", "discountPercent", "paidAmount", "psAmount"].includes(col.key);
                                const isDate = col.key === "date" || col.key === "updDate" || col.key === "changeDate" || col.key === "deliveryDateApproved" || col.key === "shippingDocDate" || col.key === "fundsReceiptDate";
                                return (
                                  <TableCell key={col.key} className={`text-xs ${isNum ? "text-right tabular-nums" : ""} ${isCurrency ? "font-medium tabular-nums" : ""}`}
                                    style={!isNum ? { maxWidth: "250px", whiteSpace: "normal", wordBreak: "break-word" } : {}}>
                                    {isCurrency ? formatCurrency(val as number) :
                                      isNum ? formatNumber(val as number) :
                                      isDate && val !== "—" && val ? new Date(val as string).toLocaleDateString("ru-RU") :
                                      typeof val === "boolean" ? (val ? "✓" : "—") :
                                      String(val)}
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                    {filtered.length > 20 && (
                      <p className="text-center text-sm text-gray-500 py-4">... и ещё {formatNumber(filtered.length - 20)} записей (всего {formatNumber(filtered.length)})</p>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* ==================== HIDDEN PDF REPORT ==================== */}
        {exportingPdf && (
        <div ref={pdfRef} style={{ position: "absolute", left: "-9999px", top: 0, width: "1140px", background: "#fff", padding: "35px 30px 30px", fontFamily: "Tahoma, Arial, Helvetica, sans-serif", color: "#333", lineHeight: 1.4 }}>
          {/* PDF Header */}
          <div style={{ textAlign: "center", marginBottom: "25px", borderBottom: "3px solid #DC2626", paddingBottom: "18px" }}>
            <h1 style={{ fontSize: "24px", fontWeight: "bold", color: "#DC2626", margin: "0 0 6px 0" }}>B2B Task Manager — Отчёт по заказам ЛУКОЙЛ</h1>
            <p style={{ fontSize: "11px", color: "#6B7280", margin: "4px 0 0 0" }}>
              Сформирован: {new Date().toLocaleString("ru-RU")} &nbsp;|&nbsp; Записей: {formatNumber(filtered.length)} &nbsp;|&nbsp; Период: {filters.dateFrom || "—"} — {filters.dateTo || "—"}
            </p>
            {summary && (
              <p style={{ fontSize: "11px", color: "#6B7280", margin: "4px 0 0 0" }}>
                Выручка: <strong style={{ color: "#DC2626" }}>{formatCurrency(summary.totalRevenue)}</strong> &nbsp;|&nbsp; Заказов: <strong>{formatNumber(summary.totalOrders)}</strong> &nbsp;|&nbsp; Средний чек: <strong>{formatCurrency(summary.avgOrderValue)}</strong>
              </p>
            )}
          </div>

          {/* 1. KPI */}
          {summary && (
            <>
              <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>1. Ключевые показатели</h2>
              <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
                <tbody>
                  <tr>
                    {[{ l: "Общая выручка", v: formatCurrency(summary.totalRevenue) }, { l: "Кол-во заказов", v: formatNumber(summary.totalOrders) }, { l: "Кол-во позиций", v: formatNumber(summary.totalProducts) }, { l: "Средний чек", v: formatCurrency(summary.avgOrderValue) }].map((item, i) => (
                      <td key={i} style={{ width: "25%", padding: "10px", border: "1px solid #e5e7eb", textAlign: "center", background: i === 0 ? "#FEF2F2" : "#F9FAFB" }}>
                        <div style={{ fontSize: "9px", color: "#6B7280", marginBottom: "4px" }}>{item.l}</div>
                        <div style={{ fontSize: "14px", fontWeight: "bold", color: i === 0 ? "#DC2626" : "#111827" }}>{item.v}</div>
                      </td>
                    ))}
                  </tr>
                  <tr>
                    {[{ l: "Оплачено", v: formatCurrency(summary.paidAmount) }, { l: "Не оплачено", v: formatCurrency(summary.unpaidAmount) }, { l: "Отменено", v: formatCurrency(summary.cancelledAmount) }, { l: "Стоимость доставки", v: formatCurrency(summary.totalDeliveryCost) }].map((item, i) => (
                      <td key={i} style={{ width: "25%", padding: "10px", border: "1px solid #e5e7eb", textAlign: "center", background: "#F9FAFB" }}>
                        <div style={{ fontSize: "9px", color: "#6B7280", marginBottom: "4px" }}>{item.l}</div>
                        <div style={{ fontSize: "13px", fontWeight: "bold", color: "#111827" }}>{item.v}</div>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </>
          )}

          {/* 2. Statuses */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>2. Распределение по статусам</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Статус</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{pdfData.statusTable.map((row, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb" }}>{row.status}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(row.count)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(row.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "200px" }}><PdfBar value={row.revenue} max={pdfData.statusTable[0]?.revenue || 1} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 3. Dealers */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>3. По дилерам</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Дилер</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{pdfData.dealerTable.map((row, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb" }}>{row.dealer}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(row.count)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(row.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "200px" }}><PdfBar value={row.revenue} max={maxDealerRev} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 4. Regions */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>4. По регионам (ТОП-20)</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Регион</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{pdfData.regionTable.slice(0, 20).map((row, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb" }}>{row.region}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(row.count)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(row.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "200px" }}><PdfBar value={row.revenue} max={maxRegionRev} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 5. Delivery */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>5. По способу доставки</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Способ доставки</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{pdfData.deliveryTable.map((row, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb" }}>{row.delivery}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(row.count)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(row.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "200px" }}><PdfBar value={row.revenue} max={pdfData.deliveryTable[0]?.revenue || 1} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 6. Viscosity */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>6. По вязкости</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Вязкость</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{pdfData.viscosityTable.map((row, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb" }}>{row.viscosity}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(row.count)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(row.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "200px" }}><PdfBar value={row.revenue} max={maxViscRev} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 7. Application */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>7. По области применения</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Область</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{pdfData.applicationTable.map((row, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb" }}>{row.app}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(row.count)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(row.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "200px" }}><PdfBar value={row.revenue} max={pdfData.applicationTable[0]?.revenue || 1} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 8. Top Products */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>8. ТОП-15 товаров по выручке</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left", width: "40px" }}>#</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Товар</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол-во</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{topProducts.map((p, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", color: "#9CA3AF" }}>{i + 1}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", fontSize: "10px" }}>{p.product}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(p.quantity)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(p.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "150px" }}><PdfBar value={p.revenue} max={maxProdRev} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 9. Top Buyers */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>9. ТОП-15 покупателей</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "11px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left", width: "40px" }}>#</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "left" }}>Покупатель</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Заказов</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>Выручка</th>
              <th style={{ padding: "6px 8px", border: "1px solid #e5e7eb" }}>Доля</th>
            </tr></thead>
            <tbody>{topBuyers.map((b, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", color: "#9CA3AF" }}>{i + 1}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", fontWeight: 600 }}>{b.buyer}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right" }}>{b.orders}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(b.revenue)}</td>
                <td style={{ padding: "5px 8px", border: "1px solid #e5e7eb", width: "150px" }}><PdfBar value={b.revenue} max={maxBuyerRev} color={colors[i % colors.length]} /></td>
              </tr>
            ))}</tbody>
          </table>

          {/* 10. Detail Table */}
          <h2 style={{ fontSize: "14px", fontWeight: "bold", color: "#DC2626", margin: "20px 0 10px 0", borderLeft: "4px solid #DC2626", paddingLeft: "8px" }}>10. Детальные данные (первые 20 записей)</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", marginBottom: "15px", fontSize: "9px" }}>
            <thead><tr style={{ background: "#FEF2F2" }}>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "left" }}>Дата</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "left" }}>Заказ</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "left" }}>Статус</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "left" }}>Покупатель</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "left" }}>Регион</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "left" }}>Товар</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "right" }}>Кол</th>
              <th style={{ padding: "4px 6px", border: "1px solid #e5e7eb", textAlign: "right" }}>Сумма</th>
            </tr></thead>
            <tbody>{filtered.slice(0, 20).map((r, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#fff" : "#F9FAFB" }}>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb", whiteSpace: "nowrap" }}>{r.date ? new Date(r.date).toLocaleDateString("ru-RU") : "—"}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb" }}>{r.orderNumber}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb" }}>{r.status}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb" }}>{r.buyer}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb" }}>{r.region}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb", maxWidth: "250px" }}>{r.product}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb", textAlign: "right" }}>{formatNumber(r.quantity)}</td>
                <td style={{ padding: "3px 6px", border: "1px solid #e5e7eb", textAlign: "right", fontWeight: 600 }}>{formatCurrency(r.productAmount)}</td>
              </tr>
            ))}</tbody>
          </table>
          {filtered.length > 20 && <p style={{ fontSize: "10px", color: "#6B7280", textAlign: "center" }}>... и ещё {filtered.length - 20} записей</p>}

          {/* Footer */}
          <div style={{ marginTop: "30px", paddingTop: "15px", borderTop: "2px solid #DC2626", textAlign: "center" }}>
            <p style={{ fontSize: "10px", color: "#9CA3AF" }}>B2B Task Manager — ЛУКОЙЛ | Отчет сформирован автоматически</p>
          </div>
        </div>
        )}
      </div>
    </Layout>
  );
}
