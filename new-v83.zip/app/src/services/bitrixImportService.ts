import type { BitrixProduct, Mapping } from "@/types/bitrixImport";
import { BITRIX_TEMPLATE_COLUMNS } from "@/types/bitrixImport";

export async function parseExcelFile(file: File): Promise<{
  headers: string[];
  rows: Record<string, string | number>[];
}> {
  return new Promise((resolve, reject) => {
    import("xlsx").then((XLSX) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rawRows: unknown[][] = XLSX.utils.sheet_to_json(sheet, {
            header: 1,
            defval: "",
          });
          if (rawRows.length < 2) {
            resolve({ headers: [], rows: [] });
            return;
          }
          const headers = (rawRows[0] as string[]).map((h) =>
            String(h).trim()
          );
          const rows: Record<string, string | number>[] = [];
          for (let i = 1; i < rawRows.length; i++) {
            const rowArr = rawRows[i] as unknown[];
            /* Check if row has any non-empty value (not just first column) */
            const hasAnyValue = rowArr.some((v) => v !== undefined && v !== null && String(v).trim() !== "");
            if (!hasAnyValue) continue;
            const row: Record<string, string | number> = {};
            headers.forEach((h, idx) => {
              row[h] =
                rowArr[idx] !== undefined && rowArr[idx] !== null ? String(rowArr[idx]).trim() : "";
            });
            rows.push(row);
          }
          resolve({ headers, rows });
        } catch (err) {
          reject(err);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  });
}

export async function generateBitrixExcel(
  products: BitrixProduct[],
  filename = "bitrix-import.xlsx",
  onProgress?: (pct: number) => void
) {
  const cols = BITRIX_TEMPLATE_COLUMNS.map((c) => c.label);
  const total = products.length;
  const batchSize = 100; // process in chunks to avoid UI blocking
  const rows: string[][] = [];

  for (let start = 0; start < total; start += batchSize) {
    const end = Math.min(start + batchSize, total);
    for (let i = start; i < end; i++) {
      const p = products[i];
      // Skip base64 photo data to keep file small
      rows.push(
        BITRIX_TEMPLATE_COLUMNS.map((c) => {
          if (!p[c.key]) return "";
          const val = String(p[c.key]);
          // Skip base64 image data (too large for Excel)
          if (val.startsWith("data:image")) return "";
          return val;
        })
      );
    }
    onProgress?.(Math.round((end / total) * 80));
    // Yield to UI thread
    await new Promise((r) => setTimeout(r, 10));
  }

  onProgress?.(85);
  await new Promise((r) => setTimeout(r, 50));

  const data = [cols, ...rows];
  const ws = XLSX.utils.aoa_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Товары");

  onProgress?.(95);
  await new Promise((r) => setTimeout(r, 50));

  XLSX.writeFile(wb, filename, { compression: true });
  onProgress?.(100);
}

export function applyMapping(
  sourceRows: Record<string, string | number>[],
  mapping: Mapping[]
): BitrixProduct[] {
  return sourceRows.map((src) => {
    const product: BitrixProduct = {};
    mapping.forEach((m) => {
      if (m.sourceCol && src[m.sourceCol] !== undefined) {
        product[m.templateCol] = src[m.sourceCol];
      }
    });
    return product;
  });
}

export function generateMappingPreview(
  sourceRows: Record<string, string | number>[],
  mapping: Mapping[]
): Record<string, string>[] {
  return sourceRows.slice(0, 5).map((src) => {
    const preview: Record<string, string> = {};
    mapping.forEach((m) => {
      if (m.sourceCol) {
        preview[m.templateCol] = String(src[m.sourceCol] || "");
      }
    });
    return preview;
  });
}
