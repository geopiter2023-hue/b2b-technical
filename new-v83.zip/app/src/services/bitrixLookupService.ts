/**
 * Bitrix Lookup Service — парсит все листы-справочники из шаблона
 * и предоставляет lookup по названию → ID/XML_ID
 */

export interface LookupTable {
  sheetName: string;
  entries: LookupEntry[];
  maxId: number;
}

export interface LookupEntry {
  name: string;
  xmlId: string;
  id?: number;
  code?: string;
}

// Сопоставление: колонка шаблона → лист справочника
export const LOOKUP_MAP: Record<string, string> = {
  "Раздел": "Разделы",
  "id раздела": "Разделы",
  "Вид транспорта": "Вид транспорта",
  "id вида транспорта": "Вид транспорта",
  "Стандарт тормозной жидкости": "Стандарт тормозной жидкости",
  "id стандарта тормозной жидкости": "Стандарт тормозной жидкости",
  "Назначение": "Назначение",
  "id назначений": "Назначение",
  "Вид": "Вид",
  "id вида": "Вид",
  "Вязкость": "Вязкость",
  "id вязкости": "Вязкость",
  "Классификация по API": "Классификация по API",
  "id классификации по api": "Классификация по API",
  "Вид двигателя": "Вид двигателя",
  "id вида двигателя": "Вид двигателя",
  "Хит": "Хит",
  "id хит": "Хит",
  "Новинка": "Новинки",
  "id новинки": "Новинки",
  "Специальный товар": "СпецТовар",
  "id спецТовар": "СпецТовар",
  "Цвет": "Цвет",
  "id цвет": "Цвет",
  "id префикс": "Префикс",
  "Фасовка": "Фасовка",
  "id фасовки": "Фасовка",
};

// Какое поле использовать для ID: 'id' | 'xmlId' | 'code'
export const ID_FIELD_MAP: Record<string, "id" | "xmlId" | "code"> = {
  "Разделы": "code",
  "Вид транспорта": "id",
  "Стандарт тормозной жидкости": "id",
  "Назначение": "id",
  "Вид": "xmlId",
  "Вязкость": "xmlId",
  "Классификация по API": "xmlId",
  "Вид двигателя": "xmlId",
  "Хит": "xmlId",
  "Новинки": "xmlId",
  "СпецТовар": "xmlId",
  "Цвет": "xmlId",
  "Префикс": "xmlId",
  "Фасовка": "id",
};

// Колонка шаблона → какой lookup-ключ использовать для поиска
export const NAME_COL_MAP: Record<string, string> = {
  "id раздела": "Раздел",
  "id вида транспорта": "Вид транспорта",
  "id стандарта тормозной жидкости": "Стандарт тормозной жидкости",
  "id назначений": "Назначение",
  "id вида": "Вид",
  "id вязкости": "Вязкость",
  "id классификации по api": "Классификация по API",
  "id вида двигателя": "Вид двигателя",
  "id хит": "Хит",
  "id новинки": "Новинка",
  "id спецТовар": "Специальный товар",
  "id цвет": "Цвет",
  "id префикс": "Не применять \u201cПрефикс для имени товаров\u201d",
  "id фасовки": "Фасовка",
};

export class BitrixLookupService {
  private lookups: Map<string, LookupTable> = new Map();

  async loadFromExcel(file: File): Promise<string[]> {
    const XLSX = await import("xlsx");
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data, { type: "array" });
    const sheetNames = workbook.SheetNames;
    this.lookups.clear();

    for (const sheetName of sheetNames) {
      const sheet = workbook.Sheets[sheetName];
      const rows: unknown[][] = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        defval: "",
      });
      if (rows.length < 2) continue;

      // Определяем колонки
      const headers = (rows[0] as string[]).map((h) => String(h).trim());
      const nameIdx = headers.findIndex(
        (h) =>
          h.toLowerCase().includes("наименование") ||
          h.toLowerCase().includes("значение") ||
          h.toLowerCase().includes("name")
      );
      const xmlIdIdx = headers.findIndex(
        (h) =>
          h.toLowerCase().includes("xml_id") ||
          h.toLowerCase().includes("xml id") ||
          h.toLowerCase().includes("xmlid")
      );
      const idIdx = headers.findIndex(
        (h) =>
          h.toLowerCase() === "id" ||
          h.toLowerCase().includes("идентификатор")
      );
      const codeIdx = headers.findIndex(
        (h) => h.toLowerCase() === "code" || h.toLowerCase() === "код"
      );

      if (nameIdx < 0) continue; // Не справочник

      const entries: LookupEntry[] = [];
      let maxId = 0;

      for (let i = 1; i < rows.length; i++) {
        const row = rows[i] as string[];
        const name = String(row[nameIdx] || "").trim();
        if (!name) continue;

        const entry: LookupEntry = {
          name,
          xmlId: xmlIdIdx >= 0 ? String(row[xmlIdIdx] || "").trim() : "",
        };

        if (idIdx >= 0) {
          const idVal = parseInt(String(row[idIdx] || ""));
          if (!isNaN(idVal)) {
            entry.id = idVal;
            if (idVal > maxId) maxId = idVal;
          }
        }

        if (codeIdx >= 0) {
          entry.code = String(row[codeIdx] || "").trim();
        }

        entries.push(entry);
      }

      if (entries.length > 0) {
        this.lookups.set(sheetName, { sheetName, entries, maxId });
      }
    }

    return Array.from(this.lookups.keys());
  }

  /**
   * Найти ID по названию в справочнике
   */
  findId(sheetName: string, searchName: string): { value: string; isNew: boolean } | null {
    const lookup = this.lookups.get(sheetName);
    if (!lookup) return null;

    const search = searchName.toLowerCase().trim();
    const idField = ID_FIELD_MAP[sheetName] || "xmlId";

    // Точное совпадение
    let entry = lookup.entries.find(
      (e) => e.name.toLowerCase().trim() === search
    );

    // Частичное совпадение
    if (!entry) {
      entry = lookup.entries.find((e) =>
        e.name.toLowerCase().includes(search)
      );
    }

    if (entry) {
      const value =
        idField === "id"
          ? String(entry.id || "")
          : idField === "code"
          ? entry.code || ""
          : entry.xmlId || "";
      return { value, isNew: false };
    }

    // Не найдено — генерируем новый ID
    return null;
  }

  /**
   * Сгенерировать новый ID для значения
   */
  generateNewId(sheetName: string, _searchName: string): string {
    const lookup = this.lookups.get(sheetName);
    if (!lookup) return "";

    const idField = ID_FIELD_MAP[sheetName] || "xmlId";
    if (idField === "id") {
      lookup.maxId += 1;
      return String(lookup.maxId);
    }

    // Для xmlId и code — транслитерируем
    return this.transliterate(_searchName);
  }

  /**
   * Получить или создать ID
   */
  getOrCreateId(
    sheetName: string,
    searchName: string
  ): { value: string; isNew: boolean } {
    if (!searchName || !searchName.trim()) return { value: "", isNew: false };

    const found = this.findId(sheetName, searchName);
    if (found) return found;

    // Создаём новый
    const newId = this.generateNewId(sheetName, searchName);
    const lookup = this.lookups.get(sheetName);
    if (lookup && newId) {
      lookup.entries.push({
        name: searchName,
        xmlId: newId,
        id: lookup.maxId,
      });
    }
    return { value: newId, isNew: true };
  }

  /**
   * Проверить, является ли колонка ID-колонкой (автозаполнение)
   */
  isIdColumn(templateColLabel: string): boolean {
    return !!NAME_COL_MAP[templateColLabel];
  }

  /**
   * Получить lookup-ключ для ID-колонки
   */
  getLookupSheetForIdCol(templateColLabel: string): string | null {
    const sourceCol = NAME_COL_MAP[templateColLabel];
    if (!sourceCol) return null;
    return LOOKUP_MAP[sourceCol] || null;
  }

  /**
   * Получить исходную колонку для поиска значения
   */
  getSourceColForIdCol(templateColLabel: string): string | null {
    return NAME_COL_MAP[templateColLabel] || null;
  }

  /**
   * Получить загруженные справочники
   */
  getLoadedSheets(): string[] {
    return Array.from(this.lookups.keys());
  }

  private transliterate(str: string): string {
    const map: Record<string, string> = {
      а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "yo", ж: "zh",
      з: "z", и: "i", й: "j", к: "k", л: "l", м: "m", н: "n", о: "o",
      п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "kh", ц: "ts",
      ч: "ch", ш: "sh", щ: "shch", ы: "y", э: "e", ю: "yu", я: "ya",
      " ": "_", "-": "_", "/": "_", ",": "_",
    };
    return str
      .toLowerCase()
      .split("")
      .map((c) => map[c] || c)
      .join("")
      .replace(/[^a-z0-9_]/g, "")
      .substring(0, 50);
  }
}
