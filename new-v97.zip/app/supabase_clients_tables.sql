-- ============================================
-- B2B Task Manager — Clients & Settings Tables
-- Version: new-v94 → v95
-- ============================================

-- 1. Clients table
CREATE TABLE IF NOT EXISTS clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inn TEXT NOT NULL UNIQUE,
  kpp TEXT,
  ogrn TEXT,
  name TEXT NOT NULL DEFAULT '',
  full_name TEXT NOT NULL DEFAULT '',
  type TEXT DEFAULT '',
  status TEXT DEFAULT '',
  address TEXT,
  management TEXT,
  management_post TEXT,
  okved TEXT,
  phone TEXT,
  email TEXT,
  note TEXT,
  tags TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Client orders table
CREATE TABLE IF NOT EXISTS client_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_inn TEXT NOT NULL REFERENCES clients(inn) ON DELETE CASCADE,
  number TEXT NOT NULL,
  date DATE,
  amount NUMERIC DEFAULT 0,
  status TEXT DEFAULT 'new',
  products TEXT NOT NULL DEFAULT '',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Client history table
CREATE TABLE IF NOT EXISTS client_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_inn TEXT NOT NULL REFERENCES clients(inn) ON DELETE CASCADE,
  type TEXT DEFAULT 'note',
  description TEXT NOT NULL,
  date TIMESTAMPTZ DEFAULT NOW(),
  author TEXT
);

-- 4. API settings table (Dadata, Metrics, etc.)
CREATE TABLE IF NOT EXISTS api_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL DEFAULT 'default',
  dadata_api_key TEXT,
  yandex_metrics_token TEXT,
  yandex_metrics_counter_id TEXT,
  yandex_metrics_client_id TEXT,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- 5. Enable RLS
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_settings ENABLE ROW LEVEL SECURITY;

-- 6. Policies (anon access for now — same as tasks)
CREATE POLICY "Allow anon on clients"
  ON clients FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon on client_orders"
  ON client_orders FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon on client_history"
  ON client_history FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon on api_settings"
  ON api_settings FOR ALL TO anon USING (true) WITH CHECK (true);

-- 7. Indexes
CREATE INDEX IF NOT EXISTS idx_clients_inn ON clients(inn);
CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(name);
CREATE INDEX IF NOT EXISTS idx_client_orders_inn ON client_orders(client_inn);
CREATE INDEX IF NOT EXISTS idx_client_history_inn ON client_history(client_inn);

-- 8. Realtime
BEGIN;
  DO $$
  BEGIN
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime' AND tablename = 'clients'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE clients;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime' AND tablename = 'client_orders'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE client_orders;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime' AND tablename = 'api_settings'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE api_settings;
    END IF;
  END $$;
COMMIT;

-- ============================================
-- After running this SQL:
-- 1. Go to Supabase Dashboard → SQL Editor → New → Paste → Run
-- 2. Go to Table Editor → clients → Realtime → Enable
-- 3. Same for client_orders, client_history, api_settings
-- 4. Reload app → data will sync to cloud
-- ============================================
