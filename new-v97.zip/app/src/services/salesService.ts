import * as XLSX from "xlsx";

// ============================================================
// ORDER RECORD INTERFACE
// ============================================================
export interface OrderRecord {
  id: string; date: string; updDate: string | null; orderNumber: string;
  region: string; dealer: string; delivery: string;
  ksss: number | null; product: string; productCode: number | null;
  externalCatalogCode: string | null; externalProductCode: string | null;
  viscosity: string | null; application: string | null;
  productWeight: number | null; grossWeight: number | null; netWeightKg: number | null;
  quantity: number; unit: string | null;
  productPrice: number; productAmount: number; totalAmount: number;
  deliveryCost: number | null; discount: number | null;
  discountPercent: number | null; discountLevel: string | null;
  nds: number | null; priceType: string | null;
  status: string; paid: boolean; shipped: boolean; cancelled: boolean;
  deliveryAllowed: boolean; hasProblem: boolean;
  buyer: string; buyerEmail: string | null; buyerInn: string | null;
  buyerLegalName: string | null; payerType: string | null;
  paymentSystem: string | null; paymentStatus: string | null;
  paidAmount: number | null; psAmount: number | null;
  updGenerated: boolean; updNumber: string | null;
  updDocNumber: string | null; updDocDate: string | null; updDocSerial: number | null;
  asfGenerated: boolean; asfDocNumber: string | null; asfDocDate: string | null;
  trackingNumber: string | null; shippingIdentifier: string | null;
  deliveryDateApproved: string | null; shippingDocNumber: string | null; shippingDocDate: string | null;
  deliveryTimeMin: string | null; deliveryTimeMax: string | null;
  deliveryPeriodMin: number | null; deliveryPeriodMax: number | null;
  pvzCode: string | null; pvzIndexCity: string | null;
  paymentOrderNumber: string | null; paymentOrderDate: string | null; paymentOrderViewStatus: string | null;
  source: string | null; externalOrderCode: string | null; site: string | null;
  responsible: string | null; office: string | null; affiliate: string | null; bitrixSync: string | null;
  comment: string | null; buyerComment: string | null;
  cancelReason: string | null; cancelComment: string | null; problemDescription: string | null;
  hydrolift: boolean; dealerPaymentEmailSent: boolean; buyerPaymentEmailSent: boolean;
  preOrder: boolean; edoParticipation: string | null;
  changeDate: string | null; fundsReceiptDate: string | null;
  yandexProUser: string | null;
  discountsAndRules: string | null; coupons: string | null;
  deliveryMethodInfo: string | null; deliveryType: string | null;
  deliveryTypeId: string | null; tariffType: string | null;
  tariffId: string | null; deliveryApp: string | null;
  tariffName: string | null; totalLogisticsCost: number | null;
  bankAccount: string | null; bankName: string | null; bankBik: string | null;
  dealerId: number | null;
  addressString: string | null; house: string | null; street: string | null;
  city: string | null; zip: string | null; location: string | null; fiasRegion: string | null;
  contactFio: string | null; contactEmail: string | null; contactPhone: string | null;
  accumulatedWeightAtOrder: number | null; accumulatedWeightAtRecalc: number | null;
  actualAccumulatedWeight: number | null; totalOrdersSinceRegistration: number | null;
  opticoreOrderId: string | null;
  courierCity: string | null; courierStreet: string | null; aouuid: string | null;
  dealerSaved: boolean; dealerConfirmed: boolean;
  deliveryInvoice: string | null;
  managerCalculationNeeded: boolean; postponeLoglabSend: boolean;
  accountingDocsEmailSent: boolean;
  riskIndicatorResponseId: string | null;
  asfFile: string | null; updFile: string | null;
  innFile: string | null; charterFile: string | null; certifiedDetailsFile: string | null;
  positionNotification: string | null; orderProblem: string | null;
}

export interface SalesSummary {
  totalRevenue: number; totalOrders: number; totalProducts: number;
  avgOrderValue: number; paidAmount: number; unpaidAmount: number;
  cancelledAmount: number; totalDeliveryCost: number; totalDiscount: number;
}

export interface ChartData {
  labels: string[];
  datasets: { label: string; data: number[]; backgroundColor: string | string[]; borderColor?: string | string[]; borderWidth?: number }[];
}

export interface ColumnDef {
  key: string; label: string; defaultVisible: boolean; category: string;
}

// ============================================================
// COLUMN DEFINITIONS
// ============================================================
export const ALL_COLUMNS: ColumnDef[] = [
  { key: "date", label: "Дата создания", defaultVisible: true, category: "Основное" },
  { key: "orderNumber", label: "Номер заказа", defaultVisible: true, category: "Основное" },
  { key: "status", label: "Статус", defaultVisible: true, category: "Основное" },
  { key: "changeDate", label: "Дата изменения", defaultVisible: false, category: "Основное" },
  { key: "product", label: "Товар", defaultVisible: true, category: "Товар" },
  { key: "ksss", label: "КССС", defaultVisible: false, category: "Товар" },
  { key: "productCode", label: "Код товара", defaultVisible: false, category: "Товар" },
  { key: "viscosity", label: "Вязкость", defaultVisible: false, category: "Товар" },
  { key: "application", label: "Область применения", defaultVisible: false, category: "Товар" },
  { key: "quantity", label: "Кол-во", defaultVisible: true, category: "Товар" },
  { key: "unit", label: "Ед.изм", defaultVisible: false, category: "Товар" },
  { key: "productWeight", label: "Вес товара", defaultVisible: false, category: "Товар" },
  { key: "grossWeight", label: "Вес брутто", defaultVisible: false, category: "Товар" },
  { key: "netWeightKg", label: "Вес нетто (кг)", defaultVisible: false, category: "Товар" },
  { key: "externalCatalogCode", label: "Внеш.код каталога", defaultVisible: false, category: "Товар" },
  { key: "externalProductCode", label: "Внеш.код товара", defaultVisible: false, category: "Товар" },
  { key: "productPrice", label: "Цена товара", defaultVisible: false, category: "Цены" },
  { key: "productAmount", label: "Сумма позиции", defaultVisible: true, category: "Цены" },
  { key: "totalAmount", label: "Сумма заказа", defaultVisible: true, category: "Цены" },
  { key: "discount", label: "Скидка", defaultVisible: false, category: "Цены" },
  { key: "discountPercent", label: "% скидки", defaultVisible: false, category: "Цены" },
  { key: "discountLevel", label: "Уровень скидки", defaultVisible: false, category: "Цены" },
  { key: "deliveryCost", label: "Стоимость доставки", defaultVisible: false, category: "Цены" },
  { key: "nds", label: "НДС", defaultVisible: false, category: "Цены" },
  { key: "priceType", label: "Тип цены", defaultVisible: false, category: "Цены" },
  { key: "paid", label: "Оплачен", defaultVisible: true, category: "Оплата" },
  { key: "paymentSystem", label: "Платежная система", defaultVisible: false, category: "Оплата" },
  { key: "paymentStatus", label: "Статус оплаты", defaultVisible: false, category: "Оплата" },
  { key: "paidAmount", label: "Оплачено (сумма)", defaultVisible: false, category: "Оплата" },
  { key: "psAmount", label: "Сумма ПС", defaultVisible: false, category: "Оплата" },
  { key: "fundsReceiptDate", label: "Дата поступления ДС", defaultVisible: false, category: "Оплата" },
  { key: "paymentOrderNumber", label: "Номер п/п", defaultVisible: false, category: "Оплата" },
  { key: "paymentOrderDate", label: "Дата п/п", defaultVisible: false, category: "Оплата" },
  { key: "buyer", label: "Покупатель", defaultVisible: true, category: "Покупатель" },
  { key: "buyerEmail", label: "Email покупателя", defaultVisible: false, category: "Покупатель" },
  { key: "buyerInn", label: "ИНН покупателя", defaultVisible: false, category: "Покупатель" },
  { key: "buyerLegalName", label: "Юр. наименование", defaultVisible: false, category: "Покупатель" },
  { key: "payerType", label: "Тип плательщика", defaultVisible: false, category: "Покупатель" },
  { key: "buyerComment", label: "Комментарий покупателя", defaultVisible: false, category: "Покупатель" },
  { key: "region", label: "Регион", defaultVisible: true, category: "Регион" },
  { key: "fiasRegion", label: "ФИАС региона", defaultVisible: false, category: "Регион" },
  { key: "dealer", label: "Дилер", defaultVisible: false, category: "Дилер" },
  { key: "dealerId", label: "ID дилера", defaultVisible: false, category: "Дилер" },
  { key: "dealerSaved", label: "Заказ сохранен дилером", defaultVisible: false, category: "Дилер" },
  { key: "dealerConfirmed", label: "Заказ подтвержден дилером", defaultVisible: false, category: "Дилер" },
  { key: "dealerPaymentEmailSent", label: "Письмо дилеру отправлено", defaultVisible: false, category: "Дилер" },
  { key: "delivery", label: "Служба доставки", defaultVisible: true, category: "Доставка" },
  { key: "shipped", label: "Отгружен", defaultVisible: false, category: "Доставка" },
  { key: "deliveryAllowed", label: "Доставка разрешена", defaultVisible: false, category: "Доставка" },
  { key: "trackingNumber", label: "Номер отслеживания", defaultVisible: false, category: "Доставка" },
  { key: "shippingIdentifier", label: "Идентификатор отправления", defaultVisible: false, category: "Доставка" },
  { key: "deliveryDateApproved", label: "Дата разрешения доставки", defaultVisible: false, category: "Доставка" },
  { key: "shippingDocNumber", label: "Номер д/о", defaultVisible: false, category: "Доставка" },
  { key: "shippingDocDate", label: "Дата документа отгрузки", defaultVisible: false, category: "Доставка" },
  { key: "hydrolift", label: "Гидроборт", defaultVisible: false, category: "Доставка" },
  { key: "deliveryMethodInfo", label: "Метод доставки", defaultVisible: false, category: "Доставка" },
  { key: "deliveryType", label: "Тип доставки", defaultVisible: false, category: "Доставка" },
  { key: "deliveryTypeId", label: "DeliveryTypeId", defaultVisible: false, category: "Доставка" },
  { key: "tariffType", label: "Tariff type", defaultVisible: false, category: "Доставка" },
  { key: "tariffId", label: "Tariff ID", defaultVisible: false, category: "Доставка" },
  { key: "deliveryApp", label: "Delivery App", defaultVisible: false, category: "Доставка" },
  { key: "tariffName", label: "TariffName", defaultVisible: false, category: "Доставка" },
  { key: "totalLogisticsCost", label: "LogLab TotalCost", defaultVisible: false, category: "Доставка" },
  { key: "deliveryTimeMin", label: "Время доставки (мин)", defaultVisible: false, category: "Доставка" },
  { key: "deliveryTimeMax", label: "Время доставки (макс)", defaultVisible: false, category: "Доставка" },
  { key: "deliveryPeriodMin", label: "Мин. срок доставки", defaultVisible: false, category: "Доставка" },
  { key: "deliveryPeriodMax", label: "deliveryPeriodMax", defaultVisible: false, category: "Доставка" },
  { key: "pvzCode", label: "PVZ Code", defaultVisible: false, category: "Доставка" },
  { key: "pvzIndexCity", label: "PVZ: Индекс, город", defaultVisible: false, category: "Доставка" },
  { key: "updGenerated", label: "УПД сгенерирован", defaultVisible: false, category: "УПД" },
  { key: "updDate", label: "Дата генерации УПД", defaultVisible: false, category: "УПД" },
  { key: "updNumber", label: "Номер УПД", defaultVisible: false, category: "УПД" },
  { key: "updDocNumber", label: "Номер документа УПД", defaultVisible: false, category: "УПД" },
  { key: "updDocDate", label: "Дата документа УПД", defaultVisible: false, category: "УПД" },
  { key: "updDocSerial", label: "Порядковый номер УПД", defaultVisible: false, category: "УПД" },
  { key: "updFile", label: "Файл УПД", defaultVisible: false, category: "УПД" },
  { key: "asfGenerated", label: "АСФ сгенерирован", defaultVisible: false, category: "АСФ" },
  { key: "asfDocNumber", label: "Номер документа АСФ", defaultVisible: false, category: "АСФ" },
  { key: "asfDocDate", label: "Дата документа АСФ", defaultVisible: false, category: "АСФ" },
  { key: "asfFile", label: "Файл АСФ", defaultVisible: false, category: "АСФ" },
  { key: "cancelled", label: "Отменен", defaultVisible: false, category: "Отмена" },
  { key: "cancelReason", label: "Причина отмены", defaultVisible: false, category: "Отмена" },
  { key: "cancelComment", label: "Комментарий к отмене", defaultVisible: false, category: "Отмена" },
  { key: "hasProblem", label: "Проблема", defaultVisible: false, category: "Проблема" },
  { key: "problemDescription", label: "Описание проблемы", defaultVisible: false, category: "Проблема" },
  { key: "riskIndicatorResponseId", label: "Risk responseId", defaultVisible: false, category: "Проблема" },
  { key: "source", label: "Источник заказа", defaultVisible: false, category: "Источник" },
  { key: "site", label: "Сайт", defaultVisible: false, category: "Источник" },
  { key: "externalOrderCode", label: "Внешний код заказа", defaultVisible: false, category: "Источник" },
  { key: "opticoreOrderId", label: "ID заказа Opticore", defaultVisible: false, category: "Источник" },
  { key: "responsible", label: "Ответственный", defaultVisible: false, category: "Управление" },
  { key: "office", label: "Офис", defaultVisible: false, category: "Управление" },
  { key: "affiliate", label: "Аффилиат", defaultVisible: false, category: "Управление" },
  { key: "bitrixSync", label: "Синхронизация с Битрикс24", defaultVisible: false, category: "Управление" },
  { key: "discountsAndRules", label: "Скидки и правила", defaultVisible: false, category: "Скидки" },
  { key: "coupons", label: "Купоны", defaultVisible: false, category: "Скидки" },
  { key: "yandexProUser", label: "Яндекс.ПРО", defaultVisible: false, category: "Прочее" },
  { key: "bankAccount", label: "Расчетный счет", defaultVisible: false, category: "Банк" },
  { key: "bankName", label: "Наименование банка", defaultVisible: false, category: "Банк" },
  { key: "bankBik", label: "БИК банка", defaultVisible: false, category: "Банк" },
  { key: "preOrder", label: "Предзаказ", defaultVisible: false, category: "Флаги" },
  { key: "edoParticipation", label: "Участие в ЭДО", defaultVisible: false, category: "Флаги" },
  { key: "managerCalculationNeeded", label: "Нужен менеджер", defaultVisible: false, category: "Флаги" },
  { key: "postponeLoglabSend", label: "Отложить отправку в ЛогЛаб", defaultVisible: false, category: "Флаги" },
  { key: "accountingDocsEmailSent", label: "Письмо с документами отправлено", defaultVisible: false, category: "Флаги" },
  { key: "buyerPaymentEmailSent", label: "Письмо покупателю отправлено", defaultVisible: false, category: "Флаги" },
  { key: "addressString", label: "Адрес доставки", defaultVisible: false, category: "Адрес" },
  { key: "house", label: "Дом", defaultVisible: false, category: "Адрес" },
  { key: "street", label: "Улица", defaultVisible: false, category: "Адрес" },
  { key: "city", label: "Город", defaultVisible: false, category: "Адрес" },
  { key: "zip", label: "Индекс", defaultVisible: false, category: "Адрес" },
  { key: "location", label: "Местоположение", defaultVisible: false, category: "Адрес" },
  { key: "fiasRegion", label: "ФИАС региона", defaultVisible: false, category: "Адрес" },
  { key: "contactFio", label: "Ф.И.О.", defaultVisible: false, category: "Контакты" },
  { key: "contactEmail", label: "E-Mail", defaultVisible: false, category: "Контакты" },
  { key: "contactPhone", label: "Телефон", defaultVisible: false, category: "Контакты" },
  { key: "accumulatedWeightAtOrder", label: "Накопл.вес при заказе", defaultVisible: false, category: "Вес" },
  { key: "accumulatedWeightAtRecalc", label: "Накопл.вес при пересчете", defaultVisible: false, category: "Вес" },
  { key: "actualAccumulatedWeight", label: "Актуальный накопл.вес", defaultVisible: false, category: "Вес" },
  { key: "totalOrdersSinceRegistration", label: "Всего заказов с регистрации", defaultVisible: false, category: "Статистика" },
  { key: "deliveryInvoice", label: "Счет на доставку", defaultVisible: false, category: "Доставка" },
  { key: "positionNotification", label: "Позиции", defaultVisible: false, category: "Прочее" },
  { key: "orderProblem", label: "Проблема с заказом", defaultVisible: false, category: "Проблема" },
  { key: "comment", label: "Комментарии", defaultVisible: false, category: "Прочее" },
  { key: "innFile", label: "Файл ИНН", defaultVisible: false, category: "Документы" },
  { key: "charterFile", label: "Файл устава", defaultVisible: false, category: "Документы" },
  { key: "certifiedDetailsFile", label: "Заверенные реквизиты", defaultVisible: false, category: "Документы" },
  { key: "courierCity", label: "CourierCity", defaultVisible: false, category: "Доставка" },
  { key: "courierStreet", label: "CourierStreet", defaultVisible: false, category: "Доставка" },
  { key: "aouuid", label: "AOUUID", defaultVisible: false, category: "Доставка" },
];

export function getRecordValue(record: OrderRecord, key: string): any {
  const val = (record as any)[key];
  if (val === null || val === undefined) return "—";
  if (typeof val === "boolean") return val ? "Да" : "Нет";
  return val;
}

// ============================================================
// PERSISTENCE
// ============================================================
const SK_ORDERS = "b2b_sales_orders";
const SK_COLS = "b2b_sales_columns";

export function saveOrdersToStorage(orders: OrderRecord[]): void {
  try { localStorage.setItem(SK_ORDERS, JSON.stringify(orders)); } catch (e) { console.error("[Sales] save failed:", e); }
}
export function loadOrdersFromStorage(): OrderRecord[] | null {
  try { const d = localStorage.getItem(SK_ORDERS); return d ? JSON.parse(d) : null; } catch (e) { return null; }
}
export function saveVisibleColumns(columns: string[]): void {
  try { localStorage.setItem(SK_COLS, JSON.stringify(columns)); } catch (e) {}
}
export function loadVisibleColumns(): string[] | null {
  try { const d = localStorage.getItem(SK_COLS); return d ? JSON.parse(d) : null; } catch (e) { return null; }
}
export function clearSalesStorage(): void {
  localStorage.removeItem(SK_ORDERS); localStorage.removeItem(SK_COLS);
}

// ============================================================
// SAVED FILE DATA (multiple files)
// ============================================================
const SK_FILE_DATA = "b2b_sales_file_data";

export interface SavedFileData {
  id: string;
  fileName: string;
  orders: OrderRecord[];
  uploadedAt: string;
}

function loadFileDataMap(): Record<string, SavedFileData> {
  try { const raw = localStorage.getItem(SK_FILE_DATA); return raw ? JSON.parse(raw) : {}; } catch { return {}; }
}
function saveFileDataMap(map: Record<string, SavedFileData>): void {
  try { localStorage.setItem(SK_FILE_DATA, JSON.stringify(map)); } catch {}
}

export function saveFileData(id: string, fileName: string, orders: OrderRecord[]): void {
  const map = loadFileDataMap();
  // Limit to 500 records to stay under localStorage 5MB limit
  const limitedOrders = orders.slice(0, 500);
  map[id] = { id, fileName, orders: limitedOrders, uploadedAt: new Date().toISOString() };
  // Keep max 10 files
  const keys = Object.keys(map);
  if (keys.length > 10) {
    const sorted = keys.sort((a, b) => (map[a].uploadedAt > map[b].uploadedAt ? 1 : -1));
    for (let i = 0; i < sorted.length - 10; i++) delete map[sorted[i]];
  }
  saveFileDataMap(map);
}
export function loadFileData(id: string): SavedFileData | null {
  return loadFileDataMap()[id] || null;
}
export function deleteFileData(id: string): void {
  const map = loadFileDataMap();
  delete map[id];
  saveFileDataMap(map);
}
export function listSavedFiles(): SavedFileData[] {
  const map = loadFileDataMap();
  return Object.values(map).sort((a, b) => (b.uploadedAt > a.uploadedAt ? 1 : -1));
}

// ============================================================
// UPLOAD HISTORY
// ============================================================
export interface UploadHistoryItem {
  id: string;
  fileName: string;
  recordCount: number;
  uploadedAt: string;
  totalRevenue: number;
}

const SK_HISTORY = "b2b_sales_history";

export function addUploadHistory(fileName: string, recordCount: number, totalRevenue: number): string {
  try {
    const history = getUploadHistory();
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const newItem: UploadHistoryItem = {
      id,
      fileName,
      recordCount,
      uploadedAt: new Date().toISOString(),
      totalRevenue,
    };
    const updated = [newItem, ...history].slice(0, 20);
    localStorage.setItem(SK_HISTORY, JSON.stringify(updated));
    return id;
  } catch (e) { console.error("[Sales] history save failed:", e); return ""; }
}

export function getUploadHistory(): UploadHistoryItem[] {
  try {
    const d = localStorage.getItem(SK_HISTORY);
    return d ? JSON.parse(d) : [];
  } catch (e) { return []; }
}

export function deleteUploadHistoryItem(id: string): void {
  try {
    const history = getUploadHistory().filter((h) => h.id !== id);
    localStorage.setItem(SK_HISTORY, JSON.stringify(history));
  } catch (e) {}
}

export function clearUploadHistory(): void {
  localStorage.removeItem(SK_HISTORY);
}

// ============================================================
// OPTIMIZED EXCEL PARSING — Single-pass header mapping
// ============================================================
function isEmptyCell(val: any): boolean {
  if (val === null || val === undefined || val === "") return true;
  const str = String(val).trim();
  return str === "NaN" || str === "NaT" || str === "null" || str === "undefined";
}

function parseRussianNumber(val: any): number {
  if (isEmptyCell(val)) return 0;
  if (typeof val === "number") return isNaN(val) ? 0 : val;
  const cleaned = String(val).trim().replace(/\s/g, "");
  const withDot = cleaned.replace(",", ".");
  const n = parseFloat(withDot);
  return isNaN(n) ? 0 : n;
}
function parseRussianDate(val: any): string | null {
  if (!val || val === "NaT") return null;
  if (val instanceof Date) return val.toISOString().split("T")[0];
  const str = String(val).trim();
  if (/^\d{2}\.\d{2}\.\d{4}$/.test(str)) { const [d, m, y] = str.split("."); return `${y}-${m}-${d}`; }
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) return str.substring(0, 10);
  if (typeof val === "number" && val > 30000) { const ep = new Date(1899, 11, 30); return new Date(ep.getTime() + val * 86400000).toISOString().split("T")[0]; }
  return null;
}
function parseBool(val: any): boolean {
  if (val === null || val === undefined) return false;
  const s = String(val).trim().toLowerCase();
  return s === "да" || s === "true" || s === "1" || s === "yes";
}
function sS(val: any): string | null { return (!val || val === "NaT") ? null : String(val).trim(); }
function sN(val: any): number | null { const n = parseRussianNumber(val); return (n === 0 && (!val || val === "NaT")) ? null : n; }

// Keyword → field mapping for single-pass header resolution
const FIELD_MAP: { key: keyof OrderRecord; keywords: string[]; type: "s" | "n" | "d" | "b" }[] = [
  { key: "date", keywords: ["Дата создания"], type: "d" },
  { key: "updDate", keywords: ["Дата генерации УПД"], type: "d" },
  { key: "region", keywords: ["Название региона"], type: "s" },
  { key: "dealer", keywords: ["Наименование дилера"], type: "s" },
  { key: "delivery", keywords: ["Служба доставки"], type: "s" },
  { key: "ksss", keywords: ["КССС"], type: "n" },
  { key: "orderNumber", keywords: ["Номер заказа"], type: "s" },
  { key: "status", keywords: ["Статус"], type: "s" },
  { key: "totalAmount", keywords: ["Сумма"], type: "n" },
  { key: "deliveryCost", keywords: ["Стоимость доставки"], type: "n" },
  { key: "buyer", keywords: ["Покупатель"], type: "s" },
  { key: "buyerEmail", keywords: ["Email покупателя"], type: "s" },
  { key: "buyerInn", keywords: ["ИНН покупателя"], type: "s" },
  { key: "buyerLegalName", keywords: ["Юридическое наименование покупателя"], type: "s" },
  { key: "product", keywords: ["Название товара"], type: "s" },
  { key: "productAmount", keywords: ["Сумма позиции"], type: "n" },
  { key: "viscosity", keywords: ["Вязкость"], type: "s" },
  { key: "productWeight", keywords: ["Вес товара"], type: "n" },
  { key: "grossWeight", keywords: ["Вес брутто"], type: "n" },
  { key: "quantity", keywords: ["Количество товара"], type: "n" },
  { key: "application", keywords: ["Область применения"], type: "s" },
  { key: "productPrice", keywords: ["Цена товара"], type: "n" },
  { key: "paid", keywords: ["Оплачен"], type: "b" },
  { key: "shipped", keywords: ["Отгружен"], type: "b" },
  { key: "cancelled", keywords: ["Отменен"], type: "b" },
  { key: "discount", keywords: ["Величина скидки на товар", "Скидка товара"], type: "n" },
  { key: "nds", keywords: ["НДС"], type: "n" },
  { key: "paymentSystem", keywords: ["Платежная система"], type: "s" },
  { key: "priceType", keywords: ["Тип цены товара"], type: "s" },
  { key: "source", keywords: ["Источник заказа"], type: "s" },
  { key: "responsible", keywords: ["Ответственный"], type: "s" },
  { key: "changeDate", keywords: ["Дата изменения"], type: "d" },
  { key: "payerType", keywords: ["Тип плательщика"], type: "s" },
  { key: "deliveryAllowed", keywords: ["Доставка разреш"], type: "b" },
  { key: "hasProblem", keywords: ["Проблема с заказом"], type: "b" },
  { key: "comment", keywords: ["Комментарии"], type: "s" },
  { key: "hydrolift", keywords: ["Гидроборт"], type: "b" },
  { key: "dealerPaymentEmailSent", keywords: ["Письмо дилеру о прикреплении"], type: "b" },
  { key: "buyerPaymentEmailSent", keywords: ["Письмо покупателю о прикреплении"], type: "b" },
  { key: "updGenerated", keywords: ["УПД сгенерирован"], type: "b" },
  { key: "updNumber", keywords: ["Номер УПД"], type: "s" },
  { key: "updDocNumber", keywords: ["Номер документа УПД"], type: "s" },
  { key: "updDocDate", keywords: ["Дата документа УПД"], type: "d" },
  { key: "updDocSerial", keywords: ["Порядковый номер документа"], type: "n" },
  { key: "trackingNumber", keywords: ["Номер отслеживания"], type: "s" },
  { key: "shippingIdentifier", keywords: ["Идентификатор отправления"], type: "s" },
  { key: "deliveryDateApproved", keywords: ["Дата разрешения доставки"], type: "d" },
  { key: "paymentOrderNumber", keywords: ["Номер п/п"], type: "s" },
  { key: "paymentOrderDate", keywords: ["Дата п/п"], type: "d" },
  { key: "paymentOrderViewStatus", keywords: ["Статус (просмотр)"], type: "s" },
  { key: "shippingDocNumber", keywords: ["Номер д/о"], type: "s" },
  { key: "shippingDocDate", keywords: ["Дата документа отгрузки"], type: "d" },
  { key: "paidAmount", keywords: ["Оплачено"], type: "n" },
  { key: "psAmount", keywords: ["Сумма ПС"], type: "n" },
  { key: "productCode", keywords: ["Код товара"], type: "n" },
  { key: "externalCatalogCode", keywords: ["Внешний код каталога"], type: "s" },
  { key: "externalProductCode", keywords: ["Внешний код товара"], type: "s" },
  { key: "discountsAndRules", keywords: ["Скидки и правила заказа"], type: "s" },
  { key: "coupons", keywords: ["Купоны заказа"], type: "s" },
  { key: "bankAccount", keywords: ["Расчетный счет"], type: "s" },
  { key: "cancelReason", keywords: ["Причина отмены"], type: "s" },
  { key: "cancelComment", keywords: ["Комментарий к отмене"], type: "s" },
  { key: "buyerComment", keywords: ["Комментарии покупателя"], type: "s" },
  { key: "problemDescription", keywords: ["Описание проблемы"], type: "s" },
  { key: "fundsReceiptDate", keywords: ["Дата поступления денежных средств"], type: "d" },
  { key: "preOrder", keywords: ["Предзаказ"], type: "b" },
  { key: "edoParticipation", keywords: ["Участие в ЭДО"], type: "s" },
  { key: "asfGenerated", keywords: ["АСФ сгенерирован"], type: "b" },
  { key: "asfDocNumber", keywords: ["Номер документа АСФ", "Номер документа ASF"], type: "s" },
  { key: "asfDocDate", keywords: ["Дата документа АСФ", "Дата документа ASF"], type: "d" },
  { key: "discountPercent", keywords: ["Процент скидки по позиции"], type: "n" },
  { key: "discountLevel", keywords: ["Уровень скидки"], type: "s" },
  { key: "netWeightKg", keywords: ["Вес нетто позиции"], type: "n" },
  { key: "postponeLoglabSend", keywords: ["ФЛАГ: Нужно ли отложить"], type: "b" },
  { key: "managerCalculationNeeded", keywords: ["ФЛАГ: Нужен ли менеджер"], type: "b" },
  { key: "accountingDocsEmailSent", keywords: ["Письмо с бухгалтерскими"], type: "b" },
  { key: "accumulatedWeightAtOrder", keywords: ["Накопленный вес на момент оформления"], type: "n" },
  { key: "accumulatedWeightAtRecalc", keywords: ["Накопленный вес на момент последнего пересчета"], type: "n" },
  { key: "actualAccumulatedWeight", keywords: ["Актуальный накопленный вес"], type: "n" },
  { key: "totalOrdersSinceRegistration", keywords: ["Кол-во заказов с момента регистрации"], type: "n" },
  { key: "pvzCode", keywords: ["ПВЗ: код", "Code PVZ"], type: "s" },
  { key: "pvzIndexCity", keywords: ["ПВЗ: Индекс"], type: "s" },
  { key: "tariffName", keywords: ["ЛогЛаб: TariffName"], type: "s" },
  { key: "totalLogisticsCost", keywords: ["ЛогЛаб: TotalCost"], type: "n" },
  { key: "deliveryTypeId", keywords: ["DeliveryTypeId"], type: "s" },
  { key: "tariffType", keywords: ["Tariff type"], type: "s" },
  { key: "tariffId", keywords: ["Tariff ID"], type: "s" },
  { key: "deliveryApp", keywords: ["Delivery App"], type: "s" },
  { key: "deliveryTimeMin", keywords: ["DeliveryTimeMin"], type: "s" },
  { key: "deliveryTimeMax", keywords: ["DeliveryTimeMax"], type: "s" },
  { key: "deliveryPeriodMin", keywords: ["Минимальный срок доставки"], type: "n" },
  { key: "deliveryPeriodMax", keywords: ["deliveryPeriodMax"], type: "n" },
  { key: "dealerSaved", keywords: ["Заказ сохранен дилером"], type: "b" },
  { key: "dealerConfirmed", keywords: ["Заказ подтвержден дилером"], type: "b" },
  { key: "bankName", keywords: ["Наименование банка"], type: "s" },
  { key: "bankBik", keywords: ["БИК банка"], type: "s" },
  { key: "dealerId", keywords: ["Id дилера"], type: "n" },
  { key: "addressString", keywords: ["Адрес доставки строкой"], type: "s" },
  { key: "house", keywords: ["Дом"], type: "s" },
  { key: "street", keywords: ["Улица"], type: "s" },
  { key: "deliveryType", keywords: ["Тип доставки"], type: "s" },
  { key: "contactFio", keywords: ["Ф.И.О."], type: "s" },
  { key: "contactEmail", keywords: ["E-Mail"], type: "s" },
  { key: "zip", keywords: ["Индекс"], type: "s" },
  { key: "location", keywords: ["Местоположение"], type: "s" },
  { key: "city", keywords: ["Город"], type: "s" },
  { key: "fiasRegion", keywords: ["FIAS региона"], type: "s" },
  { key: "deliveryInvoice", keywords: ["Счет на доставку"], type: "s" },
  { key: "riskIndicatorResponseId", keywords: ["responseId отчета с блокирующими"], type: "s" },
  { key: "asfFile", keywords: ["Файл АСФ"], type: "s" },
  { key: "updFile", keywords: ["Файл УПД"], type: "s" },
  { key: "innFile", keywords: ["Файл ИНН"], type: "s" },
  { key: "charterFile", keywords: ["Файл устава"], type: "s" },
  { key: "certifiedDetailsFile", keywords: ["Файл с заверенными"], type: "s" },
  { key: "positionNotification", keywords: ["Позиции"], type: "s" },
  { key: "orderProblem", keywords: ["Проблема с заказом"], type: "s" },
  { key: "yandexProUser", keywords: ["Яндекс.ПРО", "Пользователь в группе"], type: "s" },
  { key: "office", keywords: ["Офис"], type: "s" },
  { key: "affiliate", keywords: ["Аффилиат"], type: "s" },
  { key: "bitrixSync", keywords: ["Активность синхронизации"], type: "s" },
  { key: "site", keywords: ["Сайт"], type: "s" },
  { key: "externalOrderCode", keywords: ["Внешний код заказа"], type: "s" },
  { key: "opticoreOrderId", keywords: ["ID заказа Opticore"], type: "s" },
  { key: "courierCity", keywords: ["CourierCity"], type: "s" },
  { key: "courierStreet", keywords: ["CourierStreet"], type: "s" },
  { key: "aouuid", keywords: ["AOUUID"], type: "s" },
  { key: "contactPhone", keywords: ["Телефон"], type: "s" },
  { key: "deliveryMethodInfo", keywords: ["Метод доставки"], type: "s" },
];

export function parseLukoilExcel(file: File): Promise<OrderRecord[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false }) as any[][];
        if (rows.length < 2) { reject(new Error("Файл пустой")); return; }

        // === SINGLE-PASS HEADER MAPPING ===
        const headers = rows[0].map((h: any) => String(h).trim().toLowerCase());
        const colMap: Record<string, number> = {};
        for (const field of FIELD_MAP) {
          for (const kw of field.keywords) {
            const idx = headers.findIndex((h) => h.includes(kw.toLowerCase()));
            if (idx >= 0) { colMap[field.key as string] = idx; break; }
          }
        }

        // Parse rows
        const records: OrderRecord[] = [];
        for (let i = 1; i < rows.length; i++) {
          const row = rows[i];
          if (!row || row.every((c) => c === undefined || c === "" || c === null || String(c).trim() === "NaN" || String(c).trim() === "NaT")) continue;
          const orderNum = row[colMap.orderNumber];
          if (!orderNum || isEmptyCell(orderNum)) continue;
          const product = row[colMap.product];
          if (!product || isEmptyCell(product)) continue;

          const gv = (key: string): any => {
            const idx = colMap[key];
            if (idx === undefined || idx < 0 || idx >= row.length) return null;
            const v = row[idx];
            if (v === undefined || v === "" || v === null) return null;
            const str = String(v).trim();
            return (str === "NaN" || str === "NaT") ? null : v;
          };

          const parseField = (key: string) => {
            const f = FIELD_MAP.find((x) => x.key === key);
            if (!f) return null;
            const v = gv(key);
            if (v === null) return null;
            switch (f.type) {
              case "n": return sN(v);
              case "d": return parseRussianDate(v);
              case "b": return parseBool(v);
              default: return sS(v);
            }
          };

          records.push({
            id: String(orderNum), date: parseRussianDate(gv("date")) || "",
            updDate: parseField("updDate") as string | null,
            orderNumber: String(orderNum),
            region: sS(gv("region")) || "—",
            dealer: sS(gv("dealer")) || "—",
            delivery: sS(gv("delivery")) || "—",
            ksss: parseField("ksss") as number | null,
            product: String(product),
            productCode: parseField("productCode") as number | null,
            externalCatalogCode: parseField("externalCatalogCode") as string | null,
            externalProductCode: parseField("externalProductCode") as string | null,
            viscosity: parseField("viscosity") as string | null,
            application: parseField("application") as string | null,
            productWeight: parseField("productWeight") as number | null,
            grossWeight: parseField("grossWeight") as number | null,
            netWeightKg: parseField("netWeightKg") as number | null,
            quantity: parseRussianNumber(gv("quantity")),
            unit: null,
            productPrice: parseRussianNumber(gv("productPrice")),
            productAmount: parseRussianNumber(gv("productAmount")),
            totalAmount: parseRussianNumber(gv("totalAmount")),
            deliveryCost: parseField("deliveryCost") as number | null,
            discount: parseField("discount") as number | null,
            discountPercent: parseField("discountPercent") as number | null,
            discountLevel: parseField("discountLevel") as string | null,
            nds: parseField("nds") as number | null,
            priceType: parseField("priceType") as string | null,
            status: sS(gv("status")) || "—",
            paid: parseBool(gv("paid")),
            shipped: parseBool(gv("shipped")),
            cancelled: parseBool(gv("cancelled")),
            deliveryAllowed: parseBool(gv("deliveryAllowed")),
            hasProblem: parseBool(gv("hasProblem")),
            buyer: sS(gv("buyer")) || "—",
            buyerEmail: parseField("buyerEmail") as string | null,
            buyerInn: parseField("buyerInn") as string | null,
            buyerLegalName: parseField("buyerLegalName") as string | null,
            payerType: parseField("payerType") as string | null,
            paymentSystem: parseField("paymentSystem") as string | null,
            paymentStatus: parseField("paymentOrderViewStatus") as string | null,
            paidAmount: parseField("paidAmount") as number | null,
            psAmount: parseField("psAmount") as number | null,
            fundsReceiptDate: parseField("fundsReceiptDate") as string | null,
            paymentOrderNumber: parseField("paymentOrderNumber") as string | null,
            paymentOrderDate: parseField("paymentOrderDate") as string | null,
            paymentOrderViewStatus: parseField("paymentOrderViewStatus") as string | null,
            updGenerated: parseBool(gv("updGenerated")),
            updNumber: parseField("updNumber") as string | null,
            updDocNumber: parseField("updDocNumber") as string | null,
            updDocDate: parseField("updDocDate") as string | null,
            updDocSerial: parseField("updDocSerial") as number | null,
            asfGenerated: parseBool(gv("asfGenerated")),
            asfDocNumber: parseField("asfDocNumber") as string | null,
            asfDocDate: parseField("asfDocDate") as string | null,
            trackingNumber: parseField("trackingNumber") as string | null,
            shippingIdentifier: parseField("shippingIdentifier") as string | null,
            deliveryDateApproved: parseField("deliveryDateApproved") as string | null,
            shippingDocNumber: parseField("shippingDocNumber") as string | null,
            shippingDocDate: parseField("shippingDocDate") as string | null,
            deliveryTimeMin: parseField("deliveryTimeMin") as string | null,
            deliveryTimeMax: parseField("deliveryTimeMax") as string | null,
            deliveryPeriodMin: parseField("deliveryPeriodMin") as number | null,
            deliveryPeriodMax: parseField("deliveryPeriodMax") as number | null,
            pvzCode: parseField("pvzCode") as string | null,
            pvzIndexCity: parseField("pvzIndexCity") as string | null,
            source: parseField("source") as string | null,
            externalOrderCode: parseField("externalOrderCode") as string | null,
            site: parseField("site") as string | null,
            responsible: parseField("responsible") as string | null,
            office: parseField("office") as string | null,
            affiliate: parseField("affiliate") as string | null,
            bitrixSync: parseField("bitrixSync") as string | null,
            comment: parseField("comment") as string | null,
            buyerComment: parseField("buyerComment") as string | null,
            cancelReason: parseField("cancelReason") as string | null,
            cancelComment: parseField("cancelComment") as string | null,
            problemDescription: parseField("problemDescription") as string | null,
            hydrolift: parseBool(gv("hydrolift")),
            dealerPaymentEmailSent: parseBool(gv("dealerPaymentEmailSent")),
            buyerPaymentEmailSent: parseBool(gv("buyerPaymentEmailSent")),
            preOrder: parseBool(gv("preOrder")),
            edoParticipation: parseField("edoParticipation") as string | null,
            changeDate: parseField("changeDate") as string | null,
            yandexProUser: parseField("yandexProUser") as string | null,
            discountsAndRules: parseField("discountsAndRules") as string | null,
            coupons: parseField("coupons") as string | null,
            deliveryMethodInfo: parseField("deliveryMethodInfo") as string | null,
            deliveryType: parseField("deliveryType") as string | null,
            deliveryTypeId: parseField("deliveryTypeId") as string | null,
            tariffType: parseField("tariffType") as string | null,
            tariffId: parseField("tariffId") as string | null,
            deliveryApp: parseField("deliveryApp") as string | null,
            tariffName: parseField("tariffName") as string | null,
            totalLogisticsCost: parseField("totalLogisticsCost") as number | null,
            bankAccount: parseField("bankAccount") as string | null,
            bankName: parseField("bankName") as string | null,
            bankBik: parseField("bankBik") as string | null,
            dealerId: parseField("dealerId") as number | null,
            addressString: parseField("addressString") as string | null,
            house: parseField("house") as string | null,
            street: parseField("street") as string | null,
            city: parseField("city") as string | null,
            zip: parseField("zip") as string | null,
            location: parseField("location") as string | null,
            fiasRegion: parseField("fiasRegion") as string | null,
            contactFio: parseField("contactFio") as string | null,
            contactEmail: parseField("contactEmail") as string | null,
            contactPhone: parseField("contactPhone") as string | null,
            accumulatedWeightAtOrder: parseField("accumulatedWeightAtOrder") as number | null,
            accumulatedWeightAtRecalc: parseField("accumulatedWeightAtRecalc") as number | null,
            actualAccumulatedWeight: parseField("actualAccumulatedWeight") as number | null,
            totalOrdersSinceRegistration: parseField("totalOrdersSinceRegistration") as number | null,
            opticoreOrderId: parseField("opticoreOrderId") as string | null,
            courierCity: parseField("courierCity") as string | null,
            courierStreet: parseField("courierStreet") as string | null,
            aouuid: parseField("aouuid") as string | null,
            dealerSaved: parseBool(gv("dealerSaved")),
            dealerConfirmed: parseBool(gv("dealerConfirmed")),
            deliveryInvoice: parseField("deliveryInvoice") as string | null,
            managerCalculationNeeded: parseBool(gv("managerCalculationNeeded")),
            postponeLoglabSend: parseBool(gv("postponeLoglabSend")),
            accountingDocsEmailSent: parseBool(gv("accountingDocsEmailSent")),
            riskIndicatorResponseId: parseField("riskIndicatorResponseId") as string | null,
            asfFile: parseField("asfFile") as string | null,
            updFile: parseField("updFile") as string | null,
            innFile: parseField("innFile") as string | null,
            charterFile: parseField("charterFile") as string | null,
            certifiedDetailsFile: parseField("certifiedDetailsFile") as string | null,
            positionNotification: parseField("positionNotification") as string | null,
            orderProblem: parseField("orderProblem") as string | null,
          });
        }
        resolve(records);
      } catch (err) { reject(err); }
    };
    reader.onerror = () => reject(new Error("Ошибка чтения файла"));
    reader.readAsArrayBuffer(file);
  });
}

// ============================================================
// AGGREGATIONS
// ============================================================
function safeNum(v: number): number { return isNaN(v) || v === undefined ? 0 : v; }

export function getSummary(records: OrderRecord[]): SalesSummary {
  const totalRevenue = records.reduce((s, r) => s + safeNum(r.productAmount), 0);
  const totalOrders = new Set(records.map((r) => r.orderNumber).filter(Boolean)).size;
  const totalProducts = records.reduce((s, r) => s + safeNum(r.quantity), 0);
  const orderAmounts: Record<string, number> = {};
  records.forEach((r) => { orderAmounts[r.orderNumber] = Math.max(orderAmounts[r.orderNumber] || 0, safeNum(r.totalAmount)); });
  const uniqueVals = Object.values(orderAmounts);
  const avgOrderValue = uniqueVals.length > 0 ? uniqueVals.reduce((s, v) => s + safeNum(v), 0) / uniqueVals.length : 0;
  const paidAmount = records.filter((r) => r.paid).reduce((s, r) => s + safeNum(r.productAmount), 0);
  const unpaidAmount = records.filter((r) => !r.paid && !r.cancelled).reduce((s, r) => s + safeNum(r.productAmount), 0);
  const cancelledAmount = records.filter((r) => r.cancelled).reduce((s, r) => s + safeNum(r.productAmount), 0);
  const totalDeliveryCost = records.reduce((s, r) => s + safeNum(r.deliveryCost || 0), 0);
  const totalDiscount = records.reduce((s, r) => s + safeNum(r.discount || 0), 0);
  return { totalRevenue, totalOrders, totalProducts, avgOrderValue, paidAmount, unpaidAmount, cancelledAmount, totalDeliveryCost, totalDiscount };
}

export function aggregateByPeriod(records: OrderRecord[], period: "day" | "week" | "month"): ChartData {
  const map = new Map<string, { revenue: number; orders: Set<string> }>();
  records.forEach((r) => {
    if (!r.date || r.date === "—") return;
    let key: string; const d = new Date(r.date);
    if (isNaN(d.getTime())) return;
    if (period === "day") key = r.date;
    else if (period === "week") { const ws = new Date(d); ws.setDate(d.getDate() - d.getDay() + 1); key = ws.toISOString().split("T")[0]; }
    else key = r.date.substring(0, 7);
    const e = map.get(key) || { revenue: 0, orders: new Set() };
    e.revenue += safeNum(r.productAmount); e.orders.add(r.orderNumber); map.set(key, e);
  });
  const sorted = Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  const labels = sorted.map(([k]) => new Date(k.length === 7 ? k + "-01" : k).toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" }));
  return { labels, datasets: [{ label: "Выручка (руб)", data: sorted.map(([, v]) => v.revenue), backgroundColor: "rgba(220, 38, 38, 0.75)", borderColor: "#DC2626", borderWidth: 1 }] };
}

export function aggregateByDimension(records: OrderRecord[], dimension: "region" | "dealer" | "delivery" | "status" | "buyer" | "product" | "viscosity" | "application" | "paid" | "priceType"): ChartData {
  const map = new Map<string, number>();
  records.forEach((r) => {
    let key: string;
    switch (dimension) {
      case "region": key = r.region || "—"; break;
      case "dealer": key = r.dealer || "—"; break;
      case "delivery": key = r.delivery || "—"; break;
      case "status": key = r.status || "—"; break;
      case "buyer": key = r.buyer || "—"; break;
      case "product": key = r.product || "—"; break;
      case "viscosity": key = r.viscosity || "Не установлено"; break;
      case "application": key = r.application || "Не установлено"; break;
      case "paid": key = r.paid ? "Оплачено" : "Не оплачено"; break;
      case "priceType": key = r.priceType || "—"; break;
    }
    map.set(key, (map.get(key) || 0) + safeNum(r.productAmount));
  });
  const sorted = Array.from(map.entries()).sort((a, b) => b[1] - a[1]).slice(0, 15);
  const colors = ["#DC2626", "#EF4444", "#F87171", "#FB923C", "#FBBF24", "#22C55E", "#3B82F6", "#8B5CF6", "#EC4899", "#14B8A6", "#F43F5E", "#6366F1", "#84CC16", "#06B6D4", "#A855F7"];
  return { labels: sorted.map(([k]) => k.length > 30 ? k.substring(0, 30) + "..." : k), datasets: [{ label: "Сумма (руб)", data: sorted.map(([, v]) => v), backgroundColor: sorted.map((_, i) => colors[i % colors.length]), borderWidth: 0 }] };
}

export function getStatusDistribution(records: OrderRecord[]): ChartData {
  const map = new Map<string, number>();
  records.forEach((r) => { const k = r.status || "—"; if (k === "—" || k === "NaN") return; map.set(k, (map.get(k) || 0) + 1); });
  const sorted = Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  const colors = ["#DC2626", "#EF4444", "#F97316", "#EAB308", "#22C55E", "#3B82F6", "#8B5CF6", "#EC4899", "#14B8A6", "#6B7280", "#F43F5E"];
  return { labels: sorted.map(([k]) => k), datasets: [{ label: "Количество", data: sorted.map(([, v]) => v), backgroundColor: sorted.map((_, i) => colors[i % colors.length]), borderWidth: 0 }] };
}

export function getDeliveryDistribution(records: OrderRecord[]): ChartData {
  const map = new Map<string, { count: number; revenue: number }>();
  records.forEach((r) => { const e = map.get(r.delivery) || { count: 0, revenue: 0 }; e.count += 1; e.revenue += safeNum(r.productAmount); map.set(r.delivery, e); });
  const sorted = Array.from(map.entries()).sort((a, b) => b[1].revenue - a[1].revenue);
  return { labels: sorted.map(([k]) => k), datasets: [{ label: "Выручка (руб)", data: sorted.map(([, v]) => v.revenue), backgroundColor: ["#DC2626", "#EF4444", "#F97316", "#EAB308", "#8B5CF6"], borderWidth: 0 }] };
}

export function getTopProducts(records: OrderRecord[], limit: number = 15): { product: string; revenue: number; quantity: number }[] {
  const map = new Map<string, { revenue: number; quantity: number }>();
  records.forEach((r) => { const e = map.get(r.product) || { revenue: 0, quantity: 0 }; e.revenue += safeNum(r.productAmount); e.quantity += safeNum(r.quantity); map.set(r.product, e); });
  return Array.from(map.entries()).map(([product, v]) => ({ product, ...v })).sort((a, b) => b.revenue - a.revenue).slice(0, limit);
}

export function getTopBuyers(records: OrderRecord[], limit: number = 15): { buyer: string; revenue: number; orders: number }[] {
  const map = new Map<string, { revenue: number; orders: Set<string> }>();
  records.forEach((r) => { const e = map.get(r.buyer) || { revenue: 0, orders: new Set() }; e.revenue += safeNum(r.productAmount); e.orders.add(r.orderNumber); map.set(r.buyer, e); });
  return Array.from(map.entries()).map(([buyer, v]) => ({ buyer, revenue: v.revenue, orders: v.orders.size })).sort((a, b) => b.revenue - a.revenue).slice(0, limit);
}

export function filterRecords(records: OrderRecord[], filters: { dateFrom?: string; dateTo?: string; status?: string; region?: string; dealer?: string; delivery?: string; buyer?: string; product?: string; paid?: string; cancelled?: string }): OrderRecord[] {
  return records.filter((r) => {
    if (filters.dateFrom && r.date && r.date < filters.dateFrom) return false;
    if (filters.dateTo && r.date && r.date > filters.dateTo) return false;
    if (filters.status && filters.status !== "all" && r.status !== filters.status) return false;
    if (filters.region && filters.region !== "all" && r.region !== filters.region) return false;
    if (filters.dealer && filters.dealer !== "all" && r.dealer !== filters.dealer) return false;
    if (filters.delivery && filters.delivery !== "all" && r.delivery !== filters.delivery) return false;
    if (filters.buyer && filters.buyer !== "all" && r.buyer !== filters.buyer) return false;
    if (filters.product && filters.product !== "all" && r.product !== filters.product) return false;
    if (filters.paid && filters.paid !== "all") { if (r.paid !== (filters.paid === "yes")) return false; }
    if (filters.cancelled && filters.cancelled !== "all") { if (r.cancelled !== (filters.cancelled === "yes")) return false; }
    return true;
  });
}

export function getFilterOptions(records: OrderRecord[]) {
  return {
    statuses: [...new Set(records.map((r) => r.status).filter(Boolean))].sort(),
    regions: [...new Set(records.map((r) => r.region).filter((r) => r && r !== "—"))].sort(),
    dealers: [...new Set(records.map((r) => r.dealer).filter((r) => r && r !== "—"))].sort(),
    deliveries: [...new Set(records.map((r) => r.delivery).filter((r) => r && r !== "—"))].sort(),
    buyers: [...new Set(records.map((r) => r.buyer).filter((r) => r && r !== "—"))].sort(),
    products: [...new Set(records.map((r) => r.product).filter(Boolean))].sort(),
  };
}
