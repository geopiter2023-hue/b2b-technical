import { useState, useRef, useEffect, useCallback } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import type { Product, CardConfig } from "@/types/productCards";
import { TEMPLATES, TEMPLATE_CATEGORIES, SEASON_BACKGROUNDS, FONTS, FIELD_LABELS, getDefaultConfig } from "@/types/productCards";
import { loadProducts, saveProducts, saveConfig, loadConfig, parseExcelFile, getDemoProducts } from "@/services/productCardService";
import QRCode from "qrcode";
import JSZip from "jszip";

/* ─── Types ─── */
interface PhotoMapping {
  productId: number;
  photoDataUrl: string;
  filename: string;
}

/* ─── Helpers ─── */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

function findBestPhotoMatch(filename: string, products: Product[]): Product | null {
  const cleanName = filename.toLowerCase().replace(/[^a-zа-я0-9]/g, "");
  for (const p of products) {
    const articleClean = (p.article || p.kccc || "").toLowerCase().replace(/[^a-zа-я0-9]/g, "");
    if (articleClean && cleanName.includes(articleClean)) return p;
    const nameClean = (p.name || "").toLowerCase().replace(/[^a-zа-я0-9]/g, "");
    if (nameClean && cleanName.includes(nameClean.substring(0, 8))) return p;
    const kcccClean = (p.kccc || "").toLowerCase().replace(/[^a-zа-я0-9]/g, "");
    if (kcccClean && cleanName.includes(kcccClean)) return p;
  }
  return null;
}

function getSeasonOverlay(season: string): string {
  switch (season) {
    case "spring": return "rgba(144, 238, 144, 0.12)";
    case "summer": return "rgba(255, 215, 0, 0.1)";
    case "autumn": return "rgba(210, 105, 30, 0.12)";
    case "winter": return "rgba(173, 216, 230, 0.15)";
    default: return "transparent";
  }
}

/* ─── Canvas Draw Function ─── */
async function drawCardOnCanvas(
  canvas: HTMLCanvasElement,
  product: Product | null,
  config: CardConfig,
  photoDataUrl?: string | null,
  logoDataUrl?: string | null
) {
  if (!product) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const W = config.width;
  const H = config.height;
  canvas.width = W;
  canvas.height = H;

  const tmpl = TEMPLATES.find(t => t.key === config.template);
  const r = config.borderRadius;

  ctx.clearRect(0, 0, W, H);

  /* Background with rounded clip */
  ctx.beginPath();
  ctx.moveTo(r, 0);
  ctx.lineTo(W - r, 0);
  ctx.quadraticCurveTo(W, 0, W, r);
  ctx.lineTo(W, H - r);
  ctx.quadraticCurveTo(W, H, W - r, H);
  ctx.lineTo(r, H);
  ctx.quadraticCurveTo(0, H, 0, H - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.closePath();
  ctx.save();
  ctx.clip();

  /* ═══ Background fill ═══ */
  const userColor = config.colors.primary;
  const userAccent = config.colors.accent || "#FFD700";
  const userFrame = config.colors.frame || userColor;

  if (config.backgroundImage) {
    try {
      const img = await loadImage(config.backgroundImage);
      ctx.drawImage(img, 0, 0, W, H);
    } catch {
      ctx.fillStyle = userColor;
      ctx.fillRect(0, 0, W, H);
    }
  } else if (tmpl?.isFrame) {
    /* ═══ FRAME: white bg + colored border + inner accent strip ═══ */
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, W, H);
    const frameW = Math.max(6, Math.min(W, H) * 0.025);
    ctx.fillStyle = userFrame;
    ctx.fillRect(0, 0, W, frameW);
    ctx.fillRect(0, H - frameW, W, frameW);
    ctx.fillRect(0, 0, frameW, H);
    ctx.fillRect(W - frameW, 0, frameW, H);
    /* Inner accent line */
    ctx.fillStyle = userAccent;
    const innerGap = frameW + 3;
    ctx.fillRect(innerGap, innerGap, W - innerGap * 2, 2);
    ctx.fillRect(innerGap, H - innerGap - 2, W - innerGap * 2, 2);
    ctx.fillRect(innerGap, innerGap, 2, H - innerGap * 2);
    ctx.fillRect(W - innerGap - 2, innerGap, 2, H - innerGap * 2);
  } else if (tmpl?.isDouble) {
    /* ═══ DOUBLE: top half = primary, bottom half = accent ═══ */
    ctx.fillStyle = userColor;
    ctx.fillRect(0, 0, W, H * 0.45);
    ctx.fillStyle = userAccent;
    ctx.fillRect(0, H * 0.45, W, H * 0.55);
    /* Smooth blend */
    const blendGrad = ctx.createLinearGradient(0, H * 0.38, 0, H * 0.52);
    blendGrad.addColorStop(0, hexToRgba(userColor, 0));
    blendGrad.addColorStop(0.5, "rgba(0,0,0,0.15)");
    blendGrad.addColorStop(1, hexToRgba(userAccent, 0));
    ctx.fillStyle = blendGrad;
    ctx.fillRect(0, H * 0.38, W, H * 0.14);
  } else if (tmpl?.useCustomColor) {
    /* ═══ FULL COLOR: uses user's custom color ═══ */
    ctx.fillStyle = userColor;
    ctx.fillRect(0, 0, W, H);
    /* Subtle gradient overlay for depth */
    const depthGrad = ctx.createLinearGradient(0, 0, 0, H);
    depthGrad.addColorStop(0, "rgba(255,255,255,0.08)");
    depthGrad.addColorStop(1, "rgba(0,0,0,0.12)");
    ctx.fillStyle = depthGrad;
    ctx.fillRect(0, 0, W, H);
  } else if (tmpl?.bg) {
    if (tmpl.key === "gradient") {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, tmpl.bg[0]);
      grad.addColorStop(1, tmpl.bg[1] || tmpl.bg[0]);
      ctx.fillStyle = grad;
    } else if (tmpl.key === "silver") {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, "#C8D0D8");
      grad.addColorStop(0.3, "#E8ECF0");
      grad.addColorStop(0.5, "#B0B8C4");
      grad.addColorStop(0.7, "#D8DEE4");
      grad.addColorStop(1, "#A8B0BC");
      ctx.fillStyle = grad;
    } else if (tmpl.key === "gold") {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, "#E8C547");
      grad.addColorStop(0.3, "#D4A520");
      grad.addColorStop(0.5, "#B8860B");
      grad.addColorStop(0.7, "#E8C547");
      grad.addColorStop(1, "#AA8018");
      ctx.fillStyle = grad;
    } else if (tmpl.key === "geometry") {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, "#1E3A5F");
      grad.addColorStop(1, "#2E5A8F");
      ctx.fillStyle = grad;
    } else {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, tmpl.bg[0]);
      grad.addColorStop(1, tmpl.bg[1] || tmpl.bg[0]);
      ctx.fillStyle = grad;
    }
    ctx.fillRect(0, 0, W, H);
  } else {
    ctx.fillStyle = userColor;
    ctx.fillRect(0, 0, W, H);
  }

  /* Season overlay */
  if (config.seasonBg) {
    ctx.fillStyle = getSeasonOverlay(config.seasonBg);
    ctx.fillRect(0, 0, W, H);
  }

  /* Template decorative effects */
  if (config.template === "geometry") {
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(W * 0.15 * i, 0);
      ctx.lineTo(W * 0.15 * i + 60, H);
      ctx.stroke();
    }
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.arc(W * 0.25 * (i + 1), H * 0.4, 40 + i * 20, 0, Math.PI * 2);
      ctx.stroke();
    }
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(0, H * 0.3 * (i + 1));
      ctx.lineTo(W, H * 0.3 * (i + 1));
      ctx.stroke();
    }
  } else if (config.template === "gloss") {
    const grad = ctx.createRadialGradient(W * 0.75, H * 0.15, 0, W * 0.75, H * 0.15, W * 0.45);
    grad.addColorStop(0, "rgba(255,255,255,0.35)");
    grad.addColorStop(0.5, "rgba(255,255,255,0.08)");
    grad.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);
  } else if (config.template === "holographic") {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, "rgba(255,0,255,0.08)");
    grad.addColorStop(0.33, "rgba(0,255,255,0.08)");
    grad.addColorStop(0.66, "rgba(255,255,0,0.08)");
    grad.addColorStop(1, "rgba(255,0,255,0.08)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);
  } else if (config.template === "neon") {
    ctx.save();
    ctx.shadowColor = userColor;
    ctx.shadowBlur = 25;
    ctx.strokeStyle = hexToRgba(userColor, 0.35);
    ctx.lineWidth = 2;
    ctx.strokeRect(4, 4, W - 8, H - 8);
    ctx.restore();
  }

  /* Metallic shine for metal templates */
  if (config.category === "metallics" && config.template !== "kanistra") {
    const shineGrad = ctx.createLinearGradient(0, 0, W * 0.6, H * 0.4);
    shineGrad.addColorStop(0, "rgba(255,255,255,0.2)");
    shineGrad.addColorStop(0.5, "rgba(255,255,255,0.05)");
    shineGrad.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = shineGrad;
    ctx.fillRect(0, 0, W, H);
  }

  const textColor = config.colors.text;
  ctx.fillStyle = textColor;
  ctx.textAlign = "left";

  /* ── Logo (Brand) ── */
  if (config.fields.logo) {
    const lp = config.positions.logo;
    const logoX = (lp.x / 100) * W;
    const logoY = (lp.y / 100) * H;
    if (logoDataUrl) {
      try {
        const logoImg = await loadImage(logoDataUrl);
        const logoMaxW = W * 0.4;
        const logoMaxH = H * 0.12;
        let lw = logoImg.width;
        let lh = logoImg.height;
        const logoRatio = lw / lh;
        if (lw > logoMaxW) { lw = logoMaxW; lh = lw / logoRatio; }
        if (lh > logoMaxH) { lh = logoMaxH; lw = lh * logoRatio; }
        ctx.drawImage(logoImg, logoX, logoY, lw, lh);
      } catch {
        const ts = config.textSizes.logo;
        ctx.font = `bold ${ts.size}px ${ts.font}`;
        ctx.fillText((product.brand || "LUKOIL").toUpperCase(), logoX, logoY + ts.size);
      }
    } else {
      const ts = config.textSizes.logo;
      ctx.font = `bold ${ts.size}px ${ts.font}`;
      ctx.fillText((product.brand || "LUKOIL").toUpperCase(), logoX, logoY + ts.size);
    }
  }

  /* ── Dealer Badge ── */
  if (config.fields.dealer && config.dealerText) {
    const ts = config.textSizes.dealerBadge;
    ctx.font = `${ts.size}px ${ts.font}`;
    ctx.textAlign = "right";
    const dp = config.positions.dealer;
    const dText = config.dealerText;
    const dMetrics = ctx.measureText(dText);
    const badgePad = 6;
    const badgeW = dMetrics.width + badgePad * 2;
    const badgeX = Math.min((dp.x / 100) * W, W - badgeW - 4);
    const badgeY = (dp.y / 100) * H;
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    roundRect(ctx, badgeX, badgeY, badgeW, ts.size + 4, 3);
    ctx.fill();
    ctx.fillStyle = textColor;
    ctx.fillText(dText, badgeX + badgePad, badgeY + ts.size);
    ctx.textAlign = "left";
  }

  /* ── QR Code ── */
  if (config.fields.qrCode) {
    try {
      const qrUrl = await QRCode.toDataURL(product.kccc || "0", { width: 50, margin: 1 });
      const qrImg = await loadImage(qrUrl);
      const qp = config.positions.qrcode;
      ctx.drawImage(qrImg, (qp.x / 100) * W, (qp.y / 100) * H, 50, 50);
    } catch { /* ignore */ }
  }

  /* ── SAE Badge ── */
  if (config.fields.saeBadge && product.viscosity) {
    const sp = config.positions.saeBadge;
    drawBadge(ctx, `SAE ${product.viscosity}`, (sp.x / 100) * W, (sp.y / 100) * H, textColor);
  }

  /* ── API/ACEA Badge ── */
  if (config.fields.apiAceaBadge && (product.api || product.acea)) {
    const ap = config.positions.apiAcea;
    const text = [product.api, product.acea].filter(Boolean).join(" / ");
    drawBadge(ctx, text, (ap.x / 100) * W, (ap.y / 100) * H, textColor);
  }

  /* ── ILSAC Logo ── */
  if (config.fields.ilsacLogo && product.ilsac) {
    const ip = config.positions.ilsac;
    drawBadge(ctx, product.ilsac, (ip.x / 100) * W, (ip.y / 100) * H, textColor);
  }

  /* ── Product Photo (MAIN) ── */
  let photoRendered = false;
  if (photoDataUrl) {
    try {
      const img = await loadImage(photoDataUrl);
      const ps = config.photoScale / 100;
      const imgW = W * (0.15 + 0.70 * ps);
      const imgH = H * (0.08 + 0.55 * ps);
      const imgX = (W - imgW) / 2;
      const imgY = H * (0.28 - 0.15 * ps);
      // Free draw — no clip, no frame
      ctx.drawImage(img, imgX, imgY, imgW, imgH);
      photoRendered = true;
    } catch { /* ignore */ }
  }

  if (!photoRendered) {
    /* Placeholder */
    const ps = config.photoScale / 100;
    const imgW = W * (0.12 + 0.55 * ps);
    const imgH = H * (0.06 + 0.40 * ps);
    const imgX = (W - imgW) / 2;
    const imgY = H * (0.25 - 0.08 * ps);
    ctx.fillStyle = "rgba(0,0,0,0.15)";
    ctx.fillRect(imgX, imgY, imgW, imgH);
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.font = "14px Tahoma, Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Нет фото", W / 2, imgY + imgH / 2 + 5);
    ctx.textAlign = "left";
  }

  /* ── Product Name ── */
  if (config.fields.name && product.name) {
    const ts = config.textSizes.name;
    ctx.font = `bold ${ts.size}px ${ts.font}`;
    ctx.fillStyle = textColor;
    ctx.textAlign = "center";
    const np = config.positions.name;
    const nameY = (np.y / 100) * H;
    wrapText(ctx, product.name, W / 2, nameY, W * 0.9, ts.size * 1.3);
    ctx.textAlign = "left";
  }

  /* ── Article ── */
  if (config.fields.article && product.article) {
    const ts = config.textSizes.article;
    ctx.font = `${ts.size}px ${ts.font}`;
    ctx.fillStyle = textColor;
    const ap = config.positions.article;
    ctx.globalAlpha = 0.75;
    ctx.fillText(`Арт: ${product.article}`, (ap.x / 100) * W, (ap.y / 100) * H);
    ctx.globalAlpha = 1;
  }

  /* ── STO / Characteristics ── */
  if (config.fields.characteristics) {
    const ts = config.textSizes.characteristics;
    ctx.font = `${ts.size}px ${ts.font}`;
    const cp = config.positions.characteristics;
    const sto = config.stoNumber || (product.api && product.acea ? `СТО ${product.api}/${product.acea}` : "СТО 79345251-185-2019");
    ctx.globalAlpha = 0.7;
    ctx.fillText(sto, (cp.x / 100) * W, (cp.y / 100) * H);
    ctx.globalAlpha = 1;
  }

  /* ── Volume (big) ── */
  if (config.fields.volume && product.volume) {
    const ts = config.textSizes.volume;
    ctx.font = `bold ${ts.size}px ${ts.font}`;
    ctx.fillStyle = config.colors.volume;
    ctx.textAlign = "center";
    const vp = config.positions.volume;
    const volY = vp.y === 0 ? H - ts.size * 0.4 : (vp.y / 100) * H;
    ctx.shadowColor = "rgba(0,0,0,0.3)";
    ctx.shadowBlur = 8;
    ctx.fillText(product.volume, W / 2, volY);
    ctx.shadowBlur = 0;
    ctx.textAlign = "left";
    ctx.fillStyle = textColor;
  }

  /* ── Volume Badge ── */
  if (config.fields.volumeBadge && product.volume) {
    const vp = config.positions.volume;
    drawBadge(ctx, product.volume, W * 0.75, H * 0.88, textColor);
  }

  /* ── KCCC Code ── */
  if (config.fields.kcccCode && product.kccc) {
    ctx.font = `12px Tahoma, Arial, sans-serif`;
    ctx.fillStyle = textColor;
    ctx.globalAlpha = 0.5;
    ctx.textAlign = "center";
    ctx.fillText(`КССС: ${product.kccc}`, W / 2, H - 18);
    ctx.globalAlpha = 1;
    ctx.textAlign = "left";
  }

  /* ── Advantages ── */
  if (config.fields.advantages && config.advantages.length > 0) {
    const ts = config.textSizes.advantages;
    ctx.font = `${ts.size}px ${ts.font}`;
    const ap = config.positions.advantages;
    let ay = (ap.y / 100) * H;
    const maxAdv = Math.min(config.advantages.length, 4);
    for (let i = 0; i < maxAdv; i++) {
      ctx.fillStyle = "#4ade80";
      ctx.fillText("✓", (ap.x / 100) * W, ay);
      ctx.fillStyle = textColor;
      ctx.fillText(" " + config.advantages[i], (ap.x / 100) * W + ts.size, ay);
      ay += ts.size * 1.4;
    }
  }

  /* ── Barcode ── */
  if (config.fields.barcode && product.barcode) {
    ctx.font = "13px Tahoma, Arial, sans-serif";
    ctx.globalAlpha = 0.45;
    ctx.textAlign = "center";
    ctx.fillText(`▌▌▌▌ ${product.barcode} ▌▌▌▌`, W / 2, H - 38);
    ctx.globalAlpha = 1;
    ctx.textAlign = "left";
  }

  /* ── EAN-13 ── */
  if (config.fields.ean13 && product.barcode) {
    const ep = config.positions.ean13;
    ctx.font = "13px Tahoma, Arial, sans-serif";
    ctx.globalAlpha = 0.6;
    ctx.fillText(`EAN-13: ${product.barcode}`, (ep.x / 100) * W, (ep.y / 100) * H);
    ctx.globalAlpha = 1;
  }

  ctx.restore();

  /* Border */
  ctx.strokeStyle = "rgba(0,0,0,0.08)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(r, 0);
  ctx.lineTo(W - r, 0);
  ctx.quadraticCurveTo(W, 0, W, r);
  ctx.lineTo(W, H - r);
  ctx.quadraticCurveTo(W, H, W - r, H);
  ctx.lineTo(r, H);
  ctx.quadraticCurveTo(0, H, 0, H - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.closePath();
  ctx.stroke();
}

function drawBadge(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, textColor: string) {
  ctx.save();
  ctx.font = "bold 11px Tahoma, Arial, sans-serif";
  const metrics = ctx.measureText(text);
  const pad = 6;
  const w = metrics.width + pad * 2;
  const h = 20;
  ctx.fillStyle = "rgba(0,0,0,0.25)";
  roundRect(ctx, x, y, w, h, 4);
  ctx.fill();
  ctx.fillStyle = textColor;
  ctx.textAlign = "left";
  ctx.fillText(text, x + pad, y + 15);
  ctx.restore();
}

function wrapText(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
  const words = text.split(" ");
  let line = "";
  let cy = y;
  for (let i = 0; i < words.length; i++) {
    const test = line + words[i] + " ";
    if (ctx.measureText(test).width > maxWidth && i > 0) {
      ctx.fillText(line.trim(), x, cy);
      line = words[i] + " ";
      cy += lineHeight;
    } else {
      line = test;
    }
  }
  ctx.fillText(line.trim(), x, cy);
}

/* ═══ MAIN PAGE ═══ */
export default function ProductCardsPage() {
  const [products, setProducts] = useState<Product[]>(() => loadProducts());
  const [config, setConfig] = useState<CardConfig>(() => loadConfig() || getDefaultConfig());
  const [currentIndex, setCurrentIndex] = useState(0);
  const [photoMap, setPhotoMap] = useState<Record<number, string>>({});
  const [matchedCount, setMatchedCount] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [showNoPhotoOnly, setShowNoPhotoOnly] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [dragOverZone, setDragOverZone] = useState<string | null>(null);
  const [visibleFields, setVisibleFields] = useState<string[]>(["name", "article", "kccc", "brand", "viscosity", "volume"]);
  const [showColumnSettings, setShowColumnSettings] = useState(false);
  const [showExportFieldSettings, setShowExportFieldSettings] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const excelInputRef = useRef<HTMLInputElement>(null);
  const zipInputRef = useRef<HTMLInputElement>(null);
  const singlePhotoInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  const FIELD_OPTIONS: { key: string; label: string }[] = [
    { key: "name", label: "Название" },
    { key: "article", label: "Артикул" },
    { key: "kccc", label: "КССС" },
    { key: "brand", label: "Бренд" },
    { key: "viscosity", label: "Вязкость" },
    { key: "api", label: "API" },
    { key: "acea", label: "ACEA" },
    { key: "volume", label: "Объём" },
    { key: "direction", label: "Направление" },
    { key: "line", label: "Линейка" },
    { key: "type", label: "Вид" },
    { key: "category", label: "Категория" },
  ];

  const toggleVisibleField = (key: string) => {
    setVisibleFields((prev) =>
      prev.includes(key) ? prev.filter((f) => f !== key) : [...prev, key]
    );
  };

  const currentProduct = products[currentIndex] || null;
  const currentPhoto = currentProduct ? photoMap[currentProduct.id] : null;

  useEffect(() => { saveProducts(products); }, [products]);
  useEffect(() => { saveConfig(config); }, [config]);

  /* Redraw canvas when product/config changes */
  useEffect(() => {
    if (canvasRef.current && currentProduct) {
      drawCardOnCanvas(canvasRef.current, currentProduct, config, currentPhoto, config.logoImage || null);
    }
  }, [currentProduct, config, currentPhoto]);

  /* ── Load Excel ── */
  const handleExcel = async (file: File) => {
    setIsProcessing(true);
    try {
      const parsed = await parseExcelFile(file);
      const newProducts: Product[] = parsed.map((p, i) => ({
        id: Date.now() + i,
        kccc: p.kccc || "",
        name: p.name || "",
        brand: p.brand || "LUKOIL",
        viscosity: p.viscosity || "",
        api: p.api || "",
        acea: p.acea || "",
        volume: p.volume || "",
        barcode: p.barcode || "",
        article: p.article || p.kccc || "",
        subLine: p.subLine || "",
        direction: p.direction || "",
        line: p.line || "",
        type: p.type || "",
        ilsac: p.ilsac || "",
        country: p.country || "",
        oem: p.oem || "",
        photo: p.photo || "",
      }));
      if (newProducts.length > 0) {
        setProducts(newProducts);
        setCurrentIndex(0);
      }
    } catch (err) { console.error(err); }
    setIsProcessing(false);
  };

  /* ── Load ZIP with photos ── */
  const handleZip = async (file: File) => {
    setIsProcessing(true);
    try {
      const zip = await JSZip.loadAsync(file);
      const newPhotoMap: Record<number, string> = {};
      let matched = 0;

      const imageFiles = Object.entries(zip.files).filter(([name, zf]) =>
        !zf.dir && /\.(jpg|jpeg|png|webp|gif)$/i.test(name)
      );

      for (const [filename, zipEntry] of imageFiles) {
        const blob = await zipEntry.async("blob");
        const dataUrl = await blobToDataUrl(blob);
        const match = findBestPhotoMatch(filename, products);
        if (match) {
          if (!newPhotoMap[match.id]) {
            newPhotoMap[match.id] = dataUrl;
            matched++;
          }
        }
      }

      setPhotoMap(prev => ({ ...prev, ...newPhotoMap }));
      setMatchedCount(matched);
    } catch (err) { console.error("ZIP error:", err); }
    setIsProcessing(false);
  };

  /* ── Single photo upload ── */
  const handleSinglePhoto = (productId: number, file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setPhotoMap(prev => ({ ...prev, [productId]: e.target?.result as string }));
    };
    reader.readAsDataURL(file);
  };

  /* ── Background image ── */
  const handleBgImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setConfig(prev => ({ ...prev, backgroundImage: e.target?.result as string }));
    };
    reader.readAsDataURL(file);
  };

  /* ── Logo image ── */
  const handleLogoImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setConfig(prev => ({ ...prev, logoImage: e.target?.result as string }));
    };
    reader.readAsDataURL(file);
  };

  /* ── Export single PNG ── */
  const exportSingle = async () => {
    if (!canvasRef.current || !currentProduct) return;
    const safeName = (currentProduct.article || currentProduct.kccc || "card").replace(/[^a-zA-Z0-9]/g, "_");
    const link = document.createElement("a");
    link.download = `card_${safeName}.png`;
    link.href = canvasRef.current.toDataURL("image/png");
    link.click();
  };

  /* ── Export ALL to ZIP ── */
  const exportAll = async () => {
    const exportCanvas = document.createElement("canvas");
    const zip = new JSZip();
    const folder = zip.folder("product-cards");
    if (!folder) return;

    setExportProgress(0);
    const total = products.length;

    for (let i = 0; i < total; i++) {
      const product = products[i];
      const photo = photoMap[product.id];
      await drawCardOnCanvas(exportCanvas, product, config, photo, config.logoImage || null);

      const blob = await new Promise<Blob | null>(resolve =>
        exportCanvas.toBlob(resolve, "image/png")
      );
      if (blob) {
        const safeName = (product.article || product.kccc || String(i + 1)).replace(/[^a-zA-Z0-9]/g, "_");
        folder.file(`card_${safeName}.png`, blob);
      }
      setExportProgress(Math.round(((i + 1) / total) * 100));
    }

    const zipBlob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(zipBlob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "product-cards.zip";
    a.click();
    URL.revokeObjectURL(url);
    setExportProgress(0);
  };

  /* ── Update field toggle ── */
  const updateField = (key: string, value: boolean) => {
    setConfig(prev => ({ ...prev, fields: { ...prev.fields, [key]: value } }));
  };

  /* ── Apply template ── */
  const applyTemplate = (tmpl: typeof TEMPLATES[0]) => {
    setConfig(prev => ({
      ...prev,
      template: tmpl.key,
      category: tmpl.category,
      colors: {
        ...prev.colors,
        primary: tmpl.bg[0],
        text: tmpl.textColor,
        ...(tmpl.isFrame ? { frame: tmpl.textColor } : {}),
      },
    }));
  };

  /* ── Add/remove advantage ── */
  const addAdvantage = (text: string) => {
    if (!text.trim()) return;
    setConfig(prev => ({ ...prev, advantages: [...prev.advantages, text.trim()] }));
  };
  const removeAdvantage = (idx: number) => {
    setConfig(prev => ({ ...prev, advantages: prev.advantages.filter((_, i) => i !== idx) }));
  };

  /* ── Filtered products ── */
  const filteredProducts = products.filter(p => {
    if (showNoPhotoOnly && photoMap[p.id]) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (p.name || "").toLowerCase().includes(q) ||
             (p.article || "").toLowerCase().includes(q) ||
             (p.kccc || "").toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)] bg-gray-50">
        {/* ===== HEADER ===== */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Карточки товаров</h1>
              <p className="text-sm text-gray-500 mt-0.5">Загрузите Excel с товарами и ZIP с фото → сопоставление по артикулу → генерация карточек</p>
            </div>
            <div className="flex gap-2">
              {products.length > 0 && (
                <>
                  <Button onClick={() => setShowExportFieldSettings(!showExportFieldSettings)} variant="outline" className="gap-1.5 text-xs">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
                    Поля выгрузки
                  </Button>
                  <Button onClick={exportAll} variant="outline" className="gap-2">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    Выгрузить все ({products.length})
                  </Button>
                </>
              )}
            </div>
          </div>
          {/* Export field settings panel */}
          {showExportFieldSettings && products.length > 0 && (
            <div className="mt-3 p-3 bg-white rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-gray-500 uppercase">Поля на карточке при выгрузке</span>
                <button onClick={() => setShowExportFieldSettings(false)} className="text-xs text-gray-400 hover:text-gray-600">✕</button>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
                {[
                  { key: "logo", label: "Логотип" },
                  { key: "dealer", label: "Дилер" },
                  { key: "name", label: "Название товара" },
                  { key: "article", label: "Артикул" },
                  { key: "characteristics", label: "СТО/Характеристики" },
                  { key: "volume", label: "Объём" },
                  { key: "volumeBadge", label: "Бейдж объёма" },
                  { key: "kcccCode", label: "КССС код" },
                  { key: "advantages", label: "Преимущества" },
                  { key: "barcode", label: "Штрихкод" },
                  { key: "ean13", label: "EAN-13" },
                  { key: "qrCode", label: "QR код" },
                  { key: "saeBadge", label: "SAE бейдж" },
                  { key: "apiAceaBadge", label: "API/ACEA бейдж" },
                  { key: "ilsacLogo", label: "ILSAC лого" },
                ].map((f) => (
                  <label key={f.key} className="flex items-center gap-1.5 text-xs cursor-pointer hover:bg-gray-50 px-2 py-1 rounded">
                    <input
                      type="checkbox"
                      checked={!!(config.fields as any)[f.key]}
                      onChange={() => updateField(f.key, !(config.fields as any)[f.key])}
                      className="rounded accent-[#0d9488]"
                    />
                    <span className={(config.fields as any)[f.key] ? "text-gray-800" : "text-gray-400"}>{f.label}</span>
                  </label>
                ))}
              </div>
              <div className="mt-2 pt-2 border-t border-gray-100 text-xs text-gray-400">
                Выберите поля, которые будут отображаться на карточках при выгрузке
              </div>
            </div>
          )}

          {exportProgress > 0 && (
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                <span>Генерация карточек...</span>
                <span>{exportProgress}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-[#0d9488] rounded-full transition-all" style={{ width: `${exportProgress}%` }} />
              </div>
            </div>
          )}
        </div>

        {/* ===== UPLOAD ZONE ===== */}
        <div className="px-6 py-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {/* Excel Upload */}
            <div
              onDragOver={e => { e.preventDefault(); setDragOverZone("excel"); }}
              onDragLeave={() => setDragOverZone(null)}
              onDrop={e => { e.preventDefault(); setDragOverZone(null); const f = e.dataTransfer.files[0]; if (f) handleExcel(f); }}
              onClick={() => excelInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                dragOverZone === "excel" ? "border-[#0d9488] bg-[#f0fdfa]" : "border-gray-300 hover:border-gray-400 bg-white"
              }`}
            >
              <input ref={excelInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleExcel(f); e.target.value = ""; }} />
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="1.5" className="mx-auto mb-2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
              <div className="text-sm font-medium text-gray-700">Загрузить Excel с товарами</div>
              <div className="text-xs text-gray-400 mt-1">.xlsx, .xls, .csv</div>
              {products.length > 0 && <div className="text-xs text-[#0d9488] mt-1 font-medium">{products.length} товаров загружено</div>}
            </div>

            {/* ZIP Upload */}
            <div
              onDragOver={e => { e.preventDefault(); setDragOverZone("zip"); }}
              onDragLeave={() => setDragOverZone(null)}
              onDrop={e => { e.preventDefault(); setDragOverZone(null); const f = e.dataTransfer.files[0]; if (f) handleZip(f); }}
              onClick={() => zipInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                dragOverZone === "zip" ? "border-[#0d9488] bg-[#f0fdfa]" : "border-gray-300 hover:border-gray-400 bg-white"
              }`}
            >
              <input ref={zipInputRef} type="file" accept=".zip" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleZip(f); e.target.value = ""; }} />
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="1.5" className="mx-auto mb-2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              <div className="text-sm font-medium text-gray-700">Загрузить ZIP с фото</div>
              <div className="text-xs text-gray-400 mt-1">Имена файлов должны содержать артикул</div>
              {matchedCount > 0 && <div className="text-xs text-[#0d9488] mt-1 font-medium">{matchedCount} фото сопоставлено</div>}
            </div>
          </div>

          {/* Processing indicator */}
          {isProcessing && (
            <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
              <div className="w-4 h-4 border-2 border-gray-300 border-t-[#0d9488] rounded-full animate-spin" />
              Обработка...
            </div>
          )}
        </div>

        {/* ===== MAIN: Product list + Preview + Settings ===== */}
        {products.length > 0 && (
          <div className="px-6 pb-6">
            <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr_380px] gap-4" style={{ minHeight: "600px" }}>

              {/* ── LEFT: Product List ── */}
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden flex flex-col" style={{ maxHeight: "700px" }}>
                <div className="p-3 border-b border-gray-100">
                  <div className="flex items-center gap-2 mb-2">
                    <input
                      type="text"
                      placeholder="Поиск по названию, артикулу, КССС..."
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      className="flex-1 px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0d9488]"
                    />
                    <button
                      onClick={() => setShowColumnSettings(!showColumnSettings)}
                      className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg hover:bg-gray-50 text-gray-600"
                      title="Настройка колонок"
                    >
                      ⚙
                    </button>
                  </div>
                  {/* Column settings panel */}
                  {showColumnSettings && (
                    <div className="mb-2 p-2 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="text-[10px] font-semibold text-gray-500 uppercase mb-1">Отображаемые поля</div>
                      <div className="flex flex-wrap gap-1.5">
                        {FIELD_OPTIONS.map((f) => (
                          <label key={f.key} className="flex items-center gap-1 text-[11px] cursor-pointer hover:bg-white px-1.5 py-0.5 rounded">
                            <input
                              type="checkbox"
                              checked={visibleFields.includes(f.key)}
                              onChange={() => toggleVisibleField(f.key)}
                              className="rounded accent-[#0d9488]"
                            />
                            <span className={visibleFields.includes(f.key) ? "text-gray-800" : "text-gray-400"}>{f.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <label className="flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer">
                      <input type="checkbox" checked={showNoPhotoOnly} onChange={e => setShowNoPhotoOnly(e.target.checked)} className="rounded" />
                      Без фото
                    </label>
                    <span className="text-xs text-gray-400 ml-auto">
                      {Object.keys(photoMap).length}/{products.length} с фото
                    </span>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto">
                  {filteredProducts.map((p, i) => {
                    const globalIdx = products.findIndex(pr => pr.id === p.id);
                    const hasPhoto = !!photoMap[p.id];
                    return (
                      <div
                        key={p.id}
                        onClick={() => setCurrentIndex(globalIdx)}
                        className={`flex items-center gap-3 px-3 py-2.5 border-b border-gray-50 cursor-pointer transition-colors ${
                          globalIdx === currentIndex ? "bg-blue-50 border-l-4 border-l-[#0d9488]" : "hover:bg-gray-50 border-l-4 border-l-transparent"
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                          hasPhoto ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-400"
                        }`}>
                          {hasPhoto ? "✓" : (i + 1)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-gray-800 truncate">
                            {visibleFields.includes("name") && p.name ? p.name : visibleFields.includes("article") && p.article ? p.article : visibleFields.includes("kccc") && p.kccc ? p.kccc : p.name || "—"}
                          </div>
                          <div className="text-xs text-gray-400 font-mono truncate">
                            {visibleFields
                              .filter((f) => f !== "name" && (p as any)[f])
                              .map((f) => (p as any)[f])
                              .join(" | ")}
                          </div>
                        </div>
                        {!hasPhoto && (
                          <button
                            onClick={e => { e.stopPropagation(); setActiveTab(globalIdx); singlePhotoInputRef.current?.click(); }}
                            className="text-xs text-[#0d9488] hover:underline flex-shrink-0"
                          >
                            + фото
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
                <input
                  ref={singlePhotoInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={e => { const f = e.target.files?.[0]; if (f) handleSinglePhoto(products[activeTab]?.id || currentProduct?.id || 0, f); e.target.value = ""; }}
                />
              </div>

              {/* ── CENTER: Preview ── */}
              <div className="bg-white rounded-xl border border-gray-200 p-4 flex flex-col items-center">
                <div className="flex items-center justify-between w-full mb-3">
                  <span className="text-sm font-semibold text-gray-700">Предпросмотр</span>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))} disabled={currentIndex === 0}>←</Button>
                    <span className="text-sm text-gray-600">{currentIndex + 1} / {products.length}</span>
                    <Button size="sm" variant="outline" onClick={() => setCurrentIndex(Math.min(products.length - 1, currentIndex + 1))} disabled={currentIndex >= products.length - 1}>→</Button>
                  </div>
                </div>

                {/* Canvas */}
                <div className="bg-gray-100 rounded-xl p-3 flex items-center justify-center flex-1 w-full">
                  <canvas
                    ref={canvasRef}
                    style={{
                      maxWidth: "100%",
                      maxHeight: "520px",
                      boxShadow: "0 8px 30px rgba(0,0,0,0.15)",
                      borderRadius: config.borderRadius,
                    }}
                  />
                </div>

                {/* Current product info */}
                {currentProduct && (
                  <div className="w-full mt-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-800">{currentProduct.name}</span>
                      {currentPhoto && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">✓ фото</span>}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Арт: {currentProduct.article || currentProduct.kccc} | {currentProduct.viscosity} | {currentProduct.volume}
                    </div>
                  </div>
                )}

                <Button onClick={exportSingle} className="mt-3 w-full gap-2" disabled={!currentProduct}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  Скачать PNG
                </Button>
              </div>

              {/* ── RIGHT: Settings ── */}
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden flex flex-col" style={{ maxHeight: "700px" }}>
                <div className="p-3 border-b border-gray-100">
                  <h3 className="text-sm font-bold text-gray-800">Настройки карточки</h3>
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  <SettingsPanel
                    config={config}
                    setConfig={setConfig}
                    updateField={updateField}
                    applyTemplate={applyTemplate}
                    addAdvantage={addAdvantage}
                    removeAdvantage={removeAdvantage}
                    onBgUpload={handleBgImage}
                    bgInputRef={bgInputRef}
                    onLogoUpload={handleLogoImage}
                    logoInputRef={logoInputRef}
                  />
                </div>
              </div>

            </div>
          </div>
        )}

        {/* Empty state */}
        {products.length === 0 && !isProcessing && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mb-4"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            <p className="text-lg font-medium">Загрузите Excel с товарами</p>
            <p className="text-sm mt-1">Начните с загрузки файла с данными о товарах</p>
          </div>
        )}
      </div>
    </Layout>
  );
}

/* ═══ Settings Panel ═══ */
function SettingsPanel({
  config, setConfig, updateField, applyTemplate, addAdvantage, removeAdvantage, onBgUpload, bgInputRef, onLogoUpload, logoInputRef,
}: {
  config: CardConfig; setConfig: (c: CardConfig | ((p: CardConfig) => CardConfig)) => void;
  updateField: (k: string, v: boolean) => void; applyTemplate: (t: typeof TEMPLATES[0]) => void;
  addAdvantage: (t: string) => void; removeAdvantage: (i: number) => void;
  onBgUpload: (f: File) => void; bgInputRef: React.RefObject<HTMLInputElement | null>;
  onLogoUpload: (f: File) => void; logoInputRef: React.RefObject<HTMLInputElement | null>;
}) {
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    template: true, size: true, fields: false, colors: false, text: false, pos: false,
  });
  const toggle = (key: string) => setOpenSections(p => ({ ...p, [key]: !p[key] }));

  return (
    <div className="space-y-1">
      {/* Template */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button onClick={() => toggle("template")} className="w-full flex items-center justify-between p-2.5 text-left hover:bg-gray-50">
          <span className="text-sm font-semibold text-gray-700">Шаблон</span>
          <span className="text-xs text-gray-400">{openSections.template ? "▲" : "▼"}</span>
        </button>
        {openSections.template && (
          <div className="px-2.5 pb-2.5">
            <div className="flex flex-wrap gap-1 mb-2">
              {TEMPLATE_CATEGORIES.map(cat => (
                <button key={cat.key} onClick={() => setConfig(p => ({ ...p, category: cat.key }))}
                  className={`px-2.5 py-1 rounded-full text-xs font-medium ${config.category === cat.key ? "bg-[#0d9488] text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}>
                  {cat.name}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {TEMPLATES.filter(t => t.category === config.category).map(tmpl => {
                const isFrame = tmpl.isFrame;
                const frameColor = isFrame ? (config.colors.frame || tmpl.textColor) : null;
                return (
                  <button key={tmpl.key} onClick={() => applyTemplate(tmpl)}
                    className={`p-1.5 rounded-lg border-2 text-center ${config.template === tmpl.key ? "border-[#0d9488]" : "border-gray-200"}`}>
                    <div className="h-8 rounded mb-1 relative overflow-hidden"
                      style={isFrame && frameColor ? {
                        background: '#FFFFFF',
                        boxShadow: `inset 0 0 0 3px ${frameColor}`,
                      } : { background: tmpl.bg.length > 1 ? `linear-gradient(135deg,${tmpl.bg[0]},${tmpl.bg[1]})` : tmpl.bg[0] }}
                    />
                    <span className="text-[10px] text-gray-600">{tmpl.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Size */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button onClick={() => toggle("size")} className="w-full flex items-center justify-between p-2.5 text-left hover:bg-gray-50">
          <span className="text-sm font-semibold text-gray-700">Размер</span>
          <span className="text-xs text-gray-400">{openSections.size ? "▲" : "▼"}</span>
        </button>
        {openSections.size && (
          <div className="px-2.5 pb-2.5 space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div><label className="text-xs text-gray-500">Ширина</label><input type="number" value={config.width} onChange={e => setConfig(p => ({ ...p, width: Number(e.target.value) }))} className="w-full px-2 py-1 text-sm border rounded" /></div>
              <div><label className="text-xs text-gray-500">Высота</label><input type="number" value={config.height} onChange={e => setConfig(p => ({ ...p, height: Number(e.target.value) }))} className="w-full px-2 py-1 text-sm border rounded" /></div>
            </div>
            <div><label className="text-xs text-gray-500">Скругление {config.borderRadius}px</label><input type="range" min={0} max={50} value={config.borderRadius} onChange={e => setConfig(p => ({ ...p, borderRadius: Number(e.target.value) }))} className="w-full accent-[#0d9488]" /></div>
          </div>
        )}
      </div>

      {/* Colors */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button onClick={() => toggle("colors")} className="w-full flex items-center justify-between p-2.5 text-left hover:bg-gray-50">
          <span className="text-sm font-semibold text-gray-700">Цвета и фото</span>
          <span className="text-xs text-gray-400">{openSections.colors ? "▲" : "▼"}</span>
        </button>
        {openSections.colors && (
          <div className="px-2.5 pb-2.5 space-y-2">
            <div className="flex flex-wrap gap-1 mb-1">
              {SEASON_BACKGROUNDS.map(s => (
                <button key={s.key} onClick={() => setConfig(p => ({ ...p, seasonBg: s.key }))}
                  className={`px-2 py-0.5 rounded-full text-xs ${config.seasonBg === s.key ? "bg-[#0d9488] text-white" : "bg-gray-100 text-gray-600"}`}>{s.name}</button>
              ))}
            </div>
            {/* Photo scale slider */}
            <div>
              <label className="text-xs text-gray-600">Масштаб фото: {config.photoScale}%</label>
              <input type="range" min={10} max={100} value={config.photoScale} onChange={e => setConfig(p => ({ ...p, photoScale: Number(e.target.value) }))} className="w-full accent-[#0d9488]" />
              <div className="flex justify-between text-[10px] text-gray-400">
                <span>Маленькое</span>
                <span>Полная карточка</span>
              </div>
            </div>
            {[['Основной','primary'],['Текст','text'],['Объём','volume'],['Акцент','accent'],['Рамка','frame']].map(([label,key]) => (
              <div key={key} className="flex items-center gap-2">
                <span className="text-xs text-gray-600 w-16">{label}</span>
                <input type="color" value={config.colors[key as keyof typeof config.colors] || '#FFD700'} onChange={e => setConfig(p => ({ ...p, colors: { ...p.colors, [key]: e.target.value } }))} className="w-8 h-7 p-0 border rounded cursor-pointer" />
                <span className="text-[10px] font-mono text-gray-400">{config.colors[key as keyof typeof config.colors] || '—'}</span>
              </div>
            ))}
            {/* Logo upload */}
            <div onClick={() => logoInputRef.current?.click()} className="border border-dashed border-gray-300 rounded-lg p-2 text-center cursor-pointer hover:border-gray-400">
              <span className="text-xs text-gray-500">{config.logoImage ? "✓ Логотип загружен" : "+ Загрузить логотип"}</span>
              <input ref={logoInputRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onLogoUpload(f); e.target.value=""; }} />
            </div>
            <div onClick={() => bgInputRef.current?.click()} className="border border-dashed border-gray-300 rounded-lg p-2 text-center cursor-pointer hover:border-gray-400">
              <span className="text-xs text-gray-500">{config.backgroundImage ? "✓ Фон загружен" : "+ Фоновое изображение"}</span>
              <input ref={bgInputRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onBgUpload(f); e.target.value=""; }} />
            </div>
          </div>
        )}
      </div>

      {/* Fields */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button onClick={() => toggle("fields")} className="w-full flex items-center justify-between p-2.5 text-left hover:bg-gray-50">
          <span className="text-sm font-semibold text-gray-700">Поля</span>
          <span className="text-xs text-gray-400">{openSections.fields ? "▲" : "▼"}</span>
        </button>
        {openSections.fields && (
          <div className="px-2.5 pb-2.5">
            <div className="text-[10px] font-semibold text-gray-400 uppercase mb-1">Базовые</div>
            <div className="grid grid-cols-2 gap-x-2">
              {["characteristics","name","logo","barcode","volume","article","dealer","advantages"].map(k => (
                <label key={k} className="flex items-center gap-1.5 py-1 cursor-pointer">
                  <input type="checkbox" checked={config.fields[k as keyof typeof config.fields] as boolean} onChange={e => updateField(k, e.target.checked)} className="rounded accent-[#0d9488]" />
                  <span className="text-xs text-gray-700">{FIELD_LABELS[k] || k}</span>
                </label>
              ))}
            </div>
            <div className="mt-2"><input type="text" value={config.dealerText} onChange={e => setConfig(p => ({ ...p, dealerText: e.target.value }))} placeholder="Текст дилера" className="w-full px-2 py-1 text-xs border rounded" /></div>
            <div className="text-[10px] font-semibold text-gray-400 uppercase mt-2 mb-1">Дополнительные</div>
            <div className="grid grid-cols-2 gap-x-2">
              {["qrCode","saeBadge","apiAceaBadge","ilsacLogo","kcccCode","volumeBadge","dealerBadge","oemApproval","country","ean13"].map(k => (
                <label key={k} className="flex items-center gap-1.5 py-1 cursor-pointer">
                  <input type="checkbox" checked={config.fields[k as keyof typeof config.fields] as boolean} onChange={e => updateField(k, e.target.checked)} className="rounded accent-[#0d9488]" />
                  <span className="text-xs text-gray-700">{FIELD_LABELS[k] || k}</span>
                </label>
              ))}
            </div>
            <div className="mt-2"><input type="text" value={config.stoNumber} onChange={e => setConfig(p => ({ ...p, stoNumber: e.target.value }))} placeholder="СТО номер (пусто = авто)" className="w-full px-2 py-1 text-xs border rounded" /></div>
            <div className="mt-2">
              <div className="text-[10px] font-semibold text-gray-400 uppercase mb-1">Преимущества</div>
              {config.advantages.map((adv, i) => (
                <div key={i} className="flex items-center justify-between py-0.5">
                  <span className="text-xs text-gray-700 flex items-center gap-1"><span className="text-green-500">✓</span>{adv}</span>
                  <button onClick={() => removeAdvantage(i)} className="text-gray-400 hover:text-red-500 text-xs">✕</button>
                </div>
              ))}
              <AddAdvantageInput onAdd={addAdvantage} />
            </div>
          </div>
        )}
      </div>

      {/* Text sizes */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button onClick={() => toggle("text")} className="w-full flex items-center justify-between p-2.5 text-left hover:bg-gray-50">
          <span className="text-sm font-semibold text-gray-700">Размеры текста</span>
          <span className="text-xs text-gray-400">{openSections.text ? "▲" : "▼"}</span>
        </button>
        {openSections.text && (
          <div className="px-2.5 pb-2.5 space-y-1">
            {Object.entries(config.textSizes).map(([key, ts]) => (
              <div key={key} className="flex items-center gap-2">
                <span className="text-xs text-gray-600 w-20 truncate">{FIELD_LABELS[key] || key}</span>
                <button onClick={() => setConfig(p => ({ ...p, textSizes: { ...p.textSizes, [key]: { ...p.textSizes[key], size: Math.max(8, p.textSizes[key].size - 1) } } }))} className="w-6 h-6 rounded border text-xs">−</button>
                <span className="text-xs w-6 text-center">{ts.size}</span>
                <button onClick={() => setConfig(p => ({ ...p, textSizes: { ...p.textSizes, [key]: { ...p.textSizes[key], size: p.textSizes[key].size + 1 } } }))} className="w-6 h-6 rounded border text-xs">+</button>
                <select value={ts.font} onChange={e => setConfig(p => ({ ...p, textSizes: { ...p.textSizes, [key]: { ...p.textSizes[key], font: e.target.value } } }))} className="text-xs border rounded ml-auto">
                  {FONTS.map(f => <option key={f} value={f}>{f}</option>)}
                </select>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Positions */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button onClick={() => toggle("pos")} className="w-full flex items-center justify-between p-2.5 text-left hover:bg-gray-50">
          <span className="text-sm font-semibold text-gray-700">Позиции</span>
          <span className="text-xs text-gray-400">{openSections.pos ? "▲" : "▼"}</span>
        </button>
        {openSections.pos && (
          <div className="px-2.5 pb-2.5 space-y-0.5">
            {Object.entries(config.positions).map(([key, pos]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-xs text-gray-600 w-16 truncate">{FIELD_LABELS[key] || key}</span>
                <div className="flex items-center gap-0.5">
                  <button onClick={() => setConfig(p => ({ ...p, positions: { ...p.positions, [key]: { ...p.positions[key], y: p.positions[key].y - 1 } } }))} className="w-5 h-5 rounded border text-[10px]">↑</button>
                  <button onClick={() => setConfig(p => ({ ...p, positions: { ...p.positions, [key]: { ...p.positions[key], x: p.positions[key].x - 1 } } }))} className="w-5 h-5 rounded border text-[10px]">←</button>
                  <span className="text-[10px] font-mono w-12 text-center">X:{pos.x} Y:{pos.y}</span>
                  <button onClick={() => setConfig(p => ({ ...p, positions: { ...p.positions, [key]: { ...p.positions[key], x: p.positions[key].x + 1 } } }))} className="w-5 h-5 rounded border text-[10px]">→</button>
                  <button onClick={() => setConfig(p => ({ ...p, positions: { ...p.positions, [key]: { ...p.positions[key], y: p.positions[key].y + 1 } } }))} className="w-5 h-5 rounded border text-[10px]">↓</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Add Advantage Input ─── */
function AddAdvantageInput({ onAdd }: { onAdd: (t: string) => void }) {
  const [text, setText] = useState("");
  return (
    <div className="flex gap-1 mt-1">
      <input type="text" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => { if (e.key === "Enter") { onAdd(text); setText(""); } }}
        placeholder="Новое..." className="flex-1 px-2 py-1 text-xs border rounded" />
      <button onClick={() => { onAdd(text); setText(""); }} className="px-2 py-1 bg-[#0d9488] text-white rounded text-xs font-bold">+</button>
    </div>
  );
}

/* ─── Helpers ─── */
function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(blob);
  });
}
