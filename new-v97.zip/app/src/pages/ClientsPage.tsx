import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import type { Client, ClientOrder, ClientHistoryEntry } from "@/types/clients";
import {
  loadClients,
  saveClients,
  loadApiSettings,
  saveApiSettings,
  fetchDadataByInn,
  suggestionToClient,
  createMinimalClient,
  addClient,
  filterClients,
  addClientOrder,
  updateClientOrder,
  deleteClientOrder,
  updateClient,
  deleteClient,
  addHistoryEntry,
  bulkImportClients,
  migrateLocalToSupabase,
  type BulkImportResult,
} from "@/services/clientService";
import {
  Search,
  Plus,
  Building2,
  User,
  MapPin,
  Phone,
  Mail,
  Tag,
  Trash2,
  Edit3,
  History,
  Save,
  X,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Clock,
  ChevronDown,
  ChevronUp,
  Package,
  Filter,
  CircleDollarSign,
} from "lucide-react";

/* ═══ Status Helpers ═══ */
function statusLabel(s: string): string {
  switch (s) {
    case "ACTIVE": return "Действует";
    case "LIQUIDATING": return "Ликвидируется";
    case "LIQUIDATED": return "Ликвидирован";
    default: return "—";
  }
}
function statusColor(s: string): string {
  switch (s) {
    case "ACTIVE": return "bg-green-100 text-green-700";
    case "LIQUIDATING": return "bg-yellow-100 text-yellow-700";
    case "LIQUIDATED": return "bg-red-100 text-red-700";
    default: return "bg-gray-100 text-gray-600";
  }
}
function typeLabel(t: string): string {
  return t === "INDIVIDUAL" ? "ИП" : t === "LEGAL" ? "ООО/АО" : "—";
}

/* ═══ History Type Labels ═══ */
const HISTORY_TYPES: Record<string, { label: string; color: string }> = {
  create: { label: "Создание", color: "bg-blue-100 text-blue-700" },
  edit: { label: "Изменение", color: "bg-yellow-100 text-yellow-700" },
  call: { label: "Звонок", color: "bg-green-100 text-green-700" },
  meeting: { label: "Встреча", color: "bg-purple-100 text-purple-700" },
  order: { label: "Заказ", color: "bg-teal-100 text-teal-700" },
  note: { label: "Заметка", color: "bg-gray-100 text-gray-600" },
  status: { label: "Статус", color: "bg-orange-100 text-orange-700" },
};

/* ═══ Main Page ═══ */
export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [filterHasOrders, setFilterHasOrders] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [innQuery, setInnQuery] = useState("");
  const [dadataKey, setDadataKey] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importLog, setImportLog] = useState<string[]>([]);
  const [showImportLog, setShowImportLog] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load clients from Supabase on mount + migrate
  useEffect(() => {
    const init = async () => {
      await migrateLocalToSupabase();
      const loaded = await loadClients();
      setClients(loaded);
      // Load settings from cloud
      const settings = await loadApiSettings();
      setDadataKey(settings.dadataApiKey);
    };
    init();
  }, []);

  // Sync clients to Supabase on change
  useEffect(() => {
    if (clients.length > 0) saveClients(clients);
  }, [clients]);

  // Save settings to Supabase
  useEffect(() => {
    const timer = setTimeout(() => { if (dadataKey) saveApiSettings({ dadataApiKey: dadataKey }); }, 500);
    return () => clearTimeout(timer);
  }, [dadataKey]);

  const filtered = useMemo(() => {
    let result = [...clients];
    if (searchQuery.trim()) result = result.filter((c) =>
      c.inn.includes(searchQuery.toLowerCase()) ||
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.address?.toLowerCase().includes(searchQuery.toLowerCase())
    );
    if (filterStatus !== "all") result = result.filter((c) => c.status === filterStatus);
    if (filterType !== "all") result = result.filter((c) => c.type === filterType);
    if (filterHasOrders === "yes") result = result.filter((c) => (c.orders?.length || 0) > 0);
    if (filterHasOrders === "no") result = result.filter((c) => (c.orders?.length || 0) === 0);
    return result;
  }, [clients, searchQuery, filterStatus, filterType, filterHasOrders]);

  /* ── Search by INN via Dadata ── */
  const handleInnSearch = async () => {
    if (!innQuery.trim()) return;
    if (!dadataKey) { setError("Введите API-ключ Dadata в настройках"); return; }
    setIsLoading(true);
    setError("");
    try {
      const res = await fetchDadataByInn(innQuery.trim(), dadataKey);
      if (!res || !res.suggestions || res.suggestions.length === 0) {
        setError("Компания не найдена по ИНН");
        setIsLoading(false);
        return;
      }
      const client = suggestionToClient(res.suggestions[0]);
      // Merge with existing if any
      const existing = clients.find((c) => c.inn === client.inn);
      if (existing) {
        setSelectedClient(existing);
        setError("");
      } else {
        const updated = await addClient(client);
        setClients(updated);
        setSelectedClient(client);
        setInnQuery("");
        setShowAddForm(false);
      }
    } catch {
      setError("Ошибка запроса к Dadata");
    }
    setIsLoading(false);
  };

  /* ── Import from Excel/CSV/TXT ── */
  const handleExcelImport = async (file: File) => {
    setIsLoading(true);
    setImportProgress(0);
    setImportLog([]);
    setShowImportLog(false);
    setError("");

    const result = await bulkImportClients(file, dadataKey, setImportProgress);

    setImportLog(result.log);
    if (result.added > 0 || result.dadataMiss > 0) {
      const updated = await loadClients();
      setClients(updated);
      setShowImportLog(true);
      setError(`Импорт завершён: ${result.added} добавлено, ${result.existing} уже существовало${result.dadataMiss > 0 ? `, ${result.dadataMiss} без Dadata` : ""}`);
    } else if (result.existing > 0) {
      setError(`Все ${result.existing} клиентов уже в базе`);
    } else {
      setError("Не удалось импортировать. Проверьте формат файла.");
      setShowImportLog(true);
    }

    setIsLoading(false);
    setImportProgress(0);
  };

  /* ── Delete client ── */
  const handleDelete = async (inn: string) => {
    if (!confirm("Удалить клиента?")) return;
    const updated = await deleteClient(inn);
    setClients(updated);
    if (selectedClient?.inn === inn) setSelectedClient(null);
  };

  /* ── Add manual history entry ── */
  const handleAddHistory = useCallback(
    async (inn: string, entry: Omit<ClientHistoryEntry, "id">) => {
      const newEntry: ClientHistoryEntry = {
        ...entry,
        id: Date.now().toString() + Math.random().toString(36).slice(2),
      };
      const updated = await addHistoryEntry(inn, newEntry);
      setClients(updated);
      if (selectedClient?.inn === inn) {
        const freshClient = updated.find((c) => c.inn === inn) || null;
        setSelectedClient(freshClient);
      }
    },
    [selectedClient]
  );

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)] bg-gray-50">
        {/* ===== HEADER ===== */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Building2 className="h-6 w-6 text-[#0d9488]" />
                Клиенты
              </h1>
              <p className="text-sm text-gray-500 mt-0.5">
                {clients.length} клиентов в базе &middot; Проверка ИНН через Dadata &middot; История взаимодействий
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)} className="gap-1.5">
                <RefreshCw className="h-4 w-4" />
                Настройки API
              </Button>
              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} className="gap-1.5">
                <Upload className="h-4 w-4" />
                Импорт .xlsx / .txt
              </Button>
              <Button size="sm" onClick={() => { setShowAddForm(!showAddForm); setError(""); }} className="gap-1.5 bg-[#0d9488] hover:bg-[#0f766e]">
                <Plus className="h-4 w-4" />
                По ИНН
              </Button>
            </div>

            {/* Filters toggle */}
            <div className="flex items-center gap-2 mt-3">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg border ${showFilters ? "bg-[#f0fdfa] border-[#0d9488] text-[#0d9488]" : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"}`}
              >
                <Filter className="h-4 w-4" />
                Фильтры
                {(filterStatus !== "all" || filterType !== "all" || filterHasOrders !== "all") && (
                  <span className="w-2 h-2 rounded-full bg-[#0d9488]"></span>
                )}
              </button>
              {(filterStatus !== "all" || filterType !== "all" || filterHasOrders !== "all") && (
                <button
                  onClick={() => { setFilterStatus("all"); setFilterType("all"); setFilterHasOrders("all"); }}
                  className="text-xs text-gray-400 hover:text-gray-600"
                >
                  Сбросить
                </button>
              )}
            </div>
          </div>

          {/* Settings panel */}
          {showSettings && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <label className="text-sm font-medium text-gray-700">API-ключ Dadata</label>
              <div className="flex gap-2 mt-1">
                <input
                  type="password"
                  value={dadataKey}
                  onChange={(e) => setDadataKey(e.target.value)}
                  placeholder="Введите API-ключ Dadata..."
                  className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:border-[#0d9488]"
                />
                <Button size="sm" onClick={async () => { await saveApiSettings({ dadataApiKey: dadataKey }); setError("Ключ сохранён в облако"); }}>Сохранить</Button>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Получить ключ: <a href="https://dadata.ru/api/" target="_blank" rel="noopener noreferrer" className="text-[#0d9488] hover:underline">dadata.ru/api</a> &middot; Бесплатно 10 000 запросов/день
              </p>
            </div>
          )}

          {/* Filters panel */}
          {showFilters && (
            <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200 flex flex-wrap gap-3">
              <div>
                <label className="text-xs text-gray-500 block mb-1">Статус</label>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="text-sm border rounded px-2 py-1 bg-white">
                  <option value="all">Все</option>
                  <option value="ACTIVE">Действует</option>
                  <option value="LIQUIDATING">Ликвидируется</option>
                  <option value="LIQUIDATED">Ликвидирован</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 block mb-1">Тип</label>
                <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="text-sm border rounded px-2 py-1 bg-white">
                  <option value="all">Все</option>
                  <option value="LEGAL">ООО/АО</option>
                  <option value="INDIVIDUAL">ИП</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-500 block mb-1">Заказы</label>
                <select value={filterHasOrders} onChange={(e) => setFilterHasOrders(e.target.value)} className="text-sm border rounded px-2 py-1 bg-white">
                  <option value="all">Все</option>
                  <option value="yes">С заказами</option>
                  <option value="no">Без заказов</option>
                </select>
              </div>
            </div>
          )}

          {/* Error/Success messages */}
          {error && (
            <div className={`mt-3 flex items-center gap-2 text-sm px-3 py-2 rounded-lg ${error.includes("добавлено") || error.includes("Сохранён") || error.includes("найдена") ? "bg-green-50 text-green-700" : "bg-red-50 text-red-600"}`}>
              {error.includes("добавлено") || error.includes("Сохранён") ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
              {error}
            </div>
          )}

          {/* Import progress */}
          {importProgress > 0 && (
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                <span>Импорт клиентов...</span>
                <span>{importProgress}%</span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-[#0d9488] rounded-full transition-all" style={{ width: `${importProgress}%` }} />
              </div>
            </div>
          )}

          {/* Import log */}
          {showImportLog && importLog.length > 0 && (
            <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200 max-h-48 overflow-y-auto">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-medium text-gray-600">Лог импорта:</span>
                <button onClick={() => setShowImportLog(false)} className="text-xs text-gray-400 hover:text-gray-600">Скрыть</button>
              </div>
              {importLog.map((line, i) => (
                <div key={i} className={`text-xs ${line.startsWith("✓") ? "text-green-700" : line.startsWith("⚠") ? "text-amber-600" : line.startsWith("---") ? "text-gray-400" : "text-gray-500"}`}>
                  {line}
                </div>
              ))}
            </div>
          )}

          {/* INN Search form */}
          {showAddForm && (
            <div className="mt-4 p-4 bg-[#f0fdfa] rounded-lg border border-[#99f6e4]">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={innQuery}
                  onChange={(e) => setInnQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleInnSearch()}
                  placeholder="Введите ИНН (10 или 12 цифр)..."
                  className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:border-[#0d9488]"
                />
                <Button onClick={handleInnSearch} disabled={isLoading} className="bg-[#0d9488] hover:bg-[#0f766e] gap-1.5">
                  {isLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                  Найти в Dadata
                </Button>
              </div>
              <p className="text-xs text-gray-400 mt-1">При нахождении компании она автоматически добавится в базу</p>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv,.txt"
            className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) handleExcelImport(f); e.target.value = ""; }}
          />
        </div>

        {/* ===== MAIN: List + Detail ===== */}
        <div className="px-6 py-4">
          <div className="grid grid-cols-1 lg:grid-cols-[380px_1fr] gap-4" style={{ minHeight: "600px" }}>

            {/* ── LEFT: Client List ── */}
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden flex flex-col" style={{ maxHeight: "750px" }}>
              <div className="p-3 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Search className="h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Поиск по ИНН, названию, адресу..."
                    className="flex-1 text-sm outline-none"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery("")} className="text-gray-400 hover:text-gray-600">
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                {filtered.length === 0 ? (
                  <div className="p-8 text-center text-gray-400">
                    <Building2 className="h-10 w-10 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">{searchQuery ? "Ничего не найдено" : "База клиентов пуста"}</p>
                    <p className="text-xs mt-1">ИНН вручную, импорт .xlsx (колонка «ИНН») или .txt (один ИНН на строку)</p>
                  </div>
                ) : (
                  filtered.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => setSelectedClient(c)}
                      className={`px-4 py-3 border-b border-gray-50 cursor-pointer transition-colors ${
                        selectedClient?.inn === c.inn ? "bg-[#f0fdfa] border-l-4 border-l-[#0d9488]" : "hover:bg-gray-50 border-l-4 border-l-transparent"
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-gray-800 truncate">{c.name || "—"}</div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs font-mono text-gray-500">ИНН {c.inn}</span>
                            {c.type && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-600">{typeLabel(c.type)}</span>
                            )}
                          </div>
                          {c.address && (
                            <div className="flex items-center gap-1 mt-0.5 text-xs text-gray-400 truncate">
                              <MapPin className="h-3 w-3" />
                              {c.address}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-1 ml-2">
                          {c.status && (
                            <span className={`text-[10px] px-2 py-0.5 rounded-full whitespace-nowrap ${statusColor(c.status)}`}>
                              {statusLabel(c.status)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* ── RIGHT: Client Detail ── */}
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden flex flex-col" style={{ maxHeight: "750px" }}>
              {selectedClient ? (
                <ClientDetail
                  client={selectedClient}
                  onUpdate={async (updates) => {
                    const updated = await updateClient(selectedClient.inn, updates);
                    setClients(updated);
                    const fresh = updated.find((c) => c.inn === selectedClient.inn) || null;
                    setSelectedClient(fresh);
                  }}
                  onDelete={() => handleDelete(selectedClient.inn)}
                  onAddHistory={(entry) => handleAddHistory(selectedClient.inn, entry)}
                  onUpdateClient={(c) => {
                    setClients((prev) => prev.map((x) => x.inn === c.inn ? c : x));
                    setSelectedClient(c);
                  }}
                  dadataKey={dadataKey}
                />
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-gray-400 p-8">
                  <Building2 className="h-16 w-16 mb-3 opacity-20" />
                  <p className="text-lg font-medium">Выберите клиента</p>
                  <p className="text-sm mt-1">Или добавьте нового по ИНН</p>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>
    </Layout>
  );
}

/* ═══ Client Detail Panel ═══ */
function ClientDetail({
  client,
  onUpdate,
  onDelete,
  onAddHistory,
  onUpdateClient,
  dadataKey,
}: {
  client: Client;
  onUpdate: (u: Partial<Client>) => void;
  onDelete: () => void;
  onAddHistory: (e: Omit<ClientHistoryEntry, "id">) => Promise<void>;
  onUpdateClient?: (c: Client) => void;
  dadataKey: string;
}) {
  const [editMode, setEditMode] = useState(false);
  const [editForm, setEditForm] = useState<Partial<Client>>({});
  const [activeTab, setActiveTab] = useState<"info" | "orders" | "history">("info");
  const [historyForm, setHistoryForm] = useState({ type: "note" as ClientHistoryEntry["type"], description: "" });
  const [showHistoryForm, setShowHistoryForm] = useState(false);
  const [tagInput, setTagInput] = useState("");
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    setEditMode(false);
    setActiveTab("info");
  }, [client.inn]);

  const startEdit = () => {
    setEditForm({
      name: client.name,
      fullName: client.fullName,
      phone: client.phone,
      email: client.email,
      note: client.note,
      kpp: client.kpp,
      ogrn: client.ogrn,
      address: client.address,
      management: client.management,
      okved: client.okved,
    });
    setEditMode(true);
  };

  const saveEdit = () => {
    onUpdate(editForm);
    setEditMode(false);
  };

  const addTag = () => {
    if (!tagInput.trim()) return;
    const newTags = [...(client.tags || []), tagInput.trim()];
    onUpdate({ tags: newTags });
    setTagInput("");
  };

  const removeTag = (idx: number) => {
    const newTags = (client.tags || []).filter((_, i) => i !== idx);
    onUpdate({ tags: newTags });
  };

  const refreshFromDadata = async () => {
    if (!dadataKey) return;
    setIsRefreshing(true);
    try {
      const res = await fetchDadataByInn(client.inn, dadataKey);
      if (res?.suggestions?.[0]) {
        const fresh = suggestionToClient(res.suggestions[0]);
        // Preserve user-edited fields
        onUpdate({
          name: fresh.name,
          fullName: fresh.fullName,
          type: fresh.type,
          status: fresh.status,
          address: fresh.address,
          management: fresh.management,
          managementPost: fresh.managementPost,
          kpp: fresh.kpp,
          ogrn: fresh.ogrn,
          okved: fresh.okved,
        });
      }
    } catch { /* ignore */ }
    setIsRefreshing(false);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-100">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              {client.type === "INDIVIDUAL" ? (
                <User className="h-5 w-5 text-[#0d9488]" />
              ) : (
                <Building2 className="h-5 w-5 text-[#0d9488]" />
              )}
              <h2 className="text-lg font-bold text-gray-900 truncate">{client.name || "—"}</h2>
            </div>
            <p className="text-xs text-gray-500 mt-0.5 truncate">{client.fullName}</p>
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              {client.status && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(client.status)}`}>
                  {statusLabel(client.status)}
                </span>
              )}
              {client.type && (
                <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">
                  {typeLabel(client.type)}
                </span>
              )}
              <span className="text-xs font-mono text-gray-400">ИНН: {client.inn}</span>
              {client.kpp && <span className="text-xs font-mono text-gray-400">КПП: {client.kpp}</span>}
            </div>
          </div>
          <div className="flex items-center gap-1 ml-2">
            <Button size="sm" variant="ghost" onClick={refreshFromDadata} disabled={isRefreshing || !dadataKey} title="Обновить из Dadata">
              <RefreshCw className={`h-4 w-4 text-gray-500 ${isRefreshing ? "animate-spin" : ""}`} />
            </Button>
            {!editMode ? (
              <Button size="sm" variant="ghost" onClick={startEdit}>
                <Edit3 className="h-4 w-4 text-gray-500" />
              </Button>
            ) : (
              <Button size="sm" variant="ghost" onClick={saveEdit}>
                <Save className="h-4 w-4 text-green-600" />
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={onDelete}>
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        </div>

        {/* Tags */}
        <div className="flex items-center gap-1 mt-2 flex-wrap">
          {(client.tags || []).map((tag, i) => (
            <span key={i} className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-[#f0fdfa] text-[#0d9488] border border-[#99f6e4]">
              <Tag className="h-3 w-3" />
              {tag}
              <button onClick={() => removeTag(i)} className="hover:text-red-500">×</button>
            </span>
          ))}
          <div className="flex items-center">
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addTag()}
              placeholder="+ тег"
              className="w-20 text-xs px-1.5 py-0.5 border border-gray-200 rounded focus:outline-none focus:border-[#0d9488]"
            />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100">
        <button
          onClick={() => setActiveTab("info")}
          className={`flex-1 py-2.5 text-sm font-medium text-center ${activeTab === "info" ? "text-[#0d9488] border-b-2 border-[#0d9488]" : "text-gray-500 hover:text-gray-700"}`}
        >
          Информация
        </button>
        <button
          onClick={() => setActiveTab("orders")}
          className={`flex-1 py-2.5 text-sm font-medium text-center flex items-center justify-center gap-1.5 ${activeTab === "orders" ? "text-[#0d9488] border-b-2 border-[#0d9488]" : "text-gray-500 hover:text-gray-700"}`}
        >
          <Package className="h-4 w-4" />
          Заказы ({client.orders?.length || 0})
        </button>
        <button
          onClick={() => setActiveTab("history")}
          className={`flex-1 py-2.5 text-sm font-medium text-center flex items-center justify-center gap-1.5 ${activeTab === "history" ? "text-[#0d9488] border-b-2 border-[#0d9488]" : "text-gray-500 hover:text-gray-700"}`}
        >
          <History className="h-4 w-4" />
          История ({client.history.length})
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === "orders" ? (
          <ClientOrdersTab client={client} onUpdateClient={(c: Client) => {
            onUpdateClient?.(c);
          }} />
        ) : activeTab === "info" ? (
          <div className="space-y-3">
            {/* Main Info */}
            {editMode ? (
              <div className="space-y-2">
                <div><label className="text-xs text-gray-500">Название</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.name || ""} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} /></div>
                <div><label className="text-xs text-gray-500">Полное название</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.fullName || ""} onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="text-xs text-gray-500">Телефон</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.phone || ""} onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })} /></div>
                  <div><label className="text-xs text-gray-500">Email</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.email || ""} onChange={(e) => setEditForm({ ...editForm, email: e.target.value })} /></div>
                </div>
                <div><label className="text-xs text-gray-500">Адрес</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.address || ""} onChange={(e) => setEditForm({ ...editForm, address: e.target.value })} /></div>
                <div><label className="text-xs text-gray-500">Руководитель</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.management || ""} onChange={(e) => setEditForm({ ...editForm, management: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><label className="text-xs text-gray-500">ОГРН</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.ogrn || ""} onChange={(e) => setEditForm({ ...editForm, ogrn: e.target.value })} /></div>
                  <div><label className="text-xs text-gray-500">КПП</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.kpp || ""} onChange={(e) => setEditForm({ ...editForm, kpp: e.target.value })} /></div>
                </div>
                <div><label className="text-xs text-gray-500">ОКВЭД</label><input className="w-full px-2 py-1.5 text-sm border rounded" value={editForm.okved || ""} onChange={(e) => setEditForm({ ...editForm, okved: e.target.value })} /></div>
                <div><label className="text-xs text-gray-500">Заметки</label><textarea className="w-full px-2 py-1.5 text-sm border rounded" rows={3} value={editForm.note || ""} onChange={(e) => setEditForm({ ...editForm, note: e.target.value })} /></div>
              </div>
            ) : (
              <div className="space-y-2.5">
                <InfoRow icon={<Phone className="h-4 w-4" />} label="Телефон" value={client.phone} />
                <InfoRow icon={<Mail className="h-4 w-4" />} label="Email" value={client.email} />
                <InfoRow icon={<MapPin className="h-4 w-4" />} label="Адрес" value={client.address} />
                <InfoRow icon={<User className="h-4 w-4" />} label="Руководитель" value={client.management ? `${client.management}${client.managementPost ? ` (${client.managementPost})` : ""}` : ""} />
                <InfoRow icon={<Building2 className="h-4 w-4" />} label="ОГРН" value={client.ogrn} />
                <InfoRow icon={<Building2 className="h-4 w-4" />} label="КПП" value={client.kpp} />
                <InfoRow icon={<Tag className="h-4 w-4" />} label="ОКВЭД" value={client.okved} />
                {client.note && (
                  <div className="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-100">
                    <div className="text-xs font-medium text-yellow-700 mb-1">Заметки</div>
                    <div className="text-sm text-gray-700 whitespace-pre-wrap">{client.note}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {/* Add history button */}
            <button
              onClick={() => setShowHistoryForm(!showHistoryForm)}
              className="w-full py-2 border border-dashed border-gray-300 rounded-lg text-sm text-gray-500 hover:border-[#0d9488] hover:text-[#0d9488] transition-colors"
            >
              {showHistoryForm ? "— Отменить" : "+ Добавить запись"}
            </button>

            {showHistoryForm && (
              <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 space-y-2">
                <select
                  value={historyForm.type}
                  onChange={(e) => setHistoryForm({ ...historyForm, type: e.target.value as ClientHistoryEntry["type"] })}
                  className="w-full px-2 py-1.5 text-sm border rounded"
                >
                  {Object.entries(HISTORY_TYPES).map(([key, { label }]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
                <textarea
                  value={historyForm.description}
                  onChange={(e) => setHistoryForm({ ...historyForm, description: e.target.value })}
                  placeholder="Описание..."
                  rows={2}
                  className="w-full px-2 py-1.5 text-sm border rounded"
                />
                <Button
                  size="sm"
                  className="w-full bg-[#0d9488] hover:bg-[#0f766e]"
                  onClick={() => {
                    if (!historyForm.description.trim()) return;
                    onAddHistory({ type: historyForm.type, description: historyForm.description.trim(), date: new Date().toISOString() });
                    setHistoryForm({ type: "note", description: "" });
                    setShowHistoryForm(false);
                  }}
                >
                  Добавить
                </Button>
              </div>
            )}

            {/* History list */}
            {[...client.history].reverse().map((h) => {
              const ht = HISTORY_TYPES[h.type] || { label: h.type, color: "bg-gray-100 text-gray-600" };
              return (
                <div key={h.id} className="flex gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-shrink-0 mt-0.5">
                    <Clock className="h-4 w-4 text-gray-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${ht.color}`}>{ht.label}</span>
                      <span className="text-[10px] text-gray-400">{new Date(h.date).toLocaleDateString("ru-RU")}</span>
                    </div>
                    <p className="text-sm text-gray-700">{h.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══ Client Orders Tab ═══ */
function ClientOrdersTab({ client, onUpdateClient }: { client: Client; onUpdateClient: (c: Client) => void }) {
  const [showForm, setShowForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<ClientOrder | null>(null);
  const [form, setForm] = useState<Partial<ClientOrder>>({ status: "new", amount: 0, products: "" });

  const orderStatusColors: Record<string, string> = {
    new: "bg-blue-100 text-blue-700",
    processing: "bg-yellow-100 text-yellow-700",
    shipped: "bg-purple-100 text-purple-700",
    delivered: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    paid: "bg-teal-100 text-teal-700",
  };
  const orderStatusLabels: Record<string, string> = {
    new: "Новый", processing: "В обработке", shipped: "Отгружен",
    delivered: "Доставлен", cancelled: "Отменён", paid: "Оплачен",
  };

  const startAdd = () => { setEditingOrder(null); setForm({ status: "new", amount: 0, products: "", notes: "" }); setShowForm(true); };
  const startEdit = (o: ClientOrder) => { setEditingOrder(o); setForm({ ...o }); setShowForm(true); };

  const saveOrder = async () => {
    if (!form.products?.trim()) return;
    const order: ClientOrder = {
      id: editingOrder?.id || Date.now().toString() + Math.random().toString(36).slice(2),
      number: editingOrder?.number || `З-${String((client.orders?.length || 0) + 1).padStart(3, "0")}`,
      date: form.date || editingOrder?.date || new Date().toISOString().split("T")[0],
      amount: Number(form.amount) || 0,
      status: (form.status as ClientOrder["status"]) || "new",
      products: form.products || "",
      notes: form.notes || "",
      createdAt: editingOrder?.createdAt || new Date().toISOString(),
    };
    let updatedClients: Client[];
    if (editingOrder) {
      updatedClients = await updateClientOrder(client.inn, editingOrder.id, order);
    } else {
      updatedClients = await addClientOrder(client.inn, order);
    }
    const updatedClient = updatedClients.find((c) => c.inn === client.inn)!;
    onUpdateClient(updatedClient);
    setShowForm(false);
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!confirm("Удалить заказ?")) return;
    const updatedClients = await deleteClientOrder(client.inn, orderId);
    const updatedClient = updatedClients.find((c) => c.inn === client.inn)!;
    onUpdateClient(updatedClient);
  };

  return (
    <div className="space-y-3">
      <button onClick={startAdd} className="w-full py-2 border border-dashed border-gray-300 rounded-lg text-sm text-gray-500 hover:border-[#0d9488] hover:text-[#0d9488] transition-colors">
        + Добавить заказ
      </button>

      {showForm && (
        <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-500">Номер</label>
              <input className="w-full px-2 py-1.5 text-sm border rounded" value={editingOrder?.number || `З-${String((client.orders?.length || 0) + 1).padStart(3, "0")}`} disabled />
            </div>
            <div>
              <label className="text-xs text-gray-500">Статус</label>
              <select className="w-full px-2 py-1.5 text-sm border rounded" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as ClientOrder["status"] })}>
                {Object.entries(orderStatusLabels).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500">Дата</label>
            <input type="date" className="w-full px-2 py-1.5 text-sm border rounded" value={form.date || new Date().toISOString().split("T")[0]} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          </div>
          <div>
            <label className="text-xs text-gray-500">Товары / Услуги</label>
            <textarea className="w-full px-2 py-1.5 text-sm border rounded" rows={2} value={form.products || ""} onChange={(e) => setForm({ ...form, products: e.target.value })} placeholder="Что заказано..." />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-500">Сумма (₽)</label>
              <input type="number" className="w-full px-2 py-1.5 text-sm border rounded" value={form.amount || 0} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} />
            </div>
            <div>
              <label className="text-xs text-gray-500">Примечание</label>
              <input className="w-full px-2 py-1.5 text-sm border rounded" value={form.notes || ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Комментарий..." />
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" className="flex-1 bg-[#0d9488] hover:bg-[#0f766e]" onClick={saveOrder}>
              {editingOrder ? "Сохранить" : "Добавить"}
            </Button>
            <Button size="sm" variant="outline" onClick={() => setShowForm(false)}>Отмена</Button>
          </div>
        </div>
      )}

      {/* Orders list */}
      {(client.orders?.length || 0) === 0 ? (
        <div className="text-center py-6 text-gray-400">
          <Package className="h-8 w-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm">Нет заказов</p>
        </div>
      ) : (
        [...(client.orders || [])].reverse().map((order) => (
          <div key={order.id} className="p-3 bg-gray-50 rounded-lg border border-gray-100">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-gray-500">{order.number}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${orderStatusColors[order.status] || "bg-gray-100 text-gray-600"}`}>
                  {orderStatusLabels[order.status] || order.status}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => startEdit(order)} className="p-1 text-gray-400 hover:text-gray-600"><Edit3 className="h-3.5 w-3.5" /></button>
                <button onClick={() => handleDeleteOrder(order.id)} className="p-1 text-gray-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
            <p className="text-sm text-gray-700">{order.products}</p>
            <div className="flex items-center justify-between mt-1.5">
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <span>{order.date ? new Date(order.date).toLocaleDateString("ru-RU") : "—"}</span>
                {order.notes && <span>• {order.notes}</span>}
              </div>
              {order.amount > 0 && (
                <span className="text-sm font-medium text-gray-800 flex items-center gap-1">
                  <CircleDollarSign className="h-3.5 w-3.5 text-[#0d9488]" />
                  {order.amount.toLocaleString("ru-RU")} ₽
                </span>
              )}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

/* ═══ Info Row ═══ */
function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value?: string }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-2.5">
      <div className="text-gray-400 mt-0.5">{icon}</div>
      <div>
        <div className="text-[10px] text-gray-400 uppercase">{label}</div>
        <div className="text-sm text-gray-800">{value}</div>
      </div>
    </div>
  );
}
