export interface YandexMetricaConfig {
  oauthToken: string;
  counterId: string;
  clientId?: string;
}

export interface MetricOption {
  key: string;
  label: string;
  prefix: "ym:s:" | "ym:pv:";
  category: string;
}

export interface DimensionOption {
  key: string;
  label: string;
  prefix: "ym:s:" | "ym:pv:";
  category: string;
}

export interface MetricPreset {
  name: string;
  metrics: string[];
  dimensions: string[];
  description: string;
}

export interface MetricQuery {
  id: string;
  counterId: string;
  metrics: string[];
  dimensions: string[];
  date1: string;
  date2: string;
  filters?: string;
  limit?: number;
  sort?: string;
}

export interface MetricResponse {
  query: {
    ids: number[];
    metrics: string[];
    dimensions: string[];
    sort?: string[];
    date1?: string;
    date2?: string;
    filters?: string;
    limit?: number;
    offset?: number;
  };
  data: MetricDataRow[];
  totals?: number[];
  min?: number[];
  max?: number[];
  contains_sensitive_data?: boolean;
  sample_share?: number;
  sample_size?: number;
  sample_space?: number;
  errors?: Array<{ code: string; message: string }>;
}

export interface MetricDataRow {
  dimensions: Array<{ name: string }>;
  metrics: number[];
}

export const METRICS_VISITS: MetricOption[] = [
  { key: "ym:s:visits", label: "Визиты", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:users", label: "Посетители", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:pageviews", label: "Просмотры", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:bounceRate", label: "Отказы (%)", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:pageDepth", label: "Глубина просмотра", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:avgVisitDurationSeconds", label: "Среднее время визита (сек)", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:newUsers", label: "Новые посетители", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:percentNewVisitors", label: "Доля новых (%)", prefix: "ym:s:", category: "Основные" },
  { key: "ym:s:goalReachesAny", label: "Достижения целей", prefix: "ym:s:", category: "Цели" },
  { key: "ym:s:goalConversionAny", label: "Конверсия в цели (%)", prefix: "ym:s:", category: "Цели" },
  { key: "ym:s:sumGoalRevenueAny", label: "Доход от целей", prefix: "ym:s:", category: "Цели" },
  { key: "ym:s:ecommercePurchases", label: "Покупки (e-com)", prefix: "ym:s:", category: "E-commerce" },
  { key: "ym:s:ecommerceRevenue", label: "Выручка (e-com)", prefix: "ym:s:", category: "E-commerce" },
  { key: "ym:s:ecommerceConversionRate", label: "Конверсия покупок (%)", prefix: "ym:s:", category: "E-commerce" },
];

export const METRICS_HITS: MetricOption[] = [
  { key: "ym:pv:pageviews", label: "Просмотры страниц", prefix: "ym:pv:", category: "Основные" },
  { key: "ym:pv:users", label: "Посетители (хиты)", prefix: "ym:pv:", category: "Основные" },
  { key: "ym:pv:hourlyVisitors", label: "Посетители по часам", prefix: "ym:pv:", category: "Основные" },
];

export const DIMENSIONS_VISITS: DimensionOption[] = [
  { key: "ym:s:date", label: "Дата", prefix: "ym:s:", category: "Время" },
  { key: "ym:s:week", label: "Неделя", prefix: "ym:s:", category: "Время" },
  { key: "ym:s:month", label: "Месяц", prefix: "ym:s:", category: "Время" },
  { key: "ym:s:hour", label: "Час", prefix: "ym:s:", category: "Время" },
  { key: "ym:s:hourMinute", label: "Час:минута", prefix: "ym:s:", category: "Время" },
  { key: "ym:s:dayOfWeek", label: "День недели", prefix: "ym:s:", category: "Время" },
  { key: "ym:s:trafficSourceName", label: "Источник трафика", prefix: "ym:s:", category: "Источники" },
  { key: "ym:s:trafficSource", label: "Тип источника", prefix: "ym:s:", category: "Источники" },
  { key: "ym:s:searchEngineName", label: "Поисковая система", prefix: "ym:s:", category: "Источники" },
  { key: "ym:s:searchPhrase", label: "Поисковая фраза", prefix: "ym:s:", category: "Источники" },
  { key: "ym:s:advEngine", label: "Рекламная система", prefix: "ym:s:", category: "Источники" },
  { key: "ym:s:refererDomain", label: "Домен реферера", prefix: "ym:s:", category: "Источники" },
  { key: "ym:s:browserName", label: "Браузер", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:browserVersion", label: "Версия браузера", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:operatingSystem", label: "Операционная система", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:operatingSystemVersion", label: "Версия ОС", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:deviceCategory", label: "Тип устройства", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:screenResolution", label: "Разрешение экрана", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:screenOrientation", label: "Ориентация экрана", prefix: "ym:s:", category: "Технологии" },
  { key: "ym:s:regionCountry", label: "Страна", prefix: "ym:s:", category: "География" },
  { key: "ym:s:regionArea", label: "Регион", prefix: "ym:s:", category: "География" },
  { key: "ym:s:regionCity", label: "Город", prefix: "ym:s:", category: "География" },
  { key: "ym:s:startURL", label: "Страница входа", prefix: "ym:s:", category: "Содержание" },
  { key: "ym:s:pagePathLevel1", label: "Раздел сайта (ур.1)", prefix: "ym:s:", category: "Содержание" },
  { key: "ym:s:pageTitle", label: "Заголовок страницы", prefix: "ym:s:", category: "Содержание" },
  { key: "ym:s:exitURL", label: "Страница выхода", prefix: "ym:s:", category: "Содержание" },
  { key: "ym:s:age", label: "Возраст", prefix: "ym:s:", category: "Посетители" },
  { key: "ym:s:sex", label: "Пол", prefix: "ym:s:", category: "Посетители" },
  { key: "ym:s:interest", label: "Интерес", prefix: "ym:s:", category: "Посетители" },
  { key: "ym:s:clientID", label: "Client ID", prefix: "ym:s:", category: "Посетители" },
];

export const DIMENSIONS_HITS: DimensionOption[] = [
  { key: "ym:pv:date", label: "Дата", prefix: "ym:pv:", category: "Время" },
  { key: "ym:pv:hour", label: "Час", prefix: "ym:pv:", category: "Время" },
  { key: "ym:pv:URL", label: "URL страницы", prefix: "ym:pv:", category: "Содержание" },
  { key: "ym:pv:browserName", label: "Браузер", prefix: "ym:pv:", category: "Технологии" },
  { key: "ym:pv:operatingSystem", label: "Операционная система", prefix: "ym:pv:", category: "Технологии" },
  { key: "ym:pv:deviceCategory", label: "Тип устройства", prefix: "ym:pv:", category: "Технологии" },
  { key: "ym:pv:regionCountry", label: "Страна", prefix: "ym:pv:", category: "География" },
  { key: "ym:pv:regionCity", label: "Город", prefix: "ym:pv:", category: "География" },
];

export const PRESETS: MetricPreset[] = [
  {
    name: "Общая сводка",
    metrics: ["ym:s:visits", "ym:s:users", "ym:s:pageviews", "ym:s:bounceRate", "ym:s:pageDepth", "ym:s:avgVisitDurationSeconds"],
    dimensions: ["ym:s:date"],
    description: "Основные показатели по дням",
  },
  {
    name: "Источники трафика",
    metrics: ["ym:s:visits", "ym:s:users", "ym:s:bounceRate"],
    dimensions: ["ym:s:trafficSourceName"],
    description: "Визиты по источникам",
  },
  {
    name: "Поисковые системы",
    metrics: ["ym:s:visits", "ym:s:users"],
    dimensions: ["ym:s:searchEngineName"],
    description: "Трафик из поисковых систем",
  },
  {
    name: "Устройства",
    metrics: ["ym:s:visits", "ym:s:users", "ym:s:bounceRate"],
    dimensions: ["ym:s:deviceCategory"],
    description: "Распределение по устройствам",
  },
  {
    name: "География (страны)",
    metrics: ["ym:s:visits", "ym:s:users"],
    dimensions: ["ym:s:regionCountry"],
    description: "Посетители по странам",
  },
  {
    name: "Браузеры",
    metrics: ["ym:s:visits", "ym:s:users"],
    dimensions: ["ym:s:browserName"],
    description: "Распределение по браузерам",
  },
  {
    name: "Популярные страницы",
    metrics: ["ym:pv:pageviews", "ym:pv:users"],
    dimensions: ["ym:pv:URL"],
    description: "Топ страниц по просмотрам",
  },
  {
    name: "По часам",
    metrics: ["ym:s:visits", "ym:s:users"],
    dimensions: ["ym:s:hour"],
    description: "Распределение по часам",
  },
];

export const ALL_METRICS = [...METRICS_VISITS, ...METRICS_HITS];
export const ALL_DIMENSIONS = [...DIMENSIONS_VISITS, ...DIMENSIONS_HITS];
