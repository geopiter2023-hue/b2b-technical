export interface ClientOrder {
  id: string;
  number: string;
  date: string;
  amount: number;
  status: "new" | "processing" | "shipped" | "delivered" | "cancelled" | "paid";
  products: string;
  notes?: string;
  createdAt: string;
}

export interface Client {
  id: string;
  inn: string;
  kpp?: string;
  ogrn?: string;
  name: string;
  fullName: string;
  type: "LEGAL" | "INDIVIDUAL" | "";
  status: "ACTIVE" | "LIQUIDATING" | "LIQUIDATED" | "";
  address?: string;
  management?: string;
  managementPost?: string;
  okved?: string;
  phone?: string;
  email?: string;
  note?: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
  history: ClientHistoryEntry[];
  orders: ClientOrder[];
}

export interface ClientHistoryEntry {
  id: string;
  type: "create" | "edit" | "call" | "meeting" | "order" | "note" | "status";
  description: string;
  date: string;
  author?: string;
}

export interface DadataSuggestion {
  value: string;
  unrestricted_value: string;
  data: {
    inn: string;
    kpp: string;
    ogrn: string;
    type: string;
    state: { status: string };
    name: {
      full_with_opf: string;
      short_with_opf: string;
    };
    address: { value: string };
    management?: { name: string; post: string };
    okved?: string;
  };
}

export interface DadataResponse {
  suggestions: DadataSuggestion[];
}
