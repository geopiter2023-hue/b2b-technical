import type { YandexMetricaConfig, MetricQuery, MetricResponse } from "@/types/metrics";

const STORAGE_KEY = "yandex_metrics_config";
const API_BASE = "https://api-metrika.yandex.net/stat/v1/data";

export function saveMetricConfig(config: YandexMetricaConfig) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

export function loadMetricConfig(): YandexMetricaConfig | null {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

/* Fix ym:pv: dimensions → ym:s: equivalents (API doesn't support ym:pv: groupings) */
function fixDimensions(dims: string[]): string[] {
  return dims.map((d) => {
    if (d === "ym:pv:pagePath") return "ym:s:pagePath";
    if (d === "ym:pv:URL") return "ym:s:URL";
    if (d === "ym:pv:date") return "ym:s:date";
    if (d === "ym:pv:hour") return "ym:s:hour";
    if (d === "ym:pv:browserName") return "ym:s:browserName";
    if (d === "ym:pv:operatingSystem") return "ym:s:operatingSystem";
    if (d === "ym:pv:deviceCategory") return "ym:s:deviceCategory";
    if (d === "ym:pv:regionCountry") return "ym:s:regionCountry";
    if (d === "ym:pv:regionCity") return "ym:s:regionCity";
    return d;
  });
}

export async function fetchMetricData(
  query: MetricQuery,
  config: YandexMetricaConfig
): Promise<MetricResponse> {
  const params = new URLSearchParams();
  params.append("id", query.counterId || config.counterId);
  params.append("metrics", query.metrics.join(","));
  const fixedDims = fixDimensions(query.dimensions);
  if (fixedDims.length > 0) {
    params.append("dimensions", fixedDims.join(","));
  }
  params.append("date1", query.date1);
  params.append("date2", query.date2);
  if (query.filters) params.append("filters", query.filters);
  if (query.limit) params.append("limit", String(query.limit));
  if (query.sort) params.append("sort", query.sort);

  const url = `${API_BASE}?${params.toString()}`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `OAuth ${config.oauthToken}`,
      "Accept": "application/json",
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API Error ${response.status}: ${errorText}`);
  }

  return response.json();
}

export async function fetchMetricDataCSV(
  query: MetricQuery,
  config: YandexMetricaConfig
): Promise<string> {
  const params = new URLSearchParams();
  params.append("id", query.counterId || config.counterId);
  params.append("metrics", query.metrics.join(","));
  const fixedDims = fixDimensions(query.dimensions);
  if (fixedDims.length > 0) {
    params.append("dimensions", fixedDims.join(","));
  }
  params.append("date1", query.date1);
  params.append("date2", query.date2);
  if (query.filters) params.append("filters", query.filters);
  if (query.limit) params.append("limit", String(query.limit));
  if (query.sort) params.append("sort", query.sort);

  const url = `${API_BASE}.csv?${params.toString()}`;

  const response = await fetch(url, {
    headers: {
      "Authorization": `OAuth ${config.oauthToken}`,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API Error ${response.status}: ${errorText}`);
  }

  return response.text();
}

export function formatMetricValue(value: number, metricKey: string): string {
  if (metricKey.includes("bounceRate") || metricKey.includes("Conversion")) {
    return `${value.toFixed(2)}%`;
  }
  if (metricKey.includes("avgVisitDurationSeconds")) {
    const m = Math.floor(value / 60);
    const s = Math.floor(value % 60);
    return `${m}м ${s}с`;
  }
  if (metricKey.includes("Duration")) {
    return `${value.toFixed(0)}с`;
  }
  if (metricKey.includes("Revenue") || metricKey.includes("revenue")) {
    return `${value.toLocaleString("ru-RU")} ₽`;
  }
  if (value >= 1000000) {
    return `${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}K`;
  }
  return value.toLocaleString("ru-RU");
}

export function getMetricLabel(key: string): string {
  const map: Record<string, string> = {
    "ym:s:visits": "Визиты",
    "ym:s:users": "Посетители",
    "ym:s:pageviews": "Просмотры",
    "ym:s:bounceRate": "Отказы",
    "ym:s:pageDepth": "Глубина",
    "ym:s:avgVisitDurationSeconds": "Среднее время",
    "ym:s:newUsers": "Новые",
    "ym:s:percentNewVisitors": "Доля новых",
    "ym:s:goalReachesAny": "Достижения целей",
    "ym:s:goalConversionAny": "Конверсия",
    "ym:s:sumGoalRevenueAny": "Доход",
    "ym:s:ecommercePurchases": "Покупки",
    "ym:s:ecommerceRevenue": "Выручка",
    "ym:s:ecommerceConversionRate": "Конверсия покупок",
    "ym:pv:pageviews": "Просмотры (хиты)",
    "ym:pv:users": "Посетители (хиты)",
    "ym:pv:hourlyVisitors": "По часам",
  };
  return map[key] || key;
}

export function getDimensionLabel(key: string): string {
  const map: Record<string, string> = {
    "ym:s:date": "Дата",
    "ym:s:week": "Неделя",
    "ym:s:month": "Месяц",
    "ym:s:hour": "Час",
    "ym:s:hourMinute": "Час:минута",
    "ym:s:dayOfWeek": "День недели",
    "ym:s:trafficSourceName": "Источник",
    "ym:s:trafficSource": "Тип источника",
    "ym:s:searchEngineName": "Поисковая система",
    "ym:s:searchPhrase": "Поисковая фраза",
    "ym:s:advEngine": "Рекламная система",
    "ym:s:refererDomain": "Домен реферера",
    "ym:s:browserName": "Браузер",
    "ym:s:browserVersion": "Версия браузера",
    "ym:s:operatingSystem": "ОС",
    "ym:s:operatingSystemVersion": "Версия ОС",
    "ym:s:deviceCategory": "Устройство",
    "ym:s:screenResolution": "Разрешение",
    "ym:s:screenOrientation": "Ориентация",
    "ym:s:regionCountry": "Страна",
    "ym:s:regionArea": "Регион",
    "ym:s:regionCity": "Город",
    "ym:s:pagePath": "Путь страницы",
    "ym:s:pagePathLevel1": "Раздел",
    "ym:s:pageTitle": "Заголовок",
    "ym:s:URL": "URL",
    "ym:s:age": "Возраст",
    "ym:s:sex": "Пол",
    "ym:s:interest": "Интерес",
    "ym:s:clientID": "Client ID",
    "ym:pv:date": "Дата",
    "ym:pv:hour": "Час",
    "ym:pv:pagePath": "Путь страницы",
    "ym:pv:URL": "URL",
    "ym:pv:browserName": "Браузер",
    "ym:pv:operatingSystem": "ОС",
    "ym:pv:deviceCategory": "Устройство",
    "ym:pv:regionCountry": "Страна",
    "ym:pv:regionCity": "Город",
  };
  return map[key] || key;
}
