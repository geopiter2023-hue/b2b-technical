const CACHE_NAME = "new-v90";
const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/favicon.ico",
  "/logo.png",
  "/pwa-icon.png",
  "/manifest.json",
  "/qr-code.png",
];

// Install: pre-cache static assets
self.addEventListener("install", (event) => {
  console.log("[SW] Installing new-v90...");
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
});

// Activate: delete old caches, claim clients immediately
self.addEventListener("activate", (event) => {
  console.log("[SW] Activating new-v90...");
  event.waitUntil(
    caches.keys().then((names) => {
      return Promise.all(
        names
          .filter((n) => n !== CACHE_NAME)
          .map((n) => {
            console.log("[SW] Deleting old cache:", n);
            return caches.delete(n);
          })
      );
    }).then(() => {
      return self.clients.claim();
    })
  );
  // Force reload all clients on activate
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clients) => {
      clients.forEach((client) => {
        client.postMessage({ type: "SW_ACTIVATED", version: CACHE_NAME });
      });
    })
  );
});

// Fetch: network-first strategy for dynamic content, cache-first for static
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Skip non-GET requests
  if (event.request.method !== "GET") return;

  // API calls — network only, no cache
  if (url.pathname.startsWith("/api/")) return;

  // Static assets (JS, CSS, images) — stale-while-revalidate
  if (
    url.pathname.match(/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot)$/) ||
    url.pathname === "/" ||
    url.pathname === "/index.html"
  ) {
    event.respondWith(
      caches.match(event.request).then((cached) => {
        const fetchPromise = fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              const clone = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => {
                cache.put(event.request, clone);
              });
            }
            return networkResponse;
          })
          .catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  // Everything else — network first, fallback to cache
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, clone);
          });
        }
        return response;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});

// Listen for messages from client (force update)
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});
