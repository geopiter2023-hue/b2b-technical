// ═══════════════════════════════════════════
// Stock Balance Service — per-warehouse columns
// ═══════════════════════════════════════════

import * as XLSX from "xlsx";

export interface StockItem {
  ksss: string;
  oldKsss: string;
  name: string;
  nameEng: string;
  category: string;
  subcategory: string;
  direction: string;
  brand: string;
  line: string;
  subLine: string;
  type: string;
  viscosity: string;
  api: string;
  acea: string;
  ilsac: string;
  volume: string;
  packaging: string;
  weight: number;
  status: string;
  priceType: string;
  rrc: number;
  // Stock balances per warehouse
  stockByWarehouse: Record<string, number>;
}

const STORAGE_KEY = "b2b_stock_data_v2";
const STORAGE_META_KEY = "b2b_stock_meta_v2";

// ═══ Persistence ═══

export function saveStockData(items: StockItem[]) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch {}
}

export function loadStockData(): StockItem[] {
  try { const d = localStorage.getItem(STORAGE_KEY); return d ? JSON.parse(d) : []; } catch { return []; }
}

export function saveStockMeta(meta: Record<string, string>) {
  try { localStorage.setItem(STORAGE_META_KEY, JSON.stringify(meta)); } catch {}
}

export function loadStockMeta(): Record<string, string> {
  try { const d = localStorage.getItem(STORAGE_META_KEY); return d ? JSON.parse(d) : {}; } catch { return {}; }
}

// ═══ Get all unique warehouse names from items ═══

export function getAllWarehouses(items: StockItem[]): string[] {
  const set = new Set<string>();
  for (const it of items) {
    for (const wh of Object.keys(it.stockByWarehouse)) {
      if (it.stockByWarehouse[wh] > 0) set.add(wh);
    }
  }
  return Array.from(set).sort();
}

// ═══ Get total per warehouse across all items ═══

export function getWarehouseTotals(items: StockItem[]): Record<string, number> {
  const totals: Record<string, number> = {};
  for (const it of items) {
    for (const [wh, qty] of Object.entries(it.stockByWarehouse)) {
      if (qty > 0) totals[wh] = (totals[wh] || 0) + qty;
    }
  }
  return totals;
}

// ═══ Parse Final (base catalog) ═══

export async function parseFinalFile(file: File): Promise<StockItem[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        const items: StockItem[] = [];
        for (let i = 2; i < rows.length; i++) {
          const r = rows[i];
          if (!r[0]) continue;
          const ksss = String(r[0] || "").trim();
          if (!ksss || ksss === "КССС") continue;

          // Parse RC stocks from columns 5-10
          const rcNames = [
            "РЦ Иркутск", "РЦ Калининград", "РЦ Краснодар",
            "РЦ Санкт-Петербург", "РЦ Солнечногорск", "РЦ Тюмень"
          ];
          const stockByWarehouse: Record<string, number> = {};
          for (let j = 0; j < 6; j++) {
            const val = parseFloat(r[5 + j]);
            if (val > 0) stockByWarehouse[rcNames[j]] = val;
          }

          items.push({
            ksss, oldKsss: String(r[2] || "").trim(),
            name: String(r[16] || "").trim(), nameEng: String(r[15] || "").trim(),
            category: String(r[3] || "").trim(), subcategory: String(r[13] || "").trim(),
            direction: String(r[12] || "").trim(), brand: String(r[35] || "").trim(),
            line: String(r[36] || "").trim(), subLine: String(r[37] || "").trim(),
            type: String(r[38] || "").trim(), viscosity: String(r[39] || "").trim(),
            api: String(r[40] || "").trim(), acea: String(r[41] || "").trim(),
            ilsac: String(r[42] || "").trim(), volume: String(r[29] || "").trim(),
            packaging: String(r[30] || "").trim(), weight: parseFloat(r[11]) || 0,
            status: String(r[1] || "").trim(), priceType: String(r[23] || "").trim(),
            rrc: parseFloat(r[25]) || 0, stockByWarehouse,
          });
        }
        resolve(items);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Parse ЛогЛаб — returns map of (KSSS+warehouse -> qty) ═══

export async function parseLoglabFile(file: File): Promise<Map<string, Record<string, number>>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        // Map: ksss -> { warehouse -> qty }
        const map = new Map<string, Record<string, number>>();
        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const ksss = String(r[2] || "").trim();
          const warehouseRaw = String(r[0] || "").trim(); // e.g. "РЦ Солнечногорск_2401_F005"
          const qty = parseFloat(r[8]); // Физ остатки
          if (!ksss || isNaN(qty) || qty <= 0) continue;

          // Clean warehouse name
          const warehouse = warehouseRaw.replace(/_\d{4}_F\d{3}/, "").trim();

          if (!map.has(ksss)) map.set(ksss, {});
          const whMap = map.get(ksss)!;
          whMap[warehouse] = (whMap[warehouse] || 0) + qty;
        }
        resolve(map);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Parse Дилеры — returns map of (KSSS/name -> { dealer -> qty }) ═══

export async function parseDealerFile(file: File): Promise<Map<string, Record<string, number>>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        const map = new Map<string, Record<string, number>>();
        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const dealer = String(r[0] || "").trim(); // Дистрибьютор
          const name = String(r[2] || "").trim();   // Краткое наименование
          const article = String(r[3] || "").trim(); // Артикул
          const qty = parseFloat(r[5]); // Количество
          if (!dealer || isNaN(qty) || qty <= 0) continue;

          // Key by name + article combo
          const key = article || name;
          if (!key) continue;

          if (!map.has(key)) map.set(key, {});
          const dMap = map.get(key)!;
          dMap[dealer] = (dMap[dealer] || 0) + qty;

          // Also index by name alone for matching
          if (name && name !== key) {
            if (!map.has(name)) map.set(name, {});
            const nMap = map.get(name)!;
            nMap[dealer] = (nMap[dealer] || 0) + qty;
          }
        }
        resolve(map);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Merge all sources ═══

export function mergeStockData(
  baseItems: StockItem[],
  loglabMap: Map<string, Record<string, number>>,
  dealerMap: Map<string, Record<string, number>>
): StockItem[] {
  return baseItems.map((item) => {
    const stockByWarehouse = { ...item.stockByWarehouse };

    // Merge ЛогЛаб
    const loglabWh = loglabMap.get(item.ksss);
    if (loglabWh) {
      for (const [wh, qty] of Object.entries(loglabWh)) {
        stockByWarehouse[wh] = (stockByWarehouse[wh] || 0) + qty;
      }
    }

    // Merge Дилеры — try KSSS, then name, then nameEng
    let dealerWh = dealerMap.get(item.ksss);
    if (!dealerWh) dealerWh = dealerMap.get(item.name);
    if (!dealerWh) dealerWh = dealerMap.get(item.nameEng);
    if (dealerWh) {
      for (const [wh, qty] of Object.entries(dealerWh)) {
        stockByWarehouse[wh] = (stockByWarehouse[wh] || 0) + qty;
      }
    }

    return { ...item, stockByWarehouse };
  });
}

// ═══ Search & Filter ═══

export function searchStock(items: StockItem[], query: string): StockItem[] {
  if (!query.trim()) return items;
  const q = query.toLowerCase();
  return items.filter((it) =>
    it.ksss.includes(q) ||
    it.name.toLowerCase().includes(q) ||
    it.nameEng.toLowerCase().includes(q) ||
    it.brand.toLowerCase().includes(q) ||
    it.line.toLowerCase().includes(q) ||
    it.viscosity.toLowerCase().includes(q)
  );
}

// ═══ Export to Excel with warehouse columns ═══

export function exportStockToExcel(items: StockItem[], warehouses: string[]): Uint8Array {
  const headers = [
    "КССС", "Статус", "Наименование", "Направление", "Категория",
    "Бренд", "Линейка", "Вид", "Вязкость", "API", "ACEA", "ILSAC",
    "Объем", "Вес", "РРЦ",
    ...warehouses,
    "ИТОГО"
  ];

  const rows = items.map((it) => {
    const whValues = warehouses.map((wh) => it.stockByWarehouse[wh] || 0);
    const total = whValues.reduce((s, v) => s + v, 0);
    return [
      it.ksss, it.status, it.name, it.direction, it.category,
      it.brand, it.line, it.type, it.viscosity, it.api, it.acea, it.ilsac,
      it.volume, it.weight, it.rrc,
      ...whValues,
      total
    ];
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  XLSX.utils.book_append_sheet(wb, ws, "Остатки");
  return XLSX.write(wb, { type: "array" });
}
