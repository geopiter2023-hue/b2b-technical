import { useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import type { ReactNode } from "react";
import {
  Car, Droplets, Settings, BookOpen, ChevronRight, ChevronDown,
  Plus, Trash2, Search, Save, X, Menu, LogOut, Gauge,
  Wrench, Cog, Snowflake, Fuel, Filter, Table,
  FileText, TreeDeciduous, Link2, Users, BarChart3, Code,
  Key, Globe, Copy, RefreshCw, Activity, TrendingUp, Eye,
  FileUp, FileDown, Bot, Play, Pause, RotateCw,
} from "lucide-react";

// ═══════════════════════════════════════════
//  TYPES
// ═══════════════════════════════════════════
type SidebarItem = {
  id: string;
  label: string;
  icon: React.ElementType;
  children?: { id: string; label: string; icon?: React.ElementType }[];
};

type ContentView =
  | "dashboard"
  | "cars-list" | "car-edit" | "car-create"
  | "liquids-list" | "liquid-edit"
  | "ref-vehicleTypes" | "ref-steering" | "ref-bodyTypes" | "ref-fuelTypes"
  | "ref-transmissionTypes" | "ref-viscosity" | "ref-categories" | "ref-trees"
  | "car-liquid-link"
  | "companies" | "products" | "assignments"
  | "widgets"
  | "import-export"
  | "ai-agents";

// ═══════════════════════════════════════════
//  SIDEBAR DATA
// ═══════════════════════════════════════════
const sidebarItems: SidebarItem[] = [
  { id: "dashboard", label: "Главная", icon: BarChart3 },
  {
    id: "liquids",
    label: "Жидкости",
    icon: Droplets,
    children: [
      { id: "liquids-list", label: "Список жидкостей", icon: Table },
    ],
  },
  {
    id: "cars",
    label: "Автомобили",
    icon: Car,
    children: [
      { id: "cars-list", label: "Список автомобилей", icon: Table },
      { id: "car-create", label: "Добавить автомобиль", icon: Plus },
    ],
  },
  {
    id: "ref",
    label: "Справочники",
    icon: BookOpen,
    children: [
      { id: "ref-categories", label: "Категории жидкостей", icon: Filter },
      { id: "ref-trees", label: "Дерево агрегатов", icon: TreeDeciduous },
      { id: "ref-vehicleTypes", label: "Типы транспортных средств", icon: Car },
      { id: "ref-steering", label: "Расположение руля", icon: Settings },
      { id: "ref-bodyTypes", label: "Типы кузовов", icon: Car },
      { id: "ref-fuelTypes", label: "Типы топлива", icon: Fuel },
      { id: "ref-transmissionTypes", label: "Типы коробок передач", icon: Cog },
      { id: "ref-viscosity", label: "Классы вязкости", icon: Droplets },
    ],
  },
  {
    id: "links",
    label: "Связь",
    icon: Link2,
    children: [
      { id: "car-liquid-link", label: "Автомобиль/Жидкость", icon: Link2 },
    ],
  },
  { id: "widgets", label: "Виджеты", icon: Code },
  { id: "companies", label: "Компании", icon: Users },
  {
    id: "data",
    label: "Данные",
    icon: FileUp,
    children: [
      { id: "import-export", label: "Импорт / Экспорт Excel", icon: FileUp },
    ],
  },
  { id: "ai-agents", label: "ИИ Агенты", icon: Bot },
];

// ═══════════════════════════════════════════
//  BREADCRUMB MAP
// ═══════════════════════════════════════════
const breadcrumbMap: Record<string, string> = {
  dashboard: "Главная",
  "cars-list": "Автомобили / Список",
  "car-edit": "Автомобили / Редактирование",
  "car-create": "Автомобили / Создание",
  "liquids-list": "Жидкости / Список",
  "liquid-edit": "Жидкости / Редактирование",
  "ref-vehicleTypes": "Справочники / Типы ТС",
  "ref-steering": "Справочники / Расположение руля",
  "ref-bodyTypes": "Справочники / Типы кузовов",
  "ref-fuelTypes": "Справочники / Типы топлива",
  "ref-transmissionTypes": "Справочники / Типы КПП",
  "ref-viscosity": "Справочники / Классы вязкости",
  "ref-categories": "Справочники / Категории жидкостей",
  "ref-trees": "Справочники / Дерево агрегатов",
  "car-liquid-link": "Связь / Автомобиль-Жидкость",
  companies: "Компании",
  products: "Продукты",
  assignments: "Привязки",
  widgets: "Виджеты",
  "import-export": "Импорт / Экспорт Excel",
  "ai-agents": "ИИ Агенты",
};

// ═══════════════════════════════════════════
//  GENERIC REFERENCE TABLE
// ═══════════════════════════════════════════
function RefTable({
  title,
  endpoint,
  createEndpoint,
  deleteEndpoint,
  columns,
}: {
  title: string;
  endpoint: any;
  createEndpoint: any;
  deleteEndpoint: any;
  columns: { key: string; label: string }[];
}) {
  const utils = trpc.useUtils();
  const { data: items, isLoading } = endpoint.useQuery();
  const create = createEndpoint.useMutation({
    onSuccess: () => {
      utils.invalidate();
      setNewName("");
    },
  });
  const remove = deleteEndpoint.useMutation({
    onSuccess: () => utils.invalidate(),
  });
  const [newName, setNewName] = useState("");

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">{title}</h2>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && newName.trim()) {
                create.mutate({ name: newName.trim() });
              }
            }}
            placeholder="Название..."
            className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={() => newName.trim() && create.mutate({ name: newName.trim() })}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors"
          >
            <Plus className="w-4 h-4" /> Создать
          </button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium uppercase w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium uppercase">ID</th>
                  {columns.map((c) => (
                    <th key={c.key} className="text-left p-3 text-gray-500 text-xs font-medium uppercase">{c.label}</th>
                  ))}
                  <th className="text-left p-3 text-gray-500 text-xs font-medium uppercase w-32">Статус</th>
                </tr>
              </thead>
              <tbody>
                {items?.map((item: any) => (
                  <tr key={item.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3">
                      <button
                        onClick={() => { if (confirm("Удалить?")) remove.mutate({ id: item.id }); }}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="p-3 font-mono text-xs text-gray-500">{item.id}</td>
                    {columns.map((c) => (
                      <td key={c.key} className="p-3 text-gray-700 text-sm">{item[c.key] || "—"}</td>
                    ))}
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${item.isActive === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {item.isActive === "active" ? "Активен" : "Неактивен"}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!items || items.length === 0) && (
                  <tr>
                    <td colSpan={columns.length + 3} className="p-8 text-center text-gray-400 text-sm">
                      Нет данных
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  CAR EDIT FORM
// ═══════════════════════════════════════════
function CarEditForm({
  carId,
  onBack,
}: {
  carId: string;
  onBack: () => void;
}) {
  const utils = trpc.useUtils();
  const { data } = trpc.cars.getById.useQuery({ id: carId });
  const update = trpc.cars.update.useMutation({
    onSuccess: () => {
      utils.cars.getById.invalidate({ id: carId });
      alert("Сохранено!");
    },
  });
  const { data: refData } = trpc.reference.all.useQuery();

  const [form, setForm] = useState<Record<string, any>>({});

  // Populate form when data loads
  const car = data?.car;
  if (car && Object.keys(form).length === 0) {
    setForm({ ...car });
  }

  const updateField = (field: string, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    const { id: _id, createdAt, updatedAt, ...updateData } = form;
    update.mutate({ id: carId, ...updateData });
  };

  if (!car) {
    return (
      <div className="flex justify-center py-12">
        <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div>
      {/* Toolbar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm">
            <ChevronRight className="w-4 h-4 rotate-180" /> Назад
          </button>
          <h2 className="text-gray-800 text-xl font-semibold">
            Редактирование {car.id.substring(0, 20)}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors"
          >
            <Save className="w-4 h-4" /> Сохранить
          </button>
          <button
            onClick={onBack}
            className="border border-gray-300 text-gray-600 px-4 py-2 rounded-md text-sm hover:bg-gray-50 transition-colors"
          >
            Отмена
          </button>
        </div>
      </div>

      {/* Form sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Общие данные */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide border-b border-gray-100 pb-2">
            Общие данные
          </h3>
          <div className="space-y-4">
            <FormRow label="Тип транспортного средства">
              <select
                value={form.vehicleTypeId || ""}
                onChange={(e) => updateField("vehicleTypeId", e.target.value ? Number(e.target.value) : null)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              >
                <option value="">Не указано</option>
                {refData?.vehicleTypes?.map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </FormRow>
            <FormRow label="Расположение руля">
              <select
                value={form.steeringPositionId || ""}
                onChange={(e) => updateField("steeringPositionId", e.target.value ? Number(e.target.value) : null)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              >
                <option value="">Не указано</option>
                {refData?.steeringPositions?.map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </FormRow>
            <FormRow label="Марка">
              <input
                type="text"
                value={form.make || ""}
                onChange={(e) => updateField("make", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Модель">
              <input
                type="text"
                value={form.model || ""}
                onChange={(e) => updateField("model", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Тип кузова">
              <select
                value={form.bodyTypeId || ""}
                onChange={(e) => updateField("bodyTypeId", e.target.value ? Number(e.target.value) : null)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              >
                <option value="">Не указано</option>
                {refData?.carBodyTypes?.map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </FormRow>
            <FormRow label="Модификация">
              <input
                type="text"
                value={form.modification || ""}
                onChange={(e) => updateField("modification", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <div className="grid grid-cols-2 gap-4">
              <FormRow label="Год с">
                <input
                  type="number"
                  value={form.yearFrom || ""}
                  onChange={(e) => updateField("yearFrom", e.target.value ? Number(e.target.value) : null)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
                />
              </FormRow>
              <FormRow label="Год по">
                <input
                  type="number"
                  value={form.yearTo || ""}
                  onChange={(e) => updateField("yearTo", e.target.value ? Number(e.target.value) : null)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
                />
              </FormRow>
            </div>
          </div>
        </div>

        {/* Двигатель */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide border-b border-gray-100 pb-2">
            Двигатель
          </h3>
          <div className="space-y-4">
            <FormRow label="Объём">
              <input
                type="text"
                value={form.engineCapacity || ""}
                onChange={(e) => updateField("engineCapacity", e.target.value)}
                placeholder="2.0"
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Тип топлива">
              <select
                value={form.fuelTypeId || ""}
                onChange={(e) => updateField("fuelTypeId", e.target.value ? Number(e.target.value) : null)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              >
                <option value="">Не указано</option>
                {refData?.fuelTypes?.map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </FormRow>
            <FormRow label="Код двигателя">
              <input
                type="text"
                value={form.engineCode || ""}
                onChange={(e) => updateField("engineCode", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Название двигателя">
              <input
                type="text"
                value={form.engineName || ""}
                onChange={(e) => updateField("engineName", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Мощность">
              <input
                type="text"
                value={form.horsePower || ""}
                onChange={(e) => updateField("horsePower", e.target.value)}
                placeholder="150 л.с."
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
          </div>
        </div>

        {/* Трансмиссия */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide border-b border-gray-100 pb-2">
            Трансмиссия
          </h3>
          <div className="space-y-4">
            <FormRow label="Тип КПП">
              <select
                value={form.transmissionTypeId || ""}
                onChange={(e) => updateField("transmissionTypeId", e.target.value ? Number(e.target.value) : null)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              >
                <option value="">Не указано</option>
                {refData?.transmissionTypes?.map((t: any) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </FormRow>
            <FormRow label="Количество передач">
              <input
                type="text"
                value={form.transmissionGears || ""}
                onChange={(e) => updateField("transmissionGears", e.target.value)}
                placeholder="6/1"
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Код КПП">
              <input
                type="text"
                value={form.transmissionCode || ""}
                onChange={(e) => updateField("transmissionCode", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Код раздаточной коробки">
              <input
                type="text"
                value={form.transferCaseCode || ""}
                onChange={(e) => updateField("transferCaseCode", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
          </div>
        </div>

        {/* Дифференциалы */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide border-b border-gray-100 pb-2">
            Дифференциалы
          </h3>
          <div className="space-y-4">
            <FormRow label="Код переднего дифференциала">
              <input
                type="text"
                value={form.frontDifferentialCode || ""}
                onChange={(e) => updateField("frontDifferentialCode", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Код заднего дифференциала">
              <input
                type="text"
                value={form.rearDifferentialCode || ""}
                onChange={(e) => updateField("rearDifferentialCode", e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
            <FormRow label="Тип хладагента">
              <input
                type="text"
                value={form.refrigerantType || ""}
                onChange={(e) => updateField("refrigerantType", e.target.value)}
                placeholder="R134a"
                className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
              />
            </FormRow>
          </div>
        </div>
      </div>

      {/* Assigned Liquids */}
      <div className="mt-6 bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide border-b border-gray-100 pb-2">
          Назначенные жидкости
        </h3>
        {data?.liquids && data.liquids.length > 0 ? (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Агрегат</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Жидкость</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Объём</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Интервал</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Основная</th>
                </tr>
              </thead>
              <tbody>
                {data.liquids.map((a: any) => (
                  <tr key={a.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3 text-gray-700 text-sm">{a.aggregationTreeName || "—"}</td>
                    <td className="p-3 text-gray-700 text-sm font-medium">{a.liquidName || a.liquidId}</td>
                    <td className="p-3 text-gray-600 text-sm">{a.fillVolume || "—"}</td>
                    <td className="p-3 text-gray-600 text-sm">{a.replaceInterval || "—"}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${a.isPrimary === "yes" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-gray-500"}`}>
                        {a.isPrimary === "yes" ? "Да" : "Нет"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-400 text-sm">Жидкости не назначены</p>
        )}
      </div>
    </div>
  );
}

function FormRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 items-center">
      <label className="text-gray-600 text-sm font-medium">{label}</label>
      <div className="sm:col-span-2">{children}</div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  CAR LIST
// ═══════════════════════════════════════════
function CarList({ onEdit }: { onEdit: (id: string) => void }) {
  const [filters, setFilters] = useState({ make: "", model: "", modification: "" });
  const { data, isLoading } = trpc.cars.list.useQuery({
    make: filters.make || undefined,
    model: filters.model || undefined,
    modification: filters.modification || undefined,
    limit: 50,
  });

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">Список автомобилей</h2>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4 flex-wrap">
          <input
            type="text"
            value={filters.make}
            onChange={(e) => setFilters((p) => ({ ...p, make: e.target.value }))}
            placeholder="Марка..."
            className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-40"
          />
          <input
            type="text"
            value={filters.model}
            onChange={(e) => setFilters((p) => ({ ...p, model: e.target.value }))}
            placeholder="Модель..."
            className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-40"
          />
          <input
            type="text"
            value={filters.modification}
            onChange={(e) => setFilters((p) => ({ ...p, modification: e.target.value }))}
            placeholder="Модификация..."
            className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-48"
          />
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Марка</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Модель</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Модификация</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-24">Годы</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Статус</th>
                </tr>
              </thead>
              <tbody>
                {data?.items?.map((car: any) => (
                  <tr key={car.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50 cursor-pointer" onClick={() => onEdit(car.id)}>
                    <td className="p-3">
                      <button
                        onClick={(e) => { e.stopPropagation(); onEdit(car.id); }}
                        className="text-blue-600 hover:text-blue-800 transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="p-3 text-gray-800 text-sm font-medium">{car.make}</td>
                    <td className="p-3 text-gray-700 text-sm">{car.model}</td>
                    <td className="p-3 text-gray-600 text-sm">{car.modification}</td>
                    <td className="p-3 text-gray-500 text-xs">{car.yearFrom}{car.yearTo ? ` — ${car.yearTo}` : " — н.в."}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${car.isActive === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {car.isActive === "active" ? "Активен" : "Неактивен"}
                      </span>
                    </td>
                  </tr>
                ))}
                {(!data?.items || data.items.length === 0) && (
                  <tr><td colSpan={6} className="p-8 text-center text-gray-400 text-sm">Нет данных</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  LIQUID LIST
// ═══════════════════════════════════════════
function LiquidList() {
  const [search, setSearch] = useState("");
  const { data, isLoading } = trpc.liquids.list.useQuery({
    search: search || undefined,
    limit: 50,
  });

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">Список жидкостей</h2>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1 transition-colors">
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Поиск по названию, артикулу, спецификации..."
              className="w-full border border-gray-300 rounded-md pl-9 pr-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">ID</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Название</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Приоритет</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Активность</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Объём</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-32">Создан</th>
                </tr>
              </thead>
              <tbody>
                {data?.items?.map((item: any) => (
                  <tr key={item.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3">
                      <button className="text-blue-600 hover:text-blue-800 transition-colors">
                        <Settings className="w-4 h-4" />
                      </button>
                    </td>
                    <td className="p-3 font-mono text-xs text-gray-500">{item.id.substring(0, 16)}...</td>
                    <td className="p-3 text-gray-800 text-sm">{item.name}</td>
                    <td className="p-3 text-gray-600 text-sm text-center">{item.priority}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${item.isActive === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {item.isActive === "active" ? "Активен" : "Неактивен"}
                      </span>
                    </td>
                    <td className="p-3 text-gray-600 text-sm">{item.volume || "—"}</td>
                    <td className="p-3 text-gray-500 text-xs">{item.createdAt ? new Date(item.createdAt).toLocaleDateString("ru-RU") : "—"}</td>
                  </tr>
                ))}
                {(!data?.items || data.items.length === 0) && (
                  <tr><td colSpan={7} className="p-8 text-center text-gray-400 text-sm">Нет данных</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  MAIN ADMIN PAGE
// ═══════════════════════════════════════════
export default function Admin() {
  const { user, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
    redirectPath: "/login",
  });
  const navigate = useNavigate();

  const [view, setView] = useState<ContentView>("dashboard");
  const [editCarId, setEditCarId] = useState<string | null>(null);
  const [expandedMenus, setExpandedMenus] = useState<Set<string>>(new Set(["cars", "liquids", "ref", "links"]));
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleMenu = (id: string) => {
    setExpandedMenus((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleNav = (id: string) => {
    if (id === "car-edit" && editCarId) {
      setView("car-edit");
    } else {
      setView(id as ContentView);
    }
    setEditCarId(null);
    setSidebarOpen(false);
  };

  // Breadcrumb
  const breadcrumb = breadcrumbMap[view] || view;

  if (authLoading) return null;
  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-500 text-lg mb-2">Доступ запрещён</p>
          <p className="text-gray-500 text-sm mb-4">Требуется роль администратора</p>
          <button onClick={() => navigate("/")} className="text-blue-600 hover:underline text-sm">На главную</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`w-64 bg-[#1e1e1e] flex-shrink-0 flex flex-col h-screen fixed left-0 top-0 overflow-y-auto z-50 transition-transform duration-300 ease-in-out ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}>
        {/* Logo */}
        <div className="p-4 border-b border-gray-700">
          <h1 className="text-white text-lg font-bold tracking-tight">oilpodbor</h1>
        </div>

        {/* Menu */}
        <nav className="flex-1 py-2">
          {sidebarItems.map((item) => (
            <div key={item.id}>
              {item.children ? (
                <>
                  <button
                    onClick={() => toggleMenu(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                      expandedMenus.has(item.id)
                        ? "text-white bg-gray-800/50"
                        : "text-gray-400 hover:text-white hover:bg-gray-800/30"
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {expandedMenus.has(item.id) ? (
                      <ChevronDown className="w-3 h-3 text-gray-500" />
                    ) : (
                      <ChevronRight className="w-3 h-3 text-gray-500" />
                    )}
                  </button>
                  {expandedMenus.has(item.id) && (
                    <div className="bg-gray-900/30">
                      {item.children.map((child) => (
                        <button
                          key={child.id}
                          onClick={() => handleNav(child.id)}
                          className={`w-full flex items-center gap-3 pl-11 pr-4 py-2 text-sm transition-colors ${
                            view === child.id
                              ? "text-blue-400 bg-blue-500/10 border-l-2 border-blue-500"
                              : "text-gray-400 hover:text-white hover:bg-gray-800/30 border-l-2 border-transparent"
                          }`}
                        >
                          {child.icon && <child.icon className="w-3.5 h-3.5" />}
                          <span>{child.label}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <button
                  onClick={() => handleNav(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${
                    view === item.id
                      ? "text-blue-400 bg-blue-500/10 border-l-2 border-blue-500"
                      : "text-gray-400 hover:text-white hover:bg-gray-800/30 border-l-2 border-transparent"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              )}
            </div>
          ))}
        </nav>

        {/* User */}
        <div className="p-4 border-t border-gray-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-white text-xs font-medium">
              {user.name?.charAt(0) || "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{user.name || "Admin"}</p>
              <p className="text-gray-500 text-xs">Пользователь</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64">
        {/* Top bar */}
        <div className="bg-white border-b border-gray-200 px-4 lg:px-6 py-3 flex items-center justify-between sticky top-0 z-10">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 -ml-2 text-gray-600 hover:text-gray-900"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <span className="hover:text-gray-700 cursor-pointer">Главная</span>
            <ChevronRight className="w-3 h-3" />
            <span className="text-gray-800">{breadcrumb}</span>
          </div>
          <button
            onClick={() => { localStorage.removeItem("local_auth_token"); window.location.href = "/login"; }}
            className="text-gray-500 hover:text-red-500 text-sm flex items-center gap-1 transition-colors"
          >
            <LogOut className="w-4 h-4" /> Выход
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {view === "dashboard" && <DashboardView />}
          {view === "cars-list" && <CarList onEdit={(id) => { setEditCarId(id); setView("car-edit"); }} />}
          {view === "car-edit" && editCarId && <CarEditForm carId={editCarId} onBack={() => setView("cars-list")} />}
          {view === "car-create" && <CarCreateForm onBack={() => setView("cars-list")} />}
          {view === "liquids-list" && <LiquidList />}
          {view === "ref-vehicleTypes" && (
            <RefTable title="Типы транспортных средств" endpoint={trpc.reference.vehicleType.list} createEndpoint={trpc.reference.vehicleType.create} deleteEndpoint={trpc.reference.vehicleType.delete} columns={[{ key: "name", label: "Название" }, { key: "sortOrder", label: "Порядок" }]} />
          )}
          {view === "ref-steering" && (
            <RefTable title="Расположение руля" endpoint={trpc.reference.steeringPosition.list} createEndpoint={trpc.reference.steeringPosition.create} deleteEndpoint={trpc.reference.steeringPosition.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-bodyTypes" && (
            <RefTable title="Типы кузовов" endpoint={trpc.reference.carBodyType.list} createEndpoint={trpc.reference.carBodyType.create} deleteEndpoint={trpc.reference.carBodyType.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-fuelTypes" && (
            <RefTable title="Типы топлива" endpoint={trpc.reference.fuelType.list} createEndpoint={trpc.reference.fuelType.create} deleteEndpoint={trpc.reference.fuelType.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-transmissionTypes" && (
            <RefTable title="Типы коробок передач" endpoint={trpc.reference.transmissionType.list} createEndpoint={trpc.reference.transmissionType.create} deleteEndpoint={trpc.reference.transmissionType.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-viscosity" && (
            <RefTable title="Классы вязкости" endpoint={trpc.reference.viscosityClass.list} createEndpoint={trpc.reference.viscosityClass.create} deleteEndpoint={trpc.reference.viscosityClass.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "ref-categories" && (
            <RefTable title="Категории жидкостей" endpoint={trpc.reference.liquidCategory.list} createEndpoint={trpc.reference.liquidCategory.create} deleteEndpoint={trpc.reference.liquidCategory.delete} columns={[{ key: "name", label: "Название" }, { key: "displayName", label: "Отображаемое имя" }]} />
          )}
          {view === "ref-trees" && (
            <RefTable title="Дерево агрегатов" endpoint={trpc.reference.aggregationTree.list} createEndpoint={trpc.reference.aggregationTree.create} deleteEndpoint={trpc.reference.aggregationTree.delete} columns={[{ key: "name", label: "Название" }]} />
          )}
          {view === "companies" && <CompaniesView />}
          {view === "widgets" && <WidgetsView />}
          {view === "import-export" && <ImportExportView />}
          {view === "ai-agents" && <AiAgentsView />}
          {(view === "car-liquid-link" || view === "car-create" || view === "liquid-edit" || view === "assignments" || view === "products") && (
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center">
              <p className="text-gray-400 text-lg">В разработке</p>
              <p className="text-gray-300 text-sm mt-1">Этот раздел будет доступен в следующей версии</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

// ═══════════════════════════════════════════
//  DASHBOARD VIEW
// ═══════════════════════════════════════════
function DashboardView() {
  const { data: stats } = trpc.admin.stats.useQuery();
  const { data: carsCount } = trpc.cars.list.useQuery({ limit: 1 });

  const cards = [
    { label: "Компании", value: stats?.companies || 0, icon: Users, color: "bg-blue-50 text-blue-600" },
    { label: "Продукты", value: stats?.products || 0, icon: Droplets, color: "bg-green-50 text-green-600" },
    { label: "Привязки", value: stats?.assignments || 0, icon: Link2, color: "bg-yellow-50 text-yellow-600" },
    { label: "Автомобили", value: carsCount?.total || 0, icon: Car, color: "bg-purple-50 text-purple-600" },
    { label: "Пользователи", value: stats?.users || 0, icon: Users, color: "bg-gray-100 text-gray-600" },
  ];

  return (
    <div>
      <h2 className="text-gray-800 text-xl font-semibold mb-6">Главная</h2>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-gray-500 text-xs">{card.label}</span>
              <card.icon className={`w-5 h-5 ${card.color.split(" ")[1]}`} />
            </div>
            <span className="text-gray-800 text-2xl font-bold">{card.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  COMPANIES VIEW (simplified)
// ═══════════════════════════════════════════
function CompaniesView() {
  const utils = trpc.useUtils();
  const { data: list, isLoading } = trpc.admin.listCompanies.useQuery();
  const create = trpc.admin.createCompany.useMutation({
    onSuccess: () => { utils.admin.listCompanies.invalidate(); setNewName(""); },
  });
  const remove = trpc.admin.deleteCompany.useMutation({
    onSuccess: () => utils.admin.listCompanies.invalidate(),
  });
  const [newName, setNewName] = useState("");

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <h2 className="text-gray-800 text-lg font-semibold">Компании</h2>
      </div>
      <div className="p-4">
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && newName.trim()) create.mutate({ name: newName.trim(), slug: newName.trim().toLowerCase().replace(/\\s+/g, "-") }); }}
            placeholder="Название компании..."
            className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500"
          />
          <button onClick={() => newName.trim() && create.mutate({ name: newName.trim(), slug: newName.trim().toLowerCase().replace(/\\s+/g, "-") })} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors">
            <Plus className="w-4 h-4" /> Создать
          </button>
        </div>
        {isLoading ? (
          <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
        ) : (
          <div className="overflow-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-16">Действия</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Название</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium">Slug</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-20">Статус</th>
                  <th className="text-left p-3 text-gray-500 text-xs font-medium w-32">Создана</th>
                </tr>
              </thead>
              <tbody>
                {list?.map((c: any) => (
                  <tr key={c.id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                    <td className="p-3">
                      <button onClick={() => { if (confirm("Удалить?")) remove.mutate({ id: c.id }); }} className="text-gray-400 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                    </td>
                    <td className="p-3 text-gray-800 text-sm font-medium">{c.name}</td>
                    <td className="p-3 text-gray-500 text-sm font-mono">{c.slug}</td>
                    <td className="p-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${c.isActive === "active" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{c.isActive === "active" ? "Активна" : "Приостановлена"}</span>
                    </td>
                    <td className="p-3 text-gray-500 text-xs">{c.createdAt ? new Date(c.createdAt).toLocaleDateString("ru-RU") : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  WIDGETS VIEW
// ═══════════════════════════════════════════
function WidgetsView() {
  const utils = trpc.useUtils();
  const { data: companiesList, isLoading } = trpc.admin.listCompanies.useQuery();
  const generateKey = trpc.admin.generateApiKey.useMutation({
    onSuccess: () => { utils.admin.listCompanies.invalidate(); alert("API ключ сгенерирован!"); },
  });
  const updateDomains = trpc.admin.updateDomains.useMutation({
    onSuccess: () => utils.admin.listCompanies.invalidate(),
  });

  const [selectedCompany, setSelectedCompany] = useState<number | null>(null);
  const [domainInput, setDomainInput] = useState("");
  const [copied, setCopied] = useState(false);

  const selected = companiesList?.find((c: any) => c.id === selectedCompany);
  const domains: string[] = selected?.allowedDomains ? (typeof selected.allowedDomains === "string" ? JSON.parse(selected.allowedDomains) : selected.allowedDomains) || [] : [];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold">Компании</h2></div>
        <div className="p-4">
          {isLoading ? (
            <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
          ) : (
            <div className="divide-y divide-gray-100">
              {companiesList?.map((c: any) => (
                <button key={c.id} onClick={() => { setSelectedCompany(c.id); setDomainInput(""); }} className={`w-full text-left p-4 transition-colors ${selectedCompany === c.id ? "bg-blue-50 border-l-2 border-l-blue-500" : "hover:bg-gray-50 border-l-2 border-transparent"}`}>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-gray-800 text-sm font-medium">{c.name}</span>
                      <span className="text-gray-400 text-xs ml-2">{c.slug}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${c.apiKey ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{c.apiKey ? "Активен" : "Нет ключа"}</span>
                  </div>
                  {c.apiKey && <p className="text-gray-400 text-xs mt-1 font-mono">{c.apiKey.substring(0, 20)}...</p>}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div>
        {selected ? (
          <div className="space-y-4">
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
              <h3 className="text-gray-800 font-medium text-sm mb-4 flex items-center gap-2"><Key className="w-4 h-4 text-blue-600" /> API Ключ</h3>
              {selected.apiKey ? (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <code className="flex-1 bg-gray-50 border border-gray-200 rounded-md px-3 py-2 text-blue-600 text-xs font-mono break-all">{selected.apiKey}</code>
                    <button onClick={() => handleCopy(selected.apiKey)} className="p-2 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors" title="Копировать"><Copy className="w-4 h-4 text-gray-500" /></button>
                  </div>
                  {copied && <p className="text-green-600 text-xs mb-2">Скопировано!</p>}
                  <button onClick={() => selected.id && generateKey.mutate({ companyId: selected.id })} className="flex items-center gap-2 text-gray-500 text-xs hover:text-blue-600 transition-colors"><RefreshCw className="w-3 h-3" /> Перегенерировать</button>
                </div>
              ) : (
                <div>
                  <p className="text-gray-500 text-sm mb-3">API ключ ещё не сгенерирован</p>
                  <button onClick={() => selected.id && generateKey.mutate({ companyId: selected.id })} className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors">Сгенерировать ключ</button>
                </div>
              )}
            </div>

            <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
              <h3 className="text-gray-800 font-medium text-sm mb-4 flex items-center gap-2"><Globe className="w-4 h-4 text-blue-600" /> Разрешённые домены</h3>
              <div className="space-y-2 mb-4">
                {domains.length === 0 ? <p className="text-gray-400 text-sm">Домены не указаны</p> : domains.map((d: string, i: number) => (
                  <div key={i} className="flex items-center justify-between bg-gray-50 rounded-md px-3 py-2">
                    <span className="text-gray-700 text-sm">{d}</span>
                    <button onClick={() => { const newDomains = domains.filter((_: string, idx: number) => idx !== i); selected.id && updateDomains.mutate({ companyId: selected.id, domains: newDomains }); }} className="text-gray-400 hover:text-red-500 transition-colors"><X className="w-3 h-3" /></button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input type="text" value={domainInput} onChange={(e) => setDomainInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && domainInput.trim()) { const newDomains = [...domains, domainInput.trim().toLowerCase()]; selected.id && updateDomains.mutate({ companyId: selected.id, domains: newDomains }); setDomainInput(""); } }} placeholder="example.com" className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500" />
                <button onClick={() => { if (domainInput.trim()) { const newDomains = [...domains, domainInput.trim().toLowerCase()]; selected.id && updateDomains.mutate({ companyId: selected.id, domains: newDomains }); setDomainInput(""); } }} className="bg-blue-600 text-white px-3 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors"><Plus className="w-4 h-4" /></button>
              </div>
            </div>

            {selected.apiKey && (
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-5">
                <h3 className="text-gray-800 font-medium text-sm mb-4 flex items-center gap-2"><Code className="w-4 h-4 text-blue-600" /> Код для встраивания</h3>
                <p className="text-gray-500 text-xs mb-3">Вставьте этот код на сайт компании</p>
                <pre className="bg-gray-50 border border-gray-200 rounded-md p-3 text-xs text-gray-600 overflow-auto font-mono">{`<script src="${window.location.origin}/widget.js" data-api-key="${selected.apiKey}"></script>\n<div id="motornaya-widget"></div>`}</pre>
                <button onClick={() => handleCopy(`<script src="${window.location.origin}/widget.js" data-api-key="${selected.apiKey}"></script>\n<div id="motornaya-widget"></div>`)} className="mt-3 flex items-center gap-2 text-gray-500 text-xs hover:text-blue-600 transition-colors"><Copy className="w-3 h-3" /> Копировать код</button>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-8 text-center">
            <Globe className="w-10 h-10 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-400 text-sm">Выберите компанию слева</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  CAR CREATE FORM (placeholder)
// ═══════════════════════════════════════════
function CarCreateForm({ onBack }: { onBack: () => void }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm"><ChevronRight className="w-4 h-4 rotate-180" /> Назад</button>
          <h2 className="text-gray-800 text-xl font-semibold">Добавить автомобиль</h2>
        </div>
      </div>
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-12 text-center">
        <p className="text-gray-400">В разработке — используйте импорт из каталога</p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════
//  IMPORT / EXPORT VIEW
// ═══════════════════════════════════════════
function ImportExportView() {
  const utils = trpc.useUtils();
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [makeFilter, setMakeFilter] = useState("");
  const [batchFilter, setBatchFilter] = useState("");

  const importMutation = trpc.excel.import.useMutation({
    onSuccess: (data) => { setResult(data); setImporting(false); utils.excel.list.invalidate(); utils.excel.batches.invalidate(); },
    onError: (err) => { setResult({ error: err.message }); setImporting(false); },
  });

  const { data: batches } = trpc.excel.batches.useQuery();
  const { data: listData } = trpc.excel.list.useQuery(
    { make: makeFilter || undefined, batch: batchFilter || undefined, limit: 50 },
    { enabled: !!batchFilter || !!makeFilter }
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setFile(f);
  };

  const handleImport = async () => {
    if (!file) return;
    setImporting(true);
    setResult(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = (e.target?.result as string)?.split(",")[1];
      if (base64) importMutation.mutate({ fileBase64: base64, batchName: file.name.replace(/\\.xlsx?$/i, "") });
    };
    reader.readAsDataURL(file);
  };

  const handleExport = async () => {
    const res = await utils.excel.export.fetch({ make: makeFilter || undefined, batch: batchFilter || undefined });
    if (res?.data) {
      const link = document.createElement("a");
      link.href = `data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,${res.data}`;
      link.download = res.filename;
      link.click();
    }
  };

  return (
    <div className="space-y-6">
      {/* Import Card */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><FileUp className="w-5 h-5 text-blue-600" />Импорт Excel</h2></div>
        <div className="p-4 space-y-4">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
            <input type="file" accept=".xlsx,.xls" onChange={handleFileChange} className="hidden" id="excel-file" />
            <label htmlFor="excel-file" className="cursor-pointer">
              <FileUp className="w-10 h-10 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600 text-sm">{file ? file.name : "Нажмите чтобы выбрать файл Excel"}</p>
              <p className="text-gray-400 text-xs mt-1">Поддерживаются .xlsx, .xls</p>
            </label>
          </div>
          <button onClick={handleImport} disabled={!file || importing} className="bg-blue-600 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2">
            {importing ? <><RefreshCw className="w-4 h-4 animate-spin" />Импорт...</> : <><FileUp className="w-4 h-4" />Импортировать</>}
          </button>
          {result && (
            <div className={`p-3 rounded-lg text-sm ${result.error ? "bg-red-50 text-red-700 border border-red-200" : "bg-green-50 text-green-700 border border-green-200"}`}>
              {result.error ? `Ошибка: ${result.error}` : `Импортировано: ${result.inserted} из ${result.total} строк (пропущено: ${result.skipped}, батч: ${result.batch})`}
            </div>
          )}
        </div>
      </div>

      {/* Export Card */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><FileDown className="w-5 h-5 text-green-600" />Экспорт Excel</h2></div>
        <div className="p-4 space-y-4">
          <div className="flex gap-2 flex-wrap">
            <input type="text" value={makeFilter} onChange={(e) => setMakeFilter(e.target.value)} placeholder="Фильтр по марке..." className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-48" />
            <select value={batchFilter} onChange={(e) => setBatchFilter(e.target.value)} className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-blue-500 w-56">
              <option value="">Все батчи</option>
              {batches?.map((b: any) => <option key={b.batch} value={b.batch}>{b.batch} ({b.count} записей)</option>)}
            </select>
          </div>
          <button onClick={handleExport} className="bg-green-600 text-white px-6 py-2.5 rounded-lg text-sm font-medium hover:bg-green-700 transition-colors flex items-center gap-2"><FileDown className="w-4 h-4" />Экспортировать в Excel</button>
        </div>
      </div>

      {/* Data Preview */}
      {listData && listData.items.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold">Просмотр данных ({listData.total} записей)</h2></div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-gray-200 bg-gray-50">
                <th className="p-2 text-left text-gray-500">Марка</th><th className="p-2 text-left text-gray-500">Модель</th><th className="p-2 text-left text-gray-500">Модификация</th>
                <th className="p-2 text-left text-gray-500">ДВС</th><th className="p-2 text-left text-gray-500">Объем</th><th className="p-2 text-left text-gray-500">SAE</th>
                <th className="p-2 text-left text-gray-500">КПП</th><th className="p-2 text-left text-gray-500">Охлаждение</th><th className="p-2 text-left text-gray-500">Тормоза</th>
              </tr></thead>
              <tbody>{listData.items.map((item: any) => (
                <tr key={item.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="p-2 text-gray-800 font-medium">{item.make}</td><td className="p-2 text-gray-700">{item.model}</td><td className="p-2 text-gray-600">{item.modification || "—"}</td>
                  <td className="p-2 text-gray-600">{item.engineCode || "—"}</td><td className="p-2 text-gray-600">{item.engineFillVolume || "—"}</td><td className="p-2 text-gray-600">{item.prefOilSae || "—"}</td>
                  <td className="p-2 text-gray-600">{item.transmissionType || "—"}</td><td className="p-2 text-gray-600">{item.coolantType || "—"}</td><td className="p-2 text-gray-600">{item.brakeFluidType || "—"}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════
//  AI AGENTS VIEW
// ═══════════════════════════════════════════
// 5 AI AGENTS VIEW
const AGENT_COLORS: Record<string, { bg: string; text: string; border: string; light: string }> = {
  "catalog-parser": { bg: "bg-blue-500", text: "text-blue-700", border: "border-blue-200", light: "bg-blue-50" },
  "oil-researcher": { bg: "bg-amber-500", text: "text-amber-700", border: "border-amber-200", light: "bg-amber-50" },
  "transmission-researcher": { bg: "bg-emerald-500", text: "text-emerald-700", border: "border-emerald-200", light: "bg-emerald-50" },
  "fluids-researcher": { bg: "bg-cyan-500", text: "text-cyan-700", border: "border-cyan-200", light: "bg-cyan-50" },
  "filters-researcher": { bg: "bg-rose-500", text: "text-rose-700", border: "border-rose-200", light: "bg-rose-50" },
  "manual-finder": { bg: "bg-violet-500", text: "text-violet-700", border: "border-violet-200", light: "bg-violet-50" },
};

function AiAgentsView() {
  const utils = trpc.useUtils();
  const { data: agents, isLoading } = trpc.agents.list.useQuery();
  const { data: tasks } = trpc.agents.tasks.useQuery();
  const runBySlug = trpc.agents.runBySlug.useMutation({
    onSuccess: () => { utils.agents.tasks.invalidate(); utils.agents.list.invalidate(); utils.excel.list.invalidate(); },
    onError: (err) => alert(err.message),
  });
  const updateStatus = trpc.agents.update.useMutation({
    onSuccess: () => utils.agents.list.invalidate(),
  });
  const batchResearch = trpc.agents.researchBatch.useMutation({
    onSuccess: () => { utils.agents.tasks.invalidate(); utils.excel.list.invalidate(); },
  });

  const [forms, setForms] = useState<Record<string, { make: string; model: string; engine: string; year: string }>>({});
  const [batchLimit, setBatchLimit] = useState("10");

  const setForm = (slug: string, field: string, value: string) => {
    setForms((prev) => ({ ...prev, [slug]: { ...prev[slug], [field]: value } }));
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {agents?.map((agent: any) => {
          const c = AGENT_COLORS[agent.slug] || AGENT_COLORS["catalog-parser"];
          return (
            <div key={agent.id} className={`rounded-lg border border-gray-200 shadow-sm p-3 ${c.light}`}>
              <p className={`text-xs ${c.text} opacity-80`}>{agent.name}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className={`w-2 h-2 rounded-full ${agent.isActive === "active" ? "bg-green-500" : agent.isActive === "error" ? "bg-red-500" : "bg-gray-400"}`} />
                <p className="text-lg font-bold text-gray-800">{agent.runsSuccess || 0}/{agent.runsTotal || 0}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Batch Research */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><RotateCw className="w-5 h-5 text-purple-600" />Пакетное исследование</h2>
        </div>
        <div className="p-4 flex gap-2">
          <input type="text" value={batchLimit} onChange={(e) => setBatchLimit(e.target.value)} placeholder="Лимит" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 w-24" />
          <button onClick={() => batchResearch.mutate({ limit: parseInt(batchLimit) || 10 })} disabled={batchResearch.isPending} className="bg-purple-600 text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-purple-700 disabled:opacity-50 flex items-center gap-2">
            {batchResearch.isPending ? <><RefreshCw className="w-4 h-4 animate-spin" />Обработка...</> : <><RotateCw className="w-4 h-4" />Запустить на {batchLimit} авто</>}
          </button>
        </div>
        {batchResearch.data && (
          <div className="px-4 pb-4"><div className="bg-blue-50 text-blue-700 border border-blue-200 p-3 rounded-lg text-sm">Обработано: {batchResearch.data.processed} авто</div></div>
        )}
      </div>

      {/* 5 Agent Cards */}
      {isLoading ? (
        <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-4">
          {agents?.map((agent: any) => {
            const slug = agent.slug;
            const c = AGENT_COLORS[slug] || AGENT_COLORS["catalog-parser"];
            const form = forms[slug] || { make: "", model: "", engine: "", year: "" };
            const config = typeof agent.config === "string" ? JSON.parse(agent.config) : agent.config;
            const columns = config?.columns || [];
            const isRunning = runBySlug.isPending && runBySlug.variables?.slug === slug;

            return (
              <div key={agent.id} className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <div className={`p-4 border-b border-gray-200 flex items-center justify-between ${c.light}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${c.bg} bg-opacity-20`}>
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-800 text-sm font-semibold">{agent.name}</h3>
                      <p className="text-gray-500 text-xs">{agent.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${agent.isActive === "active" ? "bg-green-100 text-green-700" : agent.isActive === "error" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-500"}`}>
                      {agent.isActive === "active" ? "Активен" : agent.isActive === "error" ? "Ошибка" : "Пауза"}
                    </span>
                    <button onClick={() => updateStatus.mutate({ id: agent.id, isActive: agent.isActive === "active" ? "paused" : "active" })} className="p-1.5 bg-white rounded hover:bg-gray-100 transition-colors" title={agent.isActive === "active" ? "Пауза" : "Активировать"}>
                      {agent.isActive === "active" ? <Pause className="w-3.5 h-3.5 text-gray-500" /> : <Play className="w-3.5 h-3.5 text-green-600" />}
                    </button>
                  </div>
                </div>

                <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
                  <p className="text-gray-500 text-[10px] uppercase tracking-wider mb-1">Заполняемые поля ({columns.length}):</p>
                  <div className="flex flex-wrap gap-1">
                    {columns.map((col: any, i: number) => (
                      <span key={i} className={`text-[10px] px-1.5 py-0.5 rounded ${c.light} ${c.text} border ${c.border}`}>{col.label}</span>
                    ))}
                  </div>
                </div>

                <div className="p-4">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mb-3">
                    <input type="text" value={form.make} onChange={(e) => setForm(slug, "make", e.target.value)} placeholder="Марка" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                    <input type="text" value={form.model} onChange={(e) => setForm(slug, "model", e.target.value)} placeholder="Модель" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                    <input type="text" value={form.engine} onChange={(e) => setForm(slug, "engine", e.target.value)} placeholder="Двигатель" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                    <input type="text" value={form.year} onChange={(e) => setForm(slug, "year", e.target.value)} placeholder="Год" className="border border-gray-300 rounded-md px-3 py-2 text-sm text-gray-800 focus:outline-none focus:border-gray-500" />
                  </div>
                  <button
                    onClick={() => { if (form.make && form.model) runBySlug.mutate({ slug, payload: { make: form.make, model: form.model, engineCode: form.engine || undefined, year: form.year || undefined } }); }}
                    disabled={!form.make || !form.model || isRunning}
                    className="bg-gray-900 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors disabled:opacity-50 flex items-center gap-2"
                  >
                    {isRunning ? <><RefreshCw className="w-4 h-4 animate-spin" />Работаю...</> : <><Play className="w-4 h-4" />Запустить агента</>}
                  </button>
                </div>

                {agent.lastRunAt && (
                  <div className="px-4 py-2 bg-gray-50 border-t border-gray-200 flex gap-4 text-[10px] text-gray-400">
                    <span>Запусков: {agent.runsTotal || 0}</span>
                    <span>Успешно: {agent.runsSuccess || 0}</span>
                    <span>Ошибок: {agent.runsError || 0}</span>
                    <span>Записей: {agent.itemsProcessed || 0}</span>
                    <span className="ml-auto">Последний: {new Date(agent.lastRunAt).toLocaleString("ru-RU")}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Tasks */}
      {tasks && tasks.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="p-4 border-b border-gray-200"><h2 className="text-gray-800 text-lg font-semibold flex items-center gap-2"><Activity className="w-5 h-5 text-blue-600" />История задач</h2></div>
          <div className="divide-y divide-gray-100 max-h-64 overflow-auto">
            {tasks.slice(0, 30).map((task: any) => (
              <div key={task.id} className="p-3 flex items-center justify-between hover:bg-gray-50">
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${task.status === "completed" ? "bg-green-500" : task.status === "running" ? "bg-blue-500 animate-pulse" : task.status === "failed" ? "bg-red-500" : "bg-gray-400"}`} />
                  <span className="text-gray-700 text-sm">Агент #{task.agentId}</span>
                  <span className="text-gray-400 text-xs">{task.status}</span>
                </div>
                <span className="text-gray-400 text-xs">{task.createdAt ? new Date(task.createdAt).toLocaleString("ru-RU") : "—"}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
