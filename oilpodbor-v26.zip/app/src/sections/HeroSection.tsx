import { useEffect, useRef } from "react";
import { ChevronDown } from "lucide-react";

export default function HeroSection() {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const baseRef = useRef<HTMLDivElement>(null);
  const gooeyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const wrapper = wrapperRef.current;
    const base = baseRef.current;
    const gooey = gooeyRef.current;
    if (!wrapper || !base || !gooey) return;

    const handleMouseMove = (e: MouseEvent) => {
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      const offsetX = (e.clientX - centerX) / centerX;
      const offsetY = (e.clientY - centerY) / centerY;
      base.style.transform = `translate(${offsetX * 8}px, ${offsetY * 4}px)`;
      gooey.style.transform = `translate(${-offsetX * 8}px, ${-offsetY * 4}px)`;
    };

    const handleMouseEnter = () => {
      gooey.style.opacity = "1";
      gooey.style.transform = "translateY(0)";
      base.style.transform = "scale(1.05)";
      base.style.letterSpacing = "0.04em";
    };

    const handleMouseLeave = () => {
      gooey.style.opacity = "0";
      gooey.style.transform = "translateY(6px)";
      base.style.transform = "scale(1)";
      base.style.letterSpacing = "0em";
    };

    document.addEventListener("mousemove", handleMouseMove);
    wrapper.addEventListener("mouseenter", handleMouseEnter);
    wrapper.addEventListener("mouseleave", handleMouseLeave);

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      wrapper.removeEventListener("mouseenter", handleMouseEnter);
      wrapper.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []);

  const scrollToSelector = () => {
    document.getElementById("selector")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-[100dvh] flex flex-col items-center justify-center px-6 overflow-hidden bg-black">
      {/* SVG Filter */}
      <svg className="absolute w-0 h-0" aria-hidden="true">
        <defs>
          <filter id="viscous-filter" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur" />
            <feColorMatrix
              in="blur"
              mode="matrix"
              values="1 0 0 0 0  0 1 0 0 0  1 0 1 0 0  0 0 0 18 -8"
              result="gooey"
            />
            <feTurbulence
              type="fractalNoise"
              baseFrequency="0.015"
              numOctaves="3"
              result="noise"
            />
            <feDisplacementMap
              in="gooey"
              in2="noise"
              scale="20"
              xChannelSelector="R"
              yChannelSelector="G"
            />
          </filter>
        </defs>
      </svg>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-3xl">
        {/* Overline */}
        <p className="font-mono-tech text-xs text-[#a3a3a3] uppercase tracking-[0.1em] mb-6">
          Каталог технических жидкостей
        </p>

        {/* Viscous Headline */}
        <div
          ref={wrapperRef}
          className="relative inline-block mb-6"
          style={{ lineHeight: 1.1 }}
        >
          <div
            ref={baseRef}
            className="text-white font-bold transition-all duration-300 ease-out"
            style={{
              fontSize: "clamp(2.5rem, 5vw, 4rem)",
              letterSpacing: "-0.02em",
              textShadow: "0 4px 24px rgba(0,0,0,0.8)",
            }}
          >
            Подберите масло
            <br />
            для вашего авто
          </div>
          <div
            ref={gooeyRef}
            className="absolute top-0 left-0 w-full h-full text-white font-bold transition-all duration-300 ease-out pointer-events-none"
            style={{
              fontSize: "clamp(2.5rem, 5vw, 4rem)",
              letterSpacing: "-0.02em",
              opacity: 0,
              transform: "translateY(6px)",
              filter: "url('#viscous-filter')",
            }}
          >
            Подберите масло
            <br />
            для вашего авто
          </div>
        </div>

        {/* Subheadline */}
        <p className="text-[#a3a3a3] text-lg max-w-xl mb-10 leading-relaxed">
          База данных по 45 000+ моделям автомобилей. Точное соответствие по VIN,
          коду двигателя и году выпуска.
        </p>

        {/* CTA */}
        <button
          onClick={scrollToSelector}
          className="bg-[#f59e0b] text-black font-bold px-8 py-3 rounded-full hover:bg-[#f59e0b]/90 transition-all duration-200 hover:scale-105 active:scale-95"
        >
          Начать подбор
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
        <span className="font-mono-tech text-[10px] text-[#525252] uppercase tracking-wider">
          Листайте вниз
        </span>
        <div className="w-px h-10 bg-gradient-to-b from-[#a3a3a3] to-transparent animate-scroll-line" />
        <ChevronDown className="w-4 h-4 text-[#525252] animate-bounce" />
      </div>

      {/* Subtle gradient overlay at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#0a0a0a] to-transparent pointer-events-none" />
    </section>
  );
}
