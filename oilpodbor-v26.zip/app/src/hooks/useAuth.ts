import { useCallback } from "react";
import { trpc } from "@/providers/trpc";

export interface AuthUser {
  id: number;
  name: string | null;
  username: string | null;
  email: string | null;
  avatar: string | null;
  role: "user" | "admin";
}

export function useAuth() {
  const utils = trpc.useUtils();
  const { data: localUser, isLoading } = trpc.localAuth.me.useQuery(
    undefined,
    { retry: false, refetchOnWindowFocus: false }
  );

  const logout = useCallback(() => {
    localStorage.removeItem("local_auth_token");
    utils.invalidate();
    window.location.reload();
  }, [utils]);

  return {
    user: (localUser || null) as AuthUser | null,
    isAuthenticated: !!localUser,
    isLoading,
    logout,
  };
}
