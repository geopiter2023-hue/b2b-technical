import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { oils, mapping, products, productAssignments } from "@db/schema";
import { asc, and, desc, eq, sql } from "drizzle-orm";

export const oilRouter = createRouter({
  // ─── Get original catalog oils (public) ───
  byModification: publicQuery
    .input(
      z.object({
        makeId: z.number(),
        modelId: z.number(),
        modificationId: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();

      // Step 1: Find the original internal IDs from mapping table
      const mappingRows = await db
        .select({
          origMakeId: mapping.makeId,
          origModelId: mapping.modelId,
          origTypeId: mapping.typeId,
        })
        .from(mapping)
        .where(
          sql`${mapping.newMakeId} = ${input.makeId}
          AND ${mapping.newModelId} = ${input.modelId}
          AND ${mapping.newTypeId} = ${input.modificationId}`
        )
        .limit(1);

      if (
        mappingRows.length === 0 ||
        !mappingRows[0].origMakeId ||
        !mappingRows[0].origModelId ||
        !mappingRows[0].origTypeId
      ) {
        return [];
      }

      const { origMakeId, origModelId, origTypeId } = mappingRows[0];

      // Step 2: Get oils using the original internal IDs
      const result = await db
        .select({
          id: oils.id,
          makeId: oils.makeId,
          modelId: oils.modelId,
          modificationId: oils.modificationId,
          originalName: oils.originalName,
          artNumber: oils.artNumber,
          volume: oils.volume,
          commentName: oils.commentName,
          orderPosition: oils.orderPosition,
        })
        .from(oils)
        .where(
          sql`${oils.makeId} = ${origMakeId}
          AND ${oils.modelId} = ${origModelId}
          AND ${oils.modificationId} = CAST(${origTypeId} AS SIGNED)`
        )
        .orderBy(asc(oils.orderPosition));

      return result;
    }),

  // ─── Get company-specific products for a car ───
  // Returns products from the company's catalog that are assigned to this car
  companyProducts: publicQuery
    .input(
      z.object({
        companyId: z.number(),
        makeId: z.number(),
        modelId: z.number(),
        modificationId: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({
          assignmentId: productAssignments.id,
          isRecommended: productAssignments.isRecommended,
          notes: productAssignments.notes,
          id: products.id,
          name: products.name,
          sku: products.sku,
          brand: products.brand,
          category: products.category,
          price: products.price,
          volume: products.volume,
          specs: products.specs,
          imageUrl: products.imageUrl,
        })
        .from(productAssignments)
        .innerJoin(
          products,
          eq(productAssignments.productId, products.id)
        )
        .where(
          and(
            eq(productAssignments.companyId, input.companyId),
            eq(productAssignments.makeId, input.makeId),
            eq(productAssignments.modelId, input.modelId),
            eq(productAssignments.modificationId, input.modificationId)
          )
        )
        .orderBy(desc(productAssignments.isRecommended));
      return result;
    }),
});
