import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  companies,
  searchLogs,
  oils,
  mapping,
  products,
  productAssignments,
  brands,
  models,
  modifications,
} from "@db/schema";
import { eq, and, sql, asc, desc } from "drizzle-orm";

// ─── Helpers ───

function extractDomain(referrer: string): string | null {
  try {
    const url = new URL(referrer);
    return url.hostname;
  } catch {
    return null;
  }
}

function isDomainAllowed(allowedDomains: unknown, requestDomain: string): boolean {
  if (!allowedDomains) return false;
  const domains = Array.isArray(allowedDomains) ? allowedDomains : [];
  if (domains.length === 0) return false;
  // Allow exact match or subdomain match
  return domains.some((d: string) => {
    const domain = d.toLowerCase().trim();
    const req = requestDomain.toLowerCase().trim();
    return domain === req || req.endsWith(`.${domain}`);
  });
}

function generateApiKey(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let key = "mk_"; // motornaya key prefix
  for (let i = 0; i < 32; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

// ─── API Key Validation Middleware (inline in procedures) ───

async function validateWidgetRequest(apiKey: string, referrerHeader: string | null) {
  const db = getDb();

  // Find company by API key
  const [company] = await db
    .select()
    .from(companies)
    .where(eq(companies.apiKey, apiKey))
    .limit(1);

  if (!company) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Invalid API key",
    });
  }

  if (company.isActive !== "active") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Company account is suspended",
    });
  }

  // Validate domain
  const requestDomain = referrerHeader ? extractDomain(referrerHeader) : null;
  if (!requestDomain || !isDomainAllowed(company.allowedDomains, requestDomain)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: `Domain not authorized: ${requestDomain || "unknown"}`,
    });
  }

  return { company, domain: requestDomain };
}

// ─── Log search request ───

async function logSearch(
  data: {
    companyId: number;
    apiKey: string;
    domain: string;
    makeId?: number;
    modelId?: number;
    modificationId?: string | number;
    makeName?: string | null;
    modelName?: string | null;
    modificationName?: string | null;
    engineCode?: string | null;
    clientIp?: string | null;
    userAgent?: string | null;
  }
) {
  const db = getDb();
  await db.insert(searchLogs).values({
    companyId: data.companyId,
    apiKey: data.apiKey,
    domain: data.domain,
    makeId: data.makeId || null,
    modelId: data.modelId || null,
    modificationId: data.modificationId?.toString() || null,
    makeName: data.makeName || null,
    modelName: data.modelName || null,
    modificationName: data.modificationName || null,
    engineCode: data.engineCode || null,
    clientIp: data.clientIp || null,
    userAgent: data.userAgent || null,
  });
}

// ─── Widget Router ───

export const widgetRouter = createRouter({
  // ─── Validate API key (called by widget on init) ───
  validate: publicQuery
    .input(
      z.object({
        apiKey: z.string().min(1),
      })
    )
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      const { company, domain } = await validateWidgetRequest(input.apiKey, referrer);

      return {
        valid: true,
        company: {
          id: company.id,
          name: company.name,
          logo: company.logo,
        },
        domain,
      };
    }),

  // ─── Get brands (same as car.brands but with API key) ───
  brands: publicQuery
    .input(z.object({ apiKey: z.string().min(1) }))
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();
      const result = await db
        .selectDistinct({
          id: mapping.newMakeId,
          name: brands.name,
        })
        .from(brands)
        .innerJoin(mapping, sql`${brands.id} = ${mapping.makeId}`)
        .orderBy(brands.name);

      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
      }));
    }),

  // ─── Get models ───
  models: publicQuery
    .input(z.object({ apiKey: z.string().min(1), makeId: z.number() }))
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();
      const result = await db
        .selectDistinct({
          modelId: mapping.newModelId,
          makeId: mapping.newMakeId,
          modelName: models.modelName,
          yearFrom: models.yearFrom,
          yearTo: models.yearTo,
        })
        .from(models)
        .innerJoin(
          mapping,
          sql`${models.modelId} = ${mapping.modelId} AND ${models.makeId} = ${mapping.makeId}`
        )
        .where(sql`${mapping.newMakeId} = ${input.makeId}`)
        .orderBy(models.modelName);

      return result.map((r) => ({
        modelId: Number(r.modelId),
        makeId: Number(r.makeId),
        modelName: r.modelName,
        yearFrom: r.yearFrom,
        yearTo: r.yearTo,
      }));
    }),

  // ─── Get modifications ───
  modifications: publicQuery
    .input(
      z.object({
        apiKey: z.string().min(1),
        makeId: z.number(),
        modelId: z.number(),
      })
    )
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      await validateWidgetRequest(input.apiKey, referrer);

      const db = getDb();
      const result = await db
        .selectDistinct({
          id: mapping.newTypeId,
          name: modifications.name,
          engineCode: modifications.engineCode,
          fuel: modifications.fuel,
          horsePower: modifications.horsePower,
          startDate: modifications.startDate,
          endDate: modifications.endDate,
          engineCapacity: modifications.engineCapacity,
          constructionType: modifications.constructionType,
          motorType: modifications.motorType,
        })
        .from(modifications)
        .innerJoin(
          mapping,
          sql`${modifications.id} = ${mapping.typeId}
          AND ${modifications.makeId} = ${mapping.makeId}
          AND ${modifications.modelId} = ${mapping.modelId}`
        )
        .where(
          sql`${mapping.newMakeId} = ${input.makeId}
          AND ${mapping.newModelId} = ${input.modelId}`
        )
        .orderBy(modifications.name);

      return result.map((r) => ({
        id: Number(r.id),
        name: r.name,
        engineCode: r.engineCode,
        fuel: r.fuel,
        horsePower: r.horsePower,
        startDate: r.startDate,
        endDate: r.endDate,
        engineCapacity: r.engineCapacity,
        constructionType: r.constructionType,
        motorType: r.motorType,
      }));
    }),

  // ─── Get oils + company products for a specific car ───
  // This is the main endpoint — returns both catalog oils and company products
  results: publicQuery
    .input(
      z.object({
        apiKey: z.string().min(1),
        makeId: z.number(),
        modelId: z.number(),
        modificationId: z.number(),
      })
    )
    .query(async ({ input, ctx }) => {
      const referrer = ctx.req.headers.get("referer") || ctx.req.headers.get("origin");
      const { company, domain } = await validateWidgetRequest(
        input.apiKey,
        referrer
      );

      const db = getDb();

      // ── Step 1: Resolve IDs via mapping ──
      const mappingRows = await db
        .select({
          origMakeId: mapping.makeId,
          origModelId: mapping.modelId,
          origTypeId: mapping.typeId,
        })
        .from(mapping)
        .where(
          sql`${mapping.newMakeId} = ${input.makeId}
          AND ${mapping.newModelId} = ${input.modelId}
          AND ${mapping.newTypeId} = ${input.modificationId}`
        )
        .limit(1);

      if (
        mappingRows.length === 0 ||
        !mappingRows[0].origMakeId ||
        !mappingRows[0].origModelId ||
        !mappingRows[0].origTypeId
      ) {
        // Log the search even if no results
        await logSearch({
          companyId: company.id,
          apiKey: input.apiKey,
          domain,
          makeId: input.makeId,
          modelId: input.modelId,
          modificationId: input.modificationId,
          clientIp:
            ctx.req.headers.get("x-forwarded-for") ||
            ctx.req.headers.get("x-real-ip"),
          userAgent: ctx.req.headers.get("user-agent"),
        });
        return { catalogOils: [], companyProducts: [] };
      }

      const { origMakeId, origModelId, origTypeId } = mappingRows[0];

      // ── Step 2: Get catalog oils ──
      const catalogOils = await db
        .select({
          id: oils.id,
          originalName: oils.originalName,
          artNumber: oils.artNumber,
          volume: oils.volume,
          commentName: oils.commentName,
          orderPosition: oils.orderPosition,
        })
        .from(oils)
        .where(
          sql`${oils.makeId} = ${origMakeId}
          AND ${oils.modelId} = ${origModelId}
          AND ${oils.modificationId} = CAST(${origTypeId} AS SIGNED)`
        )
        .orderBy(asc(oils.orderPosition));

      // ── Step 3: Get car info for logging ──
      const [carInfo] = await db
        .select({
          makeName: brands.name,
          modelName: models.modelName,
          modificationName: modifications.name,
          engineCode: modifications.engineCode,
        })
        .from(modifications)
        .leftJoin(brands, sql`${brands.id} = ${origMakeId}`)
        .leftJoin(
          models,
          sql`${models.makeId} = ${origMakeId} AND ${models.modelId} = ${origModelId}`
        )
        .where(
          sql`${modifications.id} = ${origTypeId}
          AND ${modifications.makeId} = ${origMakeId}
          AND ${modifications.modelId} = ${origModelId}`
        )
        .limit(1);

      // ── Step 4: Get company products for this car ──
      const companyProducts = await db
        .select({
          assignmentId: productAssignments.id,
          isRecommended: productAssignments.isRecommended,
          notes: productAssignments.notes,
          id: products.id,
          name: products.name,
          sku: products.sku,
          brand: products.brand,
          category: products.category,
          price: products.price,
          volume: products.volume,
          specs: products.specs,
          imageUrl: products.imageUrl,
        })
        .from(productAssignments)
        .innerJoin(products, eq(productAssignments.productId, products.id))
        .where(
          and(
            eq(productAssignments.companyId, company.id),
            eq(productAssignments.makeId, origMakeId),
            eq(productAssignments.modelId, origModelId),
            eq(productAssignments.modificationId, origTypeId)
          )
        )
        .orderBy(desc(productAssignments.isRecommended));

      // ── Step 5: Log the search ──
      await logSearch({
        companyId: company.id,
        apiKey: input.apiKey,
        domain,
        makeId: input.makeId,
        modelId: input.modelId,
        modificationId: input.modificationId,
        makeName: carInfo?.makeName || null,
        modelName: carInfo?.modelName || null,
        modificationName: carInfo?.modificationName || null,
        engineCode: carInfo?.engineCode || null,
        clientIp:
          ctx.req.headers.get("x-forwarded-for") ||
          ctx.req.headers.get("x-real-ip"),
        userAgent: ctx.req.headers.get("user-agent"),
      });

      return {
        catalogOils,
        companyProducts,
        carInfo: {
          make: carInfo?.makeName || "",
          model: carInfo?.modelName || "",
          modification: carInfo?.modificationName || "",
          engineCode: carInfo?.engineCode || "",
        },
      };
    }),
});

export { generateApiKey };
