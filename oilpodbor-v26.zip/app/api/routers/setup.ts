import { z } from "zod";
import bcrypt from "bcryptjs";
import { createRouter, publicQuery } from "../middleware";

export const setupRouter = createRouter({
  seedUshakov: publicQuery
    .input(z.object({ key: z.string().optional() }))
    .mutation(async () => {
      const { createConnection } = await import("mysql2/promise");

      const url = process.env.DATABASE_URL || "";
      const m = url.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
      if (!m) throw new Error("Invalid DATABASE_URL");
      const [, user, password, host, port, database] = m;

      const conn = await createConnection({
        host, port: parseInt(port), user, password, database,
        connectTimeout: 20000,
        ssl: { rejectUnauthorized: false },
      });

      // 1. Add columns
      await conn.execute(
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(255) UNIQUE"
      ).catch(() => {});
      await conn.execute(
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS passwordHash VARCHAR(255)"
      ).catch(() => {});
      await conn.execute(
        "ALTER TABLE users MODIFY COLUMN unionId VARCHAR(255) NULL"
      ).catch(() => {});

      // 2. Seed Ushakov
      const hash = await bcrypt.hash("Ushakov1987", 12);

      await conn.execute(
        `INSERT INTO users (username, passwordHash, name, role, unionId) 
         VALUES (?, ?, ?, ?, ?) 
         ON DUPLICATE KEY UPDATE 
           passwordHash = VALUES(passwordHash),
           name = VALUES(name),
           role = VALUES(role)`,
        ["Ushakov", hash, "Ushakov", "admin", "local_ushakov"]
      );

      const [rows] = await conn.execute(
        "SELECT id, username, name, role FROM users WHERE username = ?",
        ["Ushakov"]
      );

      await conn.end();
      return { success: true, user: (rows as any[])[0] };
    }),
});
