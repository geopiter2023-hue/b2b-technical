import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import {
  vehicleTypes, steeringPositions, carBodyTypes, fuelTypes,
  transmissionTypes, viscosityClasses, liquidCategories, aggregationTrees,
} from "@db/schema";
import { eq, desc, asc } from "drizzle-orm";

// ─── Generic CRUD for reference tables ───
function createRefRouter<T extends { id: number }>(
  tableName: string,
  table: any,
  nameValidator: z.ZodString,
) {
  return createRouter({
    list: adminQuery.query(async () => {
      return getDb().select().from(table).orderBy(asc(table.sortOrder));
    }),
    create: adminQuery
      .input(z.object({ name: nameValidator, sortOrder: z.number().optional() }))
      .mutation(async ({ input }) => {
        const [result] = await getDb().insert(table).values({
          name: input.name,
          sortOrder: input.sortOrder ?? 0,
        }).$returningId();
        return { id: result.id };
      }),
    update: adminQuery
      .input(z.object({ id: z.number(), name: nameValidator, sortOrder: z.number().optional(), isActive: z.enum(["active", "inactive"]).optional() }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await getDb().update(table).set(data).where(eq(table.id, id));
        return { success: true };
      }),
    delete: adminQuery
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await getDb().delete(table).where(eq(table.id, input.id));
        return { success: true };
      }),
  });
}

// ─── Reference Routers ───
export const vehicleTypeRouter = createRefRouter("vehicleTypes", vehicleTypes, z.string().min(1).max(255));
export const steeringPositionRouter = createRefRouter("steeringPositions", steeringPositions, z.string().min(1).max(100));
export const carBodyTypeRouter = createRefRouter("carBodyTypes", carBodyTypes, z.string().min(1).max(255));
export const fuelTypeRouter = createRefRouter("fuelTypes", fuelTypes, z.string().min(1).max(100));
export const transmissionTypeRouter = createRefRouter("transmissionTypes", transmissionTypes, z.string().min(1).max(255));
export const viscosityClassRouter = createRefRouter("viscosityClasses", viscosityClasses, z.string().min(1).max(50));

// ─── Liquid Categories (with parent) ───
export const liquidCategoryRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(liquidCategories).orderBy(asc(liquidCategories.sortOrder));
  }),
  create: adminQuery
    .input(z.object({
      name: z.string().min(1),
      displayName: z.string().optional(),
      parentId: z.number().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const [result] = await getDb().insert(liquidCategories).values({
        name: input.name,
        displayName: input.displayName || input.name,
        parentId: input.parentId || null,
        sortOrder: input.sortOrder ?? 0,
      }).$returningId();
      return { id: result.id };
    }),
  update: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      displayName: z.string().optional(),
      parentId: z.number().nullable().optional(),
      sortOrder: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(liquidCategories).set(data).where(eq(liquidCategories.id, id));
      return { success: true };
    }),
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(liquidCategories).where(eq(liquidCategories.id, input.id));
      return { success: true };
    }),
});

// ─── Aggregation Trees ───
export const aggregationTreeRouter = createRouter({
  list: adminQuery.query(async () => {
    return getDb().select().from(aggregationTrees).orderBy(asc(aggregationTrees.sortOrder));
  }),
  create: adminQuery
    .input(z.object({
      name: z.string().min(1),
      parentId: z.number().optional(),
      liquidCategoryId: z.number().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const [result] = await getDb().insert(aggregationTrees).values({
        name: input.name,
        parentId: input.parentId || null,
        liquidCategoryId: input.liquidCategoryId || null,
        sortOrder: input.sortOrder ?? 0,
      }).$returningId();
      return { id: result.id };
    }),
  update: adminQuery
    .input(z.object({
      id: z.number(),
      name: z.string().min(1).optional(),
      parentId: z.number().nullable().optional(),
      liquidCategoryId: z.number().nullable().optional(),
      sortOrder: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await getDb().update(aggregationTrees).set(data).where(eq(aggregationTrees.id, id));
      return { success: true };
    }),
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await getDb().delete(aggregationTrees).where(eq(aggregationTrees.id, input.id));
      return { success: true };
    }),
});

// ─── Unified reference router ───
export const referenceRouter = createRouter({
  all: adminQuery.query(async () => {
    const db = getDb();
    const [
      vehicleTypesList,
      steeringPositionsList,
      carBodyTypesList,
      fuelTypesList,
      transmissionTypesList,
      viscosityClassesList,
      liquidCategoriesList,
      aggregationTreesList,
    ] = await Promise.all([
      db.select().from(vehicleTypes).where(eq(vehicleTypes.isActive, "active")).orderBy(asc(vehicleTypes.sortOrder)),
      db.select().from(steeringPositions).where(eq(steeringPositions.isActive, "active")).orderBy(asc(steeringPositions.sortOrder)),
      db.select().from(carBodyTypes).where(eq(carBodyTypes.isActive, "active")).orderBy(asc(carBodyTypes.sortOrder)),
      db.select().from(fuelTypes).where(eq(fuelTypes.isActive, "active")).orderBy(asc(fuelTypes.sortOrder)),
      db.select().from(transmissionTypes).where(eq(transmissionTypes.isActive, "active")).orderBy(asc(transmissionTypes.sortOrder)),
      db.select().from(viscosityClasses).where(eq(viscosityClasses.isActive, "active")).orderBy(asc(viscosityClasses.sortOrder)),
      db.select().from(liquidCategories).where(eq(liquidCategories.isActive, "active")).orderBy(asc(liquidCategories.sortOrder)),
      db.select().from(aggregationTrees).where(eq(aggregationTrees.isActive, "active")).orderBy(asc(aggregationTrees.sortOrder)),
    ]);

    return {
      vehicleTypes: vehicleTypesList,
      steeringPositions: steeringPositionsList,
      carBodyTypes: carBodyTypesList,
      fuelTypes: fuelTypesList,
      transmissionTypes: transmissionTypesList,
      viscosityClasses: viscosityClassesList,
      liquidCategories: liquidCategoriesList,
      aggregationTrees: aggregationTreesList,
    };
  }),

  vehicleType: vehicleTypeRouter,
  steeringPosition: steeringPositionRouter,
  carBodyType: carBodyTypeRouter,
  fuelType: fuelTypeRouter,
  transmissionType: transmissionTypeRouter,
  viscosityClass: viscosityClassRouter,
  liquidCategory: liquidCategoryRouter,
  aggregationTree: aggregationTreeRouter,
});
