import { z } from "zod";
import { createRouter, authedQuery, companyViewerProcedure, companyManagerProcedure } from "../middleware";
import { getDb } from "../queries/connection";
import {
  products,
  productAssignments,
  companies,
  companyUsers,
  users,
} from "@db/schema";
import { eq, and, desc, sql } from "drizzle-orm";

// Helper to check company membership
async function checkMembership(userId: number, companyId: number) {
  const db = getDb();
  const [membership] = await db
    .select()
    .from(companyUsers)
    .where(
      and(
        eq(companyUsers.companyId, companyId),
        eq(companyUsers.userId, userId)
      )
    );
  return membership;
}

// Helper to check minimum role
function checkRole(membership: { role: string } | undefined, minRole: "viewer" | "manager" | "owner") {
  if (!membership) return false;
  const hierarchy = { viewer: 1, manager: 2, owner: 3 };
  const userLevel = hierarchy[membership.role as keyof typeof hierarchy] || 0;
  const requiredLevel = hierarchy[minRole];
  return userLevel >= requiredLevel;
}

export const companyRouter = createRouter({
  // ─── Get current user's companies ───
  myCompanies: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const result = await db
      .select({
        id: companies.id,
        name: companies.name,
        slug: companies.slug,
        logo: companies.logo,
        role: companyUsers.role,
        isActive: companies.isActive,
      })
      .from(companyUsers)
      .innerJoin(companies, eq(companyUsers.companyId, companies.id))
      .where(eq(companyUsers.userId, ctx.user.id));
    return result;
  }),

  // ─── Get company details ───
  getCompany: authedQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();
      // Check membership or admin
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }

      const [company] = await db
        .select()
        .from(companies)
        .where(eq(companies.id, input.companyId));

      const members = await db
        .select({
          id: companyUsers.id,
          userId: companyUsers.userId,
          role: companyUsers.role,
          name: users.name,
          email: users.email,
        })
        .from(companyUsers)
        .innerJoin(users, eq(companyUsers.userId, users.id))
        .where(eq(companyUsers.companyId, input.companyId));

      const myMembership = ctx.user.role === "admin"
        ? { role: "admin" }
        : await checkMembership(ctx.user.id, input.companyId);

      return { company, members, myRole: myMembership?.role || "viewer" };
    }),

  // ─── List products ───
  listProducts: companyViewerProcedure
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();
      // Verify membership
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }
      return db
        .select()
        .from(products)
        .where(eq(products.companyId, input.companyId))
        .orderBy(desc(products.createdAt));
    }),

  // ─── Create product ───
  createProduct: companyManagerProcedure
    .input(
      z.object({
        companyId: z.number(),
        name: z.string().min(1),
        sku: z.string().min(1),
        brand: z.string().optional(),
        category: z.string().optional(),
        description: z.string().optional(),
        price: z.number().optional(),
        volume: z.string().optional(),
        specs: z.record(z.string(), z.any()).optional(),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      // Verify manager/owner
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership || !checkRole(membership, "manager")) {
          throw new Error("Permission denied");
        }
      }
      const { companyId, ...productData } = input;
      await db.insert(products).values({
        companyId,
        ...productData,
        brand: productData.brand || null,
        category: productData.category || null,
        description: productData.description || null,
        price: productData.price || null,
        volume: productData.volume || null,
        specs: productData.specs || null,
        imageUrl: productData.imageUrl || null,
      });
      return { success: true };
    }),

  // ─── Update product ───
  updateProduct: companyManagerProcedure
    .input(
      z.object({
        companyId: z.number(),
        id: z.number(),
        name: z.string().optional(),
        sku: z.string().optional(),
        brand: z.string().optional(),
        category: z.string().optional(),
        description: z.string().optional(),
        price: z.number().optional(),
        volume: z.string().optional(),
        specs: z.record(z.string(), z.any()).optional(),
        isActive: z.enum(["active", "inactive"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership || !checkRole(membership, "manager")) {
          throw new Error("Permission denied");
        }
      }
      const { companyId, id, ...data } = input;
      await db
        .update(products)
        .set(data)
        .where(and(eq(products.id, id), eq(products.companyId, companyId)));
      return { success: true };
    }),

  // ─── Delete product ───
  deleteProduct: companyManagerProcedure
    .input(z.object({ companyId: z.number(), id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership || !checkRole(membership, "manager")) {
          throw new Error("Permission denied");
        }
      }
      await db
        .delete(products)
        .where(and(eq(products.id, input.id), eq(products.companyId, input.companyId)));
      return { success: true };
    }),

  // ─── List assignments ───
  listAssignments: companyViewerProcedure
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }
      return db
        .select()
        .from(productAssignments)
        .where(eq(productAssignments.companyId, input.companyId))
        .orderBy(desc(productAssignments.createdAt));
    }),

  // ─── Assign product to car ───
  assignProduct: companyManagerProcedure
    .input(
      z.object({
        companyId: z.number(),
        productId: z.number(),
        makeId: z.number(),
        modelId: z.number(),
        modificationId: z.string(),
        notes: z.string().optional(),
        isRecommended: z.enum(["yes", "no"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership || !checkRole(membership, "manager")) {
          throw new Error("Permission denied");
        }
      }
      const { companyId, ...assignmentData } = input;
      await db.insert(productAssignments).values({
        companyId,
        ...assignmentData,
        notes: assignmentData.notes || null,
        isRecommended: assignmentData.isRecommended || "no",
      }).onDuplicateKeyUpdate({
        set: {
          notes: assignmentData.notes || null,
          isRecommended: assignmentData.isRecommended || "no",
        },
      });
      return { success: true };
    }),

  // ─── Delete assignment ───
  deleteAssignment: companyManagerProcedure
    .input(z.object({ companyId: z.number(), id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership || !checkRole(membership, "manager")) {
          throw new Error("Permission denied");
        }
      }
      await db
        .delete(productAssignments)
        .where(
          and(
            eq(productAssignments.id, input.id),
            eq(productAssignments.companyId, input.companyId)
          )
        );
      return { success: true };
    }),

  // ─── Get company products for a specific car ───
  getProductsForCar: companyViewerProcedure
    .input(
      z.object({
        companyId: z.number(),
        makeId: z.number(),
        modelId: z.number(),
        modificationId: z.string(),
      })
    )
    .query(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }
      const result = await db
        .select({
          assignmentId: productAssignments.id,
          isRecommended: productAssignments.isRecommended,
          notes: productAssignments.notes,
          id: products.id,
          name: products.name,
          sku: products.sku,
          brand: products.brand,
          category: products.category,
          price: products.price,
          volume: products.volume,
          specs: products.specs,
          imageUrl: products.imageUrl,
        })
        .from(productAssignments)
        .innerJoin(products, eq(productAssignments.productId, products.id))
        .where(
          and(
            eq(productAssignments.companyId, input.companyId),
            eq(productAssignments.makeId, input.makeId),
            eq(productAssignments.modelId, input.modelId),
            eq(productAssignments.modificationId, input.modificationId)
          )
        )
        .orderBy(desc(productAssignments.isRecommended));
      return result;
    }),

  // ─── Create company (for authenticated users) ───
  createCompany: authedQuery
    .input(z.object({
      name: z.string().min(1),
      slug: z.string().min(1),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      // Insert company
      const result = await db.insert(companies).values({
        name: input.name,
        slug: input.slug.toLowerCase().replace(/\s+/g, "-"),
      }).$returningId();
      const companyId = Number(result[0].id);
      // Auto-assign current user as owner
      await db.insert(companyUsers).values({
        companyId,
        userId: ctx.user.id,
        role: "owner",
      });
      return { id: companyId, success: true };
    }),

  // ─── Stats for company ───
  stats: companyViewerProcedure
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }
      const [productCount] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(products)
        .where(eq(products.companyId, input.companyId));
      const [assignmentCount] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(productAssignments)
        .where(eq(productAssignments.companyId, input.companyId));
      return {
        products: productCount.count,
        assignments: assignmentCount.count,
      };
    }),
});
