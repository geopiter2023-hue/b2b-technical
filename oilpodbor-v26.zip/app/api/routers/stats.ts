import { z } from "zod";
import { createRouter, adminQuery, companyViewerProcedure } from "../middleware";
import { getDb } from "../queries/connection";
import { searchLogs, companies, companyUsers, products, productAssignments } from "@db/schema";
import { eq, and, desc, sql, gte } from "drizzle-orm";

// Helper: check company membership
async function checkMembership(userId: number, companyId: number) {
  const db = getDb();
  const [membership] = await db
    .select()
    .from(companyUsers)
    .where(
      and(
        eq(companyUsers.companyId, companyId),
        eq(companyUsers.userId, userId)
      )
    );
  return membership;
}

export const statsRouter = createRouter({
  // ─── Overview stats for a company (used in company dashboard) ───
  overview: companyViewerProcedure
    .input(z.object({ companyId: z.number() }))
    .query(async ({ input, ctx }) => {
      const db = getDb();

      // Verify membership
      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }

      // Total searches
      const [totalSearches] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(searchLogs)
        .where(eq(searchLogs.companyId, input.companyId));

      // Searches today
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const [todaySearches] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(searchLogs)
        .where(
          and(
            eq(searchLogs.companyId, input.companyId),
            gte(searchLogs.createdAt, todayStart)
          )
        );

      // Searches this week
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - 7);
      const [weekSearches] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(searchLogs)
        .where(
          and(
            eq(searchLogs.companyId, input.companyId),
            gte(searchLogs.createdAt, weekStart)
          )
        );

      // Searches this month
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      const [monthSearches] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(searchLogs)
        .where(
          and(
            eq(searchLogs.companyId, input.companyId),
            gte(searchLogs.createdAt, monthStart)
          )
        );

      // Unique cars searched
      const [uniqueCars] = await db
        .select({
          count: sql<number>`COUNT(DISTINCT CONCAT(makeId, '-', modelId, '-', modificationId))`,
        })
        .from(searchLogs)
        .where(eq(searchLogs.companyId, input.companyId));

      // Top domains
      const topDomains = await db
        .select({
          domain: searchLogs.domain,
          count: sql<number>`COUNT(*)`,
        })
        .from(searchLogs)
        .where(eq(searchLogs.companyId, input.companyId))
        .groupBy(searchLogs.domain)
        .orderBy(desc(sql`COUNT(*)`))
        .limit(5);

      // Product count
      const [productCount] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(products)
        .where(eq(products.companyId, input.companyId));

      // Assignment count
      const [assignmentCount] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(productAssignments)
        .where(eq(productAssignments.companyId, input.companyId));

      return {
        searches: {
          total: totalSearches.count,
          today: todaySearches.count,
          thisWeek: weekSearches.count,
          thisMonth: monthSearches.count,
          uniqueCars: uniqueCars.count,
        },
        topDomains,
        products: productCount.count,
        assignments: assignmentCount.count,
      };
    }),

  // ─── Daily chart data ───
  dailyChart: companyViewerProcedure
    .input(
      z.object({
        companyId: z.number(),
        days: z.number().min(1).max(90).default(30),
      })
    )
    .query(async ({ input, ctx }) => {
      const db = getDb();

      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - input.days);
      startDate.setHours(0, 0, 0, 0);

      const rows = await db
        .select({
          date: sql<string>`DATE(createdAt)`,
          count: sql<number>`COUNT(*)`,
        })
        .from(searchLogs)
        .where(
          and(
            eq(searchLogs.companyId, input.companyId),
            gte(searchLogs.createdAt, startDate)
          )
        )
        .groupBy(sql`DATE(createdAt)`)
        .orderBy(sql`DATE(createdAt)`);

      return rows;
    }),

  // ─── Recent searches ───
  recentSearches: companyViewerProcedure
    .input(
      z.object({
        companyId: z.number(),
        limit: z.number().min(1).max(100).default(20),
      })
    )
    .query(async ({ input, ctx }) => {
      const db = getDb();

      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }

      return db
        .select({
          id: searchLogs.id,
          makeName: searchLogs.makeName,
          modelName: searchLogs.modelName,
          modificationName: searchLogs.modificationName,
          engineCode: searchLogs.engineCode,
          domain: searchLogs.domain,
          createdAt: searchLogs.createdAt,
        })
        .from(searchLogs)
        .where(eq(searchLogs.companyId, input.companyId))
        .orderBy(desc(searchLogs.createdAt))
        .limit(input.limit);
    }),

  // ─── Top searched cars ───
  topCars: companyViewerProcedure
    .input(
      z.object({
        companyId: z.number(),
        limit: z.number().min(1).max(50).default(10),
      })
    )
    .query(async ({ input, ctx }) => {
      const db = getDb();

      if (ctx.user.role !== "admin") {
        const membership = await checkMembership(ctx.user.id, input.companyId);
        if (!membership) throw new Error("Access denied");
      }

      return db
        .select({
          makeName: searchLogs.makeName,
          modelName: searchLogs.modelName,
          modificationName: searchLogs.modificationName,
          engineCode: searchLogs.engineCode,
          count: sql<number>`COUNT(*)`,
        })
        .from(searchLogs)
        .where(eq(searchLogs.companyId, input.companyId))
        .groupBy(
          searchLogs.makeName,
          searchLogs.modelName,
          searchLogs.modificationName
        )
        .orderBy(desc(sql`COUNT(*)`))
        .limit(input.limit);
    }),

  // ─── Admin: global stats ───
  global: adminQuery.query(async () => {
    const db = getDb();

    const [totalCompanies] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(companies);

    const [activeCompanies] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(companies)
      .where(eq(companies.isActive, "active"));

    const [totalSearches] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(searchLogs);

    const [totalProducts] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(products);

    const [totalAssignments] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(productAssignments);

    // Top companies by searches
    const topCompanies = await db
      .select({
        companyId: searchLogs.companyId,
        name: companies.name,
        count: sql<number>`COUNT(*)`,
      })
      .from(searchLogs)
      .innerJoin(companies, eq(searchLogs.companyId, companies.id))
      .groupBy(searchLogs.companyId)
      .orderBy(desc(sql`COUNT(*)`))
      .limit(10);

    return {
      companies: {
        total: totalCompanies.count,
        active: activeCompanies.count,
      },
      searches: totalSearches.count,
      products: totalProducts.count,
      assignments: totalAssignments.count,
      topCompanies,
    };
  }),
});
