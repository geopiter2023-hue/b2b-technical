import { z } from "zod";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { parts } from "@db/schema";
import { eq, and, asc } from "drizzle-orm";

export const partsRouter = createRouter({
  byModification: publicQuery
    .input(
      z.object({
        makeId: z.number(),
        modelId: z.number(),
        modificationId: z.string(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(parts)
        .where(
          and(
            eq(parts.makeId, input.makeId),
            eq(parts.modelId, input.modelId),
            eq(parts.modificationId, input.modificationId)
          )
        )
        .orderBy(asc(parts.itemName));
      return result;
    }),

  bySeoType: publicQuery
    .input(z.object({ seoType: z.string() }))
    .query(async () => {
      const db = getDb();
      const result = await db
        .select()
        .from(parts)
        .limit(100);
      return result;
    }),
});
