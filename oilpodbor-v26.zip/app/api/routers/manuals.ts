import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { ownerManuals } from "@db/schema";
import { eq, desc, sql, like, and } from "drizzle-orm";

export const manualsRouter = createRouter({
  // ─── List manuals with filters ───
  list: publicQuery
    .input(z.object({
      make: z.string().optional(),
      model: z.string().optional(),
      year: z.number().optional(),
      limit: z.number().min(1).max(100).default(50),
      offset: z.number().min(0).default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const filters = input || {};
      const limit = filters.limit || 50;
      const offset = filters.offset || 0;

      let conditions = [eq(ownerManuals.isActive, "active")];
      if (filters.make) conditions.push(like(ownerManuals.make, `%${filters.make}%`));
      if (filters.model) conditions.push(like(ownerManuals.model, `%${filters.model}%`));
      if (filters.year) {
        conditions.push(sql`${ownerManuals.yearFrom} <= ${filters.year}`);
        conditions.push(sql`${ownerManuals.yearTo} >= ${filters.year} OR ${ownerManuals.yearTo} IS NULL`);
      }

      const items = await db
        .select()
        .from(ownerManuals)
        .where(and(...conditions))
        .orderBy(desc(ownerManuals.createdAt))
        .limit(limit)
        .offset(offset);

      const [countResult] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(ownerManuals)
        .where(and(...conditions));

      return { items, total: countResult?.count || 0 };
    }),

  // ─── Get single manual ───
  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [item] = await db.select().from(ownerManuals).where(eq(ownerManuals.id, input.id)).limit(1);

      // Increment view count
      if (item) {
        await db.update(ownerManuals)
          .set({ viewCount: sql`${ownerManuals.viewCount} + 1` })
          .where(eq(ownerManuals.id, input.id));
      }

      return item || null;
    }),

  // ─── Find manual by car specs ───
  findByCar: publicQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      year: z.number().optional(),
      modification: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = getDb();

      let conditions = [
        eq(ownerManuals.isActive, "active"),
        like(ownerManuals.make, `%${input.make}%`),
        like(ownerManuals.model, `%${input.model}%`),
      ];

      if (input.year) {
        conditions.push(sql`${ownerManuals.yearFrom} <= ${input.year}`);
        conditions.push(sql`${ownerManuals.yearTo} >= ${input.year} OR ${ownerManuals.yearTo} IS NULL`);
      }

      const items = await db
        .select()
        .from(ownerManuals)
        .where(and(...conditions))
        .orderBy(desc(ownerManuals.isOfficial), desc(ownerManuals.createdAt))
        .limit(5);

      return items;
    }),

  // ─── Create manual entry ───
  create: adminQuery
    .input(z.object({
      make: z.string(),
      model: z.string(),
      yearFrom: z.number().optional(),
      yearTo: z.number().optional(),
      generation: z.string().optional(),
      modification: z.string().optional(),
      title: z.string().optional(),
      pdfUrl: z.string().optional(),
      pdfOriginalUrl: z.string().optional(),
      pdfSize: z.string().optional(),
      pdfPages: z.number().optional(),
      source: z.string().optional(),
      language: z.string().default("ru"),
      isOfficial: z.enum(["yes", "no"]).default("no"),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(ownerManuals).values({
        ...input,
        isActive: "active",
      }).$returningId();
      return { id: result.id };
    }),

  // ─── Update manual ───
  update: adminQuery
    .input(z.object({
      id: z.number(),
      data: z.record(z.any()),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(ownerManuals).set(input.data).where(eq(ownerManuals.id, input.id));
      return { ok: true };
    }),

  // ─── Delete (soft) ───
  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(ownerManuals).set({ isActive: "inactive" }).where(eq(ownerManuals.id, input.id));
      return { ok: true };
    }),

  // ─── Record download ───
  download: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(ownerManuals)
        .set({ downloadCount: sql`${ownerManuals.downloadCount} + 1` })
        .where(eq(ownerManuals.id, input.id));
      return { ok: true };
    }),

  // ─── Stats ───
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [total] = await db.select({ count: sql<number>`COUNT(*)` }).from(ownerManuals).where(eq(ownerManuals.isActive, "active"));
    const [official] = await db.select({ count: sql<number>`COUNT(*)` }).from(ownerManuals).where(and(eq(ownerManuals.isActive, "active"), eq(ownerManuals.isOfficial, "yes")));
    const [totalDownloads] = await db.select({ sum: sql<number>`COALESCE(SUM(downloadCount), 0)` }).from(ownerManuals);
    const [totalViews] = await db.select({ sum: sql<number>`COALESCE(SUM(viewCount), 0)` }).from(ownerManuals);

    // By make
    const byMake = await db
      .select({ make: ownerManuals.make, count: sql<number>`COUNT(*)` })
      .from(ownerManuals)
      .where(eq(ownerManuals.isActive, "active"))
      .groupBy(ownerManuals.make)
      .orderBy(desc(sql`COUNT(*)`))
      .limit(10);

    return { total: total.count, official: official.count, downloads: totalDownloads.sum, views: totalViews.sum, byMake };
  }),
});
