import { z } from "zod";
import { createRouter, adminQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { liquids } from "@db/schema";
import { eq, like, sql, asc, desc } from "drizzle-orm";

export const liquidsRouter = createRouter({
  // ─── List with filters ───
  list: adminQuery
    .input(z.object({
      search: z.string().optional(),
      categoryId: z.number().optional(),
      viscosityClassId: z.number().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
      limit: z.number().min(1).max(500).default(50),
      offset: z.number().default(0),
    }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const filters = [];

      if (input?.search) {
        filters.push(
          sql`(${liquids.name} LIKE ${`%${input.search}%`} OR ${liquids.sku} LIKE ${`%${input.search}%`} OR ${liquids.oemSpec} LIKE ${`%${input.search}%`})`
        );
      }
      if (input?.categoryId) filters.push(eq(liquids.categoryId, input.categoryId));
      if (input?.viscosityClassId) filters.push(eq(liquids.viscosityClassId, input.viscosityClassId));
      if (input?.isActive) filters.push(eq(liquids.isActive, input.isActive));

      const where = filters.length > 0 ? sql.join(filters, sql` AND `) : undefined;

      const items = await db.select().from(liquids)
        .where(where)
        .orderBy(asc(liquids.priority), asc(liquids.name))
        .limit(input?.limit || 50)
        .offset(input?.offset || 0);

      const [countResult] = await db.select({ count: sql<number>`COUNT(*)` })
        .from(liquids).where(where);

      return {
        items,
        total: countResult.count,
      };
    }),

  // ─── Get single ───
  getById: adminQuery
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [item] = await db.select().from(liquids).where(eq(liquids.id, input.id)).limit(1);
      return item || null;
    }),

  // ─── Create ───
  create: adminQuery
    .input(z.object({
      id: z.string().min(1),
      name: z.string().min(1),
      categoryId: z.number().optional(),
      aggregationTreeId: z.number().optional(),
      priority: z.number().default(0),
      volume: z.string().optional(),
      sku: z.string().optional(),
      viscosityClassId: z.number().optional(),
      viscosityName: z.string().optional(),
      oilType: z.string().optional(),
      apiSpec: z.string().optional(),
      aceaSpec: z.string().optional(),
      ilsacSpec: z.string().optional(),
      oemSpec: z.string().optional(),
      applicableVehicleTypes: z.array(z.string()).optional(),
      description: z.string().optional(),
      websiteUrl: z.string().optional(),
      imageUrl: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await getDb().insert(liquids).values({
        id: input.id,
        name: input.name,
        categoryId: input.categoryId || null,
        aggregationTreeId: input.aggregationTreeId || null,
        priority: input.priority,
        volume: input.volume || null,
        sku: input.sku || null,
        viscosityClassId: input.viscosityClassId || null,
        viscosityName: input.viscosityName || null,
        oilType: input.oilType || null,
        apiSpec: input.apiSpec || null,
        aceaSpec: input.aceaSpec || null,
        ilsacSpec: input.ilsacSpec || null,
        oemSpec: input.oemSpec || null,
        applicableVehicleTypes: input.applicableVehicleTypes ? JSON.stringify(input.applicableVehicleTypes) : null,
        description: input.description || null,
        websiteUrl: input.websiteUrl || null,
        imageUrl: input.imageUrl || null,
      });
      return { success: true };
    }),

  // ─── Update ───
  update: adminQuery
    .input(z.object({
      id: z.string(),
      name: z.string().optional(),
      categoryId: z.number().optional(),
      aggregationTreeId: z.number().optional(),
      priority: z.number().optional(),
      volume: z.string().optional(),
      sku: z.string().optional(),
      viscosityClassId: z.number().optional(),
      viscosityName: z.string().optional(),
      oilType: z.string().optional(),
      apiSpec: z.string().optional(),
      aceaSpec: z.string().optional(),
      ilsacSpec: z.string().optional(),
      oemSpec: z.string().optional(),
      applicableVehicleTypes: z.array(z.string()).optional(),
      description: z.string().optional(),
      websiteUrl: z.string().optional(),
      imageUrl: z.string().optional(),
      isActive: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const updateData: Record<string, any> = { ...data };
      if (data.applicableVehicleTypes !== undefined) {
        updateData.applicableVehicleTypes = data.applicableVehicleTypes ? JSON.stringify(data.applicableVehicleTypes) : null;
      }
      await getDb().update(liquids).set(updateData).where(eq(liquids.id, id));
      return { success: true };
    }),

  // ─── Delete ───
  delete: adminQuery
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await getDb().delete(liquids).where(eq(liquids.id, input.id));
      return { success: true };
    }),
});
