import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertUser } from "@db/schema";
import { getDb } from "./connection";
import { env } from "../lib/env";

export async function findUserByUnionId(unionId: string) {
  const rows = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.unionId, unionId))
    .limit(1);
  return rows.at(0);
}

export async function upsertUser(data: InsertUser) {
  const values = { ...data };
  const updateSet: Partial<InsertUser> = {
    lastSignInAt: new Date(),
    ...data,
  };

  // Check if this user matches the owner union ID
  const isOwner = values.unionId && values.unionId === env.ownerUnionId;

  // Check if there are any admins in the database yet
  const existingAdmins = await getDb()
    .select()
    .from(schema.users)
    .where(eq(schema.users.role, "admin"))
    .limit(1);

  const isFirstUser = existingAdmins.length === 0;

  // Grant admin if: matches OWNER_UNION_ID, or is the first user ever (bootstrap)
  if (values.role === undefined && (isOwner || isFirstUser)) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  await getDb()
    .insert(schema.users)
    .values(values)
    .onDuplicateKeyUpdate({ set: updateSet });
}
