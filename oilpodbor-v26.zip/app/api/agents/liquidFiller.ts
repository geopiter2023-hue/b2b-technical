/**
 * AI Agent: Liquid Filler
 * Fills liquid catalog based on specifications and patterns
 * Usage: npx tsx api/agents/liquidFiller.ts [--category=engine_oil] [--limit=50]
 */
import { getDb } from "../queries/connection";
import { liquids, viscosityClasses, liquidCategories } from "@db/schema";
import { sql, eq } from "drizzle-orm";

interface FillOptions {
  category?: string;
  limit?: number;
  dryRun?: boolean;
}

// ─── Liquid templates with specs ───
const liquidTemplates = [
  {
    categoryId: 1, // engine_oil
    name: "Моторное масло SINTEC Platinum 5W-30 SN/CF",
    volume: "5L",
    viscosityClassId: 6, // 5W-30
    viscosityName: "5W-30",
    oilType: "синтетика",
    apiSpec: "API SN/CF",
    aceaSpec: "ACEA A3/B4",
    oemSpec: "VW 502.00/505.00, MB 229.5, BMW LL-01",
    applicableVehicleTypes: ["Легковые"],
    description: "Полностью синтетическое моторное масло премиум-класса. Обеспечивает максимальную защиту двигателя в экстремальных условиях.",
  },
  {
    categoryId: 1,
    name: "Моторное масло SINTEC Ultra 5W-40 SN/CF",
    volume: "5L",
    viscosityClassId: 7, // 5W-40
    viscosityName: "5W-40",
    oilType: "синтетика",
    apiSpec: "API SN/CF",
    aceaSpec: "ACEA A3/B4, C3",
    oemSpec: "VW 502.00/505.01, MB 229.5, BMW LL-01, Porsche A40",
    applicableVehicleTypes: ["Легковые"],
    description: "Высокопроизводительное синтетическое масло для современных двигателей.",
  },
  {
    categoryId: 1,
    name: "Моторное масло SINTEC Standard 10W-40 SL/CF",
    volume: "5L",
    viscosityClassId: 10, // 10W-40
    viscosityName: "10W-40",
    oilType: "полусинтетика",
    apiSpec: "API SL/CF",
    aceaSpec: "ACEA A3/B3",
    oemSpec: "",
    applicableVehicleTypes: ["Легковые"],
    description: "Надёжное полусинтетическое масло для двигателей с большим пробегом.",
  },
  {
    categoryId: 5, // cooling
    name: "Антифриз SINTEC G12+ красный -40°C",
    volume: "5L",
    oilType: null,
    apiSpec: null,
    aceaSpec: null,
    oemSpec: "VW TL 774-G, MB 325.5, BMW GS 94000",
    applicableVehicleTypes: ["Легковые", "Грузовые"],
    description: "Карбоксилатный антифриз на основе этиленгликоля. Защита до -40°C.",
  },
  {
    categoryId: 6, // brake
    name: "Тормозная жидкость SINTEC DOT 4",
    volume: "0.5L",
    oilType: null,
    apiSpec: "DOT 4",
    aceaSpec: null,
    oemSpec: "SAE J1704, FMVSS 116",
    applicableVehicleTypes: ["Легковые", "Грузовые"],
    description: "Высококачественная тормозная жидкость на синтетической основе.",
  },
  {
    categoryId: 7, // power_steering
    name: "Жидкость ГУР SINTEC ATF DEXRON III",
    volume: "1L",
    oilType: null,
    apiSpec: "DEXRON III",
    aceaSpec: null,
    oemSpec: "GM 6297-M, Ford M2C138-CJ",
    applicableVehicleTypes: ["Легковые"],
    description: "Универсальная жидкость для гидроусилителей руля и автоматических трансмиссий.",
  },
  {
    categoryId: 2, // transmission
    name: "Трансмиссионное масло SINTEC ATF 6HP",
    volume: "1L",
    viscosityClassId: 16, // 75W-80
    viscosityName: "75W-80",
    oilType: "синтетика",
    apiSpec: null,
    aceaSpec: null,
    oemSpec: "ZF TE-ML 11B, 14B, 16L, 17C, 19C, 21L",
    applicableVehicleTypes: ["Легковые"],
    description: "Синтетическое трансмиссионное масло для АКПП ZF 6HP.",
  },
  {
    categoryId: 2,
    name: "Трансмиссионное масло SINTEC MTF 75W-90 GL-4/GL-5",
    volume: "1L",
    viscosityClassId: 17, // 75W-90
    viscosityName: "75W-90",
    oilType: "синтетика",
    apiSpec: "API GL-4/GL-5",
    aceaSpec: null,
    oemSpec: "",
    applicableVehicleTypes: ["Легковые", "Грузовые"],
    description: "Синтетическое масло для механических КПП и главных передач.",
  },
];

export async function runLiquidFiller(options: FillOptions = {}) {
  const db = getDb();
  const results = { created: 0, skipped: 0, errors: [] as string[] };

  console.log("[LiquidFiller] Starting...", options);

  const templates = options.category
    ? liquidTemplates.filter(t => t.categoryId === parseInt(options.category!))
    : liquidTemplates;

  const limit = options.limit || templates.length;

  for (let i = 0; i < Math.min(templates.length, limit); i++) {
    const tmpl = templates[i];
    try {
      const id = `liq_${tmpl.categoryId}_${i}`;

      // Check existing
      const [existing] = await db.select().from(liquids).where(eq(liquids.id, id)).limit(1);
      if (existing) {
        results.skipped++;
        continue;
      }

      if (options.dryRun) {
        console.log(`[DRY-RUN] Would create: ${tmpl.name}`);
        results.created++;
        continue;
      }

      await db.insert(liquids).values({
        id,
        name: tmpl.name,
        categoryId: tmpl.categoryId,
        priority: 0,
        volume: tmpl.volume,
        viscosityClassId: tmpl.viscosityClassId || null,
        viscosityName: tmpl.viscosityName || null,
        oilType: tmpl.oilType,
        apiSpec: tmpl.apiSpec,
        aceaSpec: tmpl.aceaSpec,
        oemSpec: tmpl.oemSpec,
        applicableVehicleTypes: tmpl.applicableVehicleTypes ? JSON.stringify(tmpl.applicableVehicleTypes) : null,
        description: tmpl.description,
      });

      results.created++;
    } catch (e: any) {
      results.errors.push(e.message);
    }
  }

  console.log("[LiquidFiller] Done:", results);
  return results;
}

// CLI
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const category = args.find(a => a.startsWith("--category="))?.split("=")[1];
  const limit = args.find(a => a.startsWith("--limit="))?.split("=")[1];
  const dryRun = args.includes("--dry-run");

  runLiquidFiller({ category, limit: limit ? parseInt(limit) : undefined, dryRun })
    .then(() => process.exit(0))
    .catch(e => { console.error(e); process.exit(1); });
}
