# Motornaya — Инструкция по развёртыванию на сервере

## Требования

- **Node.js 20+**
- **MySQL 8.0+** или **TiDB Cloud** (есть бесплатный тариф)
- **PM2** или **systemd** для запуска в фоне

## Быстрый старт

### 1. Распакуйте архив

```bash
unzip motornaya-v2.zip -d /var/www/
cd /var/www/app
```

### 2. Установите зависимости

```bash
npm install
```

### 3. Настройте переменные окружения

Файл `.env` уже содержит рабочие настройки подключения к базе данных TiDB. Если вы используете свою базу данных, замените `DATABASE_URL`.

```env
# База данных (обязательно)
DATABASE_URL=mysql://user:password@host:4000/database?ssl={"rejectUnauthorized":true}

# JWT секрет (обязательно)
APP_SECRET=your-secret-key-here

# OAuth (опционально, для входа через Kimi)
VITE_APP_ID=your-app-id
VITE_KIMI_AUTH_URL=https://auth.kimi.com
```

### 4. Примените миграции базы данных

```bash
npm run db:push
```

### 5. Создайте администратора (первый запуск)

Если пользователь `Ushakov` ещё не создан в базе данных, выполните:

```bash
npx tsx db/seed-admin.ts
```

Или вручную через SQL:

```sql
INSERT INTO users (username, passwordHash, name, unionId, role, createdAt, updatedAt, lastSignInAt)
VALUES (
  'Ushakov',
  '$2b$12$HeG7EFBQLwoD8TFDtbRzBeTQ2B1ouLMO86b1ZkTMjfh5PuBM8CU52',
  'Ushakov',
  'local_ushakov',
  'admin',
  NOW(), NOW(), NOW()
);
```

> **Пароль:** `Ushakov1987`

### 6. Соберите проект

```bash
npm run build
```

### 7. Запустите сервер

```bash
# Вручную
npm start

# Через PM2
pm2 start npm --name motornaya -- start

# Через systemd (см. ниже)
```

Сервер будет доступен на порту **3000**.

---

## Системные требования для подбора масла

Для работы подбора масла по автомобилю необходимо заполнить каталожные таблицы. Мы предоставляем SQL-дампы с полной базой:

- **131 марка** автомобилей
- **5459 моделей**
- **23768 модификаций**
- **27630 записей** о маслах

Запросите SQL-дампы у разработчика или загрузите свои данные в таблицы:
- `TObrands` — марки
- `TOmodels` — модели
- `TOmodifications` — модификации
- `TOoils` — рекомендуемые масла
- `TOparts` — запчасти
- `TOpartsCrosses` — кросс-номера
- `mapping` — связующая таблица

---

## Nginx (рекомендуется)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## Systemd сервис

Создайте файл `/etc/systemd/system/motornaya.service`:

```ini
[Unit]
Description=Motornaya Oil Selector
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/app
ExecStart=/usr/bin/node dist/boot.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable motornaya
sudo systemctl start motornaya
sudo systemctl status motornaya
```

---

## Данные для входа

| Поле | Значение |
|------|----------|
| **Логин** | `Ushakov` |
| **Пароль** | `Ushakov1987` |
| **Роль** | Администратор |

---

## Маршруты

| Путь | Описание |
|------|----------|
| `/` | Главная страница с подбором масла |
| `/login` | Вход по логину/паролю |
| `/admin` | Админ-панель (требует авторизации) |
| `/company` | Кабинет компании (требует авторизации) |

---

## Техническая поддержка

По вопросам развёртывания обращайтесь к разработчику.
