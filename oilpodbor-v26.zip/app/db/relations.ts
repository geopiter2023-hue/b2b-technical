// Relations can be added here if needed
// For now, we use simple queries without explicit relations
