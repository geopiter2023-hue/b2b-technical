/**
 * Seed script: create default admin user
 * Run: npx tsx db/seed-admin.ts
 */
import { createConnection } from "mysql2/promise";

const url = process.env.DATABASE_URL || "";

async function main() {
  const m = url.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
  if (!m) {
    console.error("Invalid DATABASE_URL");
    process.exit(1);
  }
  const [, user, password, host, port, database] = m;

  const conn = await createConnection({
    host,
    port: parseInt(port),
    user,
    password,
    database,
    connectTimeout: 20000,
    ssl: { rejectUnauthorized: true },
  });

  console.log("Connected to database");

  // Check if admin already exists
  const [rows] = await conn.execute(
    "SELECT id FROM users WHERE username = ?",
    ["Ushakov"]
  );

  if ((rows as any[]).length > 0) {
    console.log("Admin user 'Ushakov' already exists. Skipping.");
  } else {
    await conn.execute(
      `INSERT INTO users (username, passwordHash, name, unionId, role, createdAt, updatedAt, lastSignInAt)
       VALUES (?, ?, ?, ?, 'admin', NOW(), NOW(), NOW())`,
      [
        "Ushakov",
        "$2b$12$HeG7EFBQLwoD8TFDtbRzBeTQ2B1ouLMO86b1ZkTMjfh5PuBM8CU52",
        "Ushakov",
        "local_ushakov",
      ]
    );
    console.log("Admin user 'Ushakov' created successfully.");
    console.log("Login: Ushakov");
    console.log("Password: Ushakov1987");
  }

  await conn.end();
}

main().catch((e) => {
  console.error("Error:", e.message);
  process.exit(1);
});
