/**
 * Seed 5 AI Agents into the database
 * Run: npx tsx db/seed-agents.ts
 */
import { getDb } from "../api/queries/connection";
import { aiAgents } from "./schema";
import { eq } from "drizzle-orm";

const AGENTS = [
  {
    name: "Парсер каталога",
    slug: "catalog-parser",
    description: "Парсит базовые данные автомобилей из таблицы TOmodifications: марка, модель, поколение, двигатель, объём, мощность, тип топлива. Заполняет таблицу cars идентификационными данными.",
    category: "parser" as const,
    config: {
      sourceTable: "TOmodifications",
      targetTable: "cars",
      columns: [
        { db: "make", label: "Марка", source: "brand.name" },
        { db: "model", label: "Модель", source: "model.modelName" },
        { db: "modification", label: "Модификация", source: "modifications.name" },
        { db: "engineCode", label: "Код двигателя", source: "modifications.engineCode" },
        { db: "engineCapacity", label: "Объём двигателя", source: "modifications.engineCapacity" },
        { db: "horsePower", label: "Мощность (л.с.)", source: "modifications.horsePower" },
        { db: "fuelTypeId", label: "Тип топлива", source: "modifications.fuel" },
        { db: "yearFrom", label: "Год с", source: "modifications.startDate" },
        { db: "yearTo", label: "Год по", source: "modifications.endDate" },
      ],
    },
    schedule: "0 2 * * *",
    isActive: "paused",
  },
  {
    name: "Исследователь масел",
    slug: "oil-researcher",
    description: "Ищет данные по моторному маслу через AI и внешние API: SAE вязкость, API спецификация, ACEA, OEM допуски, объём заправки, регламент замены.",
    category: "enricher" as const,
    config: {
      dataType: "engine_oil",
      targetTable: "carFluidSpecs",
      columns: [
        { db: "engineFillVolume", label: "Объём масла (л)" },
        { db: "engineReplaceInterval", label: "Регламент замены" },
        { db: "prefOilSae", label: "SAE вязкость" },
        { db: "prefOilApi", label: "API спецификация" },
        { db: "prefOilAcea", label: "ACEA спецификация" },
        { db: "prefOilIlsac", label: "ILSAC спецификация" },
        { db: "prefOilOe", label: "OEM допуски" },
        { db: "altOilViscosities", label: "Альтернативные вязкости" },
        { db: "altOilApi", label: "Альт. API" },
        { db: "altOilAcea", label: "Альт. ACEA" },
        { db: "altOilIlsac", label: "Альт. ILSAC" },
        { db: "altOilOe", label: "Альт. OEM допуски" },
      ],
      aiPrompt: `Найди точные спецификации моторного масла для {make} {model} {engineCode} {year}:
- Объём масла (литры)
- SAE вязкость (предпочтительная и альтернативные)
- API класс (SN, SP и т.д.)
- ACEA класс (C2, C3, C5 и т.д.)
- ILSAC класс
- OEM допуски (BMW LL-04, VW 502.00/505.00, MB 229.51 и т.д.)
- Регламент замены (км/месяцы)
Верни только JSON.`,
    },
    schedule: null,
    isActive: "paused",
  },
  {
    name: "Исследователь трансмиссии",
    slug: "transmission-researcher",
    description: "Ищет данные по КПП, раздаточной коробке, переднему и заднему дифференциалам: тип, код, объём масла, спецификация, регламент замены.",
    category: "enricher" as const,
    config: {
      dataType: "transmission_drivetrain",
      targetTable: "carFluidSpecs",
      columns: [
        { db: "transmissionType", label: "Тип КПП" },
        { db: "transmissionGears", label: "Количество передач" },
        { db: "transmissionCode", label: "Код КПП" },
        { db: "transmissionFillVolume", label: "Объём масла КПП (л)" },
        { db: "transmissionPrefOil", label: "Масло КПП" },
        { db: "transmissionAltOil", label: "Альтернативное масло КПП" },
        { db: "transmissionReplaceInterval", label: "Регламент замены КПП" },
        { db: "transferCaseCode", label: "Код раздатки" },
        { db: "transferCaseFillVolume", label: "Объём масла раздатки (л)" },
        { db: "transferCaseOil", label: "Масло раздатки" },
        { db: "transferCaseInterval", label: "Регламент раздатки" },
        { db: "frontDiffCode", label: "Код переднего дифф." },
        { db: "frontDiffFillVolume", label: "Объём переднего дифф. (л)" },
        { db: "frontDiffOil", label: "Масло переднего дифф." },
        { db: "frontDiffInterval", label: "Регламент переднего дифф." },
        { db: "rearDiffCode", label: "Код заднего дифф." },
        { db: "rearDiffFillVolume", label: "Объём заднего дифф. (л)" },
        { db: "rearDiffOil", label: "Масло заднего дифф." },
        { db: "rearDiffInterval", label: "Регламент заднего дифф." },
      ],
      aiPrompt: `Найди точные спецификации для трансмиссии и привода {make} {model} {engineCode} {year}:
КПП:
- Тип (МКПП/АКПП/вариатор/робот)
- Количество передач
- Код АКПП (если есть)
- Объём масла КПП (литры)
- Спецификация масла КПП (ZF LifeguardFluid 8 и т.д.)
- Регламент замены
Раздаточная коробка:
- Код
- Объём масла (литры)
- Спецификация масла
- Регламент замены
Дифференциалы:
- Передний: объём, масло (75W-90 GL-5 и т.д.), регламент
- Задний: объём, масло, регламент
Верни только JSON.`,
    },
    schedule: null,
    isActive: "paused",
  },
  {
    name: "Исследователь жидкостей",
    slug: "fluids-researcher",
    description: "Ищет данные по техническим жидкостям: охлаждающая, тормозная, ГУР, подвеска, AdBlue — объём, тип, регламент замены.",
    category: "enricher" as const,
    config: {
      dataType: "technical_fluids",
      targetTable: "carFluidSpecs",
      columns: [
        { db: "coolantFillVolume", label: "Объём антифриза (л)" },
        { db: "coolantType", label: "Тип антифриза" },
        { db: "coolantInterval", label: "Регламент замены антифриза" },
        { db: "brakeFluidVolume", label: "Объём тормозной жидкости (л)" },
        { db: "brakeFluidType", label: "Тип тормозной жидкости" },
        { db: "brakeFluidInterval", label: "Регламент замены тормозной" },
        { db: "psFluidVolume", label: "Объём жидкости ГУР (л)" },
        { db: "psFluidType", label: "Тип жидкости ГУР" },
        { db: "suspFluidVolume", label: "Объём жидкости подвески (л)" },
        { db: "suspFluidType", label: "Тип жидкости подвески" },
        { db: "adblueVolume", label: "Объём AdBlue (л)" },
        { db: "adblueType", label: "Тип AdBlue" },
      ],
      aiPrompt: `Найди точные спецификации технических жидкостей для {make} {model} {engineCode} {year}:
Система охлаждения:
- Объём антифриза (литры)
- Тип (G12, G12+, G13, G48 и т.д.)
- Регламент замены
Тормозная система:
- Объём тормозной жидкости (литры)
- Тип (DOT 3, DOT 4, DOT 5.1)
- Регламент замены
ГУР:
- Объём жидкости (литры)
- Тип (ATF, PSF и т.д.)
Подвеска (если гидропневматическая):
- Объём жидкости (литры)
- Тип
AdBlue (для дизелей):
- Объём (литры)
- Тип
Верни только JSON.`,
    },
    schedule: null,
    isActive: "paused",
  },
  {
    name: "Исследователь фильтров",
    slug: "filters-researcher",
    description: "Ищет номера и артикулы фильтров: масляный, воздушный, салонный, топливный, фильтр АКПП. Оригинальные и аналоги.",
    category: "enricher" as const,
    config: {
      dataType: "filters",
      targetTable: "carFluidSpecs",
      columns: [
        { db: "oilFilter", label: "Масляный фильтр" },
        { db: "airFilter", label: "Воздушный фильтр" },
        { db: "cabinFilter", label: "Салонный фильтр" },
        { db: "fuelFilter", label: "Топливный фильтр" },
        { db: "transmissionFilter", label: "Фильтр АКПП" },
      ],
      aiPrompt: `Найди номера фильтров для {make} {model} {engineCode} {year}:
- Масляный фильтр (оригинальный номер + аналог Mann/Hengst/Bosch)
- Воздушный фильтр (оригинальный номер + аналог)
- Салонный фильтр (оригинальный номер + аналог)
- Топливный фильтр (оригинальный номер + аналог)
- Фильтр АКПП если применимо (оригинальный номер + аналог)
Верни только JSON.`,
    },
    schedule: null,
    isActive: "paused",
  },
  {
    name: "Поисковик руководств",
    slug: "manual-finder",
    description: "Ищет и собирает руководства по эксплуатации (PDF) для автомобилей: официальные сайты производителей, каталоги руководств, AI-поиск прямых ссылок на PDF.",
    category: "enricher" as const,
    config: {
      dataType: "owner_manuals",
      targetTable: "ownerManuals",
      columns: [
        { db: "pdfUrl", label: "Ссылка на PDF" },
        { db: "pdfOriginalUrl", label: "Оригинальная ссылка" },
        { db: "source", label: "Источник" },
        { db: "language", label: "Язык" },
        { db: "isOfficial", label: "Официальное" },
        { db: "title", label: "Название" },
      ],
      searchStrategies: [
        "Официальные сайты производителей",
        "Carmanuals.org",
        "Manuals.co",
        "Onlymanuals.com",
        "AI-генерация URL",
      ],
    },
    schedule: null,
    isActive: "paused",
  },
];

async function seedAgents() {
  const db = getDb();

  for (const agent of AGENTS) {
    const existing = await db.select().from(aiAgents).where(eq(aiAgents.slug, agent.slug)).limit(1);

    if (existing.length > 0) {
      console.log(`[seed] Agent "${agent.slug}" already exists, updating...`);
      await db.update(aiAgents)
        .set({
          name: agent.name,
          description: agent.description,
          category: agent.category,
          config: JSON.stringify(agent.config),
          schedule: agent.schedule,
        })
        .where(eq(aiAgents.slug, agent.slug));
    } else {
      console.log(`[seed] Creating agent "${agent.slug}"...`);
      await db.insert(aiAgents).values({
        name: agent.name,
        slug: agent.slug,
        description: agent.description,
        category: agent.category,
        config: JSON.stringify(agent.config),
        schedule: agent.schedule,
        isActive: agent.isActive as "active" | "paused" | "error",
      });
    }
  }

  console.log("[seed] 5 AI agents seeded successfully!");
  console.table(AGENTS.map((a) => ({ slug: a.slug, name: a.name, category: a.category, columns: a.config.columns.length })));
}

// ─── CLI ───
if (import.meta.url === `file://${process.argv[1]}`) {
  seedAgents().then(() => process.exit(0)).catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
