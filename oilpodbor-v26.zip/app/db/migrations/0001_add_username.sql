-- Add username and passwordHash columns to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(255) UNIQUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS passwordHash VARCHAR(255);
ALTER TABLE users MODIFY COLUMN unionId VARCHAR(255) NULL;
