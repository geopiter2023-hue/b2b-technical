-- Current sql file was generated after introspecting the database
-- If you want to run this migration please uncomment this code before executing migrations
/*
CREATE TABLE `TObrands` (
	`id` int,
	`name` varchar(255)
);
--> statement-breakpoint
CREATE TABLE `TOmodels` (
	`makeId` int,
	`modelId` int,
	`modelName` varchar(255),
	`yearFrom` varchar(255),
	`yearTo` varchar(255)
);
--> statement-breakpoint
CREATE TABLE `TOmodifications` (
	`id` varchar(53),
	`name` varchar(100),
	`engineCode` varchar(100),
	`constructionType` varchar(255),
	`fuel` varchar(255),
	`horsePower` varchar(255),
	`startDate` varchar(25),
	`endDate` varchar(25),
	`engineCapacity` varchar(255),
	`numberOfCylinders` varchar(255),
	`valves` varchar(255),
	`valvesTotal` varchar(255),
	`motorType` varchar(255),
	`fullName` varchar(255),
	`brand` json,
	`model` json,
	`makeId` int,
	`modelId` int
);
--> statement-breakpoint
CREATE TABLE `TOoils` (
	`makeId` int,
	`modelId` int,
	`modificationId` int,
	`catalogId` int,
	`catalogItemId` int,
	`orderPosition` int,
	`artNumber` varchar(255),
	`originalName` varchar(255),
	`volume` varchar(255),
	`commentName` varchar(255)
);
--> statement-breakpoint
CREATE TABLE `TOparts` (
	`makeId` int,
	`modelId` int,
	`modificationId` varchar(255),
	`manufacturerId` int,
	`manufacturerName` varchar(255),
	`itemName` varchar(100),
	`partNumber` varchar(255),
	`quantity` int,
	`comment` varchar(255),
	`id` int AUTO_INCREMENT NOT NULL
);
--> statement-breakpoint
CREATE TABLE `TOpartsCrosses` (
	`manufacturerName` varchar(255),
	`partNumber` varchar(255),
	`crossBrand` varchar(100),
	`crossNumber` varchar(50),
	`id` int AUTO_INCREMENT NOT NULL
);
--> statement-breakpoint
CREATE TABLE `companies` (
	`id` int unsigned AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`slug` varchar(255) NOT NULL,
	`logo` varchar(500),
	`contactEmail` varchar(320),
	`contactPhone` varchar(50),
	`isActive` enum('active','suspended','archived') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`updatedAt` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP) ON UPDATE CURRENT_TIMESTAMP
);
--> statement-breakpoint
CREATE TABLE `companyUsers` (
	`id` int unsigned AUTO_INCREMENT NOT NULL,
	`companyId` int unsigned NOT NULL,
	`userId` int unsigned NOT NULL,
	`role` enum('owner','manager','viewer') NOT NULL DEFAULT 'viewer',
	`createdAt` timestamp NOT NULL DEFAULT 'CURRENT_TIMESTAMP'
);
--> statement-breakpoint
CREATE TABLE `mapping` (
	`newMakeId` bigint unsigned NOT NULL DEFAULT 0,
	`newModelId` bigint unsigned NOT NULL DEFAULT 0,
	`newTypeId` bigint unsigned NOT NULL DEFAULT 0,
	`seoType` varchar(512),
	`makeId` int,
	`modelId` int,
	`typeId` varchar(53),
	`id` int AUTO_INCREMENT NOT NULL
);
--> statement-breakpoint
CREATE TABLE `productAssignments` (
	`id` int unsigned AUTO_INCREMENT NOT NULL,
	`companyId` int unsigned NOT NULL,
	`productId` int unsigned NOT NULL,
	`makeId` int unsigned NOT NULL,
	`modelId` int unsigned NOT NULL,
	`modificationId` varchar(53) NOT NULL,
	`notes` varchar(500),
	`isRecommended` enum('yes','no') NOT NULL DEFAULT 'no',
	`createdAt` timestamp NOT NULL DEFAULT 'CURRENT_TIMESTAMP'
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int unsigned AUTO_INCREMENT NOT NULL,
	`companyId` int unsigned NOT NULL,
	`name` varchar(255) NOT NULL,
	`sku` varchar(100) NOT NULL,
	`brand` varchar(255),
	`category` varchar(255),
	`description` text,
	`price` int,
	`currency` varchar(3) DEFAULT 'RUB',
	`volume` varchar(50),
	`specs` json,
	`imageUrl` varchar(500),
	`isActive` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`updatedAt` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP) ON UPDATE CURRENT_TIMESTAMP
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int unsigned AUTO_INCREMENT NOT NULL,
	`unionId` varchar(255),
	`name` varchar(255),
	`email` varchar(320),
	`avatar` text,
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`updatedAt` timestamp NOT NULL DEFAULT (CURRENT_TIMESTAMP) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignInAt` timestamp NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
	`passwordHash` varchar(255)
);
--> statement-breakpoint
CREATE INDEX `companies_slug_idx` ON `companies` (`slug`);--> statement-breakpoint
CREATE INDEX `companies_active_idx` ON `companies` (`isActive`);--> statement-breakpoint
CREATE INDEX `companyUsers_company_idx` ON `companyUsers` (`companyId`);--> statement-breakpoint
CREATE INDEX `companyUsers_user_idx` ON `companyUsers` (`userId`);--> statement-breakpoint
CREATE INDEX `productAssignments_company_idx` ON `productAssignments` (`companyId`);--> statement-breakpoint
CREATE INDEX `productAssignments_product_idx` ON `productAssignments` (`productId`);--> statement-breakpoint
CREATE INDEX `productAssignments_car_idx` ON `productAssignments` (`makeId`,`modelId`);--> statement-breakpoint
CREATE INDEX `products_company_idx` ON `products` (`companyId`);--> statement-breakpoint
CREATE INDEX `products_active_idx` ON `products` (`isActive`);--> statement-breakpoint
CREATE INDEX `products_category_idx` ON `products` (`category`);
*/