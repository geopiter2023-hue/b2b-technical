// ═══════════════════════════════════════════
// Stock Balance Service — WEIGHT (tonnes) + QTY (pieces) separately
// ═══════════════════════════════════════════

import * as XLSX from "xlsx";

export interface StockItem {
  ksss: string;
  oldKsss: string;
  name: string;
  nameEng: string;
  category: string;
  subcategory: string;
  direction: string;
  brand: string;
  line: string;
  subLine: string;
  type: string;
  viscosity: string;
  api: string;
  acea: string;
  ilsac: string;
  volume: string;
  packaging: string;
  weight: number;
  status: string;
  priceType: string;
  rrc: number;
  // Weight in TONNES (from ЛогЛаб + Final RC)
  weightByWarehouse: Record<string, number>;
  // Quantity in PIECES (from Дилеры)
  qtyByWarehouse: Record<string, number>;
}

const STORAGE_KEY = "b2b_stock_v3";
const STORAGE_META_KEY = "b2b_stock_meta_v3";

export function saveStockData(items: StockItem[]) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch {}
}
export function loadStockData(): StockItem[] {
  try { const d = localStorage.getItem(STORAGE_KEY); return d ? JSON.parse(d) : []; } catch { return []; }
}
export function saveStockMeta(meta: Record<string, string>) {
  try { localStorage.setItem(STORAGE_META_KEY, JSON.stringify(meta)); } catch {}
}
export function loadStockMeta(): Record<string, string> {
  try { const d = localStorage.getItem(STORAGE_META_KEY); return d ? JSON.parse(d) : {}; } catch { return {}; }
}

export function getWeightWarehouses(items: StockItem[]): string[] {
  const set = new Set<string>();
  for (const it of items) for (const wh of Object.keys(it.weightByWarehouse)) if (it.weightByWarehouse[wh] > 0) set.add(wh);
  return Array.from(set).sort();
}
export function getQtyWarehouses(items: StockItem[]): string[] {
  const set = new Set<string>();
  for (const it of items) for (const wh of Object.keys(it.qtyByWarehouse)) if (it.qtyByWarehouse[wh] > 0) set.add(wh);
  return Array.from(set).sort();
}
export function getWeightTotals(items: StockItem[]): Record<string, number> {
  const t: Record<string, number> = {};
  for (const it of items) for (const [wh, q] of Object.entries(it.weightByWarehouse)) if (q > 0) t[wh] = (t[wh] || 0) + q;
  return t;
}
export function getQtyTotals(items: StockItem[]): Record<string, number> {
  const t: Record<string, number> = {};
  for (const it of items) for (const [wh, q] of Object.entries(it.qtyByWarehouse)) if (q > 0) t[wh] = (t[wh] || 0) + q;
  return t;
}

// ═══ Parse Final (base catalog + RC weights in tonnes) ═══

export async function parseFinalFile(file: File): Promise<StockItem[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        const items: StockItem[] = [];
        for (let i = 2; i < rows.length; i++) {
          const r = rows[i];
          if (!r[0]) continue;
          const ksss = String(r[0] || "").trim();
          if (!ksss || ksss === "КССС") continue;

          const rcNames = ["РЦ Иркутск", "РЦ Калининград", "РЦ Краснодар", "РЦ Санкт-Петербург", "РЦ Солнечногорск", "РЦ Тюмень"];
          const weightByWarehouse: Record<string, number> = {};
          for (let j = 0; j < 6; j++) {
            const val = parseFloat(r[5 + j]);
            if (val > 0) weightByWarehouse[rcNames[j]] = val;
          }

          items.push({
            ksss, oldKsss: String(r[2] || "").trim(),
            name: String(r[16] || "").trim(), nameEng: String(r[15] || "").trim(),
            category: String(r[3] || "").trim(), subcategory: String(r[13] || "").trim(),
            direction: String(r[12] || "").trim(), brand: String(r[35] || "").trim(),
            line: String(r[36] || "").trim(), subLine: String(r[37] || "").trim(),
            type: String(r[38] || "").trim(), viscosity: String(r[39] || "").trim(),
            api: String(r[40] || "").trim(), acea: String(r[41] || "").trim(),
            ilsac: String(r[42] || "").trim(), volume: String(r[29] || "").trim(),
            packaging: String(r[30] || "").trim(), weight: parseFloat(r[11]) || 0,
            status: String(r[1] || "").trim(), priceType: String(r[23] || "").trim(),
            rrc: parseFloat(r[25]) || 0, weightByWarehouse, qtyByWarehouse: {},
          });
        }
        resolve(items);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Parse ЛогЛаб — WEIGHT in tonnes ═══

export async function parseLoglabFile(file: File): Promise<Map<string, Record<string, number>>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        const map = new Map<string, Record<string, number>>();
        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const ksss = String(r[2] || "").trim();
          const warehouseRaw = String(r[0] || "").trim();
          const qty = parseFloat(r[8]); // Физ остатки
          if (!ksss || isNaN(qty) || qty <= 0) continue;

          const warehouse = warehouseRaw.replace(/_\d{4}_F\d{3}/, "").trim();
          if (!map.has(ksss)) map.set(ksss, {});
          const whMap = map.get(ksss)!;
          whMap[warehouse] = (whMap[warehouse] || 0) + qty;
        }
        resolve(map);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Parse Дилеры — QUANTITY in pieces ═══

export async function parseDealerFile(file: File): Promise<Map<string, Record<string, number>>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        const map = new Map<string, Record<string, number>>();
        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const dealer = String(r[0] || "").trim();
          const name = String(r[2] || "").trim();
          const article = String(r[3] || "").trim();
          const qty = parseFloat(r[5]);
          if (!dealer || isNaN(qty) || qty <= 0) continue;

          const key = article || name;
          if (!key) continue;

          if (!map.has(key)) map.set(key, {});
          const dMap = map.get(key)!;
          dMap[dealer] = (dMap[dealer] || 0) + qty;

          if (name && name !== key) {
            if (!map.has(name)) map.set(name, {});
            const nMap = map.get(name)!;
            nMap[dealer] = (nMap[dealer] || 0) + qty;
          }
        }
        resolve(map);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Merge ═══

export function mergeStockData(
  baseItems: StockItem[],
  loglabMap: Map<string, Record<string, number>>,
  dealerMap: Map<string, Record<string, number>>
): StockItem[] {
  return baseItems.map((item) => {
    const weightByWarehouse = { ...item.weightByWarehouse };
    const qtyByWarehouse = { ...item.qtyByWarehouse };

    // Merge ЛогЛаб → WEIGHT (tonnes)
    const loglabWh = loglabMap.get(item.ksss);
    if (loglabWh) {
      for (const [wh, qty] of Object.entries(loglabWh)) {
        weightByWarehouse[wh] = (weightByWarehouse[wh] || 0) + qty;
      }
    }

    // Merge Дилеры → QUANTITY (pieces)
    let dealerWh = dealerMap.get(item.ksss);
    if (!dealerWh) dealerWh = dealerMap.get(item.name);
    if (!dealerWh) dealerWh = dealerMap.get(item.nameEng);
    if (!dealerWh && item.name.length > 10) {
      const shortName = item.name.slice(0, 30).trim();
      for (const [key, val] of dealerMap.entries()) {
        if (key.includes(shortName) || shortName.includes(key)) { dealerWh = val; break; }
      }
    }
    if (dealerWh) {
      for (const [wh, qty] of Object.entries(dealerWh)) {
        qtyByWarehouse[wh] = (qtyByWarehouse[wh] || 0) + qty;
      }
    }

    return { ...item, weightByWarehouse, qtyByWarehouse };
  });
}

// ═══ Search ═══

export function searchStock(items: StockItem[], query: string): StockItem[] {
  if (!query.trim()) return items;
  const q = query.toLowerCase();
  return items.filter((it) =>
    it.ksss.includes(q) || it.name.toLowerCase().includes(q) ||
    it.nameEng.toLowerCase().includes(q) || it.brand.toLowerCase().includes(q) ||
    it.line.toLowerCase().includes(q) || it.viscosity.toLowerCase().includes(q)
  );
}

// ═══ Export ═══

export function exportStockToExcel(items: StockItem[], weightWh: string[], qtyWh: string[]): Uint8Array {
  const headers = [
    "КССС", "Статус", "Наименование", "Направление", "Категория",
    "Бренд", "Линейка", "Вид", "Вязкость", "API", "ACEA", "ILSAC",
    "Объем", "Вес кг", "РРЦ",
    ...weightWh.map((w) => w + ", т"),
    "ВЕС ИТОГО, т",
    ...qtyWh.map((w) => w + ", шт"),
    "КОЛ-ВО ИТОГО, шт"
  ];

  const rows = items.map((it) => {
    const wValues = weightWh.map((wh) => it.weightByWarehouse[wh] || 0);
    const wTotal = wValues.reduce((s, v) => s + v, 0);
    const qValues = qtyWh.map((wh) => it.qtyByWarehouse[wh] || 0);
    const qTotal = qValues.reduce((s, v) => s + v, 0);
    return [
      it.ksss, it.status, it.name, it.direction, it.category,
      it.brand, it.line, it.type, it.viscosity, it.api, it.acea, it.ilsac,
      it.volume, it.weight, it.rrc,
      ...wValues, wTotal,
      ...qValues, qTotal
    ];
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  XLSX.utils.book_append_sheet(wb, ws, "Остатки");
  return XLSX.write(wb, { type: "array" });
}
