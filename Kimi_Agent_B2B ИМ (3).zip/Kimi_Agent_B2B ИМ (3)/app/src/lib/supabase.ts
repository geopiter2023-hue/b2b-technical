import { createClient } from "@supabase/supabase-js";

// Priority: 1) window object (runtime) 2) import.meta.env (build time)
const supabaseUrl =
  (typeof window !== "undefined" && (window as any).SUPABASE_URL) ||
  (import.meta as any).env?.VITE_SUPABASE_URL ||
  "";

const supabaseAnonKey =
  (typeof window !== "undefined" && (window as any).SUPABASE_KEY) ||
  (import.meta as any).env?.VITE_SUPABASE_ANON_KEY ||
  "";

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("[Supabase] Missing URL or KEY. Add to index.html:\n<script>window.SUPABASE_URL='...';window.SUPABASE_KEY='...';</script>");
}

export const supabase = createClient(supabaseUrl || "https://placeholder.supabase.co", supabaseAnonKey || "placeholder");
