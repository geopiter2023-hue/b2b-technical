import {
  pgTable,
  serial,
  varchar,
  text,
  timestamp,
  integer,
  date,
  decimal,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  login: varchar("login", { length: 255 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  role: varchar("role", { length: 50 }).notNull().default("user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 500 }).notNull(),
  description: text("description"),
  status: varchar("status", { length: 50 }).notNull().default("not_started"),
  priority: varchar("priority", { length: 50 }).notNull().default("medium"),
  assignee: varchar("assignee", { length: 255 }),
  executor: varchar("executor", { length: 255 }),
  startDate: date("start_date"),
  endDate: date("end_date"),
  complexity: integer("complexity").default(1),
  budget: decimal("budget", { precision: 12, scale: 2 }),
  progress: integer("progress").default(0),
  notes: text("notes"),
  category: varchar("category", { length: 255 }),
  sourceId: varchar("source_id", { length: 50 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
