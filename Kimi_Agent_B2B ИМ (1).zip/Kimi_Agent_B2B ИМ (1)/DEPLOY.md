# B2B Task Manager - Supabase версия (Frontend-only)

## Что изменилось

**БЕЗ Node.js сервера!** Frontend напрямую работает с Supabase REST API через `@supabase/supabase-js`.

```
Browser (React) → Supabase REST API → PostgreSQL
```

## Шаг 1: Настройка Supabase

### 1.1 Создайте проект
1. Зайдите на [supabase.com](https://supabase.com)
2. New Project → выберите регион (ближе к вам)
3. Запомните **Project URL** и **anon/public key**

### 1.2 Создайте таблицы

В SQL Editor выполните:

```sql
-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  login VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'user',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Таблица задач
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  name VARCHAR(500) NOT NULL,
  description TEXT,
  status VARCHAR(50) DEFAULT 'not_started',
  priority VARCHAR(50) DEFAULT 'medium',
  assignee VARCHAR(255),
  executor VARCHAR(255),
  start_date DATE,
  end_date DATE,
  complexity INTEGER DEFAULT 1,
  budget DECIMAL(12,2),
  progress INTEGER DEFAULT 0,
  notes TEXT,
  category VARCHAR(255),
  source_id VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Таблица комментариев (чат)
CREATE TABLE IF NOT EXISTS task_comments (
  id SERIAL PRIMARY KEY,
  task_id INTEGER NOT NULL,
  user_name VARCHAR(255) DEFAULT 'B2B',
  message TEXT NOT NULL,
  image_url TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Создаем пользователя B2B (пароль: B2B)
-- Хеш пароля "B2B" через bcrypt
INSERT INTO users (login, password_hash, role) VALUES (
  'B2B',
  '$2a$10$YourHashHere',
  'admin'
) ON CONFLICT (login) DO NOTHING;
```

### 1.3 Настройте Row Level Security (RLS)

В каждой таблице включите RLS и дайте права anon:

```sql
-- Tasks: разрешаем чтение и запись для всех
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow all" ON tasks FOR ALL USING (true) WITH CHECK (true);

-- Task comments: разрешаем всё для всех
ALTER TABLE task_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow all" ON task_comments FOR ALL USING (true) WITH CHECK (true);

-- Users: разрешаем чтение
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow select" ON users FOR SELECT USING (true);
```

### 1.4 Создайте пользователя для входа (через Supabase Auth)

В Dashboard → Authentication → Users → Add User:
- Email: `b2b@lukoil.ru`
- Password: `B2B`

## Шаг 2: Настройте frontend

### 2.1 Обновите index.html

Откройте `public_html/index.html` и в `<head>` замените:

```html
<script>
  window.API_URL = "https://your-project.supabase.co";
  window.API_KEY = "your-anon-key";
</script>
```

Или используйте `.env` файл перед сборкой:

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

### 2.2 Загрузите на сервер

Загрузите содержимое `dist/public/` в `public_html/` на beget через FTP.

## Готово!

Вход: логин `B2B`, пароль `B2B`
