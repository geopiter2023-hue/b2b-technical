# B2B Task Manager - Готовый архив для деплоя

## Структура архива

```
b2b-deploy/
├── public_html/          ← ЗАГРУЗИТЬ НА BEGET (frontend)
│   ├── index.html
│   ├── assets/
│   ├── favicon.ico
│   └── manifest.json
│
└── backend/              ← ЗАГРУЗИТЬ НА RENDER (backend)
    ├── boot.js           ← Главный файл сервера
    ├── package.json
    ├── package-lock.json
    ├── db/
    ├── deploy.sh
    └── .env
```

---

## БЫСТРЫЙ СТАРТ (3 шага)

### Шаг 1 - Supabase (База данных)

1. Зайдите на https://supabase.com
2. Создайте проект
3. Settings → Database → Connection string
4. Скопируйте: `postgresql://postgres:PASSWORD@db.xxx.supabase.co:5432/postgres`

### Шаг 2 - Render.com (Backend)

1. Зайдите на https://render.com → Sign Up (GitHub)
2. Dashboard → New → Web Service
3. Upload ZIP → выберите папку `backend/` из этого архива
4. В Environment добавьте:
   ```
   DATABASE_URL=postgresql://postgres:ВАШ_ПАРОЛЬ@db.xxx.supabase.co:5432/postgres
   SECRET_KEY=любой_длинный_ключ_минимум_20_символов
   NODE_ENV=production
   ```
5. Create Web Service → ждите 2-3 минуты
6. Получите URL вида: `https://b2b-api-xxx.onrender.com`
7. Запомните этот URL!

### Шаг 3 - Beget (Frontend)

1. Зайдите в FTP beget
2. Очистите `public_html/`
3. Загрузите содержимое папки `public_html/` из архива
4. Откройте `index.html` на компьютере
5. Найдите строку:
   ```html
   <!-- API URL: замените на ваш backend -->
   <script>
     // window.API_URL = "https://your-backend.onrender.com/api/trpc";
   </script>
   ```
6. Раскомментируйте и замените:
   ```html
   <script>
     window.API_URL = "https://b2b-api-xxx.onrender.com/api/trpc";
   </script>
   ```
7. Перезагрузите `index.html` на сервер

---

## Создание таблиц в базе

На Render (Shell tab в дашборде):
```bash
cd /opt/render/project/src
npx drizzle-kit push
npx tsx db/seed.ts
```

---

## Проверка

1. Backend health: `https://b2b-api-xxx.onrender.com/health`
2. Login: POST `https://b2b-api-xxx.onrender.com/api/trpc/auth.login`
3. Frontend: `https://b2b-technical.ru`

---

## Данные для входа
- Логин: `B2B`
- Пароль: `B2B`

