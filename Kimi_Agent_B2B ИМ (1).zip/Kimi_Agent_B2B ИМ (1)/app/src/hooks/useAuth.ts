import { useState, useEffect, useCallback } from "react";
import { getCurrentUser, logoutUser } from "@/services/authService";

export interface AuthUser {
  id: string;
  login: string;
  role: string;
}

export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    getCurrentUser().then((u) => {
      if (mounted) {
        setUser(u);
        setIsLoading(false);
      }
    }).catch(() => {
      if (mounted) setIsLoading(false);
    });
    return () => { mounted = false; };
  }, []);

  const login = useCallback((token: string, newUser: AuthUser) => {
    if (token) localStorage.setItem("sb_session", token);
    setUser(newUser);
  }, []);

  const logout = useCallback(async () => {
    await logoutUser();
    localStorage.removeItem("sb_session");
    setUser(null);
    window.location.reload();
  }, []);

  return { user, isLoading, login, logout, isAuthenticated: !!user };
}
