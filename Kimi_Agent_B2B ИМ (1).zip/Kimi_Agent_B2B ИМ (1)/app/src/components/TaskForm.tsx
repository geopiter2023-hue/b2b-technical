import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { createTask, updateTask } from "@/services/taskService";
import TaskChat from "./TaskChat";

interface TaskFormData {
  id?: number;
  name: string;
  description: string;
  status: string;
  priority: string;
  assignee: string;
  executor: string;
  startDate: string;
  endDate: string;
  complexity: number;
  budget: string;
  progress: number;
  notes: string;
}

const statusOptions = [
  { value: "not_started", label: "Не начата" },
  { value: "planning", label: "В планировании" },
  { value: "in_progress", label: "В работе" },
  { value: "review", label: "На проверке" },
  { value: "completed", label: "Завершена" },
  { value: "cancelled", label: "Отменена" },
];

const priorityOptions = [
  { value: "low", label: "Низкий" },
  { value: "medium", label: "Средний" },
  { value: "high", label: "Высокий" },
  { value: "critical", label: "Критичный" },
];

interface TaskFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialData?: any;
  onSubmit: () => void;
}

export default function TaskForm({ open, onOpenChange, initialData, onSubmit }: TaskFormProps) {
  const [form, setForm] = useState<TaskFormData>({
    name: "",
    description: "",
    status: "not_started",
    priority: "medium",
    assignee: "",
    executor: "",
    startDate: "",
    endDate: "",
    complexity: 2,
    budget: "",
    progress: 0,
    notes: "",
  });

  useEffect(() => {
    if (initialData) {
      setForm({
        name: initialData.name || "",
        description: initialData.description || "",
        status: initialData.status || "not_started",
        priority: initialData.priority || "medium",
        assignee: initialData.assignee || "",
        executor: initialData.executor || "",
        startDate: initialData.start_date || initialData.startDate || "",
        endDate: initialData.end_date || initialData.endDate || "",
        complexity: initialData.complexity || 2,
        budget: initialData.budget || "",
        progress: initialData.progress || 0,
        notes: initialData.notes || "",
      });
    } else {
      setForm({
        name: "", description: "", status: "not_started", priority: "medium",
        assignee: "", executor: "", startDate: "", endDate: "",
        complexity: 2, budget: "", progress: 0, notes: "",
      });
    }
  }, [initialData, open]);

  const handleChange = (field: keyof TaskFormData, value: string | number) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (initialData?.id) {
        await updateTask(initialData.id, form);
      } else {
        await createTask(form);
      }
      onOpenChange(false);
      onSubmit();
    } catch (err: any) {
      console.error("Error saving task:", err);
      alert("Ошибка сохранения: " + err.message);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={initialData?.id ? "max-w-5xl max-h-[95vh] overflow-y-auto w-[calc(100vw-1rem)]" : "max-w-2xl max-h-[90vh] overflow-y-auto w-[calc(100vw-2rem)]"}>
        <DialogHeader>
          <DialogTitle>{initialData?.id ? "Редактировать задачу" : "Новая задача"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="name">Название *</Label>
              <Input id="name" value={form.name} onChange={(e) => handleChange("name", e.target.value)} required />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Описание</Label>
              <Textarea id="description" value={form.description} onChange={(e) => handleChange("description", e.target.value)} rows={3} />
            </div>
            <div className="space-y-2">
              <Label>Статус</Label>
              <Select value={form.status} onValueChange={(v) => handleChange("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{statusOptions.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Приоритет</Label>
              <Select value={form.priority} onValueChange={(v) => handleChange("priority", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{priorityOptions.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="assignee">Ответственный</Label>
              <Input id="assignee" value={form.assignee} onChange={(e) => handleChange("assignee", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="executor">Исполнитель</Label>
              <Input id="executor" value={form.executor} onChange={(e) => handleChange("executor", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="startDate">Дата начала</Label>
              <Input id="startDate" type="date" value={form.startDate} onChange={(e) => handleChange("startDate", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Дата окончания</Label>
              <Input id="endDate" type="date" value={form.endDate} onChange={(e) => handleChange("endDate", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="complexity">Сложность (1-5)</Label>
              <Input id="complexity" type="number" min={1} max={5} value={form.complexity} onChange={(e) => handleChange("complexity", parseInt(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budget">Бюджет (руб)</Label>
              <Input id="budget" type="number" min={0} value={form.budget} onChange={(e) => handleChange("budget", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="progress">Прогресс (%)</Label>
              <Input id="progress" type="number" min={0} max={100} value={form.progress} onChange={(e) => handleChange("progress", parseInt(e.target.value))} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="notes">Примечания</Label>
              <Textarea id="notes" value={form.notes} onChange={(e) => handleChange("notes", e.target.value)} rows={2} />
            </div>
          </div>
          <div className="flex flex-col sm:flex-row justify-end gap-3 pt-4">
            <Button type="button" variant="outline" className="w-full sm:w-auto" onClick={() => onOpenChange(false)}>Отмена</Button>
            <Button type="submit" className="w-full sm:w-auto bg-red-700 hover:bg-red-800">Сохранить</Button>
          </div>
        </form>

        {initialData?.id && (
          <div className="mt-2">
            <TaskChat taskId={initialData.id} />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
