import { createTRPCReact } from "@trpc/react-query";
import { httpLink } from "@trpc/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import superjson from "superjson";
import type { AppRouter } from "../../api/router";
import type { ReactNode } from "react";

export const trpc = createTRPCReact<AppRouter>();

const queryClient = new QueryClient();

// API URL: from window.API_URL (set in index.html) or env or default to same-origin
const API_URL = (typeof window !== "undefined" && (window as any).API_URL) 
  || import.meta.env.VITE_API_URL 
  || "/api/trpc";

const trpcClient = trpc.createClient({
  links: [
    httpLink({
      url: API_URL,
      transformer: superjson,
      headers() {
        const token = localStorage.getItem("auth_token");
        return token ? { "x-auth-token": token } : {};
      },
      fetch(input, init) {
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        });
      },
    }),
  ],
});

export function TRPCProvider({ children }: { children: ReactNode }) {
  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </trpc.Provider>
  );
}
