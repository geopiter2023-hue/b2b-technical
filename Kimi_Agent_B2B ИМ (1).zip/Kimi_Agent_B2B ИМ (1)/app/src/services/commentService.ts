import { supabase } from "@/lib/supabase";

export interface Comment {
  id: number;
  task_id: number;
  user_name: string;
  message: string;
  image_url: string | null;
  created_at: string;
}

export async function listComments(taskId: number) {
  const { data, error } = await supabase
    .from("task_comments")
    .select("*")
    .eq("task_id", taskId)
    .order("created_at", { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as Comment[];
}

export async function createComment(
  taskId: number,
  message: string,
  imageUrl?: string,
  userName: string = "B2B"
) {
  const { data, error } = await supabase
    .from("task_comments")
    .insert({
      task_id: taskId,
      user_name: userName,
      message: message || " ",
      image_url: imageUrl || null,
    })
    .select("id")
    .single();

  if (error) throw new Error(error.message);
  return data;
}

export async function deleteComment(id: number) {
  const { error } = await supabase.from("task_comments").delete().eq("id", id);
  if (error) throw new Error(error.message);
}
