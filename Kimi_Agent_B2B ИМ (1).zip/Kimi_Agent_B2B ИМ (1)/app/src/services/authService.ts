import { supabase } from "@/lib/supabase";

function toEmail(login: string): string {
  if (login.includes("@")) return login;
  return `${login.toLowerCase()}@lukoil.ru`;
}

export async function loginUser(login: string, password: string) {
  const email = toEmail(login);

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error || !data.user) {
    throw new Error("INVALID_CREDENTIALS");
  }

  return {
    token: data.session?.access_token || "",
    user: {
      id: data.user.id,
      login: login,
      role: data.user.user_metadata?.role || "user",
    },
  };
}

export async function logoutUser() {
  await supabase.auth.signOut();
}

export async function getCurrentUser() {
  const { data } = await supabase.auth.getSession();
  if (!data.session) return null;

  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user) return null;

  return {
    id: userData.user.id,
    login: userData.user.email?.split("@")[0] || "B2B",
    role: userData.user.user_metadata?.role || "user",
  };
}
