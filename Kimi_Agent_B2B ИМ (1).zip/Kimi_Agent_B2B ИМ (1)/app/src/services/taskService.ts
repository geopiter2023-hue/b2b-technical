import { supabase } from "@/lib/supabase";

export interface Task {
  id: number;
  name: string;
  description: string | null;
  status: string;
  priority: string;
  assignee: string | null;
  executor: string | null;
  start_date: string | null;
  end_date: string | null;
  complexity: number | null;
  budget: string | null;
  progress: number | null;
  notes: string | null;
  category: string | null;
  source_id: string | null;
  created_at: string;
  updated_at: string;
}

export type TaskFilters = {
  status?: string;
  priority?: string;
  assignee?: string;
  search?: string;
};

export async function listTasks(
  filters: TaskFilters = {},
  sortBy: string = "created_at",
  sortOrder: "asc" | "desc" = "desc",
  page: number = 1,
  limit: number = 10
) {
  let query = supabase.from("tasks").select("*", { count: "exact" });

  if (filters.status && filters.status !== "all") {
    query = query.eq("status", filters.status);
  }
  if (filters.priority && filters.priority !== "all") {
    query = query.eq("priority", filters.priority);
  }
  if (filters.assignee && filters.assignee !== "all") {
    query = query.eq("assignee", filters.assignee);
  }
  if (filters.search) {
    query = query.or(`name.ilike.%${filters.search}%,assignee.ilike.%${filters.search}%`);
  }

  query = query.order(sortBy, { ascending: sortOrder === "asc" });
  query = query.range((page - 1) * limit, page * limit - 1);

  const { data, error, count } = await query;
  if (error) throw new Error(error.message);

  return {
    list: (data || []) as Task[],
    total: count || 0,
    page,
    limit,
  };
}

export async function getTask(id: number) {
  const { data, error } = await supabase
    .from("tasks")
    .select("*")
    .eq("id", id)
    .single();
  if (error) throw new Error(error.message);
  return data as Task;
}

export async function createTask(taskData: any) {
  const { data, error } = await supabase
    .from("tasks")
    .insert({
      name: taskData.name,
      description: taskData.description || null,
      status: taskData.status || "not_started",
      priority: taskData.priority || "medium",
      assignee: taskData.assignee || null,
      executor: taskData.executor || null,
      start_date: taskData.startDate || null,
      end_date: taskData.endDate || null,
      complexity: taskData.complexity ?? 2,
      budget: taskData.budget || null,
      progress: taskData.progress ?? 0,
      notes: taskData.notes || null,
      category: taskData.category || null,
      source_id: taskData.sourceId || null,
    })
    .select("id")
    .single();
  if (error) throw new Error(error.message);
  return data;
}

export async function updateTask(id: number, taskData: any) {
  const updateData: any = {};
  if (taskData.name !== undefined) updateData.name = taskData.name;
  if (taskData.description !== undefined) updateData.description = taskData.description || null;
  if (taskData.status !== undefined) updateData.status = taskData.status;
  if (taskData.priority !== undefined) updateData.priority = taskData.priority;
  if (taskData.assignee !== undefined) updateData.assignee = taskData.assignee || null;
  if (taskData.executor !== undefined) updateData.executor = taskData.executor || null;
  if (taskData.startDate !== undefined) updateData.start_date = taskData.startDate || null;
  if (taskData.endDate !== undefined) updateData.end_date = taskData.endDate || null;
  if (taskData.complexity !== undefined) updateData.complexity = taskData.complexity;
  if (taskData.budget !== undefined) updateData.budget = taskData.budget || null;
  if (taskData.progress !== undefined) updateData.progress = taskData.progress;
  if (taskData.notes !== undefined) updateData.notes = taskData.notes || null;

  const { error } = await supabase.from("tasks").update(updateData).eq("id", id);
  if (error) throw new Error(error.message);
}

export async function deleteTask(id: number) {
  const { error } = await supabase.from("tasks").delete().eq("id", id);
  if (error) throw new Error(error.message);
}

export async function getTaskStats() {
  const { data, error } = await supabase.from("tasks").select("*");
  if (error) throw new Error(error.message);
  const tasks = data as Task[];
  return {
    total: tasks.length,
    inProgress: tasks.filter((t) => t.status === "in_progress").length,
    done: tasks.filter((t) => t.status === "completed").length,
    overdue: tasks.filter(
      (t) =>
        t.end_date &&
        new Date(t.end_date) < new Date() &&
        t.status !== "completed" &&
        t.status !== "cancelled"
    ).length,
  };
}

export async function getAssignees() {
  const { data, error } = await supabase
    .from("tasks")
    .select("assignee")
    .not("assignee", "is", null);
  if (error) throw new Error(error.message);
  const unique = Array.from(new Set(data.map((a: any) => a.assignee)));
  return unique;
}
