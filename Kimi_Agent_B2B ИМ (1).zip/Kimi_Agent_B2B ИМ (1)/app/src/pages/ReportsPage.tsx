import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Layout from "@/components/Layout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, FileText, ArrowLeft } from "lucide-react";
import { Link } from "react-router";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { listTasks, type Task } from "@/services/taskService";

const statusMap: Record<string, string> = {
  not_started: "Не начата",
  planning: "В планировании",
  in_progress: "В работе",
  review: "На проверке",
  completed: "Завершена",
  cancelled: "Отменена",
};

const priorityMap: Record<string, string> = {
  low: "Низкий",
  medium: "Средний",
  high: "Высокий",
  critical: "Критичный",
};

export default function ReportsPage() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    const filters = statusFilter === "all" ? {} : { status: statusFilter };
    listTasks(filters, undefined, undefined, 1, 200)
      .then((data) => setTasks(data.list))
      .catch(console.error);
  }, [statusFilter]);

  const handleExportPdf = () => {
    try {
      const doc = new jsPDF("l", "mm", "a4");
      doc.setFontSize(16);
      doc.text("Отчет по задачам B2B", 14, 20);
      doc.setFontSize(10);
      doc.text(`Дата формирования: ${new Date().toLocaleDateString("ru-RU")}`, 14, 30);
      doc.text(`Всего задач: ${tasks.length}`, 14, 38);

      const body = tasks.map((t) => [
        t.id, t.name, statusMap[t.status] || t.status, priorityMap[t.priority] || t.priority,
        t.assignee || "—", t.executor || "—",
        t.start_date ? new Date(t.start_date).toLocaleDateString("ru-RU") : "—",
        t.end_date ? new Date(t.end_date).toLocaleDateString("ru-RU") : "—",
        t.complexity || "—", t.budget ? `${t.budget} RUB` : "—", `${t.progress || 0}%`,
      ]);

      autoTable(doc, {
        head: [["ID", "Название", "Статус", "Приоритет", "Ответственный", "Исполнитель", "Начало", "Окончание", "Сложность", "Бюджет", "Прогресс"]],
        body,
        startY: 45,
        styles: { fontSize: 8, cellPadding: 2 },
        headStyles: { fillColor: [185, 28, 28], textColor: 255 },
        alternateRowStyles: { fillColor: [249, 250, 251] },
      });

      doc.save("b2b_tasks_report.pdf");
    } catch (err) {
      console.error("PDF export error:", err);
      alert("Ошибка при создании PDF");
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Link to="/"><Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button></Link>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Отчеты и экспорт</h1>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]"><SelectValue placeholder="Все статусы" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все статусы</SelectItem>
                {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button className="bg-red-700 hover:bg-red-800" onClick={handleExportPdf}><Download className="h-4 w-4 mr-2" />Экспорт PDF</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-red-700" />PDF отчет</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">Полный отчет по всем задачам в формате PDF с таблицей, фильтрами и статусами.</p>
              <Button variant="outline" className="w-full border-red-700 text-red-700 hover:bg-red-50" onClick={handleExportPdf}><Download className="h-4 w-4 mr-2" />Скачать PDF</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-emerald-600" />Сводка</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-gray-600">Всего задач:</span><span className="font-semibold">{tasks.length}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">В работе:</span><span className="font-semibold text-red-700">{tasks.filter((t) => t.status === "in_progress").length}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Завершено:</span><span className="font-semibold text-emerald-700">{tasks.filter((t) => t.status === "completed").length}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Просрочено:</span><span className="font-semibold text-red-700">{tasks.filter((t) => t.end_date && new Date(t.end_date) < new Date() && t.status !== "completed" && t.status !== "cancelled").length}</span></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-amber-600" />Диаграмма Ганта</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">Визуальное представление задач по временной шкале. Экспортируйте в PDF.</p>
              <Link to="/gantt"><Button variant="outline" className="w-full border-amber-600 text-amber-600 hover:bg-amber-50">Перейти к Ганту</Button></Link>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle>Предпросмотр данных</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left">ID</th>
                    <th className="px-4 py-2 text-left">Название</th>
                    <th className="px-4 py-2 text-left">Статус</th>
                    <th className="px-4 py-2 text-left">Приоритет</th>
                    <th className="px-4 py-2 text-left">Ответственный</th>
                    <th className="px-4 py-2 text-left">Даты</th>
                    <th className="px-4 py-2 text-left">Прогресс</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.slice(0, 15).map((task) => (
                    <tr key={task.id} className="border-t hover:bg-gray-50">
                      <td className="px-4 py-2">{task.id}</td>
                      <td className="px-4 py-2 max-w-[300px] truncate">{task.name}</td>
                      <td className="px-4 py-2">{statusMap[task.status] || task.status}</td>
                      <td className="px-4 py-2">{priorityMap[task.priority] || task.priority}</td>
                      <td className="px-4 py-2">{task.assignee || "—"}</td>
                      <td className="px-4 py-2">
                        {task.start_date ? new Date(task.start_date).toLocaleDateString("ru-RU") : "—"} — {task.end_date ? new Date(task.end_date).toLocaleDateString("ru-RU") : "—"}
                      </td>
                      <td className="px-4 py-2">{task.progress || 0}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {tasks.length > 15 && <p className="text-center text-sm text-gray-500 py-4">... и еще {tasks.length - 15} задач</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
