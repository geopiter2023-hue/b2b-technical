import { useState, useEffect, useMemo, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  ClipboardList,
  Clock,
  CheckCircle,
  AlertTriangle,
  Plus,
  Download,
  Pencil,
  Trash2,
  Search,
  ArrowUpDown,
} from "lucide-react";
import TaskForm from "@/components/TaskForm";
import Layout from "@/components/Layout";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  listTasks,
  getTaskStats,
  deleteTask,
  type Task,
} from "@/services/taskService";

const statusMap: Record<string, { label: string; color: string }> = {
  not_started: { label: "Не начата", color: "bg-gray-100 text-gray-600" },
  planning: { label: "В планировании", color: "bg-amber-50 text-amber-700" },
  in_progress: { label: "В работе", color: "bg-red-50 text-red-700" },
  review: { label: "На проверке", color: "bg-purple-50 text-purple-700" },
  completed: { label: "Завершена", color: "bg-emerald-50 text-emerald-700" },
  cancelled: { label: "Отменена", color: "bg-red-50 text-red-700" },
};

const priorityMap: Record<string, { label: string; color: string }> = {
  low: { label: "Низкий", color: "bg-gray-100 text-gray-600" },
  medium: { label: "Средний", color: "bg-amber-50 text-amber-700" },
  high: { label: "Высокий", color: "bg-red-50 text-red-700" },
  critical: { label: "Критичный", color: "bg-red-100 text-red-800" },
};

export default function Dashboard() {
  const [filters, setFilters] = useState({
    status: "all",
    priority: "all",
    assignee: "all",
    search: "",
  });
  const [sortBy, setSortBy] = useState("created_at");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [stats, setStats] = useState({ total: 0, inProgress: 0, done: 0, overdue: 0 });
  const [tasksData, setTasksData] = useState<{ list: Task[]; total: number }>({ list: [], total: 0 });
  const [isLoading, setIsLoading] = useState(true);

  const fetchTasks = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await listTasks(
        {
          status: filters.status,
          priority: filters.priority,
          assignee: filters.assignee,
          search: filters.search,
        },
        sortBy,
        sortOrder,
        page,
        10
      );
      setTasksData(data);
    } catch (err: any) {
      console.error("Error loading tasks:", err);
    } finally {
      setIsLoading(false);
    }
  }, [filters, sortBy, sortOrder, page]);

  const fetchStats = useCallback(async () => {
    try {
      const data = await getTaskStats();
      setStats(data);
    } catch (err: any) {
      console.error("Error loading stats:", err);
    }
  }, []);

  useEffect(() => {
    fetchTasks();
    fetchStats();
  }, [fetchTasks, fetchStats]);

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortOrder("asc");
    }
  };

  const handleExport = () => {
    const list = tasksData.list;
    let csv = "ID;Название;Статус;Приоритет;Ответственный;Исполнитель;Дата начала;Дата окончания;Сложность;Бюджет;Прогресс\n";
    for (const t of list) {
      const status = statusMap[t.status]?.label || t.status;
      const priority = priorityMap[t.priority]?.label || t.priority;
      csv += `${t.id};"${t.name.replace(/"/g, '""')}";${status};${priority};${t.assignee || ""};${t.executor || ""};${t.start_date || ""};${t.end_date || ""};${t.complexity || ""};${t.budget || ""};${t.progress || 0}%\n`;
    }
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tasks_export.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteTask(deleteId);
      setDeleteId(null);
      fetchTasks();
      fetchStats();
    } catch (err: any) {
      console.error("Error deleting task:", err);
    }
  };

  const uniqueAssignees = useMemo(() => {
    const list = tasksData.list;
    return Array.from(new Set(list.map((t) => t.assignee).filter(Boolean)));
  }, [tasksData]);

  return (
    <Layout>
      <div className="space-y-4 md:space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
          <Card>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-red-50 rounded-lg">
                <ClipboardList className="h-5 w-5 md:h-6 md:w-6 text-red-700" />
              </div>
              <div>
                <p className="text-xs md:text-sm text-gray-500">Всего задач</p>
                <p className="text-xl md:text-2xl font-bold text-red-700">{stats.total}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-amber-50 rounded-lg">
                <Clock className="h-5 w-5 md:h-6 md:w-6 text-amber-600" />
              </div>
              <div>
                <p className="text-xs md:text-sm text-gray-500">В работе</p>
                <p className="text-xl md:text-2xl font-bold text-amber-600">{stats.inProgress}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-emerald-50 rounded-lg">
                <CheckCircle className="h-5 w-5 md:h-6 md:w-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-xs md:text-sm text-gray-500">Завершено</p>
                <p className="text-xl md:text-2xl font-bold text-emerald-600">{stats.done}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-red-50 rounded-lg">
                <AlertTriangle className="h-5 w-5 md:h-6 md:w-6 text-red-600" />
              </div>
              <div>
                <p className="text-xs md:text-sm text-gray-500">Просрочено</p>
                <p className="text-xl md:text-2xl font-bold text-red-600">{stats.overdue}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row flex-wrap items-stretch md:items-center gap-2 md:gap-3">
          <div className="relative flex-1 min-w-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Поиск задач..."
              className="pl-9 w-full"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            />
          </div>
          <Select value={filters.status} onValueChange={(v) => setFilters({ ...filters, status: v })}>
            <SelectTrigger className="w-full md:w-[160px]"><SelectValue placeholder="Статус" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все статусы</SelectItem>
              {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filters.priority} onValueChange={(v) => setFilters({ ...filters, priority: v })}>
            <SelectTrigger className="w-full md:w-[160px]"><SelectValue placeholder="Приоритет" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все приоритеты</SelectItem>
              {Object.entries(priorityMap).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filters.assignee} onValueChange={(v) => setFilters({ ...filters, assignee: v })}>
            <SelectTrigger className="w-full md:w-[180px]"><SelectValue placeholder="Ответственный" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все ответственные</SelectItem>
              {uniqueAssignees.map((a) => <SelectItem key={a} value={a || ""}>{a || ""}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" className="border-red-700 text-red-700 hover:bg-red-50" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />CSV
          </Button>
          <Button className="bg-red-700 hover:bg-red-800" onClick={() => { setEditingTask(null); setFormOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />Новая задача
          </Button>
        </div>

        {/* Table */}
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 hover:bg-gray-50">
                  <TableHead className="w-[50px]">ID</TableHead>
                  <TableHead><button className="flex items-center gap-1 hover:text-red-700" onClick={() => handleSort("name")}>Название<ArrowUpDown className="h-3 w-3" /></button></TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Приоритет</TableHead>
                  <TableHead className="hidden md:table-cell">Ответственный</TableHead>
                  <TableHead className="hidden lg:table-cell">Исполнитель</TableHead>
                  <TableHead><button className="flex items-center gap-1 hover:text-red-700" onClick={() => handleSort("start_date")}>Начало<ArrowUpDown className="h-3 w-3" /></button></TableHead>
                  <TableHead className="hidden md:table-cell"><button className="flex items-center gap-1 hover:text-red-700" onClick={() => handleSort("end_date")}>Окончание<ArrowUpDown className="h-3 w-3" /></button></TableHead>
                  <TableHead className="hidden lg:table-cell">Сложность</TableHead>
                  <TableHead>Прогресс</TableHead>
                  <TableHead className="w-[100px]">Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={11} className="text-center py-8">Загрузка...</TableCell></TableRow>
                ) : tasksData.list.length === 0 ? (
                  <TableRow><TableCell colSpan={11} className="text-center py-8 text-gray-500">Задачи не найдены</TableCell></TableRow>
                ) : (
                  tasksData.list.map((task) => (
                    <TableRow key={task.id} className="hover:bg-gray-50 cursor-pointer">
                      <TableCell className="font-medium">{task.id}</TableCell>
                      <TableCell className="max-w-[150px] md:max-w-[250px] truncate">{task.name}</TableCell>
                      <TableCell><Badge className={statusMap[task.status]?.color || "bg-gray-100"}>{statusMap[task.status]?.label || task.status}</Badge></TableCell>
                      <TableCell><Badge className={priorityMap[task.priority]?.color || "bg-gray-100"}>{priorityMap[task.priority]?.label || task.priority}</Badge></TableCell>
                      <TableCell className="hidden md:table-cell">{task.assignee || "—"}</TableCell>
                      <TableCell className="hidden lg:table-cell">{task.executor || "—"}</TableCell>
                      <TableCell>{task.start_date ? new Date(task.start_date).toLocaleDateString("ru-RU") : "—"}</TableCell>
                      <TableCell className="hidden md:table-cell">{task.end_date ? new Date(task.end_date).toLocaleDateString("ru-RU") : "—"}</TableCell>
                      <TableCell className="hidden lg:table-cell">{task.complexity || "—"}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2"><Progress value={task.progress || 0} className="w-16 h-2" /><span className="text-xs text-gray-500">{task.progress || 0}%</span></div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-800" onClick={() => { setEditingTask(task); setFormOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-800" onClick={() => setDeleteId(task.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Pagination */}
        {tasksData.total > 10 && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
            <p className="text-sm text-gray-500">
              Показано {(page - 1) * 10 + 1} - {Math.min(page * 10, tasksData.total)} из {tasksData.total}
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>Назад</Button>
              <Button variant="outline" size="sm" onClick={() => setPage((p) => p + 1)} disabled={page * 10 >= tasksData.total}>Вперед</Button>
            </div>
          </div>
        )}
      </div>

      <TaskForm open={formOpen} onOpenChange={setFormOpen} initialData={editingTask} onSubmit={() => { fetchTasks(); fetchStats(); }} />

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить задачу?</AlertDialogTitle>
            <AlertDialogDescription>Это действие нельзя отменить. Задача будет удалена навсегда.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={handleDelete}>Удалить</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
