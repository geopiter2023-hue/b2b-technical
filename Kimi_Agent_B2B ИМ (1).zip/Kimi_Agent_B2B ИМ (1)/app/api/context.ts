import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: { id: number; login: string; role: string };
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const token = opts.req.headers.get("x-auth-token");
  let user: { id: number; login: string; role: string } | undefined;

  if (token) {
    try {
      const payload = JSON.parse(
        Buffer.from(token.split(".")[1], "base64").toString()
      );
      if (payload.id && payload.login) {
        const db = getDb();
        const found = await db
          .select()
          .from(users)
          .where(eq(users.id, payload.id))
          .limit(1);
        if (found.length > 0) {
          user = {
            id: found[0].id,
            login: found[0].login,
            role: found[0].role,
          };
        }
      }
    } catch {
      // ignore invalid token
    }
  }

  return { req: opts.req, resHeaders: opts.resHeaders, user };
}
