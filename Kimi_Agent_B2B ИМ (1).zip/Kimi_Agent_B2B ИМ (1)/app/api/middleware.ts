import { initTRPC } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const createRouter = t.router;
export const publicQuery = t.procedure;

export const authedQuery = t.procedure.use(async function authedMiddleware(
  opts
) {
  const { ctx } = opts;
  if (!ctx.user) {
    throw new Error("UNAUTHORIZED");
  }
  return opts.next({
    ctx: { ...ctx, user: ctx.user },
  });
});
