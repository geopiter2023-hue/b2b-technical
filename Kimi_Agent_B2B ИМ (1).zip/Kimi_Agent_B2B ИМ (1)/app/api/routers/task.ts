import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { tasks } from "@db/schema";
import { eq, like, and, or, desc, asc, sql } from "drizzle-orm";
import { z } from "zod";

const listInput = z.object({
  status: z.string().optional(),
  priority: z.string().optional(),
  assignee: z.string().optional(),
  search: z.string().optional(),
  sortBy: z.string().optional(),
  sortOrder: z.enum(["asc", "desc"]).optional(),
  page: z.number().optional(),
  limit: z.number().optional(),
}).optional().default({});

export const taskRouter = createRouter({
  list: publicQuery
    .input(listInput)
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      const sortBy = input.sortBy || "createdAt";
      const sortOrder = input.sortOrder || "desc";
      const page = input.page || 1;
      const limit = input.limit || 50;

      if (input.status && input.status !== "all") {
        conditions.push(eq(tasks.status, input.status));
      }
      if (input.priority && input.priority !== "all") {
        conditions.push(eq(tasks.priority, input.priority));
      }
      if (input.assignee && input.assignee !== "all") {
        conditions.push(eq(tasks.assignee, input.assignee));
      }
      if (input.search) {
        conditions.push(
          or(
            like(tasks.name, `%${input.search}%`),
            like(tasks.assignee, `%${input.search}%`),
            like(tasks.executor, `%${input.search}%`)
          )
        );
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const totalResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(tasks)
        .where(whereClause);
      const total = totalResult[0]?.count ?? 0;

      let orderBy;
      if (sortBy === "name") {
        orderBy = sortOrder === "asc" ? asc(tasks.name) : desc(tasks.name);
      } else if (sortBy === "startDate") {
        orderBy = sortOrder === "asc" ? asc(tasks.startDate) : desc(tasks.startDate);
      } else if (sortBy === "endDate") {
        orderBy = sortOrder === "asc" ? asc(tasks.endDate) : desc(tasks.endDate);
      } else {
        orderBy = sortOrder === "asc" ? asc(tasks.createdAt) : desc(tasks.createdAt);
      }

      const list = await db
        .select()
        .from(tasks)
        .where(whereClause)
        .orderBy(orderBy)
        .limit(limit)
        .offset((page - 1) * limit);

      return { list, total, page, limit };
    }),

  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(tasks)
        .where(eq(tasks.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        status: z.string().default("not_started"),
        priority: z.string().default("medium"),
        assignee: z.string().optional(),
        executor: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        complexity: z.number().min(1).max(5).optional(),
        budget: z.string().optional(),
        progress: z.number().min(0).max(100).optional(),
        notes: z.string().optional(),
        category: z.string().optional(),
        sourceId: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const insertData: any = {
        name: input.name,
        description: input.description || null,
        status: input.status,
        priority: input.priority,
        assignee: input.assignee || null,
        executor: input.executor || null,
        startDate: input.startDate ? new Date(input.startDate) : null,
        endDate: input.endDate ? new Date(input.endDate) : null,
        complexity: input.complexity ?? 2,
        budget: input.budget || null,
        progress: input.progress ?? 0,
        notes: input.notes || null,
        category: input.category || null,
        sourceId: input.sourceId || null,
      };
      const result = await db.insert(tasks).values(insertData).returning({ id: tasks.id });
      return { id: result[0].id };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        status: z.string().optional(),
        priority: z.string().optional(),
        assignee: z.string().optional(),
        executor: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        complexity: z.number().min(1).max(5).optional(),
        budget: z.string().optional(),
        progress: z.number().min(0).max(100).optional(),
        notes: z.string().optional(),
        category: z.string().optional(),
        sourceId: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      const updateData: any = {};
      if (data.name !== undefined) updateData.name = data.name;
      if (data.description !== undefined) updateData.description = data.description || null;
      if (data.status !== undefined) updateData.status = data.status;
      if (data.priority !== undefined) updateData.priority = data.priority;
      if (data.assignee !== undefined) updateData.assignee = data.assignee || null;
      if (data.executor !== undefined) updateData.executor = data.executor || null;
      if (data.startDate !== undefined) updateData.startDate = data.startDate ? new Date(data.startDate) : null;
      if (data.endDate !== undefined) updateData.endDate = data.endDate ? new Date(data.endDate) : null;
      if (data.complexity !== undefined) updateData.complexity = data.complexity;
      if (data.budget !== undefined) updateData.budget = data.budget || null;
      if (data.progress !== undefined) updateData.progress = data.progress;
      if (data.notes !== undefined) updateData.notes = data.notes || null;
      if (data.category !== undefined) updateData.category = data.category || null;
      if (data.sourceId !== undefined) updateData.sourceId = data.sourceId || null;

      await db.update(tasks).set(updateData).where(eq(tasks.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(tasks).where(eq(tasks.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(tasks);
    return {
      total: all.length,
      inProgress: all.filter((t) => t.status === "in_progress").length,
      done: all.filter((t) => t.status === "completed").length,
      overdue: all.filter(
        (t) =>
          t.endDate &&
          new Date(t.endDate) < new Date() &&
          t.status !== "completed" &&
          t.status !== "cancelled"
      ).length,
    };
  }),

  assignees: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select({ assignee: tasks.assignee }).from(tasks);
    const unique = Array.from(
      new Set(all.map((a) => a.assignee).filter(Boolean))
    );
    return unique;
  }),
});
