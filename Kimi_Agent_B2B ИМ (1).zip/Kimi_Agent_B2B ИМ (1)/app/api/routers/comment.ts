import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { taskComments } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";

export const commentRouter = createRouter({
  list: publicQuery
    .input(z.object({ taskId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const list = await db
        .select()
        .from(taskComments)
        .where(eq(taskComments.taskId, input.taskId))
        .orderBy(desc(taskComments.createdAt));
      return list;
    }),

  create: publicQuery
    .input(
      z.object({
        taskId: z.number(),
        userName: z.string().default("B2B"),
        message: z.string().min(1),
        imageUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db
        .insert(taskComments)
        .values({
          taskId: input.taskId,
          userName: input.userName,
          message: input.message,
          imageUrl: input.imageUrl || null,
        } as any)
        .returning({ id: taskComments.id });
      return { id: result[0].id };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .delete(taskComments)
        .where(eq(taskComments.id, input.id));
      return { success: true };
    }),
});
