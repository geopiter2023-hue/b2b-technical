import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { z } from "zod";

function signToken(payload: object): string {
  const header = Buffer.from(JSON.stringify({ alg: "none", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${header}.${body}.`;
}

export const authRouter = createRouter({
  login: publicQuery
    .input(
      z.object({
        login: z.string().min(1),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const found = await db
        .select()
        .from(users)
        .where(eq(users.login, input.login))
        .limit(1);

      if (found.length === 0) {
        throw new Error("INVALID_CREDENTIALS");
      }

      const user = found[0];
      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) {
        throw new Error("INVALID_CREDENTIALS");
      }

      const token = signToken({
        id: user.id,
        login: user.login,
        role: user.role,
      });

      return {
        token,
        user: {
          id: user.id,
          login: user.login,
          role: user.role,
        },
      };
    }),

  me: authedQuery.query(({ ctx }) => {
    return ctx.user;
  }),
});
