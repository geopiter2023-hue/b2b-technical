import { createRouter, publicQuery } from "./middleware";
import { authRouter } from "./routers/auth";
import { taskRouter } from "./routers/task";
import { commentRouter } from "./routers/comment";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  task: taskRouter,
  comment: commentRouter,
});

export type AppRouter = typeof appRouter;
