import { getDb } from "../api/queries/connection";
import { users, tasks } from "./schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import seedData from "./seed_data.json";

async function main() {
  const db = getDb();

  // Create B2B user
  const passwordHash = await bcrypt.hash("B2B", 10);
  
  // Upsert user (PostgreSQL syntax)
  const existingUser = await db.select().from(users).where(eq(users.login, "B2B")).limit(1);
  if (existingUser.length === 0) {
    await db.insert(users).values({
      login: "B2B",
      passwordHash,
      role: "admin",
    });
    console.log("User B2B created");
  } else {
    await db.update(users).set({ passwordHash }).where(eq(users.login, "B2B"));
    console.log("User B2B password updated");
  }

  // Check if tasks already exist
  const existing = await db.select().from(tasks).limit(1);
  if (existing.length > 0) {
    console.log("Tasks already seeded, skipping...");
    return;
  }

  // Insert tasks
  for (const task of seedData) {
    await db.insert(tasks).values({
      name: task.name,
      assignee: task.assignee,
      executor: task.executor,
      status: task.status,
      priority: task.priority,
      startDate: task.startDate ? new Date(task.startDate) : null,
      endDate: task.endDate ? new Date(task.endDate) : null,
      complexity: task.complexity,
      progress: task.progress,
      notes: task.notes,
      sourceId: task.sourceId,
    } as any);
  }

  console.log(`Seeded ${seedData.length} tasks`);
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
