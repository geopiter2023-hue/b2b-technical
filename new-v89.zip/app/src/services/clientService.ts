import type { Client, DadataResponse, ClientHistoryEntry } from "@/types/clients";

const STORAGE_KEY = "b2b_clients_db";
const DADATA_API_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party";

// ==== localStorage persistence ====

export function loadClients(): Client[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveClients(clients: Client[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
}

// ==== CRUD ====

export function addClient(client: Client): Client[] {
  const clients = loadClients();
  if (clients.find((c) => c.inn === client.inn)) {
    const updated = clients.map((c) =>
      c.inn === client.inn ? { ...client, updatedAt: new Date().toISOString() } : c
    );
    saveClients(updated);
    return updated;
  }
  clients.push(client);
  saveClients(clients);
  return clients;
}

export function updateClient(inn: string, updates: Partial<Client>): Client[] {
  const clients = loadClients();
  const updated = clients.map((c) => {
    if (c.inn === inn) {
      const newC = { ...c, ...updates, updatedAt: new Date().toISOString() };
      if (updates.note || updates.phone || updates.email || updates.tags) {
        newC.history = [
          ...c.history,
          {
            id: Date.now().toString() + Math.random().toString(36).slice(2),
            type: "edit",
            description: `Обновлены данные: ${Object.keys(updates).join(", ")}`,
            date: new Date().toISOString(),
          },
        ];
      }
      return newC;
    }
    return c;
  });
  saveClients(updated);
  return updated;
}

export function deleteClient(inn: string): Client[] {
  const clients = loadClients().filter((c) => c.inn !== inn);
  saveClients(clients);
  return clients;
}

export function addHistoryEntry(inn: string, entry: ClientHistoryEntry): Client[] {
  const clients = loadClients();
  const updated = clients.map((c) => {
    if (c.inn === inn) {
      return { ...c, history: [...c.history, entry], updatedAt: new Date().toISOString() };
    }
    return c;
  });
  saveClients(updated);
  return updated;
}

// ==== Dadata API ====

export async function fetchDadataByInn(
  inn: string,
  apiKey: string
): Promise<DadataResponse | null> {
  if (!apiKey) return null;
  const cleanInn = inn.replace(/\D/g, "");
  if (cleanInn.length < 10) return null;

  try {
    const res = await fetch(DADATA_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Token ${apiKey}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ query: cleanInn }),
    });
    if (!res.ok) {
      console.error("[Dadata] HTTP error:", res.status);
      return null;
    }
    return (await res.json()) as DadataResponse;
  } catch (err) {
    console.error("[Dadata] Fetch error:", err);
    return null;
  }
}

// ==== Convert Dadata suggestion to Client ====

export function suggestionToClient(s: DadataResponse["suggestions"][0]): Client {
  const d = s.data;
  return {
    id: Date.now().toString() + Math.random().toString(36).slice(2),
    inn: d.inn || "",
    kpp: d.kpp || "",
    ogrn: d.ogrn || "",
    name: d.name?.short_with_opf || s.value || "",
    fullName: d.name?.full_with_opf || s.value || "",
    type: (d.type === "LEGAL" || d.type === "INDIVIDUAL" ? d.type : "") as Client["type"],
    status: (d.state?.status || "") as Client["status"],
    address: d.address?.value || "",
    management: d.management?.name || "",
    managementPost: d.management?.post || "",
    okved: d.okved || "",
    phone: "",
    email: "",
    note: "",
    tags: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    history: [
      {
        id: Date.now().toString(),
        type: "create" as const,
        description: `Клиент добавлен через Dadata (ИНН: ${d.inn})`,
        date: new Date().toISOString(),
      },
    ],
  };
}

// Create a minimal client from INN only (when Dadata fails)
export function createMinimalClient(inn: string, name?: string): Client {
  return {
    id: Date.now().toString() + Math.random().toString(36).slice(2),
    inn: inn.replace(/\D/g, ""),
    kpp: "",
    ogrn: "",
    name: name || `Клиент ИНН ${inn}`,
    fullName: name || `Клиент ИНН ${inn}`,
    type: "" as Client["type"],
    status: "" as Client["status"],
    address: "",
    management: "",
    managementPost: "",
    okved: "",
    phone: "",
    email: "",
    note: "",
    tags: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    history: [
      {
        id: Date.now().toString(),
        type: "create" as const,
        description: `Клиент добавлен из файла (ИНН: ${inn})`,
        date: new Date().toISOString(),
      },
    ],
  };
}

// ==== Search clients ====

export function searchClients(query: string): Client[] {
  const clients = loadClients();
  if (!query.trim()) return clients;
  const q = query.toLowerCase();
  return clients.filter(
    (c) =>
      c.inn.includes(q) ||
      c.name.toLowerCase().includes(q) ||
      c.fullName.toLowerCase().includes(q) ||
      c.kpp?.includes(q) ||
      c.ogrn?.includes(q) ||
      c.address?.toLowerCase().includes(q) ||
      c.tags?.some((t) => t.toLowerCase().includes(q))
  );
}

/* ═══ Detect if column header is INN ═══ */
function isInnColumn(h: string): boolean {
  const hl = h.toLowerCase();
  return (
    hl === "инн" ||
    hl === "inn" ||
    hl === "инн покупателя" ||
    hl === "покупатель инн" ||
    hl === "инн заказчика" ||
    hl === "инн клиента" ||
    hl === "инн контрагента" ||
    hl === "inn buyer" ||
    hl === "buyer inn" ||
    hl === "inn customer" ||
    hl === "клиент инн" ||
    hl.includes("инн")
  );
}

/* ═══ Convert Excel numeric INN to proper string (fixes leading zeros) ═══ */
function normalizeInn(value: unknown): string {
  if (value === undefined || value === null) return "";
  // If it's a number, convert to string and pad with leading zeros if needed
  if (typeof value === "number") {
    const str = value.toString();
    // INN is 10 or 12 digits
    if (str.length === 9) return "0" + str; // e.g. 780459677 -> 0780459677
    if (str.length === 11) return "0" + str;
    return str;
  }
  return String(value).trim();
}

// ==== Import clients from CSV/Excel ====

export interface ImportResult {
  rows: Array<{ inn: string; name?: string; phone?: string; email?: string; note?: string }>;
  innColumnFound: boolean;
  totalRows: number;
  detectedHeaders: string[];
}

export async function parseClientsFromExcel(file: File): Promise<ImportResult> {
  return new Promise((resolve, reject) => {
    const isTextFile = file.name.toLowerCase().endsWith(".txt") || file.name.toLowerCase().endsWith(".csv");

    if (isTextFile) {
      // Plain text: one INN per line
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = String(e.target?.result || "");
          const lines = text.split(/\r?\n/);
          const rows: Array<{ inn: string }> = [];
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed) continue;
            // Try to extract INN (10 or 12 digits)
            const digits = trimmed.replace(/\D/g, "");
            if (digits.length >= 10 && digits.length <= 12) {
              rows.push({ inn: digits });
            }
          }
          resolve({
            rows,
            innColumnFound: rows.length > 0,
            totalRows: lines.length,
            detectedHeaders: ["TXT_IMPORT"],
          });
        } catch (err) {
          reject(err);
        }
      };
      reader.readAsText(file);
      return;
    }

    // Excel file
    import("xlsx").then((XLSX) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

          if (rows.length < 1) {
            resolve({ rows: [], innColumnFound: false, totalRows: 0, detectedHeaders: [] });
            return;
          }

          const headers = (rows[0] as string[]).map((h) => String(h).toLowerCase().trim());

          // Find INN column
          let innCol = -1;
          for (let i = 0; i < headers.length; i++) {
            if (isInnColumn(headers[i])) {
              innCol = i;
              break;
            }
          }

          // If no INN column found, try first column
          if (innCol === -1 && headers.length > 0) {
            // Check if first column has 10-12 digit values
            const firstColValues = rows.slice(1, Math.min(6, rows.length)).map((r) => String((r as string[])[0] || "").replace(/\D/g, ""));
            if (firstColValues.some((v) => v.length >= 10 && v.length <= 12)) {
              innCol = 0;
            }
          }

          const colMap: Record<string, number> = {};
          headers.forEach((h, i) => {
            if (isInnColumn(h)) colMap.inn = i;
            if (h.includes("название") || h.includes("наименование") || h.includes("имя") || h.includes("name") || h.includes("организация") || h.includes("компания") || h.includes("контрагент") || h.includes("покупатель")) colMap.name = i;
            if (h.includes("телефон") || h.includes("phone") || h.includes("тел.")) colMap.phone = i;
            if (h.includes("email") || h.includes("почта") || h.includes("e-mail") || h.includes("mail")) colMap.email = i;
            if (h.includes("примечание") || h.includes("note") || h.includes("комментарий") || h.includes("описание")) colMap.note = i;
          });

          const results: Array<{ inn: string; name?: string; phone?: string; email?: string; note?: string }> = [];

          // Start from row 1 (skip header)
          for (let i = 1; i < rows.length; i++) {
            const row = rows[i] as unknown[];
            const hasValue = row.some((v) => v !== undefined && v !== null && String(v).trim() !== "");
            if (!hasValue) continue;

            // Get INN from detected column or first column
            const innValue = innCol >= 0 ? row[innCol] : "";
            const inn = normalizeInn(innValue);

            // Validate INN (10 or 12 digits)
            const innDigits = inn.replace(/\D/g, "");
            if (innDigits.length < 10 || innDigits.length > 12) continue;

            results.push({
              inn: innDigits,
              name: colMap.name !== undefined ? String(row[colMap.name] || "").trim() || undefined : undefined,
              phone: colMap.phone !== undefined ? String(row[colMap.phone] || "").trim() || undefined : undefined,
              email: colMap.email !== undefined ? String(row[colMap.email] || "").trim() || undefined : undefined,
              note: colMap.note !== undefined ? String(row[colMap.note] || "").trim() || undefined : undefined,
            });
          }

          resolve({
            rows: results,
            innColumnFound: innCol >= 0,
            totalRows: rows.length - 1,
            detectedHeaders: headers,
          });
        } catch (err) {
          reject(err);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  });
}

// ==== Bulk import with Dadata lookup ====

export interface BulkImportResult {
  added: number;
  existing: number;
  failed: number;
  dadataMiss: number;
  log: string[];
}

export async function bulkImportClients(
  file: File,
  dadataKey: string,
  onProgress: (pct: number) => void
): Promise<BulkImportResult> {
  const result: BulkImportResult = { added: 0, existing: 0, failed: 0, dadataMiss: 0, log: [] };

  // Parse file
  let parsed: ImportResult;
  try {
    parsed = await parseClientsFromExcel(file);
  } catch (err) {
    result.log.push(`Ошибка парсинга файла: ${String(err)}`);
    return result;
  }

  if (!parsed.innColumnFound) {
    result.log.push(`Колонка ИНН не найдена. Найдены заголовки: ${parsed.detectedHeaders.join(", ")}`);
    result.log.push("Поддерживаемые названия: ИНН, inn, ИНН покупателя, клиент инн, и т.д.");
    return result;
  }

  if (parsed.rows.length === 0) {
    result.log.push("В файле не найдено строк с валидным ИНН (10-12 цифр)");
    return result;
  }

  result.log.push(`Найдено ${parsed.rows.length} строк с ИНН`);

  const existingClients = loadClients();
  const newClients: Client[] = [];

  for (let i = 0; i < parsed.rows.length; i++) {
    const row = parsed.rows[i];
    onProgress(Math.round(((i + 1) / parsed.rows.length) * 100));

    // Skip if already exists
    if (existingClients.find((c) => c.inn === row.inn) || newClients.find((c) => c.inn === row.inn)) {
      result.existing++;
      continue;
    }

    // Try Dadata
    let client: Client | null = null;
    if (dadataKey) {
      try {
        const res = await fetchDadataByInn(row.inn, dadataKey);
        if (res?.suggestions?.[0]) {
          client = suggestionToClient(res.suggestions[0]);
          // Override with file data if provided
          if (row.phone) client.phone = row.phone;
          if (row.email) client.email = row.email;
          if (row.note) client.note = row.note;
          if (row.name && !client.name) client.name = row.name;
          result.log.push(`✓ ИНН ${row.inn} — ${client.name}`);
        }
      } catch {
        // Dadata failed, will create minimal client
      }
    }

    // If Dadata returned nothing, create minimal client
    if (!client) {
      client = createMinimalClient(row.inn, row.name);
      if (row.phone) client.phone = row.phone;
      if (row.email) client.email = row.email;
      if (row.note) client.note = row.note;
      result.dadataMiss++;
      result.log.push(`⚠ ИНН ${row.inn} — Dadata не ответил, добавлен без данных`);
    }

    newClients.push(client);
    result.added++;

    // Rate limiting delay
    if (dadataKey && i < parsed.rows.length - 1) {
      await new Promise((r) => setTimeout(r, 150));
    }
  }

  // Save all new clients
  if (newClients.length > 0) {
    const all = [...existingClients, ...newClients];
    saveClients(all);
    result.log.push(`---`);
    result.log.push(`Итого: ${result.added} добавлено, ${result.existing} уже существовало, ${result.dadataMiss} без Dadata`);
  }

  return result;
}
