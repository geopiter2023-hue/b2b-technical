# Патч: Перенос задач из localStorage в Supabase (v88)

**Проблема:** При деплое новых версий задачи теряются, потому что хранятся в localStorage.  
**Решение:** Перенести задачи в Supabase с realtime подпиской.

---

## 1. SQL миграция (Supabase → SQL Editor)

Выполнить в **Supabase Dashboard → SQL Editor**:

```sql
-- Добавить недостающие колонки
alter table tasks add column if not exists user_id uuid;
alter table tasks add column if not exists title text;
alter table tasks add column if not exists description text;
alter table tasks add column if not exists status text default 'todo';
alter table tasks add column if not exists priority text default 'medium';
alter table tasks add column if not exists category text;
alter table tasks add column if not exists assigned_to text;
alter table tasks add column if not exists due_date timestamptz;
alter table tasks add column if not exists created_at timestamptz default now();
alter table tasks add column if not exists updated_at timestamptz default now();

-- Заполнить user_id для существующих записей
update tasks set user_id = '00000000-0000-0000-0000-000000000000' where user_id is null;

-- Включить RLS
alter table tasks enable row level security;

-- Удалить старые политики если были
drop policy if exists "Users can CRUD own tasks" on tasks;
drop policy if exists "Allow anon access" on tasks;

-- Создать политики
create policy "Users can CRUD own tasks"
  on tasks for all to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "Allow anon access"
  on tasks for all to anon using (true) with check (true);
```

---

## 2. Новый taskService.ts (заменить полностью)

```typescript
import { supabase } from '../lib/supabase';

export interface Task {
  id: string;
  user_id?: string;
  title: string;
  description?: string;
  status: 'todo' | 'in_progress' | 'done' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  category?: string;
  assigned_to?: string;
  due_date?: string;
  created_at?: string;
  updated_at?: string;
}

const TABLE = 'tasks';
const DEFAULT_USER_ID = '00000000-0000-0000-0000-000000000000';

export const taskService = {
  async getAll(): Promise<Task[]> {
    const { data, error } = await supabase
      .from(TABLE)
      .select('*')
      .order('created_at', { ascending: false });
    if (error) { console.error('getAll tasks error:', error); throw error; }
    return (data || []) as Task[];
  },

  async getById(id: string): Promise<Task | null> {
    const { data, error } = await supabase.from(TABLE).select('*').eq('id', id).single();
    if (error) { if (error.code === 'PGRST116') return null; throw error; }
    return data as Task;
  },

  async create(task: Omit<Task, 'id' | 'created_at' | 'updated_at'>): Promise<Task> {
    const { data, error } = await supabase.from(TABLE).insert([{ ...task, user_id: DEFAULT_USER_ID }]).select().single();
    if (error) throw error;
    return data as Task;
  },

  async update(id: string, updates: Partial<Omit<Task, 'id' | 'created_at'>>): Promise<Task> {
    const { data, error } = await supabase.from(TABLE).update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id).select().single();
    if (error) throw error;
    return data as Task;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase.from(TABLE).delete().eq('id', id);
    if (error) throw error;
  },

  subscribe(callback: (payload: any) => void) {
    return supabase.channel('tasks-changes').on('postgres_changes', { event: '*', schema: 'public', table: TABLE }, (payload: any) => callback(payload)).subscribe();
  },

  unsubscribe(channel: any) { supabase.removeChannel(channel); }
};
```

---

## 3. Патч TaskContext / TaskStore

### Было (localStorage):
```typescript
const [tasks, setTasks] = useState<Task[]>(() => {
  const saved = localStorage.getItem('tasks');
  return saved ? JSON.parse(saved) : [];
});
useEffect(() => {
  localStorage.setItem('tasks', JSON.stringify(tasks));
}, [tasks]);
```

### Стало (Supabase + realtime):
```typescript
const [tasks, setTasks] = useState<Task[]>([]);
const [loading, setLoading] = useState(true);
const [error, setError] = useState<string | null>(null);

useEffect(() => {
  loadTasks();
  const channel = taskService.subscribe((payload) => {
    if (payload.eventType === 'INSERT') setTasks(prev => [payload.new, ...prev]);
    else if (payload.eventType === 'UPDATE') setTasks(prev => prev.map(t => t.id === payload.new.id ? payload.new : t));
    else if (payload.eventType === 'DELETE') setTasks(prev => prev.filter(t => t.id !== payload.old.id));
  });
  return () => taskService.unsubscribe(channel);
}, []);

const loadTasks = async () => {
  try {
    setLoading(true);
    // Одноразовая миграция из localStorage
    const legacy = localStorage.getItem('tasks');
    if (legacy) {
      const oldTasks = JSON.parse(legacy);
      for (const task of oldTasks) {
        await taskService.create({
          title: task.title,
          description: task.description,
          status: task.status,
          priority: task.priority,
          category: task.category,
          assigned_to: task.assigned_to,
          due_date: task.due_date,
        });
      }
      localStorage.removeItem('tasks');
      setTasks(await taskService.getAll());
      return;
    }
    setTasks(await taskService.getAll());
  } catch (err: any) {
    setError(err.message);
  } finally {
    setLoading(false);
  }
};

const addTask = async (task: Omit<Task, 'id'>) => {
  const created = await taskService.create(task);
  setTasks(prev => [created, ...prev]);
};

const updateTask = async (id: string, updates: Partial<Task>) => {
  const updated = await taskService.update(id, updates);
  setTasks(prev => prev.map(t => t.id === id ? updated : t));
};

const deleteTask = async (id: string) => {
  await taskService.delete(id);
  setTasks(prev => prev.filter(t => t.id !== id));
};
```

---

## 4. UI патч (loading + error)

```tsx
{loading && <div className="text-center py-8">Загрузка задач...</div>}
{error && (
  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
    Ошибка загрузки: {error}
  </div>
)}
{!loading && !error && tasks.length === 0 && (
  <div className="text-center text-gray-500 py-8">Задачи не найдены</div>
)}
```

---

## Чек-лист

- [ ] SQL миграция выполнена в Supabase
- [ ] taskService.ts заменен
- [ ] TaskContext обновлен (async + realtime)
- [ ] Все CRUD операции теперь async
- [ ] Добавлены loading / error стейты
- [ ] Миграция из localStorage работает
- [ ] Протестировано
- [ ] Старый localStorage код удален

---

**Это все что нужно.** Разработчик выполняет SQL, заменяет сервис и контекст — задачи переезжают в Supabase и перестают пропадать при деплое.
