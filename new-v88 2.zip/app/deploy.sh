#!/bin/bash
# Deploy script for B2B Task Manager on Supabase (PostgreSQL)

set -e

echo "=== B2B Task Manager Deploy for Supabase ==="

# 1. Install Node.js dependencies
echo "[1/5] Installing dependencies..."
npm ci --prefer-offline

# 2. Build project
echo "[2/5] Building project..."
npm run build

# 3. Setup database (PostgreSQL via Supabase)
echo "[3/5] Pushing database schema to Supabase..."
npx drizzle-kit push

# 4. Seed data
echo "[4/5] Seeding data..."
npx tsx db/seed.ts || echo "Seed skipped (data may already exist)"

# 5. Start with PM2
echo "[5/5] Starting server with PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
fi

pm2 delete b2b-task-manager 2>/dev/null || true
pm2 start dist/boot.js --name b2b-task-manager --env production
pm2 save

echo ""
echo "=== Deploy complete! ==="
echo "Backend running on http://localhost:3000"
echo "Supabase PostgreSQL connected"
