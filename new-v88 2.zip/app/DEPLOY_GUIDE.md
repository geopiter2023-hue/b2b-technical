# Инструкция по деплою B2B Task Manager

## Проблема
Beget (shared hosting) не поддерживает Node.js backend. 
Решение: backend на Render.com (бесплатно) + frontend на beget.

## Шаг 1: Задеплоить backend на Render.com

### 1.1 Создайте аккаунт
- Зайдите на https://render.com
- Зарегистрируйтесь через GitHub или email

### 1.2 Создайте Web Service
- Dashboard → New → Web Service
- Runtime: Node
- Build Command: `npm ci && npm run build`
- Start Command: `npm start`
- Plan: Free

### 1.3 Добавьте Environment Variables
В дашборде Render → Environment:
```
DATABASE_URL=postgresql://postgres:PASSWORD@db.xxx.supabase.co:5432/postgres
SECRET_KEY=любой_длинный_случайный_ключ
NODE_ENV=production
```

### 1.4 Загрузите файлы
**Вариант A - через Git:**
- Загрузите проект на GitHub
- Подключите репозиторий в Render

**Вариант B - через Upload:**
- Загрузите ZIP с проектом
- Render автоматически распакует и соберет

### 1.5 Получите URL
После деплоя Render даст URL вида:
```
https://b2b-task-manager.onrender.com
```

## Шаг 2: Соберите frontend с API URL

### 2.1 Отредактируйте index.html
В `dist/public/index.html` раскомментируйте и замените URL:
```html
<script>
  window.API_URL = "https://b2b-task-manager.onrender.com/api/trpc";
</script>
```

### 2.2 Или пересоберите с env
```bash
VITE_API_URL=https://b2b-task-manager.onrender.com/api/trpc npm run build
```

## Шаг 3: Загрузите frontend на beget

Загрузите содержимое `dist/public/` в `public_html/` на beget:
```
public_html/
  index.html
  favicon.ico
  manifest.json
  sw.js
  apple-touch-icon.png
  favicon-16x16.png
  favavicon-32x32.png
  pwa-icon-192.png
  pwa-icon-512.png
  assets/
    index-xxx.js
    index-xxx.css
    ...
```

## Шаг 4: Создайте таблицы в Supabase

На сервере Render (через Shell):
```bash
npx drizzle-kit push
npx tsx db/seed.ts
```

## Проверка

1. Backend health: `https://b2b-task-manager.onrender.com/health`
2. Login API: POST `https://b2b-task-manager.onrender.com/api/trpc/auth.login`
3. Frontend: `https://b2b-technical.ru`
