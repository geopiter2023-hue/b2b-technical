export interface BitrixConfig {
  oauthToken: string;
  clientId: string;
  counterId: string;
}

export const BITRIX_TEMPLATE_COLUMNS: TemplateColumn[] = [
  { key: "name", label: "Наименование", required: true, category: "Товар" },
  { key: "section", label: "Раздел", category: "Товар" },
  { key: "section_id", label: "id раздела", category: "Товар" },
  { key: "transport_type", label: "Вид транспорта", category: "Товар" },
  { key: "transport_type_id", label: "id вида транспорта", category: "Товар" },
  { key: "brake_fluid_std", label: "Стандарт тормозной жидкости", category: "Товар" },
  { key: "brake_fluid_std_id", label: "id стандарта", category: "Товар" },
  { key: "purpose", label: "Назначение", category: "Товар" },
  { key: "purpose_id", label: "id назначений", category: "Товар" },
  { key: "type", label: "Вид", category: "Товар" },
  { key: "type_id", label: "id вида", category: "Товар" },
  { key: "viscosity", label: "Вязкость", category: "Товар" },
  { key: "viscosity_id", label: "id вязкости", category: "Товар" },
  { key: "api_class", label: "Классификация по API", category: "Товар" },
  { key: "api_class_id", label: "id классификации по API", category: "Товар" },
  { key: "engine_type", label: "Вид двигателя", category: "Товар" },
  { key: "engine_type_id", label: "id вида двигателя", category: "Товар" },
  { key: "approvals", label: "Одобрения", category: "Товар" },
  { key: "requirements", label: "Соответствует требованиям", category: "Товар" },
  { key: "advantages", label: "Преимущества", category: "Товар" },
  { key: "documents", label: "Документы", category: "Товар" },
  { key: "image", label: "Изображение", category: "Товар" },
  { key: "model", label: "Модель", category: "Товар" },
  { key: "manufacturer", label: "Производитель", category: "Товар" },
  { key: "hit", label: "Хит", category: "Товар" },
  { key: "hit_id", label: "id хит", category: "Товар" },
  { key: "new", label: "Новинка", category: "Товар" },
  { key: "new_id", label: "id новинки", category: "Товар" },
  { key: "special", label: "Специальный товар", category: "Товар" },
  { key: "special_id", label: "id спецТовар", category: "Товар" },
  { key: "line", label: "Линейка", category: "Товар" },
  { key: "color", label: "Цвет", category: "Товар" },
  { key: "color_id", label: "id цвет", category: "Товар" },
  { key: "prefix", label: "Не применять Префикс", category: "Товар" },
  { key: "prefix_id", label: "id префикс", category: "Товар" },
  { key: "tp_name", label: "Название ТП", required: true, category: "Торговые предложения" },
  { key: "symbolic_code", label: "Символьный код API", category: "ТП" },
  { key: "sku_id", label: "SKU_ID", category: "ТП" },
  { key: "sorting", label: "Сортировка", category: "ТП" },
  { key: "kccc", label: "КССС", required: true, category: "ТП" },
  { key: "weight_net", label: "Вес нетто (грамм)", category: "ТП" },
  { key: "announce_pic", label: "Картинка для анонса", category: "ТП" },
  { key: "detail_pic", label: "Детальная картинка", category: "ТП" },
  { key: "detail_desc", label: "Детальное описание", category: "ТП" },
  { key: "packing", label: "Фасовка", category: "ТП" },
  { key: "packing_id", label: "id фасовки", category: "ТП" },
  { key: "packing_volume", label: "Объем фасовки", category: "ТП" },
  { key: "units_per_box", label: "Шт в коробке", category: "ТП" },
  { key: "avito_title", label: "Заголовок авито", category: "ТП" },
  { key: "google_subtitle", label: "Google Item subtitle", category: "ТП" },
  { key: "google_desc", label: "Google Item description", category: "ТП" },
  { key: "unit_id", label: "UNIT_ID", category: "ТП" },
  { key: "no_stock_sync", label: "Не подтягивать остатки с ЛЛ", category: "ТП" },
  { key: "active", label: "Товар активен", category: "ТП" },
  { key: "weight_net_tp", label: "Вес нетто ТП (грамм)", category: "ТП" },
];

export interface TemplateColumn {
  key: string;
  label: string;
  required?: boolean;
  category: string;
}

export interface Mapping {
  templateCol: string;
  sourceCol: string | null;
}

export interface BitrixProduct {
  [key: string]: string | number | boolean | undefined;
}

export const DEFAULT_MAPPING: Record<string, string> = {
  name: "Наименование продукции",
  section: "Наименование раздела",
  symbolic_code: "Символьный код",
  kccc: "КССС",
  weight_net: "Вес нетто (грамм)",
  weight_net_tp: "Вес нетто (грамм)",
  packing_volume: "Объем фасовки",
  packing: "Фасовка",
  packing_id: "Фасовка",
  units_per_box: "Шт в коробке",
  model: "Наименование",
  manufacturer: "Бренд",
  line: "Линейка",
  type: "Вид",
  viscosity: "Вязкость SAE",
  api_class: "API",
  advantages: "Преимущества",
  image: "Фото",
  detail_pic: "Фото Детальное",
  detail_desc: "Полное наименование",
  tp_name: "Наименование продукции",
  sorting: "КССС",
  color: "Цвет",
  engine_type: "Тип Трансмиссии",
  purpose: "Направление",
  transport_type: "Направление",
  avito_title: "Наименование продукции",
  google_subtitle: "Наименование продукции",
  google_desc: "Полное наименование",
  unit_id: "GTIN",
  active: "Статус производства",
  no_stock_sync: "честный знак",
};
