import { Routes, Route, Navigate } from "react-router";
import { useAuth } from "./hooks/useAuth";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import GanttPage from "./pages/GanttPage";
import ReportsPage from "./pages/ReportsPage";
import SalesDashboard from "./pages/SalesDashboard";
import RoadmapPage from "./pages/RoadmapPage";
import PriceComparisonPage from "./pages/PriceComparisonPage";
import PriceControlPage from "./pages/PriceControlPage";
import ProductCardsPage from "./pages/ProductCardsPage";
import MetricsPage from "./pages/MetricsPage";
import BitrixImportPage from "./pages/BitrixImportPage";
import ClientsPage from "./pages/ClientsPage";

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Загрузка...</div>;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<RequireAuth><Dashboard /></RequireAuth>} />
      <Route path="/gantt" element={<RequireAuth><GanttPage /></RequireAuth>} />
      <Route path="/reports" element={<RequireAuth><ReportsPage /></RequireAuth>} />
      <Route path="/sales" element={<RequireAuth><SalesDashboard /></RequireAuth>} />
      <Route path="/roadmap" element={<RequireAuth><RoadmapPage /></RequireAuth>} />
      <Route path="/prices" element={<RequireAuth><PriceComparisonPage /></RequireAuth>} />
      <Route path="/control" element={<RequireAuth><PriceControlPage /></RequireAuth>} />
      <Route path="/cards" element={<RequireAuth><ProductCardsPage /></RequireAuth>} />
      <Route path="/metrics" element={<RequireAuth><MetricsPage /></RequireAuth>} />
      <Route path="/bitrix" element={<RequireAuth><BitrixImportPage /></RequireAuth>} />
      <Route path="/clients" element={<RequireAuth><ClientsPage /></RequireAuth>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
