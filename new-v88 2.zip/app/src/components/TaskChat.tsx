import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Send, ImageIcon, X, Trash2 } from "lucide-react";
import { listComments, createComment, deleteComment, type Comment } from "@/services/commentService";

interface TaskChatProps {
  taskId: number;
}

export default function TaskChat({ taskId }: TaskChatProps) {
  const [message, setMessage] = useState("");
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const fetchComments = useCallback(async () => {
    try {
      const data = await listComments(taskId);
      setComments(data);
    } catch (err: any) {
      console.error("Error loading comments:", err);
    } finally {
      setIsLoading(false);
    }
  }, [taskId]);

  useEffect(() => {
    fetchComments();
  }, [fetchComments]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [comments]);

  const handleSend = async () => {
    if (!message.trim() && !imageBase64) return;
    try {
      await createComment(taskId, message.trim() || " ", imageBase64 || undefined);
      setMessage("");
      setImageBase64(null);
      setImageName(null);
      fetchComments();
    } catch (err: any) {
      console.error("Error sending comment:", err);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert("Файл слишком большой (макс 5MB)");
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) { setImageBase64(result); setImageName(file.name); }
    };
    reader.readAsDataURL(file);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleDelete = async (id: number) => {
    try { await deleteComment(id); fetchComments(); } catch (err: any) { console.error(err); }
  };

  const formatDate = (date: string | null) => {
    if (!date) return "";
    const d = new Date(date);
    return d.toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  return (
    <Card className="mt-6 border-red-200">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <span className="w-6 h-6 bg-red-100 rounded-full flex items-center justify-center text-red-700 text-xs font-bold">{comments.length}</span>
          Обсуждение
        </CardTitle>
      </CardHeader>
      <Separator />
      <CardContent className="p-0">
        <ScrollArea className="h-[350px]" ref={scrollRef as any}>
          <div className="p-4 space-y-4">
            {isLoading ? (
              <p className="text-sm text-gray-400 text-center py-8">Загрузка сообщений...</p>
            ) : comments.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">Нет сообщений. Напишите первый комментарий.</p>
            ) : (
              [...comments].reverse().map((comment) => (
                <div key={comment.id} className="flex gap-3 group">
                  <Avatar className="w-8 h-8 flex-shrink-0 bg-red-100 text-red-700">
                    <AvatarFallback className="bg-red-100 text-red-700 text-xs font-bold">{(comment.user_name || "B").charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-800">{comment.user_name || "B2B"}</span>
                      <span className="text-xs text-gray-400">{formatDate(comment.created_at)}</span>
                      <Button variant="ghost" size="icon" className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity text-gray-400 hover:text-red-600" onClick={() => handleDelete(comment.id)}><Trash2 className="h-3 w-3" /></Button>
                    </div>
                    {comment.message?.trim() && comment.message !== " " && <p className="text-sm text-gray-700 mt-1 break-words">{comment.message}</p>}
                    {comment.image_url && (
                      <div className="mt-2">
                        <img src={comment.image_url} alt="Attachment" className="max-w-[200px] max-h-[200px] rounded-lg border border-gray-200 cursor-pointer hover:opacity-90 transition-opacity object-cover" onClick={() => comment.image_url && window.open(comment.image_url, "_blank")} />
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        <Separator />

        <div className="p-3 space-y-2">
          {imageBase64 && (
            <div className="flex items-center gap-2 bg-red-50 rounded-lg p-2">
              <img src={imageBase64} alt="Preview" className="h-12 w-12 rounded object-cover" />
              <span className="text-xs text-gray-600 truncate flex-1">{imageName}</span>
              <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-500 hover:text-red-600" onClick={() => { setImageBase64(null); setImageName(null); }}><X className="h-4 w-4" /></Button>
            </div>
          )}
          <div className="flex gap-2">
            <Input placeholder="Напишите комментарий..." value={message} onChange={(e) => setMessage(e.target.value)} onKeyDown={handleKeyDown} className="flex-1" />
            <input type="file" accept="image/*" ref={fileInputRef} onChange={handleImageSelect} className="hidden" />
            <Button variant="outline" size="icon" className="border-red-300 text-red-700 hover:bg-red-50 flex-shrink-0" onClick={() => fileInputRef.current?.click()} title="Прикрепить фото"><ImageIcon className="h-4 w-4" /></Button>
            <Button size="icon" className="bg-red-700 hover:bg-red-800 text-white flex-shrink-0" onClick={handleSend} disabled={!message.trim() && !imageBase64}><Send className="h-4 w-4" /></Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
