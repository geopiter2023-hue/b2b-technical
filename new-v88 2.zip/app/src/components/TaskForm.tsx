import { useState, useEffect } from "react";
import { createTask, updateTask, type Task } from "@/services/taskService";
import {
  getCategories, addCategory, deleteCategory,
  type Category,
} from "@/services/categoryService";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import TaskChat from "./TaskChat";
import { Plus, X, Settings } from "lucide-react";

const statusOptions = [
  { value: "not_started", label: "Не начата" },
  { value: "planning", label: "Планирование" },
  { value: "in_progress", label: "В работе" },
  { value: "review", label: "На проверке" },
  { value: "completed", label: "Завершена" },
  { value: "cancelled", label: "Отменена" },
];

const priorityOptions = [
  { value: "low", label: "Низкий" },
  { value: "medium", label: "Средний" },
  { value: "high", label: "Высокий" },
  { value: "critical", label: "Критичный" },
];

interface TaskFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: () => void;
  initialData?: Task | null;
}

export default function TaskForm({ open, onOpenChange, onSubmit, initialData }: TaskFormProps) {
  const [form, setForm] = useState({
    name: "", description: "", status: "not_started", priority: "medium",
    assignee: "", executor: "", startDate: "", endDate: "",
    complexity: "3", budget: "", progress: "0", notes: "", category: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [showCatMgr, setShowCatMgr] = useState(false);
  const [newCatName, setNewCatName] = useState("");

  useEffect(() => {
    if (open) {
      setCategories(getCategories());
    }
  }, [open]);

  useEffect(() => {
    if (open && initialData) {
      setForm({
        name: initialData.name || "", description: initialData.description || "",
        status: initialData.status || "not_started", priority: initialData.priority || "medium",
        assignee: initialData.assignee || "", executor: initialData.executor || "",
        startDate: initialData.start_date || "", endDate: initialData.end_date || "",
        complexity: String(initialData.complexity || "3"),
        budget: String(initialData.budget || ""),
        progress: String(initialData.progress || 0),
        notes: initialData.notes || "", category: initialData.category || "",
      });
    } else if (open) {
      setForm({
        name: "", description: "", status: "not_started", priority: "medium",
        assignee: "", executor: "", startDate: "", endDate: "",
        complexity: "3", budget: "", progress: "0", notes: "", category: "",
      });
    }
    setError("");
    setShowCatMgr(false);
    setNewCatName("");
  }, [open, initialData]);

  if (!open) return null;

  const handleChange = (key: string, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleAddCategory = () => {
    const name = newCatName.trim();
    if (!name) return;
    if (categories.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
      setError("Категория уже существует");
      return;
    }
    addCategory(name);
    setCategories(getCategories());
    setNewCatName("");
    setError("");
  };

  const handleDeleteCategory = (id: string) => {
    deleteCategory(id);
    setCategories(getCategories());
    if (form.category && !getCategories().find((c) => c.name === form.category)) {
      handleChange("category", "");
    }
  };

  const handleSubmit = async () => {
    if (!form.name.trim()) { setError("Введите название задачи"); return; }
    setLoading(true); setError("");
    try {
      const taskData = {
        name: form.name, description: form.description || null,
        status: form.status, priority: form.priority,
        assignee: form.assignee || null, executor: form.executor || null,
        start_date: form.startDate || null, end_date: form.endDate || null,
        complexity: parseInt(form.complexity) || 3,
        budget: form.budget ? parseFloat(form.budget) : null,
        progress: parseInt(form.progress) || 0,
        notes: form.notes || null, category: form.category || null,
      };
      if (initialData?.id) {
        await updateTask(initialData.id, taskData);
      } else {
        await createTask(taskData);
      }
      onOpenChange(false); onSubmit();
    } catch (e: any) { setError(e.message || "Ошибка сохранения"); }
    finally { setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start sm:items-center justify-center pt-4 sm:pt-0 px-2 sm:px-4">
      <div className="absolute inset-0 bg-black/50" onClick={() => onOpenChange(false)} />
      <div className="relative bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">{initialData ? "Редактирование задачи" : "Новая задача"}</h2>
          <button onClick={() => onOpenChange(false)} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">&times;</button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          {error && !showCatMgr && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">{error}</div>
          )}

          {/* Category Manager Dialog */}
          {showCatMgr && (
            <div className="border rounded-lg p-4 bg-gray-50">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-sm flex items-center gap-2"><Settings className="h-4 w-4" />Управление категориями</h3>
                <button onClick={() => { setShowCatMgr(false); setError(""); }} className="text-gray-400 hover:text-gray-600"><X className="h-4 w-4" /></button>
              </div>

              {/* Add new */}
              <div className="flex gap-2 mb-3">
                <Input
                  placeholder="Новая категория..."
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleAddCategory(); }}
                  className="flex-1"
                />
                <Button size="sm" className="bg-red-700 hover:bg-red-800" onClick={handleAddCategory}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {/* List */}
              <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto">
                {categories.map((cat) => (
                  <Badge
                    key={cat.id}
                    className="flex items-center gap-1 px-2 py-1 cursor-default"
                    style={{ backgroundColor: cat.color + "20", color: cat.color, border: `1px solid ${cat.color}40` }}
                  >
                    <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: cat.color }} />
                    {cat.name}
                    <button
                      onClick={() => handleDeleteCategory(cat.id)}
                      className="ml-1 hover:opacity-70"
                      title="Удалить"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="md:col-span-2">
              <Label>Название *</Label>
              <Input value={form.name} onChange={(e) => handleChange("name", e.target.value)} />
            </div>
            <div className="md:col-span-2">
              <Label>Описание</Label>
              <Textarea value={form.description} onChange={(e) => handleChange("description", e.target.value)} rows={3} />
            </div>
            <div>
              <Label>Статус</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.status} onChange={(e) => handleChange("status", e.target.value)}>
                {statusOptions.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
            <div>
              <Label>Приоритет</Label>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.priority} onChange={(e) => handleChange("priority", e.target.value)}>
                {priorityOptions.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
              </select>
            </div>

            {/* Category with management button */}
            <div>
              <div className="flex items-center justify-between">
                <Label>Категория</Label>
                <Button variant="ghost" size="sm" className="h-6 text-xs text-red-600 hover:text-red-800 px-2" onClick={() => setShowCatMgr(!showCatMgr)}>
                  <Settings className="h-3 w-3 mr-1" />{showCatMgr ? "Скрыть" : "Управление"}
                </Button>
              </div>
              <select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={form.category} onChange={(e) => handleChange("category", e.target.value)}>
                <option value="">—</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <Label>Сложность (1-5)</Label>
              <Input type="number" min="1" max="5" value={form.complexity} onChange={(e) => handleChange("complexity", e.target.value)} />
            </div>
            <div>
              <Label>Ответственный</Label>
              <Input value={form.assignee} onChange={(e) => handleChange("assignee", e.target.value)} />
            </div>
            <div>
              <Label>Исполнитель</Label>
              <Input value={form.executor} onChange={(e) => handleChange("executor", e.target.value)} />
            </div>
            <div>
              <Label>Дата начала</Label>
              <Input type="date" value={form.startDate} onChange={(e) => handleChange("startDate", e.target.value)} />
            </div>
            <div>
              <Label>Дата окончания</Label>
              <Input type="date" value={form.endDate} onChange={(e) => handleChange("endDate", e.target.value)} />
            </div>
            <div>
              <Label>Бюджет (₽)</Label>
              <Input type="number" value={form.budget} onChange={(e) => handleChange("budget", e.target.value)} />
            </div>
            <div>
              <Label>Прогресс (%)</Label>
              <Input type="number" min="0" max="100" value={form.progress} onChange={(e) => handleChange("progress", e.target.value)} />
            </div>
            <div className="md:col-span-2">
              <Label>Примечания</Label>
              <Textarea value={form.notes} onChange={(e) => handleChange("notes", e.target.value)} rows={2} />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2 p-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">Отмена</Button>
          <Button className="bg-red-700 hover:bg-red-800 w-full sm:w-auto" onClick={handleSubmit} disabled={loading}>
            {loading ? "Сохранение..." : initialData ? "Сохранить" : "Создать"}
          </Button>
        </div>

        {initialData?.id && (
          <div className="border-t p-4">
            <TaskChat taskId={initialData.id} />
          </div>
        )}
      </div>
    </div>
  );
}
