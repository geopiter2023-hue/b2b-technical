import { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import ProgressBar from "@/components/ProgressBar";
import { Pencil, Trash2, ChevronDown, ChevronRight, LayoutGrid } from "lucide-react";
import type { Task } from "@/services/taskService";

const statusMap: Record<string, { label: string; color: string }> = {
  not_started: { label: "Не начата", color: "bg-gray-100 text-gray-700" },
  planning: { label: "В планировании", color: "bg-amber-100 text-amber-700" },
  in_progress: { label: "В работе", color: "bg-red-100 text-red-700" },
  review: { label: "На проверке", color: "bg-purple-100 text-purple-700" },
  completed: { label: "Завершена", color: "bg-emerald-100 text-emerald-700" },
  cancelled: { label: "Отменена", color: "bg-red-50 text-red-600" },
};

const priorityMap: Record<string, { label: string; color: string }> = {
  low: { label: "Низкий", color: "bg-gray-100 text-gray-600" },
  medium: { label: "Средний", color: "bg-amber-100 text-amber-700" },
  high: { label: "Высокий", color: "bg-red-100 text-red-700" },
  critical: { label: "Критичный", color: "bg-red-200 text-red-800" },
};

interface CategoryTableViewProps {
  tasks: Task[];
  isLoading: boolean;
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  tableWidth: number;
  topScrollRef: React.RefObject<HTMLDivElement | null>;
  bottomScrollRef: React.RefObject<HTMLDivElement | null>;
  handleTopScroll: (e: React.UIEvent<HTMLDivElement>) => void;
  handleBottomScroll: (e: React.UIEvent<HTMLDivElement>) => void;
}

export default function CategoryTableView({
  tasks,
  isLoading,
  onEdit,
  onDelete,
  tableWidth,
  topScrollRef,
  bottomScrollRef,
  handleTopScroll,
  handleBottomScroll,
}: CategoryTableViewProps) {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  // Group tasks by category
  const grouped = useMemo(() => {
    const map = new Map<string, Task[]>();
    for (const task of tasks) {
      const cat = task.category || "Без категории";
      const arr = map.get(cat) || [];
      arr.push(task);
      map.set(cat, arr);
    }
    // Sort: named categories first, then "Без категории" last
    const sorted = Array.from(map.entries()).sort((a, b) => {
      if (a[0] === "Без категории") return 1;
      if (b[0] === "Без категории") return -1;
      return a[0].localeCompare(b[0], "ru");
    });
    return sorted;
  }, [tasks]);

  const toggleCategory = (cat: string) => {
    setExpandedCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const expandAll = () => {
    const all: Record<string, boolean> = {};
    grouped.forEach(([cat]) => { all[cat] = true; });
    setExpandedCategories(all);
  };

  const collapseAll = () => setExpandedCategories({});

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-gray-500">Загрузка...</CardContent>
      </Card>
    );
  }

  if (tasks.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-gray-500">Задачи не найдены</CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {/* Controls */}
      <div className="flex items-center gap-2">
        <Button variant="outline" size="sm" className="text-gray-600" onClick={expandAll}>
          <LayoutGrid className="h-3 w-3 mr-1" />Развернуть все
        </Button>
        <Button variant="outline" size="sm" className="text-gray-600" onClick={collapseAll}>
          Свернуть все
        </Button>
        <span className="text-sm text-gray-500 ml-2">{grouped.length} категорий, {tasks.length} задач</span>
      </div>

      {/* Top scrollbar */}
      <div
        ref={topScrollRef}
        onScroll={handleTopScroll}
        style={{ overflowX: "auto", overflowY: "hidden", height: "16px", marginBottom: "4px", borderBottom: "1px solid #e5e7eb" }}
      >
        <div style={{ width: `${tableWidth}px`, height: "1px" }} />
      </div>

      {/* Category blocks */}
      {grouped.map(([category, categoryTasks]) => {
        const isExpanded = expandedCategories[category] || false;
        const avgProgress = categoryTasks.reduce((s, t) => s + (t.progress || 0), 0) / categoryTasks.length;
        const completedCount = categoryTasks.filter((t) => t.status === "completed").length;

        return (
          <Card key={category} className="overflow-hidden">
            {/* Category header */}
            <button
              onClick={() => toggleCategory(category)}
              className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                {isExpanded ? (
                  <ChevronDown className="h-5 w-5 text-red-600 flex-shrink-0" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-gray-500 flex-shrink-0" />
                )}
                <span className="font-semibold text-gray-800">{category}</span>
                <Badge className="bg-red-50 text-red-700 border border-red-200">
                  {categoryTasks.length} {categoryTasks.length === 1 ? "задача" : categoryTasks.length < 5 ? "задачи" : "задач"}
                </Badge>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-xs text-gray-500">Выполнено {completedCount}/{categoryTasks.length}</div>
                  <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden mt-1">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${avgProgress}%`,
                        backgroundColor: avgProgress >= 76 ? "#10B981" : avgProgress >= 26 ? "#F97316" : "#9CA3AF",
                      }}
                    />
                  </div>
                </div>
              </div>
            </button>

            {/* Tasks table */}
            {isExpanded && (
              <CardContent className="p-0" style={{ overflowX: "auto" }} ref={bottomScrollRef} onScroll={handleBottomScroll}>
                <Table style={{ minWidth: `${tableWidth}px` }}>
                  <TableHeader>
                    <TableRow className="bg-gray-50 hover:bg-gray-50">
                      <TableHead className="w-[50px]">ID</TableHead>
                      <TableHead style={{ minWidth: "280px" }}>Название</TableHead>
                      <TableHead>Статус</TableHead>
                      <TableHead>Приоритет</TableHead>
                      <TableHead className="hidden md:table-cell">Ответственный</TableHead>
                      <TableHead className="hidden lg:table-cell">Исполнитель</TableHead>
                      <TableHead>Начало</TableHead>
                      <TableHead className="hidden md:table-cell">Окончание</TableHead>
                      <TableHead className="hidden lg:table-cell">Сложность</TableHead>
                      <TableHead>Прогресс</TableHead>
                      <TableHead className="w-[100px]">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {categoryTasks.map((task) => (
                      <TableRow key={task.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium cursor-pointer" onClick={() => onEdit(task)}>{task.id}</TableCell>
                        <TableCell className="cursor-pointer" style={{ minWidth: "280px" }} onClick={() => onEdit(task)}>
                          <span className="text-sm text-gray-800 hover:text-red-700 transition-colors" style={{ whiteSpace: "normal", wordBreak: "break-word" }}>{task.name}</span>
                        </TableCell>
                        <TableCell>
                          <Badge className={statusMap[task.status]?.color || "bg-gray-100"}>
                            {statusMap[task.status]?.label || task.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={priorityMap[task.priority]?.color || "bg-gray-100"}>
                            {priorityMap[task.priority]?.label || task.priority}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">{task.assignee || "—"}</TableCell>
                        <TableCell className="hidden lg:table-cell">{task.executor || "—"}</TableCell>
                        <TableCell>{task.start_date ? new Date(task.start_date).toLocaleDateString("ru-RU") : "—"}</TableCell>
                        <TableCell className="hidden md:table-cell">{task.end_date ? new Date(task.end_date).toLocaleDateString("ru-RU") : "—"}</TableCell>
                        <TableCell className="hidden lg:table-cell">{task.complexity || "—"}</TableCell>
                        <TableCell><ProgressBar value={task.progress || 0} /></TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-800" onClick={() => onEdit(task)}><Pencil className="h-4 w-4" /></Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-800" onClick={(e) => { e.stopPropagation(); onDelete(task.id); }}><Trash2 className="h-4 w-4" /></Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            )}
          </Card>
        );
      })}

      {/* Bottom scrollbar */}
      <div style={{ overflowX: "auto", overflowY: "hidden", height: "16px", marginTop: "4px", borderTop: "1px solid #e5e7eb" }}>
        <div style={{ width: `${tableWidth}px`, height: "1px" }} />
      </div>
    </div>
  );
}
