import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronDown, X, Check } from "lucide-react";

interface MultiSelectProps {
  placeholder: string;
  options: { value: string; label: string; color?: string }[];
  selected: string[];
  onChange: (selected: string[]) => void;
  className?: string;
}

export default function MultiSelect({ placeholder, options, selected, onChange, className = "" }: MultiSelectProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  const toggleValue = (value: string) => {
    if (selected.includes(value)) {
      onChange(selected.filter((v) => v !== value));
    } else {
      onChange([...selected, value]);
    }
  };

  const selectAll = () => onChange(options.map((o) => o.value));
  const clearAll = () => onChange([]);

  const displayText = selected.length === 0
    ? placeholder
    : selected.length === 1
      ? options.find((o) => o.value === selected[0])?.label || selected[0]
      : `${selected.length} выбрано`;

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full h-8 px-3 text-sm border border-input rounded-md bg-background hover:bg-accent transition-colors"
      >
        <span className="truncate">{displayText}</span>
        <div className="flex items-center gap-1 flex-shrink-0">
          {selected.length > 0 && (
            <span
              className="flex items-center justify-center w-4 h-4 rounded-full bg-red-600 text-white text-[10px] cursor-pointer hover:bg-red-700"
              onClick={(e) => { e.stopPropagation(); clearAll(); }}
            >
              <X className="h-3 w-3" />
            </span>
          )}
          <ChevronDown className={`h-4 w-4 text-gray-400 transition-transform ${open ? "rotate-180" : ""}`} />
        </div>
      </button>

      {open && (
        <div className="absolute z-50 mt-1 w-full min-w-[200px] bg-white border rounded-md shadow-lg max-h-64 overflow-y-auto">
          <div className="sticky top-0 bg-white border-b p-2 flex items-center justify-between gap-2">
            <Button variant="ghost" size="sm" className="h-6 text-xs text-red-600" onClick={selectAll}>
              <Check className="h-3 w-3 mr-1" />Все
            </Button>
            <Button variant="ghost" size="sm" className="h-6 text-xs text-gray-500" onClick={clearAll}>
              <X className="h-3 w-3 mr-1" />Снять
            </Button>
          </div>
          <div className="p-1">
            {options.map((opt) => (
              <label
                key={opt.value}
                className="flex items-center gap-2 px-2 py-1.5 text-sm cursor-pointer hover:bg-gray-50 rounded"
              >
                <Checkbox
                  checked={selected.includes(opt.value)}
                  onCheckedChange={() => toggleValue(opt.value)}
                />
                {opt.color && (
                  <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: opt.color }} />
                )}
                <span className="truncate">{opt.label}</span>
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
