import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Lock, X } from "lucide-react";

const CORRECT_PASSWORD = "17031987";

interface PasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
  action: string;
}

export default function PasswordDialog({ open, onOpenChange, onSuccess, action }: PasswordDialogProps) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [attempts, setAttempts] = useState(0);

  if (!open) return null;

  const handleSubmit = () => {
    if (password === CORRECT_PASSWORD) {
      setPassword("");
      setError("");
      setAttempts(0);
      onOpenChange(false);
      onSuccess();
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setError(`Неверный пароль. Попытка ${newAttempts}/3`);
      if (newAttempts >= 3) {
        setPassword("");
        setError("Превышено количество попыток");
        setTimeout(() => { onOpenChange(false); setAttempts(0); setError(""); }, 1500);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={() => { onOpenChange(false); setAttempts(0); setError(""); }} />
      <div className="relative bg-white rounded-lg shadow-xl w-full max-w-sm mx-4 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-red-700" />
            <h3 className="text-lg font-semibold">Подтверждение</h3>
          </div>
          <button onClick={() => { onOpenChange(false); setAttempts(0); setError(""); }} className="text-gray-400 hover:text-gray-600">
            <X className="h-5 w-5" />
          </button>
        </div>
        <p className="text-sm text-gray-600 mb-4">
          Для выполнения действия <strong>"{action}"</strong> введите пароль:
        </p>
        <Input
          type="password"
          placeholder="Пароль"
          value={password}
          onChange={(e) => { setPassword(e.target.value); setError(""); }}
          onKeyDown={(e) => { if (e.key === "Enter") handleSubmit(); }}
          className="mb-3"
          autoFocus
        />
        {error && <p className="text-sm text-red-600 mb-3">{error}</p>}
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={() => { onOpenChange(false); setAttempts(0); setError(""); }}>
            Отмена
          </Button>
          <Button className="flex-1 bg-red-700 hover:bg-red-800" onClick={handleSubmit} disabled={!password || attempts >= 3}>
            Подтвердить
          </Button>
        </div>
      </div>
    </div>
  );
}
