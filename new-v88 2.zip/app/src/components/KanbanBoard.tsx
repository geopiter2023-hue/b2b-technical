import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2, GripVertical, ChevronDown, ChevronRight } from "lucide-react";
import { updateTask, type Task } from "@/services/taskService";

const statusConfig: Record<string, { label: string; bg: string; headerBg: string; border: string }> = {
  not_started: { label: "Не начата", bg: "bg-gray-50", headerBg: "bg-gray-200", border: "border-gray-300" },
  planning: { label: "В планировании", bg: "bg-amber-50", headerBg: "bg-amber-200", border: "border-amber-300" },
  in_progress: { label: "В работе", bg: "bg-red-50", headerBg: "bg-red-200", border: "border-red-300" },
  review: { label: "На проверке", bg: "bg-purple-50", headerBg: "bg-purple-200", border: "border-purple-300" },
  completed: { label: "Завершена", bg: "bg-emerald-50", headerBg: "bg-emerald-200", border: "border-emerald-300" },
  cancelled: { label: "Отменена", bg: "bg-red-50", headerBg: "bg-red-200", border: "border-red-300" },
};

const priorityBadge: Record<string, string> = {
  low: "bg-gray-100 text-gray-600",
  medium: "bg-amber-50 text-amber-700",
  high: "bg-red-50 text-red-700",
  critical: "bg-red-100 text-red-800",
};

const priorityLabels: Record<string, string> = {
  low: "Низкий",
  medium: "Средний",
  high: "Высокий",
  critical: "Критичный",
};

interface KanbanBoardProps {
  tasks: Task[];
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  onRefresh: () => void;
}

export default function KanbanBoard({ tasks, onEdit, onDelete, onRefresh }: KanbanBoardProps) {
  const [draggedTask, setDraggedTask] = useState<number | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  // Group tasks by category
  const groupedByCategory = tasks.reduce<Record<string, Task[]>>((acc, task) => {
    const cat = task.category || "Без категории";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(task);
    return acc;
  }, {});

  // Sort categories: ones with names first, then "Без категории" last
  const sortedCategories = Object.keys(groupedByCategory).sort((a, b) => {
    if (a === "Без категории") return 1;
    if (b === "Без категории") return -1;
    return a.localeCompare(b, "ru");
  });

  const toggleCategory = (cat: string) => {
    setExpandedCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const handleDragStart = (taskId: number) => {
    setDraggedTask(taskId);
  };

  const handleDragOver = (e: React.DragEvent, status: string) => {
    e.preventDefault();
    setDragOverColumn(status);
  };

  const handleDrop = async (e: React.DragEvent, newStatus: string) => {
    e.preventDefault();
    setDragOverColumn(null);
    if (!draggedTask) return;

    const task = tasks.find((t) => t.id === draggedTask);
    if (!task || task.status === newStatus) return;

    try {
      await updateTask(task.id, { status: newStatus });
      onRefresh();
    } catch (err) {
      console.error("Failed to update status:", err);
    }
    setDraggedTask(null);
  };

  const handleDragEnd = () => {
    setDraggedTask(null);
    setDragOverColumn(null);
  };

  // Render task card (shared between desktop kanban and mobile list)
  const TaskCard = ({ task }: { task: Task }) => (
    <div
      draggable
      onDragStart={() => handleDragStart(task.id)}
      onDragEnd={handleDragEnd}
      className="bg-white rounded-md p-3 shadow-sm border border-gray-200 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
    >
      {/* Task name */}
      <h4
        className="text-sm font-medium text-gray-800 mb-2 hover:text-red-700 cursor-pointer leading-snug"
        style={{ whiteSpace: "normal", wordBreak: "break-word" }}
        onClick={() => onEdit(task)}
      >
        {task.name}
      </h4>

      {/* Meta row */}
      <div className="flex items-center justify-between mb-2">
        <Badge className={`text-xs ${priorityBadge[task.priority] || "bg-gray-100"}`}>
          {priorityLabels[task.priority] || task.priority}
        </Badge>
        <span className="text-xs text-gray-400">#{task.id}</span>
      </div>

      {/* Progress */}
      {typeof task.progress === "number" && task.progress > 0 && (
        <div className="mb-2">
          <div className="flex justify-between text-xs mb-0.5">
            <span className="text-gray-500">Прогресс</span>
            <span className="text-gray-700">{task.progress}%</span>
          </div>
          <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${task.progress}%`,
                backgroundColor: (task.progress ?? 0) >= 76 ? "#10B981" : (task.progress ?? 0) >= 26 ? "#F97316" : "#9CA3AF",
              }}
            />
          </div>
        </div>
      )}

      {/* Footer info */}
      <div className="flex items-center justify-between text-xs text-gray-500">
        <div className="flex flex-col gap-0.5">
          {task.assignee && <span className="truncate max-w-[120px]">{task.assignee}</span>}
          {task.end_date && (
            <span>{new Date(task.end_date).toLocaleDateString("ru-RU")}</span>
          )}
        </div>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-gray-400 hover:text-red-600"
            onClick={() => onEdit(task)}
          >
            <Pencil className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-gray-400 hover:text-red-600"
            onClick={() => onDelete(task.id)}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </div>
    </div>
  );

  // Render mobile task list (vertical within category)
  const MobileTaskList = ({ categoryTasks }: { categoryTasks: Task[] }) => {
    const byStatus = Object.fromEntries(
      Object.keys(statusConfig).map((s) => [s, categoryTasks.filter((t) => t.status === s)])
    );

    return (
      <div className="md:hidden space-y-3">
        {Object.entries(statusConfig).map(([status, config]) => {
          const statusTasks = byStatus[status] || [];
          if (statusTasks.length === 0) return null;
          return (
            <div key={status}>
              <div className={`${config.headerBg} px-3 py-1.5 rounded-t-lg flex items-center justify-between`}>
                <span className="font-semibold text-xs">{config.label}</span>
                <Badge className="bg-white/80 text-gray-700 text-xs">{statusTasks.length}</Badge>
              </div>
              <div className={`${config.bg} p-2 space-y-2 rounded-b-lg`}>
                {statusTasks.map((task) => (
                  <TaskCard key={task.id} task={task} />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // Render desktop kanban columns
  const DesktopKanban = ({ categoryTasks }: { categoryTasks: Task[] }) => {
    const byStatus = Object.fromEntries(
      Object.keys(statusConfig).map((s) => [s, categoryTasks.filter((t) => t.status === s)])
    );

    return (
      <div className="hidden md:flex gap-4 overflow-x-auto pb-4" style={{ minHeight: "300px" }}>
        {Object.entries(statusConfig).map(([status, config]) => (
          <div
            key={status}
            className={`flex-shrink-0 w-[280px] rounded-lg border ${config.border} ${dragOverColumn === status ? "ring-2 ring-red-400 ring-offset-2" : ""}`}
            onDragOver={(e) => handleDragOver(e, status)}
            onDrop={(e) => handleDrop(e, status)}
          >
            {/* Column header */}
            <div className={`${config.headerBg} px-3 py-2 rounded-t-lg flex items-center justify-between`}>
              <div className="flex items-center gap-2">
                <GripVertical className="h-4 w-4 text-gray-500" />
                <span className="font-semibold text-sm">{config.label}</span>
              </div>
              <Badge className="bg-white/80 text-gray-700">{byStatus[status]?.length || 0}</Badge>
            </div>

            {/* Task cards */}
            <div className={`${config.bg} p-2 space-y-2 rounded-b-lg min-h-[150px]`}>
              {(byStatus[status] || []).map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}

              {(!byStatus[status] || byStatus[status].length === 0) && (
                <div className="text-center py-6 text-gray-400 text-sm">
                  Нет задач
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        Задачи не найдены
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {sortedCategories.map((category) => {
        const categoryTasks = groupedByCategory[category];
        const isExpanded = expandedCategories[category] ?? false;
        const taskCount = categoryTasks.length;

        return (
          <div key={category} className="border border-gray-200 rounded-lg overflow-hidden bg-white">
            {/* Accordion header */}
            <button
              onClick={() => toggleCategory(category)}
              className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
            >
              <div className="flex items-center gap-3">
                {isExpanded ? (
                  <ChevronDown className="h-5 w-5 text-red-600 flex-shrink-0" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-gray-500 flex-shrink-0" />
                )}
                <span className="font-semibold text-gray-800">{category}</span>
              </div>
              <Badge className="bg-red-50 text-red-700 border border-red-200">
                {taskCount} {taskCount === 1 ? "задача" : taskCount < 5 ? "задачи" : "задач"}
              </Badge>
            </button>

            {/* Expanded content */}
            {isExpanded && (
              <div className="p-3 border-t border-gray-200">
                <MobileTaskList categoryTasks={categoryTasks} />
                <DesktopKanban categoryTasks={categoryTasks} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
