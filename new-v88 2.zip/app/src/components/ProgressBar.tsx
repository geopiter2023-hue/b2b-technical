interface ProgressBarProps {
  value: number;
}

export default function ProgressBar({ value }: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, value || 0));

  let colorClass = "bg-gray-400";
  if (clamped >= 76) {
    colorClass = "bg-emerald-500";
  } else if (clamped >= 26) {
    colorClass = "bg-orange-500";
  }

  return (
    <div className="flex items-center gap-2">
      <div className="w-20 h-2.5 bg-gray-200 rounded-full overflow-hidden flex-shrink-0">
        <div
          className={`h-full rounded-full transition-all duration-500 ${colorClass}`}
          style={{ width: `${clamped}%` }}
        />
      </div>
      <span className="text-xs text-gray-600 font-medium w-8 flex-shrink-0">
        {clamped}%
      </span>
    </div>
  );
}
