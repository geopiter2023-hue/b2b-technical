import { useState, useEffect, useCallback } from "react";
import { getCurrentUser, logoutUser } from "@/services/authService";

export interface AuthUser {
  id: string;
  login: string;
  role: string;
}

const AUTH_USER_KEY = "b2b_auth_user";
const AUTH_TOKEN_KEY = "sb_session";

// Quick local check — returns user immediately without async
function checkLocalSession(): AuthUser | null {
  try {
    const saved = localStorage.getItem(AUTH_USER_KEY);
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    if (saved && token) {
      return JSON.parse(saved);
    }
  } catch {
    localStorage.removeItem(AUTH_USER_KEY);
    localStorage.removeItem(AUTH_TOKEN_KEY);
  }
  return null;
}

export function useAuth() {
  // Initialize from localStorage immediately (no flash of login screen)
  const [user, setUser] = useState<AuthUser | null>(() => checkLocalSession());
  const [isLoading, setIsLoading] = useState(!checkLocalSession());

  useEffect(() => {
    // If no local session, try Supabase
    if (!checkLocalSession()) {
      getCurrentUser()
        .then((u) => {
          if (u) setUser(u as AuthUser);
        })
        .catch(() => {})
        .finally(() => setIsLoading(false));
    } else {
      setIsLoading(false);
    }
  }, []);

  const login = useCallback((token: string, newUser: AuthUser) => {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(newUser));
    setUser(newUser);
  }, []);

  const logout = useCallback(async () => {
    await logoutUser();
    setUser(null);
    window.location.reload();
  }, []);

  return { user, isLoading, login, logout, isAuthenticated: !!user };
}
