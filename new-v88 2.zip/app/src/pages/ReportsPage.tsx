import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Layout from "@/components/Layout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download, FileText, ArrowLeft } from "lucide-react";
import { Link } from "react-router";
import jsPDF from "jspdf";
import html2canvas from "html2canvas-pro";
import { listTasks, type Task } from "@/services/taskService";

const statusMap: Record<string, string> = {
  not_started: "Не начата",
  planning: "В планировании",
  in_progress: "В работе",
  review: "На проверке",
  completed: "Завершена",
  cancelled: "Отменена",
};

const priorityMap: Record<string, string> = {
  low: "Низкий",
  medium: "Средний",
  high: "Высокий",
  critical: "Критичный",
};

export default function ReportsPage() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
  const [exportingPdf, setExportingPdf] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const filters = statusFilter === "all" ? {} : { status: statusFilter };
    listTasks(filters, undefined, undefined, 1, 200)
      .then((data) => {
        setTasks(data.list);
        applyDateFilter(data.list, dateFrom, dateTo);
      })
      .catch(console.error);
  }, [statusFilter]);

  const applyDateFilter = (taskList: Task[], from: string, to: string) => {
    let filtered = [...taskList];
    if (from) {
      filtered = filtered.filter((t) => !t.start_date || t.start_date >= from);
    }
    if (to) {
      filtered = filtered.filter((t) => !t.end_date || t.end_date <= to);
    }
    setFilteredTasks(filtered);
  };

  const handleDateFromChange = (val: string) => {
    setDateFrom(val);
    applyDateFilter(tasks, val, dateTo);
  };

  const handleDateToChange = (val: string) => {
    setDateTo(val);
    applyDateFilter(tasks, dateFrom, val);
  };

  const handleExportPdf = async () => {
    if (filteredTasks.length === 0) { alert("Нет данных для экспорта"); return; }
    setExportingPdf(true);
    // Give React time to render the hidden div
    await new Promise((r) => setTimeout(r, 100));
    try {
      if (!reportRef.current) throw new Error("PDF element not found");
      const canvas = await html2canvas(reportRef.current, {
        scale: 1.5,
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
        windowWidth: 1200,
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("l", "mm", "a4");
      const pageWidth = 297;
      const pageHeight = 210;
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height / canvas.width) * pageWidth;

      if (imgHeight <= pageHeight) {
        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      } else {
        let y = 0;
        while (y < imgHeight) {
          pdf.addImage(imgData, "PNG", 0, -y, imgWidth, imgHeight);
          y += pageHeight;
          if (y < imgHeight) pdf.addPage();
        }
      }
      pdf.save("b2b_tasks_report.pdf");
    } catch (err: any) {
      console.error("PDF export error:", err);
      alert("Ошибка PDF: " + err.message);
    } finally {
      setExportingPdf(false);
    }
  };

  const now = new Date().toLocaleDateString("ru-RU");

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Link to="/"><Button variant="ghost" size="icon"><ArrowLeft className="h-5 w-5" /></Button></Link>
            <h1 className="text-xl sm:text-2xl font-bold text-gray-900">Отчеты и экспорт</h1>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div>
                <Label className="text-xs text-gray-500 mb-1 block">Статус</Label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все статусы</SelectItem>
                    {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-gray-500 mb-1 block">Дата начала (с)</Label>
                <Input type="date" value={dateFrom} onChange={(e) => handleDateFromChange(e.target.value)} />
              </div>
              <div>
                <Label className="text-xs text-gray-500 mb-1 block">Дата окончания (по)</Label>
                <Input type="date" value={dateTo} onChange={(e) => handleDateToChange(e.target.value)} />
              </div>
              <div className="flex items-end">
                <Button className="w-full bg-red-700 hover:bg-red-800" onClick={handleExportPdf} disabled={exportingPdf}>
                  <Download className="h-4 w-4 mr-2" />{exportingPdf ? "Формирование..." : "Экспорт PDF"}
                </Button>
              </div>
            </div>
            <p className="text-sm text-gray-500 mt-2">Найдено задач: <strong>{filteredTasks.length}</strong></p>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-red-700" />PDF отчет</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">Полный отчет по задачам с фильтрами по статусу и датам.</p>
              <Button variant="outline" className="w-full border-red-700 text-red-700 hover:bg-red-50" onClick={handleExportPdf} disabled={exportingPdf}>
                <Download className="h-4 w-4 mr-2" />{exportingPdf ? "Формирование..." : "Скачать PDF"}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-emerald-600" />Сводка</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-gray-600">Всего задач:</span><span className="font-semibold">{filteredTasks.length}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">В работе:</span><span className="font-semibold text-red-700">{filteredTasks.filter((t) => t.status === "in_progress").length}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Завершено:</span><span className="font-semibold text-emerald-700">{filteredTasks.filter((t) => t.status === "completed").length}</span></div>
                <div className="flex justify-between"><span className="text-gray-600">Просрочено:</span><span className="font-semibold text-red-700">{filteredTasks.filter((t) => t.end_date && new Date(t.end_date) < new Date() && t.status !== "completed" && t.status !== "cancelled").length}</span></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2"><FileText className="h-5 w-5 text-amber-600" />Диаграмма Ганта</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">Визуальное представление задач по временной шкале.</p>
              <Link to="/gantt"><Button variant="outline" className="w-full border-amber-600 text-amber-600 hover:bg-amber-50">Перейти к Ганту</Button></Link>
            </CardContent>
          </Card>
        </div>

        {/* Hidden report for PDF export — grouped by category */}
        {exportingPdf && (
        <div ref={reportRef} style={{ position: "absolute", left: "-9999px", top: 0, width: "1200px" }}>
          <div style={{ padding: "30px", fontFamily: "Arial, sans-serif", background: "#fff" }}>
            {/* Header */}
            <div style={{ borderBottom: "3px solid #DC2626", marginBottom: "20px", paddingBottom: "10px" }}>
              <h1 style={{ fontSize: "24px", color: "#DC2626", margin: 0 }}>Отчет по задачам — B2B Task Manager</h1>
              <p style={{ fontSize: "11px", color: "#666", margin: "5px 0 0" }}>
                Дата: {now} | Всего задач: {filteredTasks.length}
                {dateFrom && ` | Период: с ${new Date(dateFrom).toLocaleDateString("ru-RU")} ${dateTo ? `по ${new Date(dateTo).toLocaleDateString("ru-RU")}` : ""}`}
              </p>
            </div>

            {/* Group by category */}
            {((): JSX.Element[] => {
              const grouped: Record<string, Task[]> = {};
              for (const t of filteredTasks) {
                const cat = t.category || "Без категории";
                if (!grouped[cat]) grouped[cat] = [];
                grouped[cat].push(t);
              }
              const sorted = Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b));
              return sorted.map(([category, catTasks]) => {
                const completed = catTasks.filter((t) => t.status === "completed").length;
                const inProgress = catTasks.filter((t) => t.status === "in_progress").length;
                const avgProgress = catTasks.length > 0 ? Math.round(catTasks.reduce((s, t) => s + (t.progress || 0), 0) / catTasks.length) : 0;
                return (
                  <div key={category} style={{ marginBottom: "20px", pageBreakInside: "avoid" }}>
                    <h2 style={{ fontSize: "14px", color: "#DC2626", borderBottom: "1px solid #DC2626", paddingBottom: "5px", marginBottom: "10px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span>{category}</span>
                      <span style={{ fontSize: "10px", color: "#666", fontWeight: "normal" }}>
                        {catTasks.length} задач | В работе: {inProgress} | Завершено: {completed} | Средний прогресс: {avgProgress}%
                      </span>
                    </h2>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10px" }}>
                      <thead>
                        <tr style={{ background: "#DC2626", color: "#fff" }}>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd" }}>ID</th>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd", width: "30%" }}>Название</th>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd" }}>Статус</th>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd" }}>Приоритет</th>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd" }}>Ответственный</th>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd" }}>Начало</th>
                          <th style={{ padding: "5px", textAlign: "left", border: "1px solid #ddd" }}>Окончание</th>
                          <th style={{ padding: "5px", textAlign: "right", border: "1px solid #ddd" }}>%</th>
                        </tr>
                      </thead>
                      <tbody>
                        {catTasks.map((task, i) => (
                          <tr key={task.id} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                            <td style={{ padding: "4px", border: "1px solid #ddd" }}>{task.id}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd", wordBreak: "break-word" }}>{task.name}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd" }}>{statusMap[task.status] || task.status}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd" }}>{priorityMap[task.priority] || task.priority}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd" }}>{task.assignee || "—"}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd" }}>{task.start_date ? new Date(task.start_date).toLocaleDateString("ru-RU") : "—"}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd" }}>{task.end_date ? new Date(task.end_date).toLocaleDateString("ru-RU") : "—"}</td>
                            <td style={{ padding: "4px", border: "1px solid #ddd", textAlign: "right" }}>{task.progress || 0}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              });
            })()}

            <p style={{ fontSize: "9px", color: "#999", marginTop: "20px", textAlign: "center" }}>
              Сформировано: {new Date().toLocaleString("ru-RU")} | B2B Task Manager — ЛУКОЙЛ
            </p>
          </div>
        </div>
        )}

        {/* Preview */}
        <Card>
          <CardHeader><CardTitle>Предпросмотр данных ({filteredTasks.length} задач)</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 sticky top-0 z-10">
                  <tr>
                    <th className="px-4 py-2 text-left">ID</th>
                    <th className="px-4 py-2 text-left">Название</th>
                    <th className="px-4 py-2 text-left">Статус</th>
                    <th className="px-4 py-2 text-left">Приоритет</th>
                    <th className="px-4 py-2 text-left">Ответственный</th>
                    <th className="px-4 py-2 text-left">Даты</th>
                    <th className="px-4 py-2 text-left">Прогресс</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTasks.slice(0, 50).map((task) => (
                    <tr key={task.id} className="border-t hover:bg-gray-50">
                      <td className="px-4 py-2">{task.id}</td>
                      <td className="px-4 py-2 whitespace-normal break-words" style={{ maxWidth: "400px" }}>{task.name}</td>
                      <td className="px-4 py-2">{statusMap[task.status] || task.status}</td>
                      <td className="px-4 py-2">{priorityMap[task.priority] || task.priority}</td>
                      <td className="px-4 py-2">{task.assignee || "—"}</td>
                      <td className="px-4 py-2">
                        {task.start_date ? new Date(task.start_date).toLocaleDateString("ru-RU") : "—"} — {task.end_date ? new Date(task.end_date).toLocaleDateString("ru-RU") : "—"}
                      </td>
                      <td className="px-4 py-2">{task.progress || 0}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredTasks.length > 50 && <p className="text-center text-sm text-gray-500 py-4">... и еще {filteredTasks.length - 50} задач</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
