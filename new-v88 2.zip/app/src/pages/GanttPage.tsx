import { useState, useRef, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ZoomIn, ZoomOut, Download, ArrowLeft } from "lucide-react";
import { Link } from "react-router";
import jsPDF from "jspdf";
import { listTasks, type Task } from "@/services/taskService";

const statusColors: Record<string, string> = {
  not_started: "#9CA3AF",
  planning: "#FCD34D",
  in_progress: "#DC2626",
  review: "#A855F7",
  completed: "#10B981",
  cancelled: "#EF4444",
};

const statusMap: Record<string, string> = {
  not_started: "Не начата",
  planning: "В планировании",
  in_progress: "В работе",
  review: "На проверке",
  completed: "Завершена",
  cancelled: "Отменена",
};

export default function GanttPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    listTasks({}, "start_date", "asc", 1, 200)
      .then((data) => setTasks(data.list))
      .catch(console.error)
      .finally(() => setIsLoading(false));
  }, []);

  const [scale, setScale] = useState<"week" | "month">("week");
  const [zoom, setZoom] = useState(1);
  const ganttRef = useRef<HTMLDivElement>(null);

  const { minDate, maxDate, timeline } = useMemo(() => {
    const allDates = tasks
      .filter((t) => t.start_date && t.end_date)
      .flatMap((t) => [new Date(t.start_date!), new Date(t.end_date!)]);

    if (allDates.length === 0) {
      const now = new Date();
      return { minDate: now, maxDate: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000), timeline: [] };
    }

    const min = new Date(Math.min(...allDates.map((d) => d.getTime())));
    const max = new Date(Math.max(...allDates.map((d) => d.getTime())));
    min.setDate(min.getDate() - 7);
    max.setDate(max.getDate() + 14);

    const items: { label: string; date: Date }[] = [];
    const curr = new Date(min);

    if (scale === "week") {
      while (curr <= max) {
        const weekStart = new Date(curr);
        const weekEnd = new Date(curr);
        weekEnd.setDate(weekEnd.getDate() + 6);
        items.push({ label: `${weekStart.getDate()}.${weekStart.getMonth() + 1}-${weekEnd.getDate()}.${weekEnd.getMonth() + 1}`, date: new Date(curr) });
        curr.setDate(curr.getDate() + 7);
      }
    } else {
      while (curr <= max) {
        items.push({ label: `${curr.toLocaleString("ru-RU", { month: "short" })} ${curr.getFullYear()}`, date: new Date(curr) });
        curr.setMonth(curr.getMonth() + 1);
      }
    }

    return { minDate: min, maxDate: max, timeline: items };
  }, [tasks, scale]);

  const totalDays = Math.max(1, (maxDate.getTime() - minDate.getTime()) / (1000 * 60 * 60 * 24));

  const getTaskPosition = (start: Date | string, end: Date | string) => {
    const s = typeof start === "string" ? new Date(start) : start;
    const e = typeof end === "string" ? new Date(end) : end;
    // Clamp dates to timeline bounds
    const clampedStart = new Date(Math.max(s.getTime(), minDate.getTime()));
    const clampedEnd = new Date(Math.min(e.getTime(), maxDate.getTime()));
    const left = ((clampedStart.getTime() - minDate.getTime()) / (1000 * 60 * 60 * 24)) / totalDays;
    const width = Math.max(0.02, (clampedEnd.getTime() - clampedStart.getTime()) / (1000 * 60 * 60 * 24)) / totalDays;
    return { left: Math.max(0, Math.min(99, left * 100)), width: Math.max(0.5, Math.min(100 - left * 100, width * 100)) };
  };

  const handleExportPdf = async () => {
    if (!ganttRef.current) return;
    try {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) { alert("Ошибка canvas"); return; }

      const width = Math.min(ganttRef.current.scrollWidth, 3000);
      const height = Math.min(ganttRef.current.scrollHeight, 5000);
      canvas.width = width;
      canvas.height = height;

      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, width, height);

      const colWidth = timeline.length > 0 ? (width - 200) / timeline.length : 100;
      ctx.font = "12px sans-serif";
      ctx.fillStyle = "#374151";
      ctx.textAlign = "center";

      timeline.forEach((item, i) => {
        const x = 200 + i * colWidth + colWidth / 2;
        ctx.fillText(item.label, x, 20);
        ctx.strokeStyle = "#E5E7EB";
        ctx.beginPath();
        ctx.moveTo(200 + i * colWidth, 30);
        ctx.lineTo(200 + i * colWidth, height);
        ctx.stroke();
      });

      const rowHeight = 40;
      tasks.forEach((task, i) => {
        const y = 50 + i * rowHeight;
        ctx.fillStyle = "#7F1D1D";
        ctx.textAlign = "left";
        ctx.font = "12px sans-serif";
        const name = task.name.length > 28 ? task.name.substring(0, 28) + "..." : task.name;
        ctx.fillText(name, 10, y + 18);

        if (task.start_date && task.end_date) {
          const { left, width: barWidth } = getTaskPosition(task.start_date, task.end_date);
          const barX = 200 + (left / 100) * (width - 200);
          const barW = Math.max(2, (barWidth / 100) * (width - 200));
          ctx.fillStyle = statusColors[task.status] || "#DC2626";
          ctx.fillRect(barX, y + 8, barW, 20);
          ctx.fillStyle = "rgba(255,255,255,0.3)";
          ctx.fillRect(barX, y + 8, barW * ((task.progress || 0) / 100), 20);
        }
      });

      ctx.strokeStyle = "#E5E7EB";
      ctx.beginPath();
      ctx.moveTo(0, 30);
      ctx.lineTo(width, 30);
      ctx.stroke();

      const pdf = new jsPDF("l", "mm", "a4");
      const imgData = canvas.toDataURL("image/png");
      const pageWidth = 297;
      const pageHeight = 210;
      const imgWidth = pageWidth;
      const imgHeight = (height / width) * pageWidth;

      if (imgHeight <= pageHeight) {
        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      } else {
        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
        let heightLeft = imgHeight - pageHeight;
        while (heightLeft > 0) {
          pdf.addPage();
          pdf.addImage(imgData, "PNG", 0, heightLeft - imgHeight, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }
      }
      pdf.save("gantt_chart.pdf");
    } catch (err) {
      console.error("PDF export error:", err);
      alert("Ошибка при создании PDF");
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-[60vh]">
          <p className="text-gray-500">Загрузка задач...</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 sm:gap-3">
            <Link to="/"><Button variant="ghost" size="icon" className="h-8 w-8"><ArrowLeft className="h-5 w-5" /></Button></Link>
            <h1 className="text-lg sm:text-2xl font-bold text-gray-900">Диаграмма Ганта</h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Select value={scale} onValueChange={(v: "week" | "month") => setScale(v)}>
              <SelectTrigger className="w-[110px] sm:w-[120px] h-8 sm:h-10"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="week">По неделям</SelectItem>
                <SelectItem value="month">По месяцам</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => setZoom((z) => Math.min(3, z + 0.2))}><ZoomIn className="h-4 w-4" /></Button>
            <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))}><ZoomOut className="h-4 w-4" /></Button>
            <Button variant="outline" size="sm" className="border-red-700 text-red-700 hover:bg-red-50 h-8 sm:h-9" onClick={handleExportPdf}>
              <Download className="h-4 w-4 sm:mr-2" /><span className="hidden sm:inline">PDF</span>
            </Button>
          </div>
        </div>

        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div ref={ganttRef} className="overflow-x-auto" style={{ minHeight: "400px" }}>
              <div style={{ minWidth: `${Math.max(800, 250 + timeline.length * 80 * zoom)}px` }}>
                <div className="flex border-b bg-gray-50 sticky top-0 z-10">
                  <div className="w-[200px] sm:w-[250px] lg:w-[350px] flex-shrink-0 p-2 sm:p-3 font-semibold text-sm text-gray-700 border-r">Задача</div>
                  <div className="flex flex-1">
                    {timeline.map((item, i) => (
                      <div key={i} className="flex-shrink-0 p-2 sm:p-3 text-center text-xs text-gray-500 border-r border-gray-200" style={{ width: `${Math.max(60, 80 * zoom)}px` }}>{item.label}</div>
                    ))}
                  </div>
                </div>

                {tasks.map((task) => {
                  const pos = task.start_date && task.end_date ? getTaskPosition(task.start_date, task.end_date) : null;
                  return (
                    <div key={task.id} className="flex border-b hover:bg-gray-50">
                      <div className="w-[200px] sm:w-[250px] lg:w-[350px] flex-shrink-0 p-2 sm:p-3 border-r text-xs sm:text-sm text-gray-800 flex items-start gap-2 leading-tight">
                        <Badge className="w-2 h-2 p-0 rounded-full flex-shrink-0 mt-1" style={{ backgroundColor: statusColors[task.status] || "#9CA3AF" }} />
                        <span className="whitespace-normal break-words" style={{ wordBreak: "break-word" }}>{task.name}</span>
                      </div>
                      <div className="flex flex-1 relative" style={{ minHeight: "36px" }}>
                        {pos && (
                          <div className="absolute top-1.5 sm:top-2 h-5 sm:h-6 rounded-md text-xs text-white flex items-center px-2 overflow-hidden whitespace-nowrap cursor-pointer hover:brightness-110 transition-all"
                            style={{ left: `${pos.left}%`, width: `${Math.max(2, pos.width)}%`, backgroundColor: statusColors[task.status] || "#DC2626" }}
                            title={`${task.name} (${statusMap[task.status]})`}>
                            <div className="absolute inset-0 bg-white/20" style={{ width: `${task.progress || 0}%` }} />
                            <span className="relative z-10">{task.progress || 0}%</span>
                          </div>
                        )}
                        {timeline.map((_, i) => <div key={i} className="flex-shrink-0 border-r border-gray-100" style={{ width: `${Math.max(60, 80 * zoom)}px` }} />)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-wrap gap-3">
          {Object.entries(statusMap).map(([key, label]) => (
            <div key={key} className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: statusColors[key] }} />
              <span className="text-sm text-gray-600">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
