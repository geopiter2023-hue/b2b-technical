import { useEffect, useMemo, useRef, useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Upload, Download, Trash2, TrendingUp, TrendingDown, Minus,
  FileSpreadsheet, BarChart3, Calendar, Package, Building2,
  AlertTriangle, RotateCcw,
} from "lucide-react";
import { Line, Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, PointElement,
  LineElement, Title, Tooltip, Legend, ArcElement,
} from "chart.js";
import ChartDataLabels from "chartjs-plugin-datalabels";
import {
  parsePriceExcel, loadPrices, savePrices, clearPrices,
  addUploadHistory, getUploadHistory,
  savePriceFileData, loadPriceFileData, deletePriceFileData,
  getSummary,
  getMonthlyTrend, getQuarterlyTrend, getYearlyComparison,
  getSupplierComparison, getProductComparison,
  formatPrice, formatNumber,
  type PriceRecord, type PriceSummary, type PriceUploadHistory,
} from "@/services/priceService";
import PasswordDialog from "@/components/PasswordDialog";
import MultiSelect from "@/components/MultiSelect";
import html2canvas from "html2canvas-pro";
import jsPDF from "jspdf";

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Title, Tooltip, Legend, ArcElement, ChartDataLabels);

const MONTHS = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];

const CHART_COLORS = ["#DC2626", "#2563EB", "#D97706", "#16A34A", "#7C3AED", "#0891B2", "#BE185D", "#4338CA", "#059669", "#CA8A04"];

export default function PriceComparisonPage() {
  const [records, setRecords] = useState<PriceRecord[]>([]);
  const [summary, setSummary] = useState<PriceSummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);

  // Filters (multi-select arrays)
  const [yearFilter, setYearFilter] = useState<string[]>([]);
  const [quarterFilter, setQuarterFilter] = useState<string[]>([]);
  const [categoryFilter, setCategoryFilter] = useState<string[]>([]);
  const [supplierFilter, setSupplierFilter] = useState<string[]>([]);
  const [productFilter, setProductFilter] = useState<string[]>([]);
  const [regionFilter, setRegionFilter] = useState<string[]>([]);
  const [ksssSearch, setKsssSearch] = useState("");

  const [uploadHistory, setUploadHistory] = useState<PriceUploadHistory[]>([]);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [pwdDialogOpen, setPwdDialogOpen] = useState(false);
  const [pwdAction, setPwdAction] = useState<{ type: "upload" | "clear"; label: string }>({ type: "upload", label: "Загрузка файла" });
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const pdfRef = useRef<HTMLDivElement>(null);

  // Load saved data
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        const saved = loadPrices();
        if (saved.length > 0) {
          console.log("[PricePage] Loaded", saved.length, "records from storage");
          setRecords(saved);
          setSummary(getSummary(saved));
        } else {
          console.log("[PricePage] No saved data found");
        }
      } catch (e: any) { console.error("[PricePage] Load error:", e.message); }
      setUploadHistory(getUploadHistory());
      setIsDataLoaded(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  // Filtered records
  const filtered = useMemo(() => {
    return records.filter((r) => {
      if (yearFilter.length > 0 && !yearFilter.includes(String(r.year))) return false;
      if (quarterFilter.length > 0 && !quarterFilter.includes(String(r.quarter))) return false;
      if (categoryFilter.length > 0 && !categoryFilter.includes(r.category)) return false;
      if (supplierFilter.length > 0 && !supplierFilter.includes(r.supplier)) return false;
      if (productFilter.length > 0 && !productFilter.includes(r.product)) return false;
      if (regionFilter.length > 0 && !regionFilter.includes(r.region)) return false;
      if (ksssSearch && !r.ksss_code?.toLowerCase().includes(ksssSearch.toLowerCase()) && !r.product_name?.toLowerCase().includes(ksssSearch.toLowerCase())) return false;
      return true;
    });
  }, [records, yearFilter, quarterFilter, categoryFilter, supplierFilter, productFilter, regionFilter, ksssSearch]);

  // Unique filter values
  const years = useMemo(() => Array.from(new Set(records.map((r) => r.year))).sort((a, b) => b - a), [records]);
  const categories = useMemo(() => Array.from(new Set(records.map((r) => r.category))).sort(), [records]);
  const suppliers = useMemo(() => Array.from(new Set(records.map((r) => r.supplier))).sort(), [records]);
  const products = useMemo(() => Array.from(new Set(records.map((r) => r.product))).sort(), [records]);
  const regions = useMemo(() => Array.from(new Set(records.map((r) => r.region))).sort(), [records]);

  // Extra column names from uploaded file
  const extraColumnNames = useMemo(() => {
    const names = new Set<string>();
    for (const r of records) {
      if (r.extra_fields) {
        for (const key of Object.keys(r.extra_fields)) names.add(key);
      }
    }
    return Array.from(names);
  }, [records]);

  // Analytics
  const filteredSummary = useMemo(() => getSummary(filtered), [filtered]);
  const monthlyTrend = useMemo(() => getMonthlyTrend(filtered), [filtered]);
  const quarterlyTrend = useMemo(() => getQuarterlyTrend(filtered), [filtered]);
  const yearlyComp = useMemo(() => getYearlyComparison(filtered), [filtered]);
  const supplierComp = useMemo(() => getSupplierComparison(filtered), [filtered]);
  const productComp = useMemo(() => getProductComparison(filtered), [filtered]);

  // Charts data
  const monthlyChart = useMemo(() => {
    return {
      labels: monthlyTrend.map((t) => { const [y, m] = t.period.split("-"); return `${MONTHS[parseInt(m) - 1]} ${y}`; }),
      datasets: [{
        label: "Средняя цена", data: monthlyTrend.map((t) => t.avgPrice),
        borderColor: "#DC2626", backgroundColor: "#DC262620", fill: true, tension: 0.3,
        pointRadius: 4, pointBackgroundColor: "#DC2626",
      }, {
        label: "Мин. цена", data: monthlyTrend.map((t) => t.minPrice),
        borderColor: "#6B7280", borderDash: [5, 5], pointRadius: 2, fill: false, tension: 0.3,
      }, {
        label: "Макс. цена", data: monthlyTrend.map((t) => t.maxPrice),
        borderColor: "#6B7280", borderDash: [5, 5], pointRadius: 2, fill: false, tension: 0.3,
      }],
    };
  }, [monthlyTrend]);

  const yearlyChart = useMemo(() => {
    return {
      labels: yearlyComp.map((y) => String(y.year)),
      datasets: [{
        label: "Средняя цена",
        data: yearlyComp.map((y) => y.avgPrice),
        backgroundColor: yearlyComp.map((_, i) => CHART_COLORS[i % CHART_COLORS.length] + "80"),
        borderColor: yearlyComp.map((_, i) => CHART_COLORS[i % CHART_COLORS.length]),
        borderWidth: 2,
      }],
    };
  }, [yearlyComp]);

  const supplierChart = useMemo(() => {
    const top = supplierComp.slice(0, 10);
    return {
      labels: top.map((s) => s.supplier.length > 15 ? s.supplier.slice(0, 15) + "..." : s.supplier),
      datasets: [{
        label: "Средняя цена",
        data: top.map((s) => s.avgPrice),
        backgroundColor: CHART_COLORS.slice(0, top.length).map((c) => c + "80"),
        borderColor: CHART_COLORS.slice(0, top.length),
        borderWidth: 2,
      }],
    };
  }, [supplierComp]);

  const productPieChart = useMemo(() => {
    const top = productComp.slice(0, 8);
    return {
      labels: top.map((p) => p.productName.length > 20 ? p.productName.slice(0, 20) + "..." : p.productName),
      datasets: [{
        data: top.map((p) => p.totalQty),
        backgroundColor: CHART_COLORS.slice(0, top.length),
        borderWidth: 2,
        borderColor: "#fff",
      }],
    };
  }, [productComp]);

  const productBarChart = useMemo(() => {
    const top = productComp.slice(0, 10);
    return {
      labels: top.map((p) => p.productName.length > 15 ? p.productName.slice(0, 15) + "..." : p.productName),
      datasets: [{
        label: "Средняя цена (₽)",
        data: top.map((p) => p.avgPrice),
        backgroundColor: CHART_COLORS.slice(0, top.length).map((c) => c + "80"),
        borderColor: CHART_COLORS.slice(0, top.length),
        borderWidth: 2,
      }],
    };
  }, [productComp]);

  // Chart options
  const lineOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { position: "bottom" as const },
      datalabels: { display: false },
    },
    scales: { y: { beginAtZero: false } },
  };

  const barOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      datalabels: {
        display: true, color: "#374151", font: { weight: "bold" as const, size: 10 },
        anchor: "end" as const, align: "top" as const,
      },
    },
    scales: { y: { beginAtZero: false } },
  };

  const hbarOptions = {
    responsive: true, maintainAspectRatio: false, indexAxis: "y" as const,
    plugins: {
      legend: { display: false },
      datalabels: {
        display: true, color: "#374151", font: { weight: "bold" as const, size: 10 },
        anchor: "end" as const, align: "right" as const,
      },
    },
    scales: { x: { beginAtZero: false } },
  };

  const pieOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { position: "bottom" as const, labels: { boxWidth: 12, font: { size: 10 } } },
      datalabels: {
        display: true, color: "#fff", font: { weight: "bold" as const, size: 10 },
        formatter: (_v: number, ctx: any) => {
          const sum = ctx.dataset.data.reduce((a: number, b: number) => a + b, 0);
          return sum > 0 ? ((ctx.dataset.data[ctx.dataIndex] / sum) * 100).toFixed(1) + "%" : "";
        },
      },
    },
  };

  // Handlers
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    // Show password dialog first, save file for later processing
    setPendingFile(file);
    setPwdAction({ type: "upload", label: "Загрузка файла" });
    setPwdDialogOpen(true);
    if (fileRef.current) fileRef.current.value = "";
  };

  const processFile = async (file: File) => {
    setIsLoading(true); setLoadError("");
    try {
      const buffer = await file.arrayBuffer();
      const { records: data, errors } = parsePriceExcel(buffer);
      if (errors.length > 0 && data.length === 0) { setLoadError(errors.join("\n")); setIsLoading(false); return; }
      setRecords(data);
      const sm = getSummary(data);
      setSummary(sm);
      const saved = savePrices(data);
      if (!saved) setLoadError("Данные загружены но не сохранены (localStorage переполнен)");
      try { const uid = addUploadHistory(file.name, data.length); if (uid) savePriceFileData(uid, file.name, data); } catch {}
      setUploadHistory(getUploadHistory());
      if (errors.length > 0) setLoadError("Предупреждения: " + errors.join("; "));
    } catch (err: any) { setLoadError("Ошибка загрузки: " + err.message); }
    finally { setIsLoading(false); }
  };

  const handleExportPdf = async () => {
    if (!filtered.length) { alert("Нет данных для PDF"); return; }
    setExportingPdf(true);
    await new Promise((r) => setTimeout(r, 800));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (!pdfRef.current) { setExportingPdf(false); alert("PDF элемент не найден"); return; }
    try {
      const canvas = await html2canvas(pdfRef.current, { scale: 1.5, useCORS: true, logging: false, backgroundColor: "#ffffff", windowWidth: 1200 });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("l", "mm", "a4");
      const pw = 297, ph = 210, m = 10, cw = pw - m * 2;
      const imgH = (canvas.height * cw) / canvas.width;
      let pos = 0, rem = imgH;
      while (rem > 0) {
        const sliceH = Math.min(ph - m * 2, rem);
        const sc = document.createElement("canvas"); sc.width = canvas.width; sc.height = (sliceH / imgH) * canvas.height;
        const ctx = sc.getContext("2d")!; ctx.drawImage(canvas, 0, (pos / imgH) * canvas.height, canvas.width, (sliceH / imgH) * canvas.height, 0, 0, sc.width, sc.height);
        if (pos > 0) pdf.addPage();
        pdf.addImage(sc.toDataURL("image/png"), "PNG", m, m, cw, sliceH); pos += sliceH; rem -= sliceH;
      }
      pdf.save(`price_comparison_${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch (err: any) { alert("Ошибка PDF: " + err.message); }
    finally { setExportingPdf(false); }
  };

  const handleClear = () => {
    clearPrices(); setRecords([]); setSummary(null);
    setYearFilter("all"); setQuarterFilter("all"); setCategoryFilter("all");
    setSupplierFilter("all"); setProductFilter("all"); setRegionFilter("all");
    setShowClearConfirm(false);
  };

  if (!isDataLoaded) {
    return <Layout><div className="flex items-center justify-center h-96"><div className="animate-spin h-10 w-10 border-4 border-red-200 border-t-red-700 rounded-full" /></div></Layout>;
  }

  // Empty state
  if (records.length === 0) {
    return (
      <Layout>
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><BarChart3 className="h-7 w-7 text-red-700" />Сравнение цен</h1>
          </div>
          <Card className="py-8 sm:py-16">
            <CardContent className="text-center px-4">
              <Upload className="h-12 w-12 sm:h-16 sm:w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-base sm:text-lg font-semibold text-gray-600 mb-2">Загрузите данные о ценах</h3>
              <p className="text-xs sm:text-sm text-gray-400 mb-4">Колонки: Дата, КССС, Товар, Название товара, Категория, Поставщик, Цена, Кол-во, Регион</p>
              <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} onChange={handleFileUpload} className="hidden" />
              <Button className="bg-red-700 hover:bg-red-800" size="sm" onClick={() => fileRef.current?.click()} disabled={isLoading}>
                <Upload className="h-4 w-4 mr-2" />{isLoading ? "Загрузка..." : "Выбрать файл"}
              </Button>
              {loadError && <p className="text-red-600 text-sm mt-3">{loadError}</p>}
            </CardContent>
          </Card>
          {uploadHistory.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">История загрузок ({uploadHistory.length})</CardTitle></CardHeader>
              <CardContent className="p-0">
                <div className="divide-y">
                  {uploadHistory.map((item) => {
                    const hasData = !!loadPriceFileData(item.id);
                    return (
                    <div key={item.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-50">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <FileSpreadsheet className="h-5 w-5 text-red-600 flex-shrink-0" />
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{item.fileName}</p>
                          <p className="text-xs text-gray-500">{new Date(item.uploadedAt).toLocaleDateString("ru-RU")} · {formatNumber(item.recordCount)} записей</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {hasData && (
                          <Button variant="outline" size="sm" className="text-red-700 border-red-200 hover:bg-red-50 h-7 text-xs" onClick={() => {
                            const saved = loadPriceFileData(item.id);
                            if (saved) { setRecords(saved.records); setSummary(getSummary(saved.records)); }
                          }}>
                            <Upload className="h-3 w-3 mr-1" />Загрузить
                          </Button>
                        )}
                        <Button variant="ghost" size="sm" className="text-gray-400 hover:text-red-600 h-7 w-7 p-0" onClick={() => { deletePriceFileData(item.id); setUploadHistory(getUploadHistory()); }}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
          {/* Password Dialog */}
          <PasswordDialog
            open={pwdDialogOpen}
            onOpenChange={setPwdDialogOpen}
            action={pwdAction.label}
            onSuccess={() => {
              if (pwdAction.type === "upload" && pendingFile) {
                processFile(pendingFile);
                setPendingFile(null);
              } else if (pwdAction.type === "clear") {
                handleClear();
              }
            }}
          />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-4">
        {/* PDF Header */}
        <div className="hidden" style={{ display: exportingPdf ? "block" : "none" }}>
          <div className="mb-4 pb-3 border-b-2 border-red-700">
            <h2 className="text-xl font-bold text-red-700">Сравнение цен — B2B Task Manager</h2>
            <p className="text-xs text-gray-500">Период: {summary?.dateRange.from} — {summary?.dateRange.to} | Записей: {filtered.length}</p>
          </div>
        </div>

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2"><BarChart3 className="h-7 w-7 text-red-700" />Сравнение цен</h1>
            {summary && <p className="text-xs text-gray-500">{summary.dateRange.from} — {summary.dateRange.to} · {formatNumber(summary.totalRecords)} записей</p>}
          </div>
          <div className="flex gap-2 flex-wrap">
            <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} onChange={handleFileUpload} className="hidden" />
            <Button variant="outline" size="sm" className="border-red-700 text-red-700 hover:bg-red-50" onClick={() => fileRef.current?.click()} disabled={isLoading}>
              <Upload className="h-4 w-4 mr-2" />{isLoading ? "..." : "Новый файл"}
            </Button>
            <Button variant="outline" size="sm" className="border-gray-300 text-gray-700" onClick={handleExportPdf} disabled={exportingPdf}>
              <Download className="h-4 w-4 mr-2" />{exportingPdf ? "..." : "PDF"}
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-red-600" onClick={() => { setPwdAction({ type: "clear", label: "Удаление данных" }); setPwdDialogOpen(true); }}><Trash2 className="h-4 w-4" /></Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Средняя цена</p><p className="text-2xl font-bold text-gray-900">{formatPrice(filteredSummary.avgPrice)}</p><p className="text-xs text-gray-400">₽</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Диапазон</p><p className="text-lg font-bold text-gray-900">{formatPrice(filteredSummary.minPrice)} — {formatPrice(filteredSummary.maxPrice)}</p><p className="text-xs text-gray-400">₽</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Товаров</p><p className="text-2xl font-bold text-gray-900">{filteredSummary.products}</p><p className="text-xs text-gray-400">позиций</p></CardContent></Card>
          <Card><CardContent className="p-4"><p className="text-xs text-gray-500">Поставщиков</p><p className="text-2xl font-bold text-gray-900">{filteredSummary.suppliers}</p><p className="text-xs text-gray-400">контрагентов</p></CardContent></Card>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="h-8 flex items-center"><Calendar className="h-3 w-3 mr-1" />{filtered.length} записей</Badge>
          <MultiSelect placeholder="Год" options={years.map((y) => ({ value: String(y), label: String(y) }))} selected={yearFilter} onChange={setYearFilter} className="w-[110px]" />
          <MultiSelect placeholder="Квартал" options={["1","2","3","4"].map((q) => ({ value: q, label: q + " квартал" }))} selected={quarterFilter} onChange={setQuarterFilter} className="w-[130px]" />
          <MultiSelect placeholder="Категория" options={categories.map((c) => ({ value: c, label: c }))} selected={categoryFilter} onChange={setCategoryFilter} className="w-[150px]" />
          <MultiSelect placeholder="Поставщик" options={suppliers.map((s) => ({ value: s, label: s }))} selected={supplierFilter} onChange={setSupplierFilter} className="w-[170px]" />
          <MultiSelect placeholder="Товар" options={products.map((p) => ({ value: p, label: p }))} selected={productFilter} onChange={setProductFilter} className="w-[180px]" />
          <MultiSelect placeholder="Регион" options={regions.map((r) => ({ value: r, label: r }))} selected={regionFilter} onChange={setRegionFilter} className="w-[160px]" />
          <Button variant="ghost" size="sm" className="h-8 text-gray-500" onClick={() => { setYearFilter([]); setQuarterFilter([]); setCategoryFilter([]); setSupplierFilter([]); setProductFilter([]); setRegionFilter([]); setKsssSearch(""); }}>
            <RotateCcw className="h-3 w-3 mr-1" />Сбросить
          </Button>
        </div>

        {/* KSSS / Product search */}
        <div className="flex gap-2">
          <Input
            placeholder="Поиск по КССС или названию товара..."
            value={ksssSearch}
            onChange={(e) => setKsssSearch(e.target.value)}
            className="max-w-md h-8 text-sm"
          />
          {ksssSearch && <Badge variant="outline" className="h-8">{filtered.length} найдено</Badge>}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="dynamics">
          <TabsList className="flex-wrap h-auto">
            <TabsTrigger value="dynamics">Динамика</TabsTrigger>
            <TabsTrigger value="years">По годам</TabsTrigger>
            <TabsTrigger value="suppliers">Поставщики</TabsTrigger>
            <TabsTrigger value="products">Товары</TabsTrigger>
            <TabsTrigger value="table">Таблица</TabsTrigger>
          </TabsList>

          {/* Dynamics Tab */}
          <TabsContent value="dynamics">
            <div className="grid grid-cols-1 gap-4">
              <Card>
                <CardHeader><CardTitle className="text-base">Динамика цен по месяцам</CardTitle></CardHeader>
                <CardContent><div style={{ height: "350px" }}><Line data={monthlyChart as any} options={lineOptions} /></div></CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="text-base">Динамика по кварталам</CardTitle></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {quarterlyTrend.map((t) => (
                      <div key={t.period} className="border rounded-lg p-3">
                        <p className="text-xs text-gray-500">{t.period}</p>
                        <p className="text-lg font-bold">{formatPrice(t.avgPrice)} ₽</p>
                        <p className="text-xs text-gray-400">{t.records} записей · {formatNumber(t.totalQty)} шт</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Years Tab */}
          <TabsContent value="years">
            <div className="grid grid-cols-1 gap-4">
              <Card>
                <CardHeader><CardTitle className="text-base">Сравнение по годам (YoY)</CardTitle></CardHeader>
                <CardContent><div style={{ height: "300px" }}><Bar data={yearlyChart as any} options={barOptions} /></div></CardContent>
              </Card>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                {yearlyComp.map((y) => (
                  <Card key={y.year}>
                    <CardContent className="p-3">
                      <p className="text-xs text-gray-500">{y.year}</p>
                      <p className="text-xl font-bold">{formatPrice(y.avgPrice)} ₽</p>
                      {y.changePct !== undefined && (
                        <p className={`text-xs font-medium flex items-center gap-1 ${y.changePct > 0 ? "text-red-600" : y.changePct < 0 ? "text-green-600" : "text-gray-500"}`}>
                          {y.changePct > 0 ? <TrendingUp className="h-3 w-3" /> : y.changePct < 0 ? <TrendingDown className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
                          {y.changePct > 0 ? "+" : ""}{y.changePct}%
                        </p>
                      )}
                      <p className="text-xs text-gray-400">{formatNumber(y.totalQty)} шт</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Suppliers Tab */}
          <TabsContent value="suppliers">
            <div className="grid grid-cols-1 gap-4">
              <Card>
                <CardHeader><CardTitle className="text-base">Средние цены по поставщикам</CardTitle></CardHeader>
                <CardContent><div style={{ height: "400px" }}><Bar data={supplierChart as any} options={hbarOptions} /></div></CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="text-base">Детализация по поставщикам</CardTitle></CardHeader>
                <CardContent className="p-0 overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50"><tr><th className="px-4 py-2 text-left">Поставщик</th><th className="px-4 py-2 text-right">Средняя</th><th className="px-4 py-2 text-right">Мин</th><th className="px-4 py-2 text-right">Макс</th><th className="px-4 py-2 text-right">Кол-во</th><th className="px-4 py-2 text-right">Объем</th></tr></thead>
                    <tbody className="divide-y">
                      {supplierComp.map((s) => (
                        <tr key={s.supplier} className="hover:bg-gray-50">
                          <td className="px-4 py-2 font-medium">{s.supplier}</td>
                          <td className="px-4 py-2 text-right font-bold">{formatPrice(s.avgPrice)}</td>
                          <td className="px-4 py-2 text-right text-gray-500">{formatPrice(s.minPrice)}</td>
                          <td className="px-4 py-2 text-right text-gray-500">{formatPrice(s.maxPrice)}</td>
                          <td className="px-4 py-2 text-right">{s.records}</td>
                          <td className="px-4 py-2 text-right">{formatNumber(s.totalQty)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card>
                <CardHeader><CardTitle className="text-base">Объем по товарам</CardTitle></CardHeader>
                <CardContent><div style={{ height: "350px" }}><Pie data={productPieChart as any} options={pieOptions} /></div></CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="text-base">Средняя цена по товарам (топ-10)</CardTitle></CardHeader>
                <CardContent><div style={{ height: "350px" }}><Bar data={productBarChart as any} options={hbarOptions} /></div></CardContent>
              </Card>
            </div>
            <Card className="mt-4">
              <CardHeader><CardTitle className="text-base">Детализация по товарам ({productComp.length})</CardTitle></CardHeader>
              <CardContent className="p-0 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50"><tr><th className="px-4 py-2 text-left">КССС</th><th className="px-4 py-2 text-left">Товар</th><th className="px-4 py-2 text-left">Категория</th><th className="px-4 py-2 text-right">Средняя</th><th className="px-4 py-2 text-right">Последняя</th><th className="px-4 py-2 text-right">Изменение</th><th className="px-4 py-2 text-right">Объем</th><th className="px-4 py-2 text-right">Записей</th></tr></thead>
                  <tbody className="divide-y">
                    {productComp.map((p) => (
                      <tr key={p.product} className="hover:bg-gray-50">
                        <td className="px-4 py-2 text-xs font-mono text-gray-600">{p.ksssCode || "—"}</td>
                        <td className="px-4 py-2 font-medium">{p.productName || p.product}</td>
                        <td className="px-4 py-2 text-gray-500">{p.category}</td>
                        <td className="px-4 py-2 text-right">{formatPrice(p.avgPrice)}</td>
                        <td className="px-4 py-2 text-right font-bold">{formatPrice(p.latestPrice)}</td>
                        <td className="px-4 py-2 text-right">
                          {p.priceChangePct !== undefined ? (
                            <span className={`font-medium ${p.priceChangePct > 0 ? "text-red-600" : p.priceChangePct < 0 ? "text-green-600" : "text-gray-500"}`}>
                              {p.priceChangePct > 0 ? "+" : ""}{p.priceChangePct}%
                            </span>
                          ) : <span className="text-gray-400">—</span>}
                        </td>
                        <td className="px-4 py-2 text-right">{formatNumber(p.totalQty)}</td>
                        <td className="px-4 py-2 text-right">{p.records}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Table Tab */}
          <TabsContent value="table">
            <Card>
              <CardHeader><CardTitle className="text-base">Данные ({formatNumber(filtered.length)} записей)</CardTitle></CardHeader>
              <CardContent className="p-0 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50"><tr><th className="px-3 py-2 text-left">Дата</th><th className="px-3 py-2 text-left">КССС</th><th className="px-3 py-2 text-left">Товар</th><th className="px-3 py-2 text-left">Категория</th><th className="px-3 py-2 text-left">Поставщик</th><th className="px-3 py-2 text-right">Цена</th><th className="px-3 py-2 text-right">Кол-во</th><th className="px-3 py-2 text-left">Регион</th>{extraColumnNames.map((cn) => <th key={cn} className="px-3 py-2 text-left text-gray-600">{cn}</th>)}</tr></thead>
                  <tbody className="divide-y">
                    {filtered.slice(0, 200).map((r) => (
                      <tr key={r.id} className="hover:bg-gray-50">
                        <td className="px-3 py-2">{r.date}</td>
                        <td className="px-3 py-2 text-xs font-mono text-gray-600">{r.ksss_code || "—"}</td>
                        <td className="px-3 py-2 font-medium">{r.product_name || r.product}</td>
                        <td className="px-3 py-2 text-gray-500">{r.category}</td>
                        <td className="px-3 py-2">{r.supplier}</td>
                        <td className="px-3 py-2 text-right font-bold">{formatPrice(r.price)}</td>
                        <td className="px-3 py-2 text-right">{formatNumber(r.quantity)} {r.unit}</td>
                        <td className="px-3 py-2 text-gray-500">{r.region}</td>
                        {extraColumnNames.map((cn) => <td key={cn} className="px-3 py-2 text-gray-600">{r.extra_fields?.[cn] || ""}</td>)}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* ============ CLEAN PDF DIV (no UI elements) ============ */}
      {exportingPdf && (
        <div ref={pdfRef} style={{ position: "absolute", left: "-9999px", top: 0, width: "1200px", background: "#fff", padding: "30px", fontFamily: "Arial, sans-serif" }}>
          <div style={{ borderBottom: "3px solid #DC2626", marginBottom: "20px", paddingBottom: "10px" }}>
            <h1 style={{ fontSize: "22px", color: "#DC2626", margin: 0 }}>Сравнение цен — B2B Task Manager</h1>
            <p style={{ fontSize: "11px", color: "#666", margin: "5px 0 0" }}>
              Период: {summary?.dateRange.from} — {summary?.dateRange.to} | Записей: {formatNumber(filtered.length)} | Товаров: {filteredSummary.products} | Поставщиков: {filteredSummary.suppliers}
            </p>
          </div>

          {/* Stats row */}
          <div style={{ display: "flex", gap: "20px", marginBottom: "20px" }}>
            <div style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "12px" }}>
              <p style={{ fontSize: "10px", color: "#666", margin: 0 }}>Средняя цена</p>
              <p style={{ fontSize: "18px", fontWeight: "bold", margin: "4px 0 0" }}>{formatPrice(filteredSummary.avgPrice)} ₽</p>
            </div>
            <div style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "12px" }}>
              <p style={{ fontSize: "10px", color: "#666", margin: 0 }}>Диапазон</p>
              <p style={{ fontSize: "14px", fontWeight: "bold", margin: "4px 0 0" }}>{formatPrice(filteredSummary.minPrice)} — {formatPrice(filteredSummary.maxPrice)} ₽</p>
            </div>
            <div style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "12px" }}>
              <p style={{ fontSize: "10px", color: "#666", margin: 0 }}>Товаров</p>
              <p style={{ fontSize: "18px", fontWeight: "bold", margin: "4px 0 0" }}>{filteredSummary.products}</p>
            </div>
            <div style={{ flex: 1, border: "1px solid #e5e7eb", borderRadius: "8px", padding: "12px" }}>
              <p style={{ fontSize: "10px", color: "#666", margin: 0 }}>Поставщиков</p>
              <p style={{ fontSize: "18px", fontWeight: "bold", margin: "4px 0 0" }}>{filteredSummary.suppliers}</p>
            </div>
          </div>

          {/* Products table */}
          <h2 style={{ fontSize: "14px", margin: "15px 0 10px" }}>Детализация по товарам ({productComp.length})</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10px" }}>
            <thead>
              <tr style={{ background: "#DC2626", color: "#fff" }}>
                <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>КССС</th>
                <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Товар</th>
                <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Категория</th>
                <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Средняя</th>
                <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Последняя</th>
                <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Изменение</th>
                <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Объем</th>
                <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Записей</th>
                {extraColumnNames.map((cn) => <th key={cn} style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd", fontSize: "9px" }}>{cn}</th>)}
              </tr>
            </thead>
            <tbody>
              {productComp.map((p, i) => (
                <tr key={p.product} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                  <td style={{ padding: "5px", border: "1px solid #ddd", fontFamily: "monospace" }}>{p.ksssCode || "—"}</td>
                  <td style={{ padding: "5px", border: "1px solid #ddd", fontWeight: "bold" }}>{p.productName || p.product}</td>
                  <td style={{ padding: "5px", border: "1px solid #ddd" }}>{p.category}</td>
                  <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{formatPrice(p.avgPrice)}</td>
                  <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right", fontWeight: "bold" }}>{formatPrice(p.latestPrice)}</td>
                  <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right", color: (p.priceChangePct || 0) > 0 ? "#DC2626" : (p.priceChangePct || 0) < 0 ? "#16A34A" : "#666" }}>
                    {p.priceChangePct !== undefined ? `${p.priceChangePct > 0 ? "+" : ""}${p.priceChangePct}%` : "—"}
                  </td>
                  <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{formatNumber(p.totalQty)}</td>
                  <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{p.records}</td>
                  {extraColumnNames.map((cn) => {
                    const rec = filtered.find((r) => r.product === p.product);
                    return <td key={cn} style={{ padding: "5px", border: "1px solid #ddd" }}>{rec?.extra_fields?.[cn] || ""}</td>;
                  })}
                </tr>
              ))}
            </tbody>
          </table>

          {/* Yearly comparison */}
          {yearlyComp.length > 1 && (
            <>
              <h2 style={{ fontSize: "14px", margin: "20px 0 10px" }}>Сравнение по годам</h2>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10px" }}>
                <thead>
                  <tr style={{ background: "#DC2626", color: "#fff" }}>
                    <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Год</th>
                    <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Средняя цена</th>
                    <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Объем</th>
                    <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Изменение</th>
                    <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Записей</th>
                  </tr>
                </thead>
                <tbody>
                  {yearlyComp.map((y, i) => (
                    <tr key={y.year} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                      <td style={{ padding: "5px", border: "1px solid #ddd", fontWeight: "bold" }}>{y.year}</td>
                      <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{formatPrice(y.avgPrice)} ₽</td>
                      <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{formatNumber(y.totalQty)}</td>
                      <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right", color: (y.changePct || 0) > 0 ? "#DC2626" : (y.changePct || 0) < 0 ? "#16A34A" : "#666" }}>
                        {y.changePct !== undefined ? `${y.changePct > 0 ? "+" : ""}${y.changePct}%` : "—"}
                      </td>
                      <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{y.records}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}

          <p style={{ fontSize: "9px", color: "#999", marginTop: "20px", textAlign: "center" }}>
            Сформировано: {new Date().toLocaleString("ru-RU")} | B2B Task Manager — ЛУКОЙЛ
          </p>
        </div>
      )}
    </Layout>
  );
}
