import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  ClipboardList,
  Clock,
  CheckCircle,
  AlertTriangle,
  Plus,
  Download,
  Pencil,
  Trash2,
  Search,
  ArrowUpDown,
  RotateCcw,
  Filter,
  FileText,
} from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas-pro";
import TaskForm from "@/components/TaskForm";
import Layout from "@/components/Layout";
import CategoryTableView from "@/components/CategoryTableView";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  listTasks,
  getTaskStats,
  deleteTask,
  migrateLocalToSupabase,
  subscribeToTasks,
  type Task,
} from "@/services/taskService";
import { getCategories, getCategoryColor } from "@/services/categoryService";
import ProgressBar from "@/components/ProgressBar";
import KanbanBoard from "@/components/KanbanBoard";

const statusMap: Record<string, { label: string; color: string }> = {
  not_started: { label: "Не начата", color: "bg-gray-100 text-gray-600" },
  planning: { label: "В планировании", color: "bg-amber-50 text-amber-700" },
  in_progress: { label: "В работе", color: "bg-red-50 text-red-700" },
  review: { label: "На проверке", color: "bg-purple-50 text-purple-700" },
  completed: { label: "Завершена", color: "bg-emerald-50 text-emerald-700" },
  cancelled: { label: "Отменена", color: "bg-red-50 text-red-700" },
};

const priorityMap: Record<string, { label: string; color: string }> = {
  low: { label: "Низкий", color: "bg-gray-100 text-gray-600" },
  medium: { label: "Средний", color: "bg-amber-50 text-amber-700" },
  high: { label: "Высокий", color: "bg-red-50 text-red-700" },
  critical: { label: "Критичный", color: "bg-red-100 text-red-800" },
};

type QuickFilter = "all" | "in_progress" | "completed" | "overdue";

export default function Dashboard() {
  const [quickFilter, setQuickFilter] = useState<QuickFilter>("all");
  const [filters, setFilters] = useState({
    status: "all",
    priority: "all",
    assignee: "all",
    category: "all",
    search: "",
  });
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [sortBy, setSortBy] = useState("created_at");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [exportingPdf, setExportingPdf] = useState(false);
  const pdfRef = useRef<HTMLDivElement>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [stats, setStats] = useState({ total: 0, inProgress: 0, done: 0, overdue: 0 });
  const [tasksData, setTasksData] = useState<{ list: Task[]; total: number }>({ list: [], total: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [migrateStatus, setMigrateStatus] = useState<"idle" | "migrating" | "done" | "error">("idle");
  const [tableWidth, setTableWidth] = useState(1400);
  const [viewMode, setViewMode] = useState<"table" | "kanban">("kanban");
  const [searchInput, setSearchInput] = useState("");
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Refs for dual scroll
  const topScrollRef = useRef<HTMLDivElement>(null);
  const bottomScrollRef = useRef<HTMLDivElement>(null);
  const isScrolling = useRef(false);

  const fetchTasks = useCallback(async () => {
    setIsLoading(true);
    try {
      let data = await listTasks(
        {
          status: filters.status,
          priority: filters.priority,
          assignee: filters.assignee,
          category: filters.category,
          search: filters.search,
        },
        sortBy,
        sortOrder,
        page,
        200
      );

      if (quickFilter === "overdue") {
        const now = new Date();
        const filtered = data.list.filter(
          (t: Task) =>
            t.end_date &&
            new Date(t.end_date) < now &&
            t.status !== "completed" &&
            t.status !== "cancelled"
        );
        data = { ...data, list: filtered, total: filtered.length };
      }

      setTasksData(data);
    } catch (err: any) {
      console.error("Error loading tasks:", err);
    } finally {
      setIsLoading(false);
    }
  }, [filters, sortBy, sortOrder, page, quickFilter]);

  const fetchStats = useCallback(async () => {
    try {
      const data = await getTaskStats();
      setStats(data);
    } catch (err: any) {
      console.error("Error loading stats:", err);
    }
  }, []);

  // Measure actual table width after render
  useEffect(() => {
    const timer = setTimeout(() => {
      const table = document.getElementById("tasks-table");
      if (table) {
        setTableWidth(table.scrollWidth);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [tasksData, isLoading]);

  // Dual scroll sync
  const handleTopScroll = () => {
    if (isScrolling.current) return;
    isScrolling.current = true;
    if (bottomScrollRef.current && topScrollRef.current) {
      bottomScrollRef.current.scrollLeft = topScrollRef.current.scrollLeft;
    }
    requestAnimationFrame(() => { isScrolling.current = false; });
  };

  const handleBottomScroll = () => {
    if (isScrolling.current) return;
    isScrolling.current = true;
    if (topScrollRef.current && bottomScrollRef.current) {
      topScrollRef.current.scrollLeft = bottomScrollRef.current.scrollLeft;
    }
    requestAnimationFrame(() => { isScrolling.current = false; });
  };

  useEffect(() => {
    if (quickFilter === "overdue") {
      setFilters((f) => ({ ...f, status: "all" }));
    } else if (quickFilter === "all") {
      setFilters((f) => ({ ...f, status: "all" }));
    } else {
      setFilters((f) => ({ ...f, status: quickFilter }));
    }
    setPage(1);
  }, [quickFilter]);

  // Migration: localStorage → Supabase on first load
  useEffect(() => {
    const runMigration = async () => {
      setMigrateStatus("migrating");
      const ok = await migrateLocalToSupabase();
      setMigrateStatus(ok ? "done" : "error");
    };
    runMigration();
  }, []);

  // Realtime subscription
  useEffect(() => {
    const unsubscribe = subscribeToTasks(() => {
      fetchTasks();
      fetchStats();
    });
    return unsubscribe;
  }, [fetchTasks, fetchStats]);

  useEffect(() => {
    fetchTasks();
    fetchStats();
  }, [fetchTasks, fetchStats]);

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortOrder("asc");
    }
  };

  const handleExport = () => {
    const list = tasksData.list;
    let csv = "ID;Название;Статус;Приоритет;Ответственный;Исполнитель;Дата начала;Дата окончания;Сложность;Бюджет;Прогресс\n";
    for (const t of list) {
      const status = statusMap[t.status]?.label || t.status;
      const priority = priorityMap[t.priority]?.label || t.priority;
      csv += `${t.id};"${t.name.replace(/"/g, '""')}";${status};${priority};${t.assignee || ""};${t.executor || ""};${t.start_date || ""};${t.end_date || ""};${t.complexity || ""};${t.budget || ""};${t.progress || 0}%\n`;
    }
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tasks_export.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportPdf = async () => {
    if (!tasksData.list.length) { alert("Нет задач для экспорта"); return; }
    setExportingPdf(true);
    await new Promise((r) => setTimeout(r, 800));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (!pdfRef.current) { setExportingPdf(false); return; }
    try {
      const canvas = await html2canvas(pdfRef.current, { scale: 1.5, useCORS: true, logging: false, backgroundColor: "#ffffff", windowWidth: 1200 });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("l", "mm", "a4");
      const pw = 297, ph = 210, m = 10, cw = pw - m * 2;
      const imgH = (canvas.height * cw) / canvas.width;
      let pos = 0, rem = imgH;
      while (rem > 0) {
        const sliceH = Math.min(ph - m * 2, rem);
        const sc = document.createElement("canvas"); sc.width = canvas.width; sc.height = (sliceH / imgH) * canvas.height;
        const ctx = sc.getContext("2d")!; ctx.drawImage(canvas, 0, (pos / imgH) * canvas.height, canvas.width, (sliceH / imgH) * canvas.height, 0, 0, sc.width, sc.height);
        if (pos > 0) pdf.addPage();
        pdf.addImage(sc.toDataURL("image/png"), "PNG", m, m, cw, sliceH); pos += sliceH; rem -= sliceH;
      }
      pdf.save(`tasks_report_${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch (err: any) { console.error("PDF error:", err); }
    finally { setExportingPdf(false); }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await deleteTask(deleteId);
      setDeleteId(null);
      fetchTasks();
      fetchStats();
    } catch (err: any) {
      console.error("Error deleting task:", err);
    }
  };

  const openEditForm = (task: Task) => {
    setEditingTask(task);
    setFormOpen(true);
  };

  const uniqueAssignees = useMemo(() => {
    const list = tasksData.list;
    return Array.from(new Set(list.map((t) => t.assignee).filter(Boolean)));
  }, [tasksData]);

  const categories = useMemo(() => getCategories(), []);

  return (
    <Layout>
      <div className="space-y-4 md:space-y-6">
        {/* Migration status */}
        {migrateStatus === "migrating" && (
          <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-3 py-2 rounded-lg">
            <RotateCcw className="h-4 w-4 animate-spin" />
            Перенос задач в облако...
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
          <Card className={`cursor-pointer transition-all hover:shadow-md ${quickFilter === "all" ? "ring-2 ring-red-500" : ""}`} onClick={() => setQuickFilter("all")}>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-red-50 rounded-lg"><ClipboardList className="h-5 w-5 md:h-6 md:w-6 text-red-700" /></div>
              <div><p className="text-xs md:text-sm text-gray-500">Всего задач</p><p className="text-xl md:text-2xl font-bold text-red-700">{stats.total}</p></div>
            </CardContent>
          </Card>
          <Card className={`cursor-pointer transition-all hover:shadow-md ${quickFilter === "in_progress" ? "ring-2 ring-amber-500" : ""}`} onClick={() => setQuickFilter("in_progress")}>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-amber-50 rounded-lg"><Clock className="h-5 w-5 md:h-6 md:w-6 text-amber-600" /></div>
              <div><p className="text-xs md:text-sm text-gray-500">В работе</p><p className="text-xl md:text-2xl font-bold text-amber-600">{stats.inProgress}</p></div>
            </CardContent>
          </Card>
          <Card className={`cursor-pointer transition-all hover:shadow-md ${quickFilter === "completed" ? "ring-2 ring-emerald-500" : ""}`} onClick={() => setQuickFilter("completed")}>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-emerald-50 rounded-lg"><CheckCircle className="h-5 w-5 md:h-6 md:w-6 text-emerald-600" /></div>
              <div><p className="text-xs md:text-sm text-gray-500">Завершено</p><p className="text-xl md:text-2xl font-bold text-emerald-600">{stats.done}</p></div>
            </CardContent>
          </Card>
          <Card className={`cursor-pointer transition-all hover:shadow-md ${quickFilter === "overdue" ? "ring-2 ring-red-500" : ""}`} onClick={() => setQuickFilter("overdue")}>
            <CardContent className="p-3 md:p-4 flex items-center gap-3 md:gap-4">
              <div className="p-2 md:p-3 bg-red-50 rounded-lg"><AlertTriangle className="h-5 w-5 md:h-6 md:w-6 text-red-600" /></div>
              <div><p className="text-xs md:text-sm text-gray-500">Просрочено</p><p className="text-xl md:text-2xl font-bold text-red-600">{stats.overdue}</p></div>
            </CardContent>
          </Card>
        </div>

        {quickFilter !== "all" && (
          <div className="flex items-center gap-2 -mt-2">
            <span className="text-sm text-gray-600">Фильтр:</span>
            <Badge className={quickFilter === "in_progress" ? "bg-amber-50 text-amber-700" : quickFilter === "completed" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}>
              {quickFilter === "in_progress" ? "В работе" : quickFilter === "completed" ? "Завершено" : "Просрочено"}
            </Badge>
            <button className="text-xs text-gray-400 hover:text-red-600 underline" onClick={() => setQuickFilter("all")}>Сбросить</button>
          </div>
        )}

        {/* View mode toggle + Filters row */}
        <div className="flex flex-col gap-3">
          {/* Top row: View toggle + Action buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex gap-1">
              <Button
                variant={viewMode === "kanban" ? "default" : "outline"}
                size="sm"
                className={viewMode === "kanban" ? "bg-red-700 hover:bg-red-800" : "border-gray-300"}
                onClick={() => setViewMode("kanban")}
              >
                Доска
              </Button>
              <Button
                variant={viewMode === "table" ? "default" : "outline"}
                size="sm"
                className={viewMode === "table" ? "bg-red-700 hover:bg-red-800" : "border-gray-300"}
                onClick={() => setViewMode("table")}
              >
                Таблица
              </Button>
            </div>
            <div className="flex-1" />
            <Button variant="outline" size="sm" className="border-gray-300 text-gray-600 hover:bg-gray-50" onClick={() => { setFilters({ status: "all", priority: "all", assignee: "all", category: "all", search: "" }); setSearchInput(""); setQuickFilter("all"); }}>
              <RotateCcw className="h-4 w-4 mr-1" />Сбросить
            </Button>
            <Button variant="outline" size="sm" className="border-red-700 text-red-700 hover:bg-red-50" onClick={handleExport}>
              <Download className="h-4 w-4 mr-1 sm:mr-2" /><span className="hidden sm:inline">CSV</span>
            </Button>
            <Button variant="outline" size="sm" className="border-gray-300 text-gray-700 hover:bg-gray-50" onClick={handleExportPdf} disabled={exportingPdf}>
              <FileText className="h-4 w-4 mr-1" />{exportingPdf ? "..." : <span className="hidden sm:inline">PDF</span>}
            </Button>
            <Button size="sm" className="bg-red-700 hover:bg-red-800" onClick={() => { setEditingTask(null); setFormOpen(true); }}>
              <Plus className="h-4 w-4 mr-1 sm:mr-2" /><span className="hidden sm:inline">Новая задача</span><span className="sm:hidden">Создать</span>
            </Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-2">
            <div className="relative sm:col-span-2 lg:col-span-1 xl:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input placeholder="Поиск задач..." className="pl-9 w-full" value={searchInput} onChange={(e) => {
                setSearchInput(e.target.value);
                if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
                searchTimerRef.current = setTimeout(() => {
                  setFilters((f) => ({ ...f, search: e.target.value }));
                }, 300);
              }} />
            </div>
            <Select value={filters.status} onValueChange={(v) => setFilters({ ...filters, status: v })}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Все статусы" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все статусы</SelectItem>
                {Object.entries(statusMap).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.priority} onValueChange={(v) => setFilters({ ...filters, priority: v })}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Все приоритеты" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все приоритеты</SelectItem>
                {Object.entries(priorityMap).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.assignee} onValueChange={(v) => setFilters({ ...filters, assignee: v })}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Все ответственные" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все ответственные</SelectItem>
                {uniqueAssignees.map((a) => <SelectItem key={a} value={a || ""}>{a || ""}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.category} onValueChange={(v) => setFilters({ ...filters, category: v })}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Все категории" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все категории</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={c.name}>
                    <span className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                      {c.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Active filters badge */}
        {(filters.status !== "all" || filters.priority !== "all" || filters.assignee !== "all" || filters.category !== "all" || filters.search) && (
          <div className="flex flex-wrap items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <span className="text-xs text-gray-500">Активные фильтры:</span>
            {filters.status !== "all" && <Badge variant="outline" className="text-xs">Статус: {statusMap[filters.status]?.label || filters.status}</Badge>}
            {filters.priority !== "all" && <Badge variant="outline" className="text-xs">Приоритет: {priorityMap[filters.priority]?.label || filters.priority}</Badge>}
            {filters.assignee !== "all" && <Badge variant="outline" className="text-xs">Ответственный: {filters.assignee}</Badge>}
            {filters.category !== "all" && <Badge variant="outline" className="text-xs">Категория: {filters.category}</Badge>}
            {filters.search && <Badge variant="outline" className="text-xs">Поиск: "{filters.search}"</Badge>}
            <span className="text-xs text-gray-400 ml-2">{tasksData.total} задач</span>
          </div>
        )}

        {/* Kanban or Table view */}
        {viewMode === "kanban" ? (
          <KanbanBoard
            tasks={tasksData.list}
            onEdit={openEditForm}
            onDelete={setDeleteId}
            onRefresh={fetchTasks}
          />
        ) : (
          <CategoryTableView
            tasks={tasksData.list}
            isLoading={isLoading}
            onEdit={openEditForm}
            onDelete={setDeleteId}
            tableWidth={tableWidth}
            topScrollRef={topScrollRef}
            bottomScrollRef={bottomScrollRef}
            handleTopScroll={handleTopScroll}
            handleBottomScroll={handleBottomScroll}
          />
        )}
      </div>

      <TaskForm open={formOpen} onOpenChange={setFormOpen} initialData={editingTask} onSubmit={() => { fetchTasks(); fetchStats(); }} />

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить задачу?</AlertDialogTitle>
            <AlertDialogDescription>Это действие нельзя отменить. Задача будет удалена навсегда.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={handleDelete}>Удалить</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* PDF Export */}
      {exportingPdf && (
        <div ref={pdfRef} style={{ position: "absolute", left: "-9999px", top: 0, width: "1200px", background: "#fff", padding: "30px", fontFamily: "Arial, sans-serif" }}>
          <div style={{ borderBottom: "3px solid #DC2626", marginBottom: "20px", paddingBottom: "10px" }}>
            <h1 style={{ fontSize: "22px", color: "#DC2626", margin: 0 }}>Отчет по задачам — B2B Task Manager</h1>
            <p style={{ fontSize: "11px", color: "#666", margin: "5px 0 0" }}>Всего задач: {tasksData.total} | Дата: {new Date().toLocaleDateString("ru-RU")}</p>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "10px" }}>
            <thead><tr style={{ background: "#DC2626", color: "#fff" }}>
              <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>ID</th>
              <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Название</th>
              <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Статус</th>
              <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Приоритет</th>
              <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Ответственный</th>
              <th style={{ padding: "6px", textAlign: "left", border: "1px solid #ddd" }}>Даты</th>
              <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>Бюджет</th>
              <th style={{ padding: "6px", textAlign: "right", border: "1px solid #ddd" }}>%</th>
            </tr></thead>
            <tbody>{tasksData.list.map((t, i) => (
              <tr key={t.id} style={{ background: i % 2 === 0 ? "#fff" : "#f9fafb" }}>
                <td style={{ padding: "5px", border: "1px solid #ddd" }}>{t.id}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd", fontWeight: "bold" }}>{t.name}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd" }}>{statusMap[t.status]?.label || t.status}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd" }}>{priorityMap[t.priority]?.label || t.priority}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd" }}>{t.assignee || "—"}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd" }}>{t.start_date || ""} — {t.end_date || ""}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{t.budget || "—"}</td>
                <td style={{ padding: "5px", border: "1px solid #ddd", textAlign: "right" }}>{t.progress || 0}%</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}
