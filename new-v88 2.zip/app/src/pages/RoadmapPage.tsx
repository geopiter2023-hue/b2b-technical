import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft, Download, Map, ZoomIn, ZoomOut,
  Filter, Calendar, CheckCircle2, Clock, AlertTriangle,
} from "lucide-react";
import { listTasks, type Task } from "@/services/taskService";
import html2canvas from "html2canvas-pro";
import jsPDF from "jspdf";

// ============================================================
// CONFIG
// ============================================================
const statusColors: Record<string, string> = {
  not_started: "#6B7280",
  in_progress: "#2563EB",
  review: "#D97706",
  completed: "#16A34A",
  cancelled: "#DC2626",
  overdue: "#DC2626",
};
const statusLabels: Record<string, string> = {
  not_started: "Не начато",
  in_progress: "В работе",
  review: "На проверке",
  completed: "Завершено",
  cancelled: "Отменено",
  overdue: "Просрочено",
};
const priorityLabels: Record<string, string> = {
  low: "Низкий",
  medium: "Средний",
  high: "Высокий",
  critical: "Критичный",
};

const categoryColors: Record<string, string> = {
  Логистика: "#DC2626",
  Продажи: "#2563EB",
  Маркетинг: "#D97706",
  IT: "#7C3AED",
  Финансы: "#16A34A",
  HR: "#0891B2",
  Закупки: "#BE185D",
  Юридический: "#4338CA",
  Производство: "#059669",
  Аналитика: "#CA8A04",
};

// ============================================================
// UTILS
// ============================================================
function parseDate(d: string | null): Date | null {
  if (!d) return null;
  const p = new Date(d);
  return isNaN(p.getTime()) ? null : p;
}
function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}
function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}
function formatDateShort(d: Date): string {
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" });
}
function formatDateLong(d: Date): string {
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit", year: "numeric" });
}

// ============================================================
// LANING — distribute tasks into non-overlapping lanes
// ============================================================
interface TaskWithDates extends Task {
  sDate: Date;
  eDate: Date;
  lane: number;
}

function assignLanes(tasks: Task[]): TaskWithDates[] {
  const withDates = tasks
    .map((t) => {
      const s = parseDate(t.start_date) || new Date();
      const e = parseDate(t.end_date) || new Date(s.getTime() + 7 * 24 * 60 * 60 * 1000);
      return { ...t, sDate: s, eDate: e > s ? e : new Date(s.getTime() + 1 * 24 * 60 * 60 * 1000) };
    })
    .filter((t) => t.sDate && t.eDate)
    .sort((a, b) => a.sDate.getTime() - b.sDate.getTime());

  const lanes: { end: Date }[][] = [];

  for (const task of withDates) {
    let placed = false;
    for (const lane of lanes) {
      const last = lane[lane.length - 1];
      if (last.end.getTime() < task.sDate.getTime()) {
        lane.push({ end: task.eDate });
        (task as any).lane = lanes.indexOf(lane);
        placed = true;
        break;
      }
    }
    if (!placed) {
      lanes.push([{ end: task.eDate }]);
      (task as any).lane = lanes.length - 1;
    }
  }

  return withDates as TaskWithDates[];
}

// ============================================================
// PAGE
// ============================================================
export default function RoadmapPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [exportingPdf, setExportingPdf] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [scale, setScale] = useState<"week" | "month">("week");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const roadmapRef = useRef<HTMLDivElement>(null);
  const pdfRef = useRef<HTMLDivElement>(null);

  // Load tasks
  useEffect(() => {
    listTasks().then((res) => {
      setTasks(res.list);
      setLoading(false);
    });
  }, []);

  // Filtered tasks
  const filtered = useMemo(() => {
    return tasks.filter((t) => {
      if (statusFilter !== "all" && t.status !== statusFilter) return false;
      if (categoryFilter !== "all" && t.category !== categoryFilter) return false;
      return t.start_date && t.end_date;
    });
  }, [tasks, statusFilter, categoryFilter]);

  // Compute timeline bounds
  const { minDate, maxDate, totalDays } = useMemo(() => {
    if (filtered.length === 0) {
      const now = new Date();
      return { minDate: now, maxDate: new Date(now.getTime() + 30 * 86400000), totalDays: 30 };
    }
    const dates = filtered.flatMap((t) => [parseDate(t.start_date), parseDate(t.end_date)]).filter(Boolean) as Date[];
    const min = new Date(Math.min(...dates.map((d) => d.getTime())));
    const max = new Date(Math.max(...dates.map((d) => d.getTime())));
    // Add padding
    min.setDate(min.getDate() - 3);
    max.setDate(max.getDate() + 7);
    const days = daysBetween(min, max);
    return { minDate: min, maxDate: max, totalDays: Math.max(days, 14) };
  }, [filtered]);

  // Assign lanes
  const lanedTasks = useMemo(() => assignLanes(filtered), [filtered]);
  const laneCount = useMemo(() => {
    if (lanedTasks.length === 0) return 0;
    return Math.max(...lanedTasks.map((t) => t.lane)) + 1;
  }, [lanedTasks]);

  // Timeline ticks
  const ticks = useMemo(() => {
    const result: { date: Date; label: string }[] = [];
    if (scale === "week") {
      const d = new Date(minDate);
      while (d <= maxDate) {
        result.push({ date: new Date(d), label: formatDateShort(d) });
        d.setDate(d.getDate() + 1);
      }
    } else {
      const d = new Date(minDate);
      d.setDate(1);
      while (d <= maxDate) {
        result.push({
          date: new Date(d),
          label: d.toLocaleDateString("ru-RU", { month: "short", year: "2-digit" }),
        });
        d.setMonth(d.getMonth() + 1);
      }
    }
    return result;
  }, [minDate, maxDate, scale]);

  // Helpers for positioning
  const pxPerDay = (50 * zoom) * (scale === "month" ? 0.3 : 1);
  const timelineWidth = totalDays * pxPerDay;
  const laneHeight = 56;
  const headerHeight = 50;

  function getTaskLeft(task: TaskWithDates): number {
    return daysBetween(minDate, task.sDate) * pxPerDay;
  }
  function getTaskWidth(task: TaskWithDates): number {
    const w = daysBetween(task.sDate, task.eDate) * pxPerDay;
    return Math.max(w, 60); // Minimum width for label
  }
  function getTickLeft(date: Date): number {
    return daysBetween(minDate, date) * pxPerDay;
  }

  // Unique categories for filter
  const categories = useMemo(() => Array.from(new Set(tasks.map((t) => t.category).filter(Boolean))), [tasks]);

  // PDF Export
  const handleExportPdf = async () => {
    if (lanedTasks.length === 0) { alert("Нет данных для PDF"); return; }
    setExportingPdf(true);
    await new Promise((r) => setTimeout(r, 800));
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    if (!pdfRef.current) { setExportingPdf(false); alert("PDF элемент не найден"); return; }
    try {
      const canvas = await html2canvas(pdfRef.current, {
        scale: 1.5, useCORS: true, logging: false,
        backgroundColor: "#ffffff", windowWidth: 1400,
      });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("l", "mm", "a4");
      const pw = 297, ph = 210, m = 10, cw = pw - m * 2;
      const imgH = (canvas.height * cw) / canvas.width;
      let pos = 0, rem = imgH;
      while (rem > 0) {
        const sliceH = Math.min(ph - m * 2, rem);
        const sc = document.createElement("canvas");
        sc.width = canvas.width;
        sc.height = (sliceH / imgH) * canvas.height;
        const ctx = sc.getContext("2d")!;
        ctx.drawImage(canvas, 0, (pos / imgH) * canvas.height, canvas.width, (sliceH / imgH) * canvas.height, 0, 0, sc.width, sc.height);
        if (pos > 0) pdf.addPage();
        pdf.addImage(sc.toDataURL("image/png"), "PNG", m, m, cw, sliceH);
        pos += sliceH; rem -= sliceH;
      }
      pdf.save(`roadmap_${new Date().toISOString().slice(0, 10)}.pdf`);
    } catch (err: any) { alert("Ошибка PDF: " + err.message); }
    finally { setExportingPdf(false); }
  };

  // Stat counts
  const statCounts = useMemo(() => {
    const s: Record<string, number> = {};
    for (const t of filtered) { s[t.status] = (s[t.status] || 0) + 1; }
    return s;
  }, [filtered]);

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin h-10 w-10 border-4 border-red-200 border-t-red-700 rounded-full" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 sm:gap-3">
            <Link to="/"><Button variant="ghost" size="icon" className="h-8 w-8"><ArrowLeft className="h-5 w-5" /></Button></Link>
            <h1 className="text-lg sm:text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Map className="h-6 w-6 sm:h-7 sm:w-7 text-red-700" />Дорожная карта
            </h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Select value={scale} onValueChange={(v: "week" | "month") => setScale(v)}>
              <SelectTrigger className="w-[110px] sm:w-[120px] h-8 sm:h-10"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="week">По неделям</SelectItem>
                <SelectItem value="month">По месяцам</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => setZoom((z) => Math.min(3, z + 0.25))}><ZoomIn className="h-4 w-4" /></Button>
            <Button variant="outline" size="icon" className="h-8 w-8 sm:h-9 sm:w-9" onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}><ZoomOut className="h-4 w-4" /></Button>
            <Button variant="outline" size="sm" className="border-red-700 text-red-700 hover:bg-red-50 h-8 sm:h-9" onClick={handleExportPdf} disabled={exportingPdf || lanedTasks.length === 0}>
              <Download className="h-4 w-4 sm:mr-2" /><span className="hidden sm:inline">{exportingPdf ? "..." : "PDF"}</span>
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 items-center">
          <Filter className="h-4 w-4 text-gray-400" />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px] h-8"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все статусы</SelectItem>
              {Object.entries(statusLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[160px] h-8"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все категории</SelectItem>
              {categories.map((c) => <SelectItem key={c} value={c!}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
          <span className="text-sm text-gray-500 ml-2">{lanedTasks.length} задач</span>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3">
          {Object.entries(statusLabels).map(([k, v]) => (
            statCounts[k] > 0 && (
              <div key={k} className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm" style={{ background: statusColors[k] }} />
                <span className="text-xs text-gray-600">{v} ({statCounts[k] || 0})</span>
              </div>
            )
          ))}
        </div>

        {/* Roadmap Canvas */}
        {lanedTasks.length === 0 ? (
          <Card className="py-16">
            <CardContent className="text-center">
              <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Нет задач с датами</h3>
              <p className="text-sm text-gray-400">Создайте задачи с указанием дат начала и окончания</p>
            </CardContent>
          </Card>
        ) : (
          <div className="overflow-x-auto border rounded-lg bg-white shadow-sm" style={{ maxHeight: "70vh" }}>
            <div style={{ minWidth: `${Math.max(1200, timelineWidth + 40)}px`, padding: "20px" }}>
              {/* PDF Header (visible only in export) */}
              <div className="mb-4 pb-3 border-b-2 border-red-700" style={{ pageBreakInside: "avoid" }}>
                <h2 className="text-xl font-bold text-red-700">Дорожная карта — B2B Task Manager</h2>
                <p className="text-xs text-gray-500">
                  Период: {formatDateLong(minDate)} — {formatDateLong(maxDate)} | Задач: {lanedTasks.length}
                </p>
              </div>

              {/* Timeline Header */}
              <div style={{ position: "sticky", top: 0, zIndex: 10, height: `${headerHeight}px`, marginBottom: "10px", background: "#fff" }}>
                {/* Base line */}
                <div style={{ position: "absolute", left: 0, right: 0, top: headerHeight - 10, height: "2px", background: "#e5e7eb" }} />
                {/* Ticks */}
                {ticks.map((tick, i) => {
                  const left = getTickLeft(tick.date);
                  return (
                    <div key={i} style={{ position: "absolute", left, top: 0 }}>
                      <div style={{ width: "1px", height: headerHeight - 5, background: "#d1d5db" }} />
                      <span className="text-xs text-gray-500 whitespace-nowrap" style={{ position: "absolute", top: headerHeight - 8, transform: "translateX(-50%)", fontSize: "10px" }}>
                        {tick.label}
                      </span>
                    </div>
                  );
                })}
                {/* Today marker */}
                {(() => {
                  const today = new Date();
                  if (today >= minDate && today <= maxDate) {
                    const left = getTickLeft(today);
                    return (
                      <div key="today" style={{ position: "absolute", left, top: 0, zIndex: 5 }}>
                        <div style={{ width: "2px", height: laneCount * laneHeight + headerHeight, background: "#DC2626", opacity: 0.5 }} />
                        <Badge className="bg-red-700 text-white text-[10px] px-1 py-0" style={{ position: "absolute", top: 0, transform: "translateX(-50%)" }}>Сегодня</Badge>
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>

              {/* Lanes */}
              <div style={{ position: "relative" }}>
                {/* Lane background lines */}
                {Array.from({ length: laneCount }).map((_, i) => (
                  <div key={i} style={{ position: "absolute", left: 0, right: 0, top: i * laneHeight, height: laneHeight - 4, background: i % 2 === 0 ? "#f9fafb" : "#ffffff", borderRadius: "4px" }} />
                ))}

                {/* Today line across all lanes */}
                {(() => {
                  const today = new Date();
                  if (today >= minDate && today <= maxDate) {
                    const left = getTickLeft(today);
                    return (
                      <div style={{ position: "absolute", left, top: -headerHeight, width: "2px", height: laneCount * laneHeight + headerHeight + 10, background: "#DC2626", opacity: 0.3, zIndex: 4 }} />
                    );
                  }
                  return null;
                })()}

                {/* Tasks */}
                {lanedTasks.map((task) => {
                  const left = getTaskLeft(task);
                  const width = getTaskWidth(task);
                  const top = task.lane * laneHeight + 6;
                  const color = statusColors[task.status] || "#6B7280";
                  const progress = task.progress || 0;

                  return (
                    <div
                      key={task.id}
                      className="group cursor-pointer"
                      style={{
                        position: "absolute",
                        left,
                        top,
                        width,
                        height: laneHeight - 16,
                        zIndex: 10,
                      }}
                      title={`${task.name}\n${statusLabels[task.status]} | ${priorityLabels[task.priority] || task.priority}\n${formatDateLong(task.sDate)} — ${formatDateLong(task.eDate)}\nПрогресс: ${progress}%`}
                    >
                      {/* Task bar */}
                      <div
                        className="rounded-md overflow-hidden h-full border shadow-sm transition-all hover:shadow-md hover:brightness-105"
                        style={{ background: color + "18", borderColor: color + "40" }}
                      >
                        {/* Progress fill */}
                        <div style={{ position: "absolute", left: 0, top: 0, width: `${clamp(progress, 0, 100)}%`, height: "100%", background: color + "25", borderRadius: "4px" }} />
                        {/* Content */}
                        <div className="relative z-10 px-2 py-1 flex flex-col justify-center h-full min-w-0">
                          <div className="flex items-center gap-1 min-w-0">
                            <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
                            <span className="text-xs font-semibold text-gray-800 truncate">{task.name}</span>
                          </div>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span className="text-[10px] text-gray-500 truncate">
                              {formatDateShort(task.sDate)} — {formatDateShort(task.eDate)}
                            </span>
                            {task.assignee && (
                              <span className="text-[10px] text-gray-400 truncate ml-1">· {task.assignee}</span>
                            )}
                          </div>
                          {/* Progress bar mini */}
                          <div className="mt-1 h-1 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${clamp(progress, 0, 100)}%`, background: color }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Total height spacer */}
                <div style={{ height: laneCount * laneHeight + 20 }} />
              </div>
            </div>
          </div>
        )}

        {/* Status cards */}
        {lanedTasks.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {Object.entries(statusLabels).map(([k, v]) => (
              <Card key={k} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setStatusFilter(statusFilter === k ? "all" : k)}>
                <CardContent className="p-3 flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: statusColors[k] }} />
                  <div>
                    <p className="text-lg font-bold text-gray-900">{statCounts[k] || 0}</p>
                    <p className="text-xs text-gray-500">{v}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* ========== CLEAN PDF DIV ========== */}
        {exportingPdf && (
          <div ref={pdfRef} style={{ position: "absolute", left: "-9999px", top: 0, width: `${Math.max(1400, timelineWidth + 80)}px`, background: "#fff", padding: "30px", fontFamily: "Arial, sans-serif" }}>
            {/* PDF Header */}
            <div style={{ borderBottom: "3px solid #DC2626", marginBottom: "20px", paddingBottom: "10px" }}>
              <h1 style={{ fontSize: "22px", color: "#DC2626", margin: 0 }}>Дорожная карта — B2B Task Manager</h1>
              <p style={{ fontSize: "11px", color: "#666", margin: "5px 0 0" }}>
                Период: {formatDateLong(minDate)} — {formatDateLong(maxDate)} | Задач: {lanedTasks.length} | {formatDateLong(new Date())}
              </p>
            </div>

            {/* PDF Timeline */}
            <div style={{ position: "relative" }}>
              {/* Header row */}
              <div style={{ display: "flex", borderBottom: "2px solid #DC2626", paddingBottom: "5px", marginBottom: "10px" }}>
                <div style={{ width: "200px", flexShrink: 0, fontWeight: "bold", fontSize: "12px", color: "#DC2626" }}>Задача</div>
                <div style={{ flex: 1, position: "relative", height: "30px" }}>
                  {ticks.filter((_, i) => i % Math.max(1, Math.floor(ticks.length / 20)) === 0).map((tick, i) => {
                    const left = (getTickLeft(tick.date) / timelineWidth) * 100;
                    return <span key={i} style={{ position: "absolute", left: `${left}%`, fontSize: "9px", color: "#666", transform: "translateX(-50%)" }}>{tick.label}</span>;
                  })}
                </div>
              </div>

              {/* Task rows by lane */}
              {Array.from({ length: laneCount }).map((_, laneIdx) => (
                <div key={laneIdx} style={{ position: "relative", height: `${laneHeight}px`, borderBottom: "1px solid #f0f0f0", background: laneIdx % 2 === 0 ? "#fafafa" : "#fff" }}>
                  {lanedTasks.filter((t) => t.lane === laneIdx).map((task) => {
                    const left = (getTaskLeft(task) / timelineWidth) * 100;
                    const width = Math.max((getTaskWidth(task) / timelineWidth) * 100, 3);
                    const color = statusColors[task.status] || "#6B7280";
                    const progress = task.progress || 0;
                    return (
                      <div key={task.id} style={{ position: "absolute", left: `${left}%`, top: "8px", width: `${width}%`, height: `${laneHeight - 16}px`, background: color + "18", border: `1px solid ${color}60`, borderRadius: "4px", padding: "4px 6px", fontSize: "10px", overflow: "hidden" }}>
                        <div style={{ position: "absolute", left: 0, top: 0, width: `${Math.min(progress, 100)}%`, height: "100%", background: color + "15", borderRadius: "4px" }} />
                        <div style={{ position: "relative", zIndex: 2 }}>
                          <div style={{ fontWeight: "bold", color: "#1f2937", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{task.name}</div>
                          <div style={{ color: "#6b7280", fontSize: "9px" }}>{formatDateShort(task.sDate)} — {formatDateShort(task.eDate)} · {progress}%</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Legend */}
            <div style={{ marginTop: "20px", display: "flex", gap: "15px", flexWrap: "wrap" }}>
              {Object.entries(statusLabels).map(([k, v]) => (
                <span key={k} style={{ fontSize: "10px", color: "#374151" }}>
                  <span style={{ display: "inline-block", width: "10px", height: "10px", borderRadius: "2px", background: statusColors[k], marginRight: "4px", verticalAlign: "middle" }} />
                  {v}
                </span>
              ))}
            </div>

            <p style={{ fontSize: "9px", color: "#999", marginTop: "20px", textAlign: "center" }}>
              Сформировано: {new Date().toLocaleString("ru-RU")} | B2B Task Manager — ЛУКОЙЛ
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
