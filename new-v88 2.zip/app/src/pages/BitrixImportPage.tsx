import { useState, useRef, useCallback } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import {
  BITRIX_TEMPLATE_COLUMNS,
  DEFAULT_MAPPING,
} from "@/types/bitrixImport";
import type { Mapping, BitrixProduct } from "@/types/bitrixImport";
import {
  parseExcelFile,
  applyMapping,
  generateBitrixExcel,
} from "@/services/bitrixImportService";
import {
  BitrixLookupService,
  NAME_COL_MAP,
} from "@/services/bitrixLookupService";
import JSZip from "jszip";

export default function BitrixImportPage() {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  /* ── Template (file 1) ── */
  const [templateHeaders, setTemplateHeaders] = useState<string[]>([]);

  /* ── Source data (file 2) ── */
  const [sourceHeaders, setSourceHeaders] = useState<string[]>([]);
  const [sourceRows, setSourceRows] = useState<Record<string, string | number>[]>([]);

  /* ── Mapping ── */
  const [mapping, setMapping] = useState<Mapping[]>([]);

  /* ── Photos ── */
  const [photos, setPhotos] = useState<Record<string, string[]>>({});
  const [photoMapByKccc, setPhotoMapByKccc] = useState<Record<string, string[]>>({});

  /* ── Generated products ── */
  const [products, setProducts] = useState<BitrixProduct[]>([]);

  /* ── Loading ── */
  const [loading, setLoading] = useState(false);

  /* refs */
  const templateInputRef = useRef<HTMLInputElement>(null);
  const sourceInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  /* ═══ STEP 1: Load Template (all sheets) ═══ */
  const handleTemplateUpload = async (file: File) => {
    setLoading(true);
    try {
      /* Parse main sheet headers */
      const { headers } = await parseExcelFile(file);
      setTemplateHeaders(headers);

      /* Parse all lookup sheets */
      const sheets = await lookupService.loadFromExcel(file);
      setLoadedSheets(sheets);
      console.log("[Bitrix] Loaded lookup sheets:", sheets);

      setStep(2);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  /* ═══ STEP 2: Load Source Data ═══ */
  const handleSourceUpload = async (file: File) => {
    setLoading(true);
    try {
      const { headers, rows } = await parseExcelFile(file);
      setSourceHeaders(headers);
      setSourceRows(rows);

      /* Auto-mapping */
      const autoMap: Mapping[] = BITRIX_TEMPLATE_COLUMNS.map((tc) => {
        const suggested = DEFAULT_MAPPING[tc.key];
        const match = suggested && headers.includes(suggested) ? suggested : null;
        return { templateCol: tc.label, sourceCol: match };
      });
      setMapping(autoMap);
      setStep(3);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  /* ═══ STEP 3: Update Mapping ═══ */
  const updateMapping = (templateLabel: string, sourceHeader: string | null) => {
    setMapping((prev) =>
      prev.map((m) =>
        m.templateCol === templateLabel ? { ...m, sourceCol: sourceHeader } : m
      )
    );
  };

  /* ═══ STEP 3→4: Apply & Generate with ID auto-lookup ═══ */
  const handleSave = () => {
    const keyMapping: Mapping[] = BITRIX_TEMPLATE_COLUMNS.map((tc) => {
      const mapped = mapping.find((m) => m.templateCol === tc.label);
      return { templateCol: tc.key, sourceCol: mapped?.sourceCol || null };
    }).filter((m) => m.sourceCol);

    const newAutoFilled: Record<string, number> = {};

    const generated = applyMapping(sourceRows, keyMapping).map((p, i) => {
      const src = sourceRows[i];
      if (!src) return p;

      const kccc = String(src["КССС"] || src["КСС"] || src["kccc"] || p.kccc || "");
      const photosForProduct = photoMapByKccc[kccc] || [];

      const enriched: BitrixProduct = {
        ...p,
        kccc,
        image: photosForProduct[0] || p.image || "",
        announce_pic: photosForProduct[0] || p.announce_pic || "",
        detail_pic: photosForProduct[1] || photosForProduct[0] || p.detail_pic || "",
      };

      /* Auto-fill ID columns from lookup sheets */
      BITRIX_TEMPLATE_COLUMNS.forEach((tc) => {
        if (!lookupService.isIdColumn(tc.label)) return;
        const sourceColName = lookupService.getSourceColForIdCol(tc.label);
        const lookupSheet = lookupService.getLookupSheetForIdCol(tc.label);
        if (!sourceColName || !lookupSheet) return;
        const mappedEntry = mapping.find((m) => m.templateCol === sourceColName);
        if (!mappedEntry?.sourceCol) return;
        const sourceValue = String(src[mappedEntry.sourceCol] || "");
        if (!sourceValue) return;
        const result = lookupService.getOrCreateId(lookupSheet, sourceValue);
        if (result.value) {
          enriched[tc.key] = result.value;
          if (!result.isNew) {
            newAutoFilled[tc.key] = (newAutoFilled[tc.key] || 0) + 1;
          }
        }
      });

      return enriched;
    });

    setAutoFilledIds(newAutoFilled);
    setProducts(generated);
    setStep(4);
  };

  /* ═══ STEP 4: Photo Upload (ZIP or individual) ═══ */
  const handlePhotoZip = async (file: File) => {
    setLoading(true);
    try {
      const zip = await JSZip.loadAsync(file);
      const newPhotos: Record<string, string[]> = {};

      const imageFiles = Object.entries(zip.files).filter(
        ([name, zf]) => !zf.dir && /\.(jpg|jpeg|png|webp)$/i.test(name)
      );

      for (const [filename, zipEntry] of imageFiles) {
        const blob = await zipEntry.async("blob");
        const dataUrl = await blobToDataUrl(blob);
        const cleanName = filename.toLowerCase().replace(/[^a-z0-9]/g, "");

        /* Find matching product by KCCC */
        sourceRows.forEach((row) => {
          const kccc = String(row["КССС"] || row["КСС"] || "");
          if (kccc && cleanName.includes(kccc.toLowerCase())) {
            if (!newPhotos[kccc]) newPhotos[kccc] = [];
            newPhotos[kccc].push(dataUrl);
          }
        });
      }

      setPhotoMapByKccc((prev) => ({ ...prev, ...newPhotos }));
    } catch (err) {
      console.error("ZIP photo error:", err);
    }
    setLoading(false);
  };

  const handleSinglePhoto = (file: File, kccc: string) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setPhotoMapByKccc((prev) => ({
        ...prev,
        [kccc]: [...(prev[kccc] || []), dataUrl],
      }));
    };
    reader.readAsDataURL(file);
  };

  /* ═══ Lookup service for ID auto-fill ═══ */
  const [lookupService] = useState(() => new BitrixLookupService());
  const [loadedSheets, setLoadedSheets] = useState<string[]>([]);
  const [autoFilledIds, setAutoFilledIds] = useState<Record<string, number>>({});

  /* ═══ Export ═══ */
  const [exportProgress, setExportProgress] = useState(0);
  const [exporting, setExporting] = useState(false);

  const [exportError, setExportError] = useState("");

  const exportExcel = async () => {
    setExporting(true);
    setExportProgress(0);
    setExportError("");
    await new Promise((resolve) => setTimeout(resolve, 50));
    try {
      await generateBitrixExcel(products, "bitrix-import-result.xlsx", (pct) => {
        setExportProgress(pct);
      });
    } catch (err: any) {
      console.error("Export error:", err);
      setExportError("Ошибка выгрузки: " + (err.message || "Неизвестная ошибка"));
    }
    setTimeout(() => {
      setExporting(false);
      setExportProgress(0);
    }, 500);
  };

  const exportPhotosZip = async () => {
    const zip = new JSZip();
    const folder = zip.folder("photos");
    if (!folder) return;

    Object.entries(photoMapByKccc).forEach(([kccc, imgs]) => {
      imgs.forEach((img, i) => {
        const ext = img.startsWith("data:image/png") ? "png" : "jpg";
        const base64 = img.split(",")[1];
        if (base64) {
          folder.file(`${kccc}_${i + 1}.${ext}`, base64, { base64: true });
        }
      });
    });

    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "photos-by-kccc.zip";
    a.click();
    URL.revokeObjectURL(url);
  };

  /* ═══ Render ═══ */
  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)] bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <h1 className="text-2xl font-bold text-gray-900">Битрикс Загрузка</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Сопоставление шаблона Битрикс с данными → генерация импорта
          </p>
          {/* Stepper */}
          <div className="flex items-center gap-0 mt-4">
            {[
              { n: 1, label: "Шаблон" },
              { n: 2, label: "Данные" },
              { n: 3, label: "Сопоставление" },
              { n: 4, label: "Результат" },
            ].map((s, i) => (
              <div key={s.n} className="flex items-center flex-1">
                <div
                  className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold ${
                    step >= s.n
                      ? "bg-[#0d9488] text-white"
                      : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {step > s.n ? "✓" : s.n}
                </div>
                <span
                  className={`ml-2 text-xs font-medium ${
                    step >= s.n ? "text-gray-800" : "text-gray-400"
                  }`}
                >
                  {s.label}
                </span>
                {i < 3 && <div className="flex-1 h-0.5 bg-gray-200 mx-3" />}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-4">
          {/* ═══ STEP 1 ═══ */}
          {step === 1 && (
            <StepUpload
              title="Загрузите шаблон Битрикс"
              description="Файл с колонками шаблона (колонки не изменяются)"
              accept=".xlsx,.xls"
              onUpload={handleTemplateUpload}
              inputRef={templateInputRef}
              loading={loading}
            />
          )}

          {/* ═══ STEP 2 ═══ */}
          {step === 2 && (
            <>
              <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-800">
                ✓ Шаблон загружен: {templateHeaders.length} колонок
              </div>
              <StepUpload
                title="Загрузите файл с данными"
                description="Файл 'Загрузка Финал' для сопоставления"
                accept=".xlsx,.xls,.csv"
                onUpload={handleSourceUpload}
                inputRef={sourceInputRef}
                loading={loading}
              />
            </>
          )}

          {/* ═══ STEP 3: Mapping ═══ */}
          {step === 3 && (
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-100">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-bold text-gray-800">
                    Сопоставление колонок
                  </h3>
                  <span className="text-xs text-gray-500">
                    {sourceRows.length} товаров | Авто-сопоставление выполнено
                  </span>
                </div>
                {loadedSheets.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    <span className="text-[10px] text-gray-500">Справочники:</span>
                    {loadedSheets.map((s) => (
                      <span key={s} className="px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] rounded-full font-medium">
                        {s}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[500px] overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
                  {BITRIX_TEMPLATE_COLUMNS.map((tc) => {
                    const mapped = mapping.find(
                      (m) => m.templateCol === tc.label
                    );
                    const isAutoId = lookupService.isIdColumn(tc.label);
                    return (
                      <MappingRow
                        key={tc.key}
                        templateCol={tc.label}
                        required={tc.required}
                        category={tc.category}
                        sourceHeaders={sourceHeaders}
                        selectedSource={mapped?.sourceCol || null}
                        onChange={(val) => updateMapping(tc.label, val)}
                        isAutoId={isAutoId}
                      />
                    );
                  })}
                </div>
                <div className="flex gap-3 mt-4 pt-4 border-t">
                  <Button onClick={handleSave} className="gap-2">
                    💾 Сохранить и сгенерировать
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setStep(2)}
                  >
                    ← Назад
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* ═══ STEP 4: Result ═══ */}
          {step === 4 && (
            <div className="space-y-4">
              {/* Summary */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <StatCard label="Товаров" value={products.length} />
                <StatCard
                  label="С фото"
                  value={Object.keys(photoMapByKccc).length}
                />
                <StatCard
                  label="Колонок шаблона"
                  value={BITRIX_TEMPLATE_COLUMNS.length}
                />
                <StatCard
                  label="Сопоставлено"
                  value={mapping.filter((m) => m.sourceCol).length}
                />
              </div>

              {/* Auto-filled IDs */}
              {Object.keys(autoFilledIds).length > 0 && (
                <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
                  <div className="text-sm font-semibold text-orange-800 mb-2">
                    🟠 Авто-подстановка ID из справочников
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(autoFilledIds).map(([key, count]) => {
                      const col = BITRIX_TEMPLATE_COLUMNS.find((c) => c.key === key);
                      return (
                        <span
                          key={key}
                          className="px-3 py-1 bg-orange-100 border border-orange-300 rounded-full text-xs font-medium text-orange-700"
                        >
                          {col?.label || key}: {count} товаров
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Photos */}
              <div className="bg-white rounded-xl border border-gray-200 p-4">
                <h3 className="text-sm font-bold text-gray-800 mb-3">
                  📷 Загрузка фото
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div
                    onClick={() => photoInputRef.current?.click()}
                    className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:border-[#0d9488] transition-colors"
                  >
                    <input
                      ref={photoInputRef}
                      type="file"
                      accept=".zip"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handlePhotoZip(f);
                        e.target.value = "";
                      }}
                    />
                    <svg
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="#9CA3AF"
                      strokeWidth="1.5"
                      className="mx-auto mb-1"
                    >
                      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" />
                      <polyline points="17 8 12 3 7 8" />
                      <line x1="12" y1="3" x2="12" y2="15" />
                    </svg>
                    <span className="text-xs text-gray-500">
                      ZIP с фото (по КССС)
                    </span>
                  </div>
                </div>

                {/* Photo list */}
                {Object.keys(photoMapByKccc).length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {Object.entries(photoMapByKccc).map(([kccc, imgs]) => (
                      <div
                        key={kccc}
                        className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-200 rounded-full"
                      >
                        <span className="text-xs font-mono text-green-700">
                          {kccc}
                        </span>
                        <span className="text-xs text-green-600">
                          {imgs.length} фото
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Table preview */}
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                  <h3 className="text-sm font-bold text-gray-800">
                    📋 Результат ({products.length} товаров)
                  </h3>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={exportPhotosZip}
                    >
                      📷 Выгрузить фото
                    </Button>
                    <Button size="sm" onClick={exportExcel} disabled={exporting}>
                      {exporting ? `⏳ ${exportProgress}%` : "📄 Выгрузить Excel"}
                    </Button>
                    {exportError && <span className="text-xs text-red-600 ml-2">{exportError}</span>}
                  </div>
                </div>
                <div className="overflow-x-auto" style={{ maxHeight: "400px" }}>
                  <table className="w-full text-xs">
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        {BITRIX_TEMPLATE_COLUMNS.map((tc) => (
                          <th
                            key={tc.key}
                            className="px-2 py-1.5 text-left font-semibold text-gray-600 border-b whitespace-nowrap"
                          >
                            {tc.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {products.slice(0, 50).map((p, i) => (
                        <tr
                          key={i}
                          className="border-b border-gray-50 hover:bg-gray-50"
                        >
                          {BITRIX_TEMPLATE_COLUMNS.map((tc) => (
                            <td
                              key={tc.key}
                              className="px-2 py-1.5 text-gray-700 whitespace-nowrap"
                            >
                              {p[tc.key] !== undefined ? String(p[tc.key]) : ""}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

/* ═══ Sub-Components ═══ */

function StepUpload({
  title,
  description,
  accept,
  onUpload,
  inputRef,
  loading,
}: {
  title: string;
  description: string;
  accept: string;
  onUpload: (file: File) => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
  loading: boolean;
}) {
  const [dragOver, setDragOver] = useState(false);

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragOver(false);
        const f = e.dataTransfer.files[0];
        if (f) onUpload(f);
      }}
      onClick={() => inputRef.current?.click()}
      className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all max-w-lg mx-auto ${
        dragOver
          ? "border-[#0d9488] bg-[#f0fdfa]"
          : "border-gray-300 hover:border-gray-400 bg-white"
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onUpload(f);
          e.target.value = "";
        }}
      />
      {loading ? (
        <div className="w-8 h-8 border-2 border-gray-300 border-t-[#0d9488] rounded-full animate-spin mx-auto" />
      ) : (
        <>
          <svg
            width="48"
            height="48"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#9CA3AF"
            strokeWidth="1.5"
            className="mx-auto mb-3"
          >
            <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
            <polyline points="14 2 14 8 20 8" />
            <line x1="16" y1="13" x2="8" y2="13" />
            <line x1="16" y1="17" x2="8" y2="17" />
          </svg>
          <div className="text-lg font-medium text-gray-700">{title}</div>
          <div className="text-sm text-gray-400 mt-1">{description}</div>
          <div className="text-xs text-gray-400 mt-2">
            Поддерживаемые форматы: {accept}
          </div>
        </>
      )}
    </div>
  );
}

function MappingRow({
  templateCol,
  required,
  category,
  sourceHeaders,
  selectedSource,
  onChange,
  isAutoId,
}: {
  templateCol: string;
  required?: boolean;
  category: string;
  sourceHeaders: string[];
  selectedSource: string | null;
  onChange: (val: string | null) => void;
  isAutoId?: boolean;
}) {
  const orangeStyle = isAutoId
    ? { background: selectedSource ? "#fff7ed" : "#fff7ed88", borderColor: selectedSource ? "#fdba74" : "#fed7aa", borderStyle: selectedSource ? "solid" as const : "dashed" as const }
    : {};

  return (
    <div
      className={`flex items-center gap-2 p-2 rounded-lg border ${isAutoId ? "" : "bg-gray-50 border-gray-100"}`}
      style={isAutoId ? { ...orangeStyle, borderWidth: 1, borderRadius: 8 } : {}}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1">
          <span className="text-xs font-semibold truncate" style={isAutoId ? { color: "#9a3412" } : { color: "#374151" }}>
            {templateCol}
          </span>
          {required && <span className="text-red-500 text-xs">*</span>}
          {isAutoId && (
            <span className="text-[9px] px-1 py-0.5 rounded font-medium" style={{ background: "#fed7aa", color: "#9a3412" }}>
              ID
            </span>
          )}
        </div>
        <span className="text-[10px] text-gray-400">{category}</span>
      </div>
      <select
        value={selectedSource || ""}
        onChange={(e) => onChange(e.target.value || null)}
        className="text-xs border rounded px-2 py-1 max-w-[140px]"
        style={
          selectedSource
            ? isAutoId
              ? { borderColor: "#fb923c", background: "#fff", color: "#7c2d12" }
              : { borderColor: "#0d9488", background: "#f0fdfa", color: "#1f2937" }
            : { borderColor: "#e5e7eb", color: "#9ca3af" }
        }
      >
        <option value="">— не сопоставлено —</option>
        {sourceHeaders.map((h) => (
          <option key={h} value={h}>
            {h}
          </option>
        ))}
      </select>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4">
      <div className="text-xs text-gray-500 uppercase tracking-wider">
        {label}
      </div>
      <div className="text-2xl font-bold text-gray-900 mt-1">{value}</div>
    </div>
  );
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.readAsDataURL(blob);
  });
}
