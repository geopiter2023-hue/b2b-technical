export interface Category {
  id: string;
  name: string;
  color: string;
  createdAt: string;
}

const LS_KEY = "b2b_categories";

const DEFAULT_CATEGORIES: Category[] = [
  { id: "cat-logistics", name: "Логистика", color: "#DC2626", createdAt: "2024-01-01" },
  { id: "cat-sales", name: "Продажи", color: "#2563EB", createdAt: "2024-01-01" },
  { id: "cat-marketing", name: "Маркетинг", color: "#D97706", createdAt: "2024-01-01" },
  { id: "cat-it", name: "IT", color: "#7C3AED", createdAt: "2024-01-01" },
  { id: "cat-finance", name: "Финансы", color: "#16A34A", createdAt: "2024-01-01" },
  { id: "cat-hr", name: "HR", color: "#0891B2", createdAt: "2024-01-01" },
  { id: "cat-procurement", name: "Закупки", color: "#BE185D", createdAt: "2024-01-01" },
  { id: "cat-legal", name: "Юридический", color: "#4338CA", createdAt: "2024-01-01" },
  { id: "cat-production", name: "Производство", color: "#059669", createdAt: "2024-01-01" },
  { id: "cat-analytics", name: "Аналитика", color: "#CA8A04", createdAt: "2024-01-01" },
];

const COLORS = [
  "#DC2626", "#2563EB", "#D97706", "#7C3AED", "#16A34A",
  "#0891B2", "#BE185D", "#4338CA", "#059669", "#CA8A04",
  "#EA580C", "#0D9488", "#4F46E5", "#C026D3", "#65A30D",
];

function load(): Category[] {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [...DEFAULT_CATEGORIES];
}

function save(cats: Category[]) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(cats));
  } catch { /* ignore */ }
}

export function getCategories(): Category[] {
  return load();
}

export function addCategory(name: string): Category {
  const cats = load();
  const newCat: Category = {
    id: "cat-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5),
    name: name.trim(),
    color: COLORS[cats.length % COLORS.length],
    createdAt: new Date().toISOString(),
  };
  cats.push(newCat);
  save(cats);
  return newCat;
}

export function deleteCategory(id: string): void {
  const cats = load().filter((c) => c.id !== id);
  save(cats);
}

export function renameCategory(id: string, newName: string): void {
  const cats = load();
  const idx = cats.findIndex((c) => c.id === id);
  if (idx !== -1) {
    cats[idx].name = newName.trim();
    save(cats);
  }
}

export function getCategoryColor(name: string): string {
  const cat = load().find((c) => c.name === name);
  return cat?.color || "#6B7280";
}

export function resetCategories(): void {
  localStorage.removeItem(LS_KEY);
}
