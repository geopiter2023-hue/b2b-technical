import { supabase, isSupabaseConfigured } from "@/lib/supabase";

export interface Comment { id: number; task_id: number; user_name: string; message: string; image_url: string | null; created_at: string; }

const LS_KEY = "b2b_comments";
function load(): Comment[] { try { const r = localStorage.getItem(LS_KEY); return r ? JSON.parse(r) : []; } catch { return []; } }
function save(c: Comment[]) { try { localStorage.setItem(LS_KEY, JSON.stringify(c)); } catch {} }
function nextId(c: Comment[]): number { return c.length === 0 ? 1 : Math.max(...c.map((x) => x.id)) + 1; }

export async function listComments(taskId: number) {
  if (isSupabaseConfigured) {
    try { const { data, error } = await supabase.from("task_comments").select("*").eq("task_id", taskId).order("created_at", { ascending: false }); if (error) throw error; const comments = (data || []) as Comment[]; const all = load(); save([...all.filter((c) => c.task_id !== taskId), ...comments]); return comments; } catch (err) { console.warn("[Comments] Supabase failed:", err); }
  }
  return load().filter((c) => c.task_id === taskId).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export async function createComment(taskId: number, message: string, imageUrl?: string, userName = "B2B") {
  if (isSupabaseConfigured) {
    try { const { data, error } = await supabase.from("task_comments").insert({ task_id: taskId, user_name: userName, message: message || " ", image_url: imageUrl || null }).select("id").single(); if (error) throw error; const updated = await listComments(taskId); const all = load(); save([...all.filter((c) => c.task_id !== taskId), ...updated]); return data; } catch (err) { console.warn("[Comments] Supabase failed:", err); }
  }
  const comments = load();
  const newC: Comment = { id: nextId(comments), task_id: taskId, user_name: userName, message: message || " ", image_url: imageUrl || null, created_at: new Date().toISOString() };
  comments.push(newC); save(comments);
  return { id: newC.id };
}

export async function deleteComment(id: number) {
  if (isSupabaseConfigured) { try { await supabase.from("task_comments").delete().eq("id", id); save(load().filter((c) => c.id !== id)); return; } catch {} }
  save(load().filter((c) => c.id !== id));
}
