import * as XLSX from "xlsx";

export interface PriceControlRecord {
  id: string;
  name: string;
  ksss: string;
  sku_id: string;
  category: string;
  fasovka: string;
  obem: string;
  purchasePrice: number;
  retailPrice: number;
  specialPrice: number | null;
  markup: number;
  deviation: string;
  stock: number;
  available: number;
  unit: string;
  weightNetto: number | null;
  vat: string;
  active: boolean;
  efficiency: number | null; // Эффективность на тонну
  extra?: Record<string, string>;
}

export interface PriceControlSummary {
  totalProducts: number;
  totalStock: number;
  avgMarkup: number;
  minMarkup: number;
  maxMarkup: number;
  markupRanges: {
    low: number;
    normal: number;
    high: number;
    veryHigh: number;
  };
  avgPurchasePrice: number;
  avgRetailPrice: number;
  totalRetailValue: number;
  totalPurchaseValue: number;
  avgEfficiency: number | null;
}

export interface CategoryStat {
  category: string;
  count: number;
  avgPurchase: number;
  avgRetail: number;
  avgMarkup: number;
  totalStock: number;
  totalRetailValue: number;
  avgEfficiency: number | null;
}

export interface DeviationGroup {
  label: string;
  color: string;
  count: number;
  products: PriceControlRecord[];
}

export interface PriceSource {
  id: string;
  name: string;
  url: string;
  active: boolean;
  lastScraped?: string;
  prices?: Record<string, number>; // ksss -> price
}

export interface EfficiencyRecord {
  ksss: string;
  name: string;
  efficiency: number; // эффективность на тонну
}

const SK_DATA = "b2b_price_control";
const SK_HISTORY = "b2b_price_control_history";
const SK_SOURCES = "b2b_price_sources";
const SK_EFFICIENCY = "b2b_price_efficiency";

function safeStr(v: any): string {
  if (v === null || v === undefined) return "";
  return String(v).trim();
}

function safeNum(v: any): number {
  if (v === null || v === undefined || v === "") return 0;
  const s = String(v).replace(/\s/g, "").replace(/[₽$€,]/g, "").replace("\u00a0", "");
  const n = parseFloat(s);
  return isNaN(n) ? 0 : n;
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

export function parsePriceControlExcel(buffer: ArrayBuffer): { records: PriceControlRecord[]; errors: string[] } {
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: "" }) as any[][];

  if (raw.length < 2) return { records: [], errors: ["Файл пустой"] };

  const headers = raw[0].map((h) => String(h).trim());
  const records: PriceControlRecord[] = [];
  const errors: string[] = [];
  const usedCols = new Set<number>();

  const findCol = (aliases: string[], exact?: string[]): number | undefined => {
    if (exact) {
      for (let i = 0; i < headers.length; i++) {
        if (usedCols.has(i)) continue;
        const h = headers[i].toLowerCase().trim();
        if (exact.some((e) => h === e.toLowerCase())) { usedCols.add(i); return i; }
      }
    }
    for (let i = 0; i < headers.length; i++) {
      if (usedCols.has(i)) continue;
      const h = headers[i].toLowerCase().trim();
      if (aliases.some((a) => h.includes(a.toLowerCase()))) { usedCols.add(i); return i; }
    }
    return undefined;
  };

  const colName = findCol(["Название", "название", "name", "товар"], ["название", "наименование"]);
  const colKSSS = findCol(["КССС", "кссс", "код"], ["кссс"]);
  const colSKU = findCol(["SKU_ID", "sku"], ["sku_id"]);
  const colCategory = findCol(["Элемент каталога", "каталог", "category"], ["элемент каталога"]);
  const colFasovka = findCol(["Фасовка", "фасовка"], ["фасовка"]);
  const colObem = findCol(["Объем фасовки", "объем"], ["объем фасовки"]);
  const colPurchase = findCol(["Закупочная цена", "закуп", "purchase"], ["закупочная цена"]);
  const colRetail = findCol(["Розничная цена", "розница", "retail"], ["розничная цена"]);
  const colSpecial = findCol(["Специальная", "спец"], ["специальная"]);
  const colStock = findCol(["Остатки", "остаток"], ["остатки"]);
  const colAvailable = findCol(["Доступное количество", "доступно"], ["доступное количество"]);
  const colUnit = findCol(["Ед. измерения", "единица"], ["ед. измерения"]);
  const colWeight = findCol(["Вес нетто", "вес"], ["вес нетто (грамм)"]);
  const colVAT = findCol(["Ставка НДС", "ндс"], ["ставка ндс"]);
  const colActive = findCol(["Товар активен", "активен"], ["товар активен"]);
  const colEfficiency = findCol(["Эффективность", "эффективность", "на тонну", "тонн"], ["эффективность", "эффективность на тонну"]);

  if (colName === undefined) errors.push("Не найдена колонка 'Название'");
  if (colPurchase === undefined) errors.push("Не найдена колонка 'Закупочная цена'");
  if (colRetail === undefined) errors.push("Не найдена колонка 'Розничная цена'");

  if (errors.length > 0 && (!colName || !colPurchase || !colRetail)) {
    return { records: [], errors };
  }

  for (let i = 1; i < raw.length; i++) {
    const row = raw[i];
    if (!row || row.every((v) => !v || String(v).trim() === "")) continue;

    const name = safeStr(row[colName ?? 1]);
    if (!name) continue;

    const purchasePrice = safeNum(row[colPurchase ?? 50]);
    const retailPrice = safeNum(row[colRetail ?? 51]);
    const specialPrice = colSpecial !== undefined ? safeNum(row[colSpecial]) || null : null;
    const efficiency = colEfficiency !== undefined ? safeNum(row[colEfficiency]) || null : null;

    if (purchasePrice <= 0 && retailPrice <= 0) continue;

    const markup = purchasePrice > 0 ? Math.round(((retailPrice - purchasePrice) / purchasePrice) * 10000) / 100 : 0;

    let deviation = "Норма";
    if (markup < 10) deviation = "Низкая наценка";
    else if (markup > 50) deviation = "Высокая наценка";
    else if (purchasePrice <= 0 && retailPrice > 0) deviation = "Нет закупочной цены";
    else if (retailPrice <= 0 && purchasePrice > 0) deviation = "Нет розничной цены";

    const extra: Record<string, string> = {};
    for (let ci = 0; ci < headers.length; ci++) {
      if (usedCols.has(ci)) continue;
      const h = raw[0][ci];
      const v = safeStr(row[ci]);
      if (h && v) extra[String(h)] = v;
    }

    records.push({
      id: generateId(),
      name,
      ksss: safeStr(row[colKSSS ?? 29]),
      sku_id: safeStr(row[colSKU ?? 25]),
      category: safeStr(row[colCategory ?? 22]),
      fasovka: safeStr(row[colFasovka ?? 34]),
      obem: safeStr(row[colObem ?? 31]),
      purchasePrice,
      retailPrice,
      specialPrice,
      markup,
      deviation,
      stock: safeNum(row[colStock ?? 32]),
      available: safeNum(row[colAvailable ?? 38]),
      unit: safeStr(row[colUnit ?? 41]),
      weightNetto: colWeight !== undefined ? safeNum(row[colWeight]) || null : null,
      vat: safeStr(row[colVAT ?? 49]),
      active: colActive !== undefined ? String(row[colActive ?? 33]).toLowerCase().includes("да") : true,
      efficiency,
      extra: Object.keys(extra).length > 0 ? extra : undefined,
    });
  }

  return { records, errors };
}

// Efficiency parsing from separate file
export function parseEfficiencyExcel(buffer: ArrayBuffer): EfficiencyRecord[] {
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: "" }) as any[][];

  if (raw.length < 2) return [];

  const headers = raw[0].map((h) => String(h).trim().toLowerCase());
  const ksssIdx = headers.findIndex((h) => h.includes("кссс") || h.includes("код"));
  const nameIdx = headers.findIndex((h) => h.includes("название") || h.includes("наименование"));
  const effIdx = headers.findIndex((h) => h.includes("эффективность") || h.includes("тонн"));

  if (effIdx < 0) return [];

  const records: EfficiencyRecord[] = [];
  for (let i = 1; i < raw.length; i++) {
    const row = raw[i];
    if (!row) continue;
    const ksss = ksssIdx >= 0 ? safeStr(row[ksssIdx]) : "";
    const name = nameIdx >= 0 ? safeStr(row[nameIdx]) : "";
    const efficiency = safeNum(row[effIdx]);
    if (efficiency > 0) {
      records.push({ ksss: ksss || String(i), name, efficiency });
    }
  }
  return records;
}

export function applyEfficiency(records: PriceControlRecord[], efficiency: EfficiencyRecord[]): PriceControlRecord[] {
  const effMap: Record<string, number> = {};
  efficiency.forEach((e) => { if (e.ksss) effMap[e.ksss] = e.efficiency; });
  return records.map((r) => ({
    ...r,
    efficiency: effMap[r.ksss] !== undefined ? effMap[r.ksss] : r.efficiency,
  }));
}

// Price Sources
export function savePriceSources(sources: PriceSource[]): void {
  try { localStorage.setItem(SK_SOURCES, JSON.stringify(sources)); } catch {}
}

export function loadPriceSources(): PriceSource[] {
  try { const raw = localStorage.getItem(SK_SOURCES); return raw ? JSON.parse(raw) : []; } catch { return []; }
}

export function addPriceSource(name: string, url: string): PriceSource {
  const source: PriceSource = { id: generateId(), name, url, active: true };
  const sources = loadPriceSources();
  sources.push(source);
  savePriceSources(sources);
  return source;
}

export function removePriceSource(id: string): void {
  const sources = loadPriceSources().filter((s) => s.id !== id);
  savePriceSources(sources);
}

// Storage
export function savePriceControlData(records: PriceControlRecord[]): void {
  try {
    const slim = records.slice(0, 500).map((r) => {
      const { extra, ...rest } = r;
      return rest;
    });
    localStorage.setItem(SK_DATA, JSON.stringify(slim));
  } catch {}
}

export function loadPriceControlData(): PriceControlRecord[] {
  try {
    const raw = localStorage.getItem(SK_DATA);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export function clearPriceControlData(): void {
  localStorage.removeItem(SK_DATA);
}

// Upload history
export interface PriceControlUpload {
  id: string;
  fileName: string;
  recordCount: number;
  uploadedAt: string;
}

export function addPriceControlUpload(fileName: string, recordCount: number): void {
  try {
    const history = getPriceControlUploads();
    history.unshift({ id: generateId(), fileName, recordCount, uploadedAt: new Date().toISOString() });
    localStorage.setItem(SK_HISTORY, JSON.stringify(history.slice(0, 20)));
  } catch {}
}

export function getPriceControlUploads(): PriceControlUpload[] {
  try { const raw = localStorage.getItem(SK_HISTORY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}

// Analytics
export function getPriceControlSummary(records: PriceControlRecord[]): PriceControlSummary {
  if (records.length === 0) {
    return { totalProducts: 0, totalStock: 0, avgMarkup: 0, minMarkup: 0, maxMarkup: 0, markupRanges: { low: 0, normal: 0, high: 0, veryHigh: 0 }, avgPurchasePrice: 0, avgRetailPrice: 0, totalRetailValue: 0, totalPurchaseValue: 0, avgEfficiency: null };
  }
  const markups = records.map((r) => r.markup).filter((m) => m > 0);
  const purchasePrices = records.map((r) => r.purchasePrice).filter((p) => p > 0);
  const retailPrices = records.map((r) => r.retailPrice).filter((p) => p > 0);
  const efficiencies = records.map((r) => r.efficiency).filter((e) => e !== null && e !== undefined && e > 0) as number[];
  const totalRetailValue = records.reduce((s, r) => s + r.retailPrice * r.stock, 0);
  const totalPurchaseValue = records.reduce((s, r) => s + r.purchasePrice * r.stock, 0);

  return {
    totalProducts: records.length,
    totalStock: records.reduce((s, r) => s + r.stock, 0),
    avgMarkup: markups.length > 0 ? Math.round((markups.reduce((a, b) => a + b, 0) / markups.length) * 100) / 100 : 0,
    minMarkup: markups.length > 0 ? Math.min(...markups) : 0,
    maxMarkup: markups.length > 0 ? Math.max(...markups) : 0,
    markupRanges: {
      low: records.filter((r) => r.markup < 10).length,
      normal: records.filter((r) => r.markup >= 10 && r.markup <= 30).length,
      high: records.filter((r) => r.markup > 30 && r.markup <= 50).length,
      veryHigh: records.filter((r) => r.markup > 50).length,
    },
    avgPurchasePrice: purchasePrices.length > 0 ? Math.round((purchasePrices.reduce((a, b) => a + b, 0) / purchasePrices.length) * 100) / 100 : 0,
    avgRetailPrice: retailPrices.length > 0 ? Math.round((retailPrices.reduce((a, b) => a + b, 0) / retailPrices.length) * 100) / 100 : 0,
    totalRetailValue,
    totalPurchaseValue,
    avgEfficiency: efficiencies.length > 0 ? Math.round((efficiencies.reduce((a, b) => a + b, 0) / efficiencies.length) * 100) / 100 : null,
  };
}

export function getCategoryStats(records: PriceControlRecord[]): CategoryStat[] {
  const grouped: Record<string, PriceControlRecord[]> = {};
  for (const r of records) {
    const cat = r.category || "Без категории";
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(r);
  }
  return Object.entries(grouped).map(([category, items]) => {
    const purchasePrices = items.map((i) => i.purchasePrice).filter((p) => p > 0);
    const retailPrices = items.map((i) => i.retailPrice).filter((p) => p > 0);
    const markups = items.map((i) => i.markup).filter((m) => m > 0);
    const efficiencies = items.map((i) => i.efficiency).filter((e) => e !== null && e !== undefined && e > 0) as number[];
    return {
      category,
      count: items.length,
      avgPurchase: purchasePrices.length > 0 ? Math.round((purchasePrices.reduce((a, b) => a + b, 0) / purchasePrices.length) * 100) / 100 : 0,
      avgRetail: retailPrices.length > 0 ? Math.round((retailPrices.reduce((a, b) => a + b, 0) / retailPrices.length) * 100) / 100 : 0,
      avgMarkup: markups.length > 0 ? Math.round((markups.reduce((a, b) => a + b, 0) / markups.length) * 100) / 100 : 0,
      totalStock: items.reduce((s, i) => s + i.stock, 0),
      totalRetailValue: items.reduce((s, i) => s + i.retailPrice * i.stock, 0),
      avgEfficiency: efficiencies.length > 0 ? Math.round((efficiencies.reduce((a, b) => a + b, 0) / efficiencies.length) * 100) / 100 : null,
    };
  }).sort((a, b) => b.count - a.count);
}

export function getDeviationGroups(records: PriceControlRecord[]): DeviationGroup[] {
  return [
    { label: "Низкая наценка (< 10%)", color: "#EF4444", count: records.filter((r) => r.markup < 10).length, products: records.filter((r) => r.markup < 10) },
    { label: "Норма (10-30%)", color: "#22C55E", count: records.filter((r) => r.markup >= 10 && r.markup <= 30).length, products: records.filter((r) => r.markup >= 10 && r.markup <= 30) },
    { label: "Высокая (30-50%)", color: "#F59E0B", count: records.filter((r) => r.markup > 30 && r.markup <= 50).length, products: records.filter((r) => r.markup > 30 && r.markup <= 50) },
    { label: "Очень высокая (> 50%)", color: "#DC2626", count: records.filter((r) => r.markup > 50).length, products: records.filter((r) => r.markup > 50) },
    { label: "Нет данных", color: "#6B7280", count: records.filter((r) => r.markup <= 0).length, products: records.filter((r) => r.markup <= 0) },
  ];
}

export function formatPrice(n: number): string {
  if (!n || n <= 0) return "—";
  return n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatNumber(n: number): string {
  return n.toLocaleString("ru-RU");
}

export function formatMarkup(n: number): string {
  if (n === 0) return "—";
  const prefix = n > 0 ? "+" : "";
  return `${prefix}${n.toFixed(2)}%`;
}

export function formatEfficiency(n: number | null): string {
  if (n === null || n === undefined || n <= 0) return "—";
  return `${n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} т/т`;
}
