/**
 * Bitrix Lookup Service — парсит все листы-справочники из шаблона
 * и предоставляет lookup по названию → ID/XML_ID
 */

export interface LookupTable {
  sheetName: string;
  entries: LookupEntry[];
  maxId: number;
}

export interface LookupEntry {
  name: string;
  xmlId: string;
  id?: number;
  code?: string;
}

// Колонка шаблона → исходная колонка для поиска значения
export const NAME_COL_MAP: Record<string, string> = {
  "id раздела": "Раздел",
  "id вида транспорта": "Вид транспорта",
  "id стандарта тормозной жидкости": "Стандарт тормозной жидкости",
  "id назначений": "Назначение",
  "id вида": "Вид",
  "id вязкости": "Вязкость",
  "id классификации по api": "Классификация по API",
  "id вида двигателя": "Вид двигателя",
  "id хит": "Хит",
  "id новинки": "Новинка",
  "id спецТовар": "Специальный товар",
  "id цвет": "Цвет",
  "id префикс": "Не применять \u201cПрефикс для имени товаров\u201d",
  "id фасовки": "Фасовка",
};

// ID-колонка → лист справочника
export const ID_TO_SHEET: Record<string, string> = {
  "id раздела": "Разделы",
  "id вида транспорта": "Вид транспорта",
  "id стандарта тормозной жидкости": "Стандарт тормозной жидкости",
  "id назначений": "Назначение",
  "id вида": "Вид",
  "id вязкости": "Вязкость",
  "id классификации по api": "Классификация по API",
  "id вида двигателя": "Вид двигателя",
  "id хит": "Хит",
  "id новинки": "Новинки",
  "id спецТовар": "СпецТовар",
  "id цвет": "Цвет",
  "id префикс": "Префикс",
  "id фасовки": "Фасовка",
};

// Какое поле использовать для ID
export const ID_FIELD_MAP: Record<string, "id" | "xmlId" | "code"> = {
  "Разделы": "code",
  "Вид транспорта": "id",
  "Стандарт тормозной жидкости": "id",
  "Назначение": "id",
  "Вид": "xmlId",
  "Вязкость": "xmlId",
  "Классификация по API": "xmlId",
  "Вид двигателя": "xmlId",
  "Хит": "xmlId",
  "Новинки": "xmlId",
  "СпецТовар": "xmlId",
  "Цвет": "xmlId",
  "Префикс": "xmlId",
  "Фасовка": "id",
};

export class BitrixLookupService {
  private lookups: Map<string, LookupTable> = new Map();

  async loadFromExcel(file: File): Promise<string[]> {
    const XLSX = await import("xlsx");
    const data = await file.arrayBuffer();
    const workbook = XLSX.read(data, { type: "array" });
    const sheetNames = workbook.SheetNames;
    this.lookups.clear();

    for (const sheetName of sheetNames) {
      const sheet = workbook.Sheets[sheetName];
      const rows: unknown[][] = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        defval: "",
      });
      if (rows.length < 2) continue;

      // Find header row — scan first 20 rows
      let headerRow = -1;
      let nameIdx = -1;
      let xmlIdIdx = -1;
      let idIdx = -1;
      let codeIdx = -1;

      for (let r = 0; r < Math.min(20, rows.length); r++) {
        const row = rows[r] as string[];
        if (!row || row.length < 2) continue;

        const cols = row.map((h) => String(h).trim().toLowerCase());

        // Look for name column
        const ni = cols.findIndex(
          (h) =>
            h === "наименование" ||
            h === "наименование раздела" ||
            h === "значение" ||
            h === "name" ||
            h === "value"
        );

        // Look for ID column
        const xi = cols.findIndex(
          (h) => h === "xml_id" || h === "xml id" || h === "xmlid"
        );
        const ii = cols.findIndex(
          (h) => h === "id" || h === "идентификатор"
        );
        const ci = cols.findIndex((h) => h === "code" || h === "код");

        if (ni >= 0 && (xi >= 0 || ii >= 0 || ci >= 0)) {
          headerRow = r;
          nameIdx = ni;
          xmlIdIdx = xi;
          idIdx = ii;
          codeIdx = ci;
          break;
        }
      }

      if (headerRow < 0 || nameIdx < 0) continue; // Not a lookup sheet

      const entries: LookupEntry[] = [];
      let maxId = 0;

      for (let r = headerRow + 1; r < rows.length; r++) {
        const row = rows[r] as string[];
        const name = String(row[nameIdx] || "").trim();
        if (!name) continue;

        const entry: LookupEntry = {
          name,
          xmlId: xmlIdIdx >= 0 ? String(row[xmlIdIdx] || "").trim() : "",
        };

        if (idIdx >= 0) {
          const idVal = parseInt(String(row[idIdx] || ""));
          if (!isNaN(idVal)) {
            entry.id = idVal;
            if (idVal > maxId) maxId = idVal;
          }
        }

        if (codeIdx >= 0) {
          entry.code = String(row[codeIdx] || "").trim();
        }

        entries.push(entry);
      }

      if (entries.length > 0) {
        this.lookups.set(sheetName, { sheetName, entries, maxId });
        console.log(`[BitrixLookup] Loaded "${sheetName}": ${entries.length} entries`);
      }
    }

    return Array.from(this.lookups.keys());
  }

  findId(sheetName: string, searchName: string): { value: string; isNew: boolean } | null {
    const lookup = this.lookups.get(sheetName);
    if (!lookup) return null;

    const search = searchName.toLowerCase().trim();
    const idField = ID_FIELD_MAP[sheetName] || "xmlId";

    // Exact match
    let entry = lookup.entries.find(
      (e) => e.name.toLowerCase().trim() === search
    );

    // Partial match
    if (!entry) {
      entry = lookup.entries.find((e) =>
        e.name.toLowerCase().includes(search)
      );
    }

    if (entry) {
      const value =
        idField === "id"
          ? String(entry.id || "")
          : idField === "code"
          ? entry.code || ""
          : entry.xmlId || "";
      return { value, isNew: false };
    }

    return null;
  }

  generateNewId(sheetName: string, _searchName: string): string {
    const lookup = this.lookups.get(sheetName);
    if (!lookup) return "";

    const idField = ID_FIELD_MAP[sheetName] || "xmlId";
    if (idField === "id") {
      lookup.maxId += 1;
      return String(lookup.maxId);
    }

    return this.transliterate(_searchName);
  }

  getOrCreateId(
    sheetName: string,
    searchName: string
  ): { value: string; isNew: boolean } {
    if (!searchName || !searchName.trim()) return { value: "", isNew: false };

    const found = this.findId(sheetName, searchName);
    if (found) return found;

    const newId = this.generateNewId(sheetName, searchName);
    const lookup = this.lookups.get(sheetName);
    if (lookup && newId) {
      lookup.entries.push({
        name: searchName,
        xmlId: newId,
        id: lookup.maxId,
      });
    }
    return { value: newId, isNew: true };
  }

  isIdColumn(templateColLabel: string): boolean {
    return !!NAME_COL_MAP[templateColLabel];
  }

  getLookupSheetForIdCol(templateColLabel: string): string | null {
    return ID_TO_SHEET[templateColLabel] || null;
  }

  getSourceColForIdCol(templateColLabel: string): string | null {
    return NAME_COL_MAP[templateColLabel] || null;
  }

  getLoadedSheets(): string[] {
    return Array.from(this.lookups.keys());
  }

  private transliterate(str: string): string {
    const map: Record<string, string> = {
      а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "yo", ж: "zh",
      з: "z", и: "i", й: "j", к: "k", л: "l", м: "m", н: "n", о: "o",
      п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "kh", ц: "ts",
      ч: "ch", ш: "sh", щ: "shch", ы: "y", э: "e", ю: "yu", я: "ya",
      " ": "_", "-": "_", "/": "_", ",": "_",
    };
    return str
      .toLowerCase()
      .split("")
      .map((c) => map[c] || c)
      .join("")
      .replace(/[^a-z0-9_]/g, "")
      .substring(0, 50);
  }
}
