import { supabase, isSupabaseConfigured } from "@/lib/supabase";

const AUTH_USER_KEY = "b2b_auth_user";
const AUTH_TOKEN_KEY = "sb_session";

const VALID_CREDS = [
  { login: "B2B", password: "123" },
  { login: "B2B", password: "B2B123!" },
  { login: "admin", password: "admin" },
];

function checkLocalCreds(login: string, password: string): boolean {
  const ll = login.trim().toLowerCase();
  return VALID_CREDS.some((c) => c.login.toLowerCase() === ll && c.password === password);
}

function createLocalSession(login: string) {
  const user = { id: "local-" + login.toLowerCase(), login: login, role: "admin" };
  const token = "local-" + Date.now() + "-" + Math.random().toString(36).slice(2);
  localStorage.setItem(AUTH_TOKEN_KEY, token);
  localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
  return { token, user };
}

export async function loginUser(login: string, password: string) {
  // 1. Try hardcoded credentials (works always)
  if (checkLocalCreds(login, password)) return createLocalSession(login);
  // 2. If Supabase is configured, try real login
  if (isSupabaseConfigured) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email: login, password });
      if (error) throw error;
      const user = { id: data.user!.id, login: data.user!.email || login, role: "admin" };
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
      return { token: data.session!.access_token, user };
    } catch (e) { console.warn("[Auth] Supabase login failed, using fallback:", e); }
  }
  throw new Error("INVALID_CREDENTIALS");
}

export async function logoutUser() {
  localStorage.removeItem(AUTH_TOKEN_KEY);
  localStorage.removeItem(AUTH_USER_KEY);
  if (isSupabaseConfigured) { try { await supabase.auth.signOut(); } catch {} }
}

export async function getCurrentUser() {
  const savedUser = localStorage.getItem(AUTH_USER_KEY);
  if (savedUser) { try { return JSON.parse(savedUser); } catch { localStorage.removeItem(AUTH_USER_KEY); localStorage.removeItem(AUTH_TOKEN_KEY); } }
  if (isSupabaseConfigured) {
    try { const { data } = await supabase.auth.getUser(); if (data.user) return { id: data.user.id, login: data.user.email, role: "admin" }; } catch {}
  }
  return null;
}
