import * as XLSX from "xlsx";

export interface PriceRecord {
  id: string;
  date: string;
  ksss_code: string;
  product: string;
  product_name: string;
  category: string;
  supplier: string;
  price: number;
  quantity: number;
  unit: string;
  region: string;
  year: number;
  month: number;
  quarter: number;
  extra_fields?: Record<string, string>; // all other columns from Excel
}

export interface PriceSummary {
  totalRecords: number;
  avgPrice: number;
  minPrice: number;
  maxPrice: number;
  totalQuantity: number;
  suppliers: number;
  products: number;
  dateRange: { from: string; to: string };
}

export interface PriceTrend {
  period: string;
  avgPrice: number;
  minPrice: number;
  maxPrice: number;
  totalQty: number;
  records: number;
}

export interface YearComparison {
  year: number;
  avgPrice: number;
  totalQty: number;
  records: number;
  changePct?: number;
}

export interface SupplierComparison {
  supplier: string;
  avgPrice: number;
  totalQty: number;
  records: number;
  minPrice: number;
  maxPrice: number;
}

export interface ProductComparison {
  product: string;
  productName: string;
  ksssCode: string;
  category: string;
  avgPrice: number;
  totalQty: number;
  records: number;
  latestPrice: number;
  priceChangePct?: number;
}

const SK_PRICES = "b2b_prices";
const SK_HISTORY = "b2b_price_uploads";

function safeNum(v: any): number {
  if (v === null || v === undefined || v === "") return 0;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/\s/g, "").replace(",", "."));
  return isNaN(n) ? 0 : n;
}

function safeStr(v: any): string {
  if (v === null || v === undefined) return "";
  return String(v).trim();
}

function isEmptyCell(v: any): boolean {
  if (v === null || v === undefined || v === "") return true;
  const s = String(v).trim().toLowerCase();
  return s === "nan" || s === "nat" || s === "null" || s === "undefined" || s === "-" || s === "—";
}

function parseDate(v: any): string | null {
  if (!v) return null;
  if (typeof v === "number") {
    const d = XLSX.SSF.parse_date_code(v);
    if (d) return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const s = String(v).trim();
  const patterns = [
    /^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/.exec(s),
    /^(\d{4})[./-](\d{1,2})[./-](\d{1,2})$/.exec(s),
  ];
  for (const m of patterns) {
    if (m) {
      const [, a, b, c] = m;
      if (a.length === 4) return `${a}-${String(b).padStart(2, "0")}-${String(c).padStart(2, "0")}`;
      return `${c}-${String(b).padStart(2, "0")}-${String(a).padStart(2, "0")}`;
    }
  }
  const d = new Date(s);
  if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  return null;
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

// ========== PARSE EXCEL ==========
export function parsePriceExcel(buffer: ArrayBuffer): { records: PriceRecord[]; errors: string[] } {
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: "" }) as any[][];

  if (raw.length < 2) return { records: [], errors: ["Файл пустой или не содержит данных"] };

  const headers = raw[0].map((h) => String(h).trim().toLowerCase());
  const records: PriceRecord[] = [];
  const errors: string[] = [];

  // Auto-detect columns with conflict prevention
  const colMap: Record<string, number> = {};
  const usedCols = new Set<number>();

  // Priority order: exact match first, then partial
  const fieldDefs: { field: string; aliases: string[]; exact?: string[] }[] = [
    { field: "date", aliases: ["дата", "date", "период", "period"], exact: ["дата", "date", "дата заказа", "order_date"] },
    { field: "ksss_code", aliases: ["кссс", "код_товара", "артикул", "sku", "ksss"], exact: ["кссс", "ksss", "код_товара", "код товара"] },
    { field: "product_name", aliases: ["название_товара", "наименование", "product_name"], exact: ["название товара", "наименование товара", "product_name", "название_товара"] },
    { field: "product", aliases: ["товар", "продукт", "product"], exact: ["товар", "продукт", "product"] },
    { field: "category", aliases: ["категория", "category", "группа"], exact: ["категория", "category", "категория товара"] },
    { field: "supplier", aliases: ["поставщик", "supplier", "партнер", "контрагент", "клиент"], exact: ["поставщик", "supplier", "контрагент", "клиент"] },
    { field: "region", aliases: ["регион", "region", "территория", "область"], exact: ["регион", "region", "территория"] },
    { field: "price", aliases: ["цена", "price", "стоимость", "сумма"], exact: ["цена", "price", "цена за ед"] },
    { field: "quantity", aliases: ["количество", "quantity", "объем", "кол-во"], exact: ["количество", "quantity", "кол-во"] },
    { field: "unit", aliases: ["единица", "unit", "ед.изм"], exact: ["ед.изм", "unit", "единица измерения"] },
  ];

  // Phase 1: exact matches
  for (const { field, exact } of fieldDefs) {
    if (!exact) continue;
    for (let i = 0; i < headers.length; i++) {
      if (usedCols.has(i)) continue;
      const h = headers[i].replace(/\s+/g, "_").replace(/[\s]+/g, " ").trim();
      if (exact.some((e) => h === e || headers[i] === e)) {
        colMap[field] = i; usedCols.add(i); break;
      }
    }
  }

  // Phase 2: partial matches (includes)
  for (const { field, aliases } of fieldDefs) {
    if (colMap[field] !== undefined) continue;
    for (let i = 0; i < headers.length; i++) {
      if (usedCols.has(i)) continue;
      if (aliases.some((a) => headers[i].includes(a))) {
        colMap[field] = i; usedCols.add(i); break;
      }
    }
  }

  // Phase 3: guess remaining from header names
  // If product still not found but product_name found, use it
  if (colMap.product === undefined && colMap.product_name !== undefined) {
    colMap.product = colMap.product_name;
  }
  // If product_name not found but product found, use it
  if (colMap.product_name === undefined && colMap.product !== undefined) {
    colMap.product_name = colMap.product;
  }

  // Required fields
  if (colMap.date === undefined) errors.push("Не найдена колонка 'Дата'");
  if (colMap.product === undefined) errors.push("Не найдена колонка 'Товар' (ищите: товар, продукт, наименование)");
  if (colMap.price === undefined) errors.push("Не найдена колонка 'Цена'");

  if (errors.length > 0 && (!colMap.date || !colMap.product || !colMap.price)) {
    return { records: [], errors };
  }

  for (let i = 1; i < raw.length; i++) {
    const row = raw[i];
    if (!row || row.every(isEmptyCell)) continue;

    const dateStr = parseDate(row[colMap.date ?? 0]);
    const product = safeStr(row[colMap.product ?? 1]);
    const price = safeNum(row[colMap.price ?? 4]);

    if (!dateStr || !product || price <= 0) continue;

    const d = new Date(dateStr);
    // Use product_name column if available, otherwise use product
    const productName = colMap.product_name !== undefined
      ? safeStr(row[colMap.product_name]) || product
      : product;
    const ksssCode = colMap.ksss_code !== undefined
      ? safeStr(row[colMap.ksss_code]) || ""
      : "";
    // Collect extra fields (unknown columns)
    const extraFields: Record<string, string> = {};
    for (let ci = 0; ci < headers.length; ci++) {
      if (usedCols.has(ci)) continue; // skip mapped columns
      const h = raw[0][ci]; // original header name
      const v = safeStr(row[ci]);
      if (h && v) extraFields[String(h)] = v;
    }

    const record: PriceRecord = {
      id: generateId(),
      date: dateStr,
      ksss_code: ksssCode,
      product,
      product_name: productName,
      category: safeStr(row[colMap.category ?? 2]) || "Без категории",
      supplier: safeStr(row[colMap.supplier ?? 3]) || "Не указан",
      price,
      quantity: safeNum(row[colMap.quantity ?? 5]) || 1,
      unit: safeStr(row[colMap.unit ?? 6]) || "шт",
      region: safeStr(row[colMap.region ?? 7]) || "Все регионы",
      year: d.getFullYear(),
      month: d.getMonth() + 1,
      quarter: Math.floor(d.getMonth() / 3) + 1,
      extra_fields: Object.keys(extraFields).length > 0 ? extraFields : undefined,
    };
    records.push(record);
  }

  if (records.length === 0) errors.push("Не удалось распознать данные. Проверьте формат файла.");
  return { records, errors };
}

// ========== STORAGE ==========
export function savePrices(records: PriceRecord[]): boolean {
  // Strip extra_fields before saving to avoid exceeding localStorage 5MB limit
  const slim = records.map((r) => {
    const { extra_fields, ...rest } = r;
    return rest;
  });
  try {
    const json = JSON.stringify(slim);
    if (json.length > 4 * 1024 * 1024) { // 4MB safety limit
      console.warn("[Prices] Data too large for localStorage:", json.length, "bytes");
      // Try saving first 500 records only
      const limited = slim.slice(0, 500);
      localStorage.setItem(SK_PRICES, JSON.stringify(limited));
      console.warn("[Prices] Saved only first 500 records");
      return true;
    }
    localStorage.setItem(SK_PRICES, json);
    return true;
  } catch (e: any) {
    console.error("[Prices] Failed to save:", e.message);
    return false;
  }
}

export function loadPrices(): PriceRecord[] {
  try {
    const raw = localStorage.getItem(SK_PRICES);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    console.log("[Prices] Loaded", parsed.length, "records from localStorage");
    return parsed;
  } catch (e: any) {
    console.error("[Prices] Failed to load:", e.message);
    return [];
  }
}

export function clearPrices(): void {
  localStorage.removeItem(SK_PRICES);
  localStorage.removeItem(SK_HISTORY);
}

// ========== UPLOAD HISTORY ==========
export interface PriceUploadHistory {
  id: string;
  fileName: string;
  recordCount: number;
  uploadedAt: string;
}

export function addUploadHistory(fileName: string, recordCount: number): string {
  try {
    const history = getUploadHistory();
    const id = generateId();
    history.unshift({ id, fileName, recordCount, uploadedAt: new Date().toISOString() });
    localStorage.setItem(SK_HISTORY, JSON.stringify(history.slice(0, 20)));
    return id;
  } catch { return ""; }
}

export function getUploadHistory(): PriceUploadHistory[] {
  try { const raw = localStorage.getItem(SK_HISTORY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}

// ========== SAVED FILE DATA ==========
const SK_FILE_DATA = "b2b_price_file_data";

export interface SavedPriceFile {
  id: string;
  fileName: string;
  records: PriceRecord[];
  uploadedAt: string;
}

function loadPriceFileMap(): Record<string, SavedPriceFile> {
  try { const raw = localStorage.getItem(SK_FILE_DATA); return raw ? JSON.parse(raw) : {}; } catch { return {}; }
}
function savePriceFileMap(map: Record<string, SavedPriceFile>): void {
  try { localStorage.setItem(SK_FILE_DATA, JSON.stringify(map)); } catch {}
}

export function savePriceFileData(id: string, fileName: string, records: PriceRecord[]): void {
  const map = loadPriceFileMap();
  // Limit to 500 records to stay under localStorage 5MB limit
  const limitedRecords = records.slice(0, 500);
  map[id] = { id, fileName, records: limitedRecords, uploadedAt: new Date().toISOString() };
  const keys = Object.keys(map);
  if (keys.length > 10) {
    const sorted = keys.sort((a, b) => (map[a].uploadedAt > map[b].uploadedAt ? 1 : -1));
    for (let i = 0; i < sorted.length - 10; i++) delete map[sorted[i]];
  }
  savePriceFileMap(map);
}
export function loadPriceFileData(id: string): SavedPriceFile | null {
  return loadPriceFileMap()[id] || null;
}
export function deletePriceFileData(id: string): void {
  const map = loadPriceFileMap();
  delete map[id];
  savePriceFileMap(map);
}

// ========== ANALYTICS ==========
export function getSummary(records: PriceRecord[]): PriceSummary {
  if (records.length === 0) {
    return { totalRecords: 0, avgPrice: 0, minPrice: 0, maxPrice: 0, totalQuantity: 0, suppliers: 0, products: 0, dateRange: { from: "", to: "" } };
  }
  const prices = records.map((r) => r.price);
  const dates = records.map((r) => r.date).sort();
  return {
    totalRecords: records.length,
    avgPrice: Math.round((prices.reduce((a, b) => a + b, 0) / prices.length) * 100) / 100,
    minPrice: Math.min(...prices),
    maxPrice: Math.max(...prices),
    totalQuantity: records.reduce((s, r) => s + r.quantity, 0),
    suppliers: new Set(records.map((r) => r.supplier)).size,
    products: new Set(records.map((r) => r.product)).size,
    dateRange: { from: dates[0], to: dates[dates.length - 1] },
  };
}

export function getMonthlyTrend(records: PriceRecord[]): PriceTrend[] {
  const grouped: Record<string, PriceRecord[]> = {};
  for (const r of records) {
    const key = `${r.year}-${String(r.month).padStart(2, "0")}`;
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(r);
  }
  return Object.entries(grouped)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([period, items]) => {
      const prices = items.map((i) => i.price);
      return {
        period,
        avgPrice: Math.round((prices.reduce((a, b) => a + b, 0) / prices.length) * 100) / 100,
        minPrice: Math.min(...prices),
        maxPrice: Math.max(...prices),
        totalQty: items.reduce((s, i) => s + i.quantity, 0),
        records: items.length,
      };
    });
}

export function getQuarterlyTrend(records: PriceRecord[]): PriceTrend[] {
  const grouped: Record<string, PriceRecord[]> = {};
  for (const r of records) {
    const key = `${r.year} Q${r.quarter}`;
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(r);
  }
  return Object.entries(grouped)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([period, items]) => {
      const prices = items.map((i) => i.price);
      return {
        period,
        avgPrice: Math.round((prices.reduce((a, b) => a + b, 0) / prices.length) * 100) / 100,
        minPrice: Math.min(...prices),
        maxPrice: Math.max(...prices),
        totalQty: items.reduce((s, i) => s + i.quantity, 0),
        records: items.length,
      };
    });
}

export function getYearlyComparison(records: PriceRecord[]): YearComparison[] {
  const grouped: Record<number, PriceRecord[]> = {};
  for (const r of records) {
    if (!grouped[r.year]) grouped[r.year] = [];
    grouped[r.year].push(r);
  }
  const years = Object.entries(grouped)
    .sort(([a], [b]) => Number(a) - Number(b))
    .map(([year, items]) => {
      const prices = items.map((i) => i.price);
      return {
        year: Number(year),
        avgPrice: Math.round((prices.reduce((a, b) => a + b, 0) / prices.length) * 100) / 100,
        totalQty: items.reduce((s, i) => s + i.quantity, 0),
        records: items.length,
      };
    });
  // Calculate YoY change
  for (let i = 1; i < years.length; i++) {
    const prev = years[i - 1].avgPrice;
    if (prev > 0) years[i].changePct = Math.round(((years[i].avgPrice - prev) / prev) * 1000) / 10;
  }
  return years;
}

export function getSupplierComparison(records: PriceRecord[]): SupplierComparison[] {
  const grouped: Record<string, PriceRecord[]> = {};
  for (const r of records) {
    if (!grouped[r.supplier]) grouped[r.supplier] = [];
    grouped[r.supplier].push(r);
  }
  return Object.entries(grouped)
    .map(([supplier, items]) => {
      const prices = items.map((i) => i.price);
      return {
        supplier,
        avgPrice: Math.round((prices.reduce((a, b) => a + b, 0) / prices.length) * 100) / 100,
        totalQty: items.reduce((s, i) => s + i.quantity, 0),
        records: items.length,
        minPrice: Math.min(...prices),
        maxPrice: Math.max(...prices),
      };
    })
    .sort((a, b) => b.records - a.records);
}

export function getProductComparison(records: PriceRecord[]): ProductComparison[] {
  const grouped: Record<string, PriceRecord[]> = {};
  for (const r of records) {
    if (!grouped[r.product]) grouped[r.product] = [];
    grouped[r.product].push(r);
  }
  return Object.entries(grouped)
    .map(([product, items]) => {
      const prices = items.map((i) => i.price);
      const sorted = [...items].sort((a, b) => a.date.localeCompare(b.date));
      const latest = sorted[sorted.length - 1];
      const first = sorted[0];
      let changePct: number | undefined;
      if (sorted.length > 1 && first.price > 0) {
        changePct = Math.round(((latest.price - first.price) / first.price) * 1000) / 10;
      }
      return {
        product,
        productName: items[0].product_name || product,
        ksssCode: items[0].ksss_code || "",
        category: items[0].category,
        avgPrice: Math.round((prices.reduce((a, b) => a + b, 0) / prices.length) * 100) / 100,
        totalQty: items.reduce((s, i) => s + i.quantity, 0),
        records: items.length,
        latestPrice: latest.price,
        priceChangePct: changePct,
      };
    })
    .sort((a, b) => b.records - a.records);
}

export function formatPrice(n: number): string {
  return n.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatNumber(n: number): string {
  return n.toLocaleString("ru-RU");
}
