import type { Client, DadataResponse, ClientHistoryEntry } from "@/types/clients";

const STORAGE_KEY = "b2b_clients_db";
const DADATA_API_URL = "https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party";

// ==== localStorage persistence ====

export function loadClients(): Client[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveClients(clients: Client[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(clients));
}

// ==== CRUD ====

export function addClient(client: Client): Client[] {
  const clients = loadClients();
  if (clients.find((c) => c.inn === client.inn)) {
    // Update existing
    const updated = clients.map((c) =>
      c.inn === client.inn ? { ...client, updatedAt: new Date().toISOString() } : c
    );
    saveClients(updated);
    return updated;
  }
  clients.push(client);
  saveClients(clients);
  return clients;
}

export function updateClient(inn: string, updates: Partial<Client>): Client[] {
  const clients = loadClients();
  const updated = clients.map((c) => {
    if (c.inn === inn) {
      const newC = { ...c, ...updates, updatedAt: new Date().toISOString() };
      if (updates.note || updates.phone || updates.email || updates.tags) {
        newC.history = [
          ...c.history,
          {
            id: Date.now().toString() + Math.random().toString(36).slice(2),
            type: "edit",
            description: `Обновлены данные: ${Object.keys(updates).join(", ")}`,
            date: new Date().toISOString(),
          },
        ];
      }
      return newC;
    }
    return c;
  });
  saveClients(updated);
  return updated;
}

export function deleteClient(inn: string): Client[] {
  const clients = loadClients().filter((c) => c.inn !== inn);
  saveClients(clients);
  return clients;
}

export function addHistoryEntry(inn: string, entry: ClientHistoryEntry): Client[] {
  const clients = loadClients();
  const updated = clients.map((c) => {
    if (c.inn === inn) {
      return { ...c, history: [...c.history, entry], updatedAt: new Date().toISOString() };
    }
    return c;
  });
  saveClients(updated);
  return updated;
}

// ==== Dadata API ====

export async function fetchDadataByInn(
  inn: string,
  apiKey: string
): Promise<DadataResponse | null> {
  if (!apiKey) return null;
  const cleanInn = inn.replace(/\D/g, "");
  if (cleanInn.length < 10) return null;

  try {
    const res = await fetch(DADATA_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Token ${apiKey}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ query: cleanInn }),
    });
    if (!res.ok) {
      console.error("[Dadata] HTTP error:", res.status);
      return null;
    }
    return (await res.json()) as DadataResponse;
  } catch (err) {
    console.error("[Dadata] Fetch error:", err);
    return null;
  }
}

// ==== Convert Dadata suggestion to Client ====

export function suggestionToClient(s: DadataResponse["suggestions"][0]): Client {
  const d = s.data;
  return {
    id: Date.now().toString() + Math.random().toString(36).slice(2),
    inn: d.inn || "",
    kpp: d.kpp || "",
    ogrn: d.ogrn || "",
    name: d.name?.short_with_opf || s.value || "",
    fullName: d.name?.full_with_opf || s.value || "",
    type: (d.type === "LEGAL" || d.type === "INDIVIDUAL" ? d.type : "") as Client["type"],
    status: (d.state?.status || "") as Client["status"],
    address: d.address?.value || "",
    management: d.management?.name || "",
    managementPost: d.management?.post || "",
    okved: d.okved || "",
    phone: "",
    email: "",
    note: "",
    tags: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    history: [
      {
        id: Date.now().toString(),
        type: "create" as const,
        description: `Клиент добавлен через Dadata (ИНН: ${d.inn})`,
        date: new Date().toISOString(),
      },
    ],
  };
}

// ==== Search clients ====

export function searchClients(query: string): Client[] {
  const clients = loadClients();
  if (!query.trim()) return clients;
  const q = query.toLowerCase();
  return clients.filter(
    (c) =>
      c.inn.includes(q) ||
      c.name.toLowerCase().includes(q) ||
      c.fullName.toLowerCase().includes(q) ||
      c.kpp?.includes(q) ||
      c.ogrn?.includes(q) ||
      c.address?.toLowerCase().includes(q) ||
      c.tags?.some((t) => t.toLowerCase().includes(q))
  );
}

// ==== Import clients from CSV/Excel ====

export async function parseClientsFromExcel(file: File): Promise<Array<{ inn: string; name?: string; phone?: string; email?: string; note?: string }>> {
  return new Promise((resolve, reject) => {
    import("xlsx").then(XLSX => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
          if (rows.length < 2) { resolve([]); return; }

          const headers = (rows[0] as string[]).map(h => String(h).toLowerCase().trim());
          const colMap: Record<string, number> = {};

          headers.forEach((h, i) => {
            if (h === "инн" || h === "inn") colMap.inn = i;
            if (h === "название" || h === "наименование" || h === "name") colMap.name = i;
            if (h === "телефон" || h === "phone") colMap.phone = i;
            if (h === "email" || h === "почта") colMap.email = i;
            if (h === "примечание" || h === "note" || h === "комментарий") colMap.note = i;
          });

          const results: Array<{ inn: string; name?: string; phone?: string; email?: string; note?: string }> = [];
          for (let i = 1; i < rows.length; i++) {
            const row = rows[i] as string[];
            const hasValue = row.some(v => v !== undefined && v !== null && String(v).trim() !== "");
            if (!hasValue) continue;
            const inn = colMap.inn !== undefined ? String(row[colMap.inn] || "").trim() : "";
            if (!inn) continue;
            results.push({
              inn,
              name: colMap.name !== undefined ? String(row[colMap.name] || "").trim() : undefined,
              phone: colMap.phone !== undefined ? String(row[colMap.phone] || "").trim() : undefined,
              email: colMap.email !== undefined ? String(row[colMap.email] || "").trim() : undefined,
              note: colMap.note !== undefined ? String(row[colMap.note] || "").trim() : undefined,
            });
          }
          resolve(results);
        } catch (err) { reject(err); }
      };
      reader.readAsArrayBuffer(file);
    });
  });
}
