import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = (window as any).SUPABASE_URL || "";
const SUPABASE_KEY = (window as any).SUPABASE_KEY || "";

const isConfigured = SUPABASE_URL.length > 10 && SUPABASE_KEY.length > 10;

const emptyPromise = (data: any = null) => Promise.resolve({ data, error: null });
const errorPromise = () => Promise.resolve({ data: null, error: new Error("offline") });

function createMockClient(): any {
  console.warn("[Supabase] Using mock client — insert real URL/KEY in index.html");

  const makeQuery = () => ({
    eq: () => makeQuery(),
    or: () => makeQuery(),
    not: () => makeQuery(),
    is: () => makeQuery(),
    order: () => makeQuery(),
    range: () => makeQuery(),
    limit: () => makeQuery(),
    single: () => emptyPromise(),
    then: (cb: any) => cb({ data: [], error: null }),
  });

  const makeFrom = () => ({
    select: () => makeQuery(),
    insert: () => ({ select: () => ({ single: () => emptyPromise() }) }),
    update: () => ({ eq: () => emptyPromise() }),
    delete: () => ({ eq: () => emptyPromise() }),
  });

  return {
    from: makeFrom,
    auth: {
      signInWithPassword: () => errorPromise(),
      signOut: () => emptyPromise(),
      getSession: () => emptyPromise({ session: null }),
      getUser: () => emptyPromise({ user: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
    },
  };
}

export const supabase = isConfigured
  ? createClient(SUPABASE_URL, SUPABASE_KEY)
  : createMockClient();

export const isSupabaseConfigured = isConfigured;
export { SUPABASE_URL, SUPABASE_KEY };
