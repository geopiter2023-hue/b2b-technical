#!/bin/bash
# Diagnostic script for B2B Task Manager

echo "=== B2B Task Manager Diagnostics ==="
echo ""

# Check Node.js
echo "[1] Node.js version:"
node --version 2>/dev/null || echo "ERROR: Node.js not found!"

# Check if process is running
echo ""
echo "[2] Process status:"
ps aux | grep -E "boot\.js|b2b-task" | grep -v grep || echo "WARNING: No running process found"

# Check port
echo ""
echo "[3] Port 3000:"
netstat -tlnp 2>/dev/null | grep :3000 || ss -tlnp 2>/dev/null | grep :3000 || echo "WARNING: Port 3000 not listening"

# Test local API
echo ""
echo "[4] API health check:"
curl -s http://localhost:3000/health 2>/dev/null || echo "ERROR: Cannot connect to localhost:3000"

# Test API login
echo ""
echo "[5] API login test:"
curl -s -X POST \
  -H "Content-Type: application/json" \
  -d '{"json":{"login":"B2B","password":"B2B"}}' \
  http://localhost:3000/api/trpc/auth.login 2>/dev/null | head -c 100 || echo "ERROR: Login failed"

# Check MySQL
echo ""
echo "[6] MySQL connection:"
source .env 2>/dev/null
if command -v mysql &> /dev/null; then
  DB_HOST=$(echo $DATABASE_URL | sed -n 's/.*@\([^:]*\).*/\1/p')
  DB_PORT=$(echo $DATABASE_URL | sed -n 's/.*:\([0-9]*\)\/.*/\1/p')
  mysql -h "$DB_HOST" -P "${DB_PORT:-3306}" -e "SELECT 1" 2>/dev/null && echo "OK" || echo "ERROR: Cannot connect to MySQL"
else
  echo "MySQL client not installed"
fi

# Check nginx
echo ""
echo "[7] Nginx:"
nginx -t 2>&1 | head -3

echo ""
echo "=== Diagnostics complete ==="
