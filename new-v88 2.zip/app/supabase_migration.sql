-- ============================================
-- B2B Task Manager — Supabase Migration Patch
-- Version: new-v87+
-- ============================================

-- 1. Add missing columns to existing tasks table
ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS user_id UUID,
  ADD COLUMN IF NOT EXISTS title TEXT,
  ADD COLUMN IF NOT EXISTS description TEXT,
  ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'todo',
  ADD COLUMN IF NOT EXISTS priority TEXT DEFAULT 'medium',
  ADD COLUMN IF NOT EXISTS category TEXT,
  ADD COLUMN IF NOT EXISTS assigned_to TEXT,
  ADD COLUMN IF NOT EXISTS due_date TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 2. Migrate data: copy name -> title if title is null
UPDATE tasks SET title = name WHERE title IS NULL AND name IS NOT NULL;
UPDATE tasks SET status = 'not_started' WHERE status IS NULL;
UPDATE tasks SET priority = 'medium' WHERE priority IS NULL;

-- 3. Enable Row Level Security
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- 4. Drop old policies if exist
DROP POLICY IF EXISTS "Users can CRUD own tasks" ON tasks;
DROP POLICY IF EXISTS "Allow anon access" ON tasks;
DROP POLICY IF EXISTS "Enable all for anon" ON tasks;

-- 5. Create policy: users can only access their own tasks
CREATE POLICY "Users can CRUD own tasks"
  ON tasks FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 6. Create policy for anon access (for development / public apps)
CREATE POLICY "Allow anon access"
  ON tasks FOR ALL TO anon
  USING (true)
  WITH CHECK (true);

-- 7. Create index for performance
CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);

-- 8. Set up realtime for tasks table
BEGIN;
  -- Check if tasks is already in realtime publication
  DO $$
  BEGIN
    IF NOT EXISTS (
      SELECT 1 FROM pg_publication_tables
      WHERE pubname = 'supabase_realtime' AND tablename = 'tasks'
    ) THEN
      ALTER PUBLICATION supabase_realtime ADD TABLE tasks;
    END IF;
  END $$;
COMMIT;

-- 9. Create updated_at trigger (auto-update timestamp)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS tr_tasks_updated_at ON tasks;
CREATE TRIGGER tr_tasks_updated_at
  BEFORE UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- After running this SQL:
-- 1. Go to Supabase Dashboard > SQL Editor
-- 2. Paste and run this script
-- 3. Go to Table Editor > tasks > Realtime
-- 4. Enable "Realtime" toggle for tasks table
-- 5. Reload the app — tasks will persist!
-- ============================================
