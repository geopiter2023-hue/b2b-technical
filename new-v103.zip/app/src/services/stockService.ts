// ═══════════════════════════════════════════
// Stock Balance Service
// Merges: Финал (base) + ЛогЛаб (RC stocks) + Дилеры (dealer stocks)
// ═══════════════════════════════════════════

import * as XLSX from "xlsx";

export interface StockItem {
  ksss: string;
  oldKsss: string;
  name: string;
  nameEng: string;
  category: string;
  subcategory: string;
  direction: string;
  brand: string;
  line: string;
  subLine: string;
  type: string;
  viscosity: string;
  api: string;
  acea: string;
  ilsac: string;
  volume: string;
  packaging: string;
  weight: number;
  status: string;
  priceType: string;
  rrc: number;
  // Stock balances
  loglabTotal: number;        // Sum from ЛогЛаб (Физ остатки)
  dealerTotal: number;        // Sum from Дилеры (Количество)
  rcStocks: Record<string, number>; // Per-RC from Финал
  grandTotal: number;         // loglab + dealer
}

export interface StockUpload {
  finalFile?: File;
  loglabFile?: File;
  dealerFile?: File;
  date: string;
}

const STORAGE_KEY = "b2b_stock_data";
const STORAGE_META_KEY = "b2b_stock_meta";

// ═══ Persistence ═══

export function saveStockData(items: StockItem[]) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); } catch {}
}

export function loadStockData(): StockItem[] {
  try { const d = localStorage.getItem(STORAGE_KEY); return d ? JSON.parse(d) : []; } catch { return []; }
}

export function saveStockMeta(meta: { lastFinalUpload?: string; lastLoglabUpload?: string; lastDealerUpload?: string }) {
  try { localStorage.setItem(STORAGE_META_KEY, JSON.stringify(meta)); } catch {}
}

export function loadStockMeta() {
  try { const d = localStorage.getItem(STORAGE_META_KEY); return d ? JSON.parse(d) : {}; } catch { return {}; }
}

// ═══ Parse Final (base catalog) ═══

export async function parseFinalFile(file: File): Promise<StockItem[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        // Skip first 2 rows (headers)
        const items: StockItem[] = [];
        for (let i = 2; i < rows.length; i++) {
          const r = rows[i];
          if (!r[0]) continue;

          const ksss = String(r[0] || "").trim();
          if (!ksss || ksss === "КССС") continue;

          // Parse RC stocks from columns 5-10 (indices 5-10)
          const rcStocks: Record<string, number> = {};
          const rcNames = [
            "РЦ Иркутск", "РЦ Калининград", "РЦ Краснодар",
            "РЦ Санкт-Петербург", "РЦ Солнечногорск", "РЦ Тюмень"
          ];
          for (let j = 0; j < 6; j++) {
            const val = parseFloat(r[5 + j]);
            if (val > 0) rcStocks[rcNames[j]] = val;
          }

          items.push({
            ksss,
            oldKsss: String(r[2] || "").trim(),
            name: String(r[16] || "").trim(),
            nameEng: String(r[15] || "").trim(),
            category: String(r[3] || "").trim(),
            subcategory: String(r[13] || "").trim(),
            direction: String(r[12] || "").trim(),
            brand: String(r[35] || "").trim(),
            line: String(r[36] || "").trim(),
            subLine: String(r[37] || "").trim(),
            type: String(r[38] || "").trim(),
            viscosity: String(r[39] || "").trim(),
            api: String(r[40] || "").trim(),
            acea: String(r[41] || "").trim(),
            ilsac: String(r[42] || "").trim(),
            volume: String(r[29] || "").trim(),
            packaging: String(r[30] || "").trim(),
            weight: parseFloat(r[11]) || 0,
            status: String(r[1] || "").trim(),
            priceType: String(r[23] || "").trim(),
            rrc: parseFloat(r[25]) || 0,
            loglabTotal: 0,
            dealerTotal: 0,
            rcStocks,
            grandTotal: 0,
          });
        }
        resolve(items);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Parse ЛогЛаб ═══

export async function parseLoglabFile(file: File): Promise<Map<string, number>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        // Map: KSSS -> sum of Физ остатки
        const map = new Map<string, number>();
        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const ksss = String(r[2] || "").trim(); // КССС column
          const qty = parseFloat(r[8]); // Физ остатки column
          if (ksss && !isNaN(qty)) {
            map.set(ksss, (map.get(ksss) || 0) + qty);
          }
        }
        resolve(map);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Parse Дилеры ═══

export async function parseDealerFile(file: File): Promise<Map<string, number>> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });

        // Map: article/name -> sum of Количество
        const map = new Map<string, number>();
        for (let i = 1; i < rows.length; i++) {
          const r = rows[i];
          const article = String(r[3] || "").trim(); // Артикул товара
          const name = String(r[2] || "").trim(); // Краткое наименование
          const qty = parseFloat(r[5]); // Количество
          if (!isNaN(qty) && qty > 0) {
            // Try match by article first, then by name
            if (article) map.set(article, (map.get(article) || 0) + qty);
            if (name) map.set(name, (map.get(name) || 0) + qty);
          }
        }
        resolve(map);
      } catch (err) { reject(err); }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ═══ Merge all sources ═══

export function mergeStockData(
  baseItems: StockItem[],
  loglabMap: Map<string, number>,
  dealerMap: Map<string, number>
): StockItem[] {
  return baseItems.map((item) => {
    const loglabQty = loglabMap.get(item.ksss) || 0;

    // Try dealer match: by KSSS, then by name, then by ENG name
    let dealerQty = dealerMap.get(item.ksss) || 0;
    if (!dealerQty) dealerQty = dealerMap.get(item.name) || 0;
    if (!dealerQty) dealerQty = dealerMap.get(item.nameEng) || 0;

    // Sum RC stocks
    const rcTotal = Object.values(item.rcStocks).reduce((s, v) => s + v, 0);

    return {
      ...item,
      loglabTotal: Math.round(loglabQty * 1000) / 1000,
      dealerTotal: Math.round(dealerQty * 1000) / 1000,
      grandTotal: Math.round((loglabQty + dealerQty + rcTotal) * 1000) / 1000,
    };
  });
}

// ═══ Search & Filter ═══

export function searchStock(items: StockItem[], query: string): StockItem[] {
  if (!query.trim()) return items;
  const q = query.toLowerCase();
  return items.filter((it) =>
    it.ksss.includes(q) ||
    it.name.toLowerCase().includes(q) ||
    it.nameEng.toLowerCase().includes(q) ||
    it.category.toLowerCase().includes(q) ||
    it.brand.toLowerCase().includes(q) ||
    it.line.toLowerCase().includes(q) ||
    it.viscosity.toLowerCase().includes(q) ||
    it.api.toLowerCase().includes(q)
  );
}

// ═══ Export to Excel ═══

export function exportStockToExcel(items: StockItem[]): Uint8Array {
  const headers = [
    "КССС", "Статус", "Наименование", "Направление", "Категория",
    "Бренд", "Линейка", "Вид", "Вязкость", "API", "ACEA", "ILSAC",
    "Объем", "Вес", "РРЦ",
    "ЛогЛаб остатки", "Остатки дилеров", "Остатки РЦ", "ИТОГО"
  ];

  const rows = items.map((it) => [
    it.ksss, it.status, it.name, it.direction, it.category,
    it.brand, it.line, it.type, it.viscosity, it.api, it.acea, it.ilsac,
    it.volume, it.weight, it.rrc,
    it.loglabTotal, it.dealerTotal,
    Object.entries(it.rcStocks).map(([k, v]) => `${k}: ${v}`).join("; "),
    it.grandTotal
  ]);

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  XLSX.utils.book_append_sheet(wb, ws, "Остатки");
  return XLSX.write(wb, { type: "array" });
}
