import { useState, useRef, useEffect, useMemo } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import type { StockItem } from "@/services/stockService";
import {
  loadStockData,
  saveStockData,
  loadStockMeta,
  saveStockMeta,
  parseFinalFile,
  parseLoglabFile,
  parseDealerFile,
  mergeStockData,
  searchStock,
  exportStockToExcel,
} from "@/services/stockService";
import {
  Package, Upload, Download, Search, X, Warehouse,
  TrendingUp, Filter, ChevronDown, ChevronUp, BarChart3,
} from "lucide-react";

export default function StockPage() {
  const [items, setItems] = useState<StockItem[]>(loadStockData);
  const [searchQuery, setSearchQuery] = useState("");
  const [meta, setMeta] = useState(loadStockMeta);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterBrand, setFilterBrand] = useState("all");
  const [expandedItem, setExpandedItem] = useState<string | null>(null);

  const finalRef = useRef<HTMLInputElement>(null);
  const loglabRef = useRef<HTMLInputElement>(null);
  const dealerRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => {
    let result = searchQuery.trim() ? searchStock(items, searchQuery) : [...items];
    if (filterCategory !== "all") result = result.filter((it) => it.category === filterCategory);
    if (filterBrand !== "all") result = result.filter((it) => it.brand === filterBrand);
    return result;
  }, [items, searchQuery, filterCategory, filterBrand]);

  const categories = useMemo(() => [...new Set(items.map((it) => it.category).filter(Boolean))].sort(), [items]);
  const brands = useMemo(() => [...new Set(items.map((it) => it.brand).filter(Boolean))].sort(), [items]);

  const stats = useMemo(() => {
    const withStock = items.filter((it) => it.grandTotal > 0).length;
    const totalQty = items.reduce((s, it) => s + it.grandTotal, 0);
    const loglabTotal = items.reduce((s, it) => s + it.loglabTotal, 0);
    const dealerTotal = items.reduce((s, it) => s + it.dealerTotal, 0);
    return { total: items.length, withStock, totalQty, loglabTotal, dealerTotal };
  }, [items]);

  const handleUpload = async (type: "final" | "loglab" | "dealer", file: File) => {
    setIsLoading(true);
    setError("");
    try {
      let currentItems = [...items];
      let loglabMap = new Map<string, number>();
      let dealerMap = new Map<string, number>();

      if (type === "final") {
        currentItems = await parseFinalFile(file);
        // Re-merge if we have other files already loaded
        const savedMeta = loadStockMeta();
        if (savedMeta.lastLoglabUpload) {
          // Loglab map would need re-parse — for now just clear
        }
        setMeta((m) => ({ ...m, lastFinalUpload: new Date().toISOString() }));
      } else if (type === "loglab") {
        loglabMap = await parseLoglabFile(file);
        // Need base items — if none loaded, error
        if (currentItems.length === 0) {
          setError("Сначала загрузите «Финал для B2B» — базовый каталог");
          setIsLoading(false);
          return;
        }
        currentItems = mergeStockData(currentItems, loglabMap, new Map());
        setMeta((m) => ({ ...m, lastLoglabUpload: new Date().toISOString() }));
      } else if (type === "dealer") {
        dealerMap = await parseDealerFile(file);
        if (currentItems.length === 0) {
          setError("Сначала загрузите «Финал для B2B» — базовый каталог");
          setIsLoading(false);
          return;
        }
        currentItems = mergeStockData(currentItems, new Map(), dealerMap);
        setMeta((m) => ({ ...m, lastDealerUpload: new Date().toISOString() }));
      }

      setItems(currentItems);
      saveStockData(currentItems);
      saveStockMeta(meta);
    } catch (err) {
      setError("Ошибка загрузки: " + String(err));
    }
    setIsLoading(false);
  };

  const handleExport = () => {
    if (items.length === 0) return;
    const data = exportStockToExcel(items);
    const blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Остатки_свод_${new Date().toISOString().split("T")[0]}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-56px)] bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <Warehouse className="h-6 w-6 text-[#0d9488]" />
                Остатки на складах
              </h1>
              <p className="text-sm text-gray-500 mt-0.5">
                {stats.total} позиций &middot; {stats.withStock} с остатками &middot; Итого: {stats.totalQty.toLocaleString("ru-RU")} т
              </p>
            </div>
            <div className="flex gap-2 flex-wrap">
              {items.length > 0 && (
                <Button variant="outline" size="sm" onClick={handleExport} className="gap-1.5">
                  <Download className="h-4 w-4" /> Экспорт
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="px-6 py-4 space-y-4">
          {/* Stats cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard label="Всего позиций" value={stats.total} icon={<Package className="h-5 w-5 text-blue-500" />} />
            <StatCard label="С остатками" value={stats.withStock} icon={<TrendingUp className="h-5 w-5 text-green-500" />} />
            <StatCard label="ЛогЛаб, т" value={Math.round(stats.loglabTotal * 100) / 100} icon={<Warehouse className="h-5 w-5 text-amber-500" />} />
            <StatCard label="У дилеров, т" value={Math.round(stats.dealerTotal * 100) / 100} icon={<BarChart3 className="h-5 w-5 text-purple-500" />} />
          </div>

          {/* Upload zone */}
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <h2 className="text-sm font-semibold text-gray-700 mb-3">Загрузка файлов</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Final */}
              <div
                onClick={() => finalRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${meta.lastFinalUpload ? "border-green-300 bg-green-50" : "border-gray-300 hover:border-[#0d9488]"}`}
              >
                <Upload className="h-5 w-5 mx-auto mb-1 text-gray-400" />
                <div className="text-sm font-medium text-gray-700">Финал для B2B</div>
                <div className="text-xs text-gray-400">Базовый каталог товаров</div>
                {meta.lastFinalUpload && <div className="text-xs text-green-600 mt-1">Загружен</div>}
                <input ref={finalRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload("final", f); e.target.value = ""; }} />
              </div>
              {/* Loglab */}
              <div
                onClick={() => loglabRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${meta.lastLoglabUpload ? "border-green-300 bg-green-50" : "border-gray-300 hover:border-[#0d9488]"}`}
              >
                <Upload className="h-5 w-5 mx-auto mb-1 text-gray-400" />
                <div className="text-sm font-medium text-gray-700">Запасы ЛогЛаб</div>
                <div className="text-xs text-gray-400">Остатки по РЦ</div>
                {meta.lastLoglabUpload && <div className="text-xs text-green-600 mt-1">Загружен</div>}
                <input ref={loglabRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload("loglab", f); e.target.value = ""; }} />
              </div>
              {/* Dealers */}
              <div
                onClick={() => dealerRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${meta.lastDealerUpload ? "border-green-300 bg-green-50" : "border-gray-300 hover:border-[#0d9488]"}`}
              >
                <Upload className="h-5 w-5 mx-auto mb-1 text-gray-400" />
                <div className="text-sm font-medium text-gray-700">Остатки дилеров</div>
                <div className="text-xs text-gray-400">Склады дистрибьюторов</div>
                {meta.lastDealerUpload && <div className="text-xs text-green-600 mt-1">Загружен</div>}
                <input ref={dealerRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload("dealer", f); e.target.value = ""; }} />
              </div>
            </div>
            {error && <div className="mt-2 text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</div>}
          </div>

          {/* Search & Filters */}
          {items.length > 0 && (
            <div className="bg-white rounded-xl border border-gray-200 p-4">
              <div className="flex flex-wrap gap-2 items-center">
                <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2 flex-1 min-w-[200px]">
                  <Search className="h-4 w-4 text-gray-400" />
                  <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Поиск по КССС, названию, бренду..." className="bg-transparent text-sm outline-none flex-1" />
                  {searchQuery && <button onClick={() => setSearchQuery("")}><X className="h-4 w-4 text-gray-400" /></button>}
                </div>
                <button onClick={() => setShowFilters(!showFilters)} className={`flex items-center gap-1.5 text-sm px-3 py-2 rounded-lg border ${showFilters ? "bg-[#f0fdfa] border-[#0d9488] text-[#0d9488]" : "border-gray-200 text-gray-600"}`}>
                  <Filter className="h-4 w-4" /> Фильтры
                </button>
              </div>

              {showFilters && (
                <div className="mt-3 flex flex-wrap gap-3">
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">Категория</label>
                    <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className="text-sm border rounded px-2 py-1">
                      <option value="all">Все</option>
                      {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 block mb-1">Бренд</label>
                    <select value={filterBrand} onChange={(e) => setFilterBrand(e.target.value)} className="text-sm border rounded px-2 py-1">
                      <option value="all">Все</option>
                      {brands.map((b) => <option key={b} value={b}>{b}</option>)}
                    </select>
                  </div>
                  {(filterCategory !== "all" || filterBrand !== "all") && (
                    <button onClick={() => { setFilterCategory("all"); setFilterBrand("all"); }} className="text-xs text-gray-400 self-end">Сбросить</button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Table */}
          {filtered.length > 0 && (
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto" style={{ maxHeight: "600px" }}>
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">КССС</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Наименование</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Бренд/Линейка</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">ЛогЛаб, т</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">Дилеры, шт</th>
                      <th className="px-3 py-2 text-right text-xs font-medium text-gray-500">ИТОГО</th>
                      <th className="px-3 py-2 text-center text-xs font-medium text-gray-500"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((it) => (
                      <>
                        <tr key={it.ksss} className="border-b border-gray-50 hover:bg-gray-50 cursor-pointer" onClick={() => setExpandedItem(expandedItem === it.ksss ? null : it.ksss)}>
                          <td className="px-3 py-2 font-mono text-xs">{it.ksss}</td>
                          <td className="px-3 py-2 max-w-[300px] truncate">{it.name}</td>
                          <td className="px-3 py-2 text-xs text-gray-500">{it.brand} / {it.line}</td>
                          <td className={`px-3 py-2 text-right font-mono ${it.loglabTotal > 0 ? "text-amber-700" : "text-gray-300"}`}>{it.loglabTotal > 0 ? it.loglabTotal.toFixed(3) : "—"}</td>
                          <td className={`px-3 py-2 text-right font-mono ${it.dealerTotal > 0 ? "text-purple-700" : "text-gray-300"}`}>{it.dealerTotal > 0 ? it.dealerTotal.toFixed(0) : "—"}</td>
                          <td className={`px-3 py-2 text-right font-mono font-semibold ${it.grandTotal > 0 ? "text-green-700" : "text-gray-300"}`}>{it.grandTotal > 0 ? it.grandTotal.toFixed(3) : "—"}</td>
                          <td className="px-3 py-2 text-center">
                            {expandedItem === it.ksss ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />}
                          </td>
                        </tr>
                        {expandedItem === it.ksss && (
                          <tr>
                            <td colSpan={7} className="px-4 py-3 bg-gray-50 border-b border-gray-100">
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                                <div><span className="text-gray-400">Направление:</span> {it.direction}</div>
                                <div><span className="text-gray-400">Категория:</span> {it.category}</div>
                                <div><span className="text-gray-400">Подкатегория:</span> {it.subcategory}</div>
                                <div><span className="text-gray-400">Вид:</span> {it.type}</div>
                                <div><span className="text-gray-400">Вязкость SAE:</span> {it.viscosity}</div>
                                <div><span className="text-gray-400">API:</span> {it.api}</div>
                                <div><span className="text-gray-400">ACEA:</span> {it.acea}</div>
                                <div><span className="text-gray-400">ILSAC:</span> {it.ilsac}</div>
                                <div><span className="text-gray-400">Объем:</span> {it.volume}</div>
                                <div><span className="text-gray-400">Вес:</span> {it.weight} кг</div>
                                <div><span className="text-gray-400">РРЦ:</span> {it.rrc.toLocaleString("ru-RU")} ₽</div>
                                <div><span className="text-gray-400">Статус:</span> {it.status}</div>
                              </div>
                              {Object.keys(it.rcStocks).length > 0 && (
                                <div className="mt-2 pt-2 border-t border-gray-200">
                                  <div className="text-xs font-medium text-gray-500 mb-1">Остатки по РЦ (из Финал):</div>
                                  <div className="flex flex-wrap gap-2">
                                    {Object.entries(it.rcStocks).map(([rc, qty]) => (
                                      <span key={rc} className="text-xs px-2 py-0.5 rounded bg-blue-50 text-blue-700">{rc}: {qty.toFixed(3)} т</span>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="px-4 py-2 border-t border-gray-100 text-xs text-gray-400">
                Показано {filtered.length} из {items.length} позиций
              </div>
            </div>
          )}

          {items.length === 0 && !isLoading && (
            <div className="text-center py-16 text-gray-400">
              <Warehouse className="h-16 w-16 mx-auto mb-3 opacity-20" />
              <p className="text-lg font-medium">Нет данных</p>
              <p className="text-sm mt-1">Загрузите файлы выше: Финал + ЛогЛаб + Дилеры</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function StatCard({ label, value, icon }: { label: string; value: number | string; icon: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-3">
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-xs text-gray-500">{label}</span>
      </div>
      <div className="text-xl font-bold text-gray-800">{typeof value === "number" ? value.toLocaleString("ru-RU") : value}</div>
    </div>
  );
}
